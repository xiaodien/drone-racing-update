"""总页面（首页）：深空航空蓝渐变抬头 + 六张分色现代功能卡片。"""
import math

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontMetrics, QLinearGradient, QPainter, QPainterPath, QPen, QRadialGradient
from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QLabel, QSizePolicy, QVBoxLayout, QWidget

# (key, 标题, 说明, 图标, 主色起始, 主色结束, 浅底高亮色)
CARDS = [
    ("train",    "训练模式",         "采集图传画面，解锁自动录像，打杆数据同步回看",         "camera", "#3b82f6", "#1d4ed8", "#eff6ff"),
    ("race",     "比赛模式",         "多路画面，连计时器自动记圈、排名次、出成绩海报",       "flag",   "#fb7185", "#e11d48", "#fff1f2"),
    ("build",    "赛道搭建",         "3D 摆门、导入组委会图纸自动建门、铺设二层高架赛道",     "gate",   "#10b981", "#047857", "#ecfdf5"),
    ("track",    "黑羊导出 / 模拟飞行", "打开搭好的或组委会赛道，3D 模拟飞一遍，导出黑羊地图", "drone",  "#8b5cf6", "#6d28d9", "#f5f3ff"),
    ("guide",    "使用向导",         "第一次用看这里：设录像位置、采集卡、遥控器、学员",     "guide",  "#f59e0b", "#d97706", "#fffbeb"),
    ("settings", "系统设置",         "录像保存位置、录像时长、自动更新与硬件诊断报告",       "gear",   "#64748b", "#334155", "#f8fafc"),
]
COLS = 3


def _icon(p, kind, r, c0, c1):
    """卡片左上角图标：精致渐变圆角方块 + 白色线性图标"""
    g = QLinearGradient(r.topLeft(), r.bottomRight())
    g.setColorAt(0, QColor(c0))
    g.setColorAt(1, QColor(c1))
    p.setPen(Qt.NoPen)
    p.setBrush(g)
    p.drawRoundedRect(r, r.width() * 0.28, r.width() * 0.28)
    p.setPen(QPen(QColor("white"), r.width() * 0.06, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
    p.setBrush(Qt.NoBrush)
    c, s = r.center(), r.width()

    def P(x, y):
        return QPointF(c.x() + x * s, c.y() + y * s)

    if kind == "camera":
        p.drawRoundedRect(QRectF(P(-0.28, -0.15), P(0.1, 0.17)), s * 0.06, s * 0.06)
        p.drawPolygon([P(0.1, -0.02), P(0.28, -0.13), P(0.28, 0.15), P(0.1, 0.04)])
    elif kind == "flag":
        p.drawLine(P(-0.22, -0.27), P(-0.22, 0.28))
        path = QPainterPath(P(-0.22, -0.25))
        path.cubicTo(P(-0.05, -0.33), P(0.05, -0.15), P(0.25, -0.22))
        path.lineTo(P(0.25, 0.04))
        path.cubicTo(P(0.05, 0.11), P(-0.05, -0.07), P(-0.22, 0.01))
        p.drawPath(path)
    elif kind == "gate":
        p.drawRect(QRectF(P(-0.2, -0.24), P(0.2, 0.14)))
        p.drawLine(P(-0.2, 0.14), P(-0.2, 0.27))
        p.drawLine(P(0.2, 0.14), P(0.2, 0.27))
        p.drawLine(P(-0.3, 0.27), P(-0.1, 0.27))
        p.drawLine(P(0.1, 0.27), P(0.3, 0.27))
    elif kind == "drone":
        p.drawLine(P(-0.17, -0.17), P(0.17, 0.17))
        p.drawLine(P(-0.17, 0.17), P(0.17, -0.17))
        for x, y in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
            p.drawEllipse(P(0.2 * x, 0.2 * y), s * 0.1, s * 0.1)
        p.setBrush(QColor("white"))
        p.drawRoundedRect(QRectF(P(-0.06, -0.06), P(0.06, 0.06)), 2, 2)
    elif kind == "guide":
        path = QPainterPath(P(0, -0.2))
        path.cubicTo(P(-0.1, -0.27), P(-0.22, -0.26), P(-0.28, -0.22))
        path.lineTo(P(-0.28, 0.22))
        path.cubicTo(P(-0.2, 0.18), P(-0.08, 0.18), P(0, 0.25))
        path.cubicTo(P(0.08, 0.18), P(0.2, 0.18), P(0.28, 0.22))
        path.lineTo(P(0.28, -0.22))
        path.cubicTo(P(0.22, -0.26), P(0.1, -0.27), P(0, -0.2))
        path.lineTo(P(0, 0.25))
        p.drawPath(path)
    elif kind == "gear":
        p.drawEllipse(P(0, 0), s * 0.09, s * 0.09)
        for k in range(8):
            a = k * math.pi / 4
            p.drawLine(P(0.17 * math.cos(a), 0.17 * math.sin(a)), P(0.27 * math.cos(a), 0.27 * math.sin(a)))
        p.drawEllipse(P(0, 0), s * 0.18, s * 0.18)


class Card(QWidget):
    clicked = Signal()

    def __init__(self, title, sub, icon, c0, c1, tint):
        super().__init__()
        self.title, self.sub, self.icon = title, sub, icon
        self.c0, self.c1, self.tint = c0, c1, tint
        self.hover = False
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumSize(250, 175)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMouseTracking(True)

    def enterEvent(self, e):
        self.hover = True
        self.update()

    def leaveEvent(self, e):
        self.hover = False
        self.update()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self.rect().contains(e.position().toPoint()):
            self.clicked.emit()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(8, 8, -8, -8)
        if self.hover:
            r.translate(0, -3)
        # 多层柔和阴影
        for k in range(1, 7):
            p.setPen(Qt.NoPen)
            alpha = 11 - k if self.hover else 7 - k
            if alpha > 0:
                p.setBrush(QColor(15, 23, 42, alpha))
                p.drawRoundedRect(r.adjusted(-k * 0.7, -k * 0.3 + 4, k * 0.7, k * 0.8 + 4), 18 + k * 0.5, 18 + k * 0.5)
        # 卡片底面
        p.setBrush(QColor("white"))
        p.setPen(QPen(QColor(self.c0) if self.hover else QColor("#e2e8f0"), 1.8 if self.hover else 1.0))
        p.drawRoundedRect(r, 18, 18)
        # 顶部精致色条（悬停时显出）
        if self.hover:
            p.save()
            clip = QPainterPath()
            clip.addRoundedRect(r, 18, 18)
            p.setClipPath(clip)
            bar_g = QLinearGradient(r.left(), r.top(), r.right(), r.top())
            bar_g.setColorAt(0, QColor(self.c0))
            bar_g.setColorAt(1, QColor(self.c1))
            p.setPen(Qt.NoPen)
            p.setBrush(bar_g)
            p.drawRect(QRectF(r.left(), r.top(), r.width(), 4))
            p.restore()

        ic = min(56.0, r.height() * 0.36)
        _icon(p, self.icon, QRectF(r.left() + 22, r.top() + 22, ic, ic), self.c0, self.c1)

        f = QFont()
        f.setBold(True)
        tx = r.left() + 22 + ic + 16
        tw = r.right() - tx - 16
        title = self.title
        px = 21
        while True:
            f.setPixelSize(px)
            if max(QFontMetrics(f).horizontalAdvance(t) for t in title.split("\n")) <= tw or px <= 15:
                break
            if px <= 18 and " / " in title and "\n" not in title:
                title, px = title.replace(" / ", " /\n"), 20
                continue
            px -= 1
        p.setFont(f)
        p.setPen(QColor("#0f172a"))
        p.drawText(QRectF(tx, r.top() + 20, tw, ic + 4), Qt.AlignVCenter | Qt.AlignLeft, title)

        f.setBold(False)
        f.setPixelSize(13.5)
        p.setFont(f)
        p.setPen(QColor("#64748b"))
        p.drawText(QRectF(r.left() + 22, r.top() + 22 + ic + 12, r.width() - 44, r.bottom() - (r.top() + 22 + ic + 12) - 42),
                   Qt.AlignLeft | Qt.AlignTop | Qt.TextWordWrap, self.sub)

        # 右下角精致「进入 →」胶囊
        f.setPixelSize(13)
        f.setBold(True)
        p.setFont(f)
        pill = QRectF(r.left() + 22, r.bottom() - 38, 82, 26)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(self.c0) if self.hover else QColor(self.tint))
        p.drawRoundedRect(pill, 13, 13)
        p.setPen(QColor("white") if self.hover else QColor(self.c1))
        p.drawText(pill, Qt.AlignCenter, "进入  →")


class HomePage(QWidget):
    """首页。open_card(key) 由主窗口接上"""
    chosen = Signal(str)

    def __init__(self, name, version, clock=None):
        super().__init__()
        self.name, self.version = name, version
        self.cards = {}
        lay = QVBoxLayout(self)
        lay.setContentsMargins(48, 0, 48, 24)
        lay.setSpacing(0)
        head = QWidget()
        head.setFixedHeight(215)
        hl = QHBoxLayout(head)
        hl.setContentsMargins(0, 0, 0, 0)
        hl.addStretch()
        if clock is not None:
            col = QVBoxLayout()
            col.addSpacing(46)
            clock.setStyleSheet("QPushButton { background: rgba(255,255,255,0.14); color: white;"
                                " border: 1px solid rgba(255,255,255,0.28); border-radius: 12px;"
                                " padding: 8px 16px; font-weight: 600; }"
                                "QPushButton:hover { background: rgba(255,255,255,0.24); }")
            col.addWidget(clock)
            col.addStretch()
            hl.addLayout(col)
        lay.addWidget(head)
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(14)
        for k, (key, title, sub, ic, c0, c1, tint) in enumerate(CARDS):
            c = Card(title, sub, ic, c0, c1, tint)
            c.setFixedHeight(204)
            c.clicked.connect(lambda kk=key: self.chosen.emit(kk))
            grid.addWidget(c, k // COLS, k % COLS)
            self.cards[key] = c
        lay.addStretch(1)
        lay.addLayout(grid)
        lay.addStretch(2)
        foot = QLabel("点击任意模块进入 · 工作界面随时点左上角「⌂ 首页」返回")
        foot.setAlignment(Qt.AlignCenter)
        foot.setStyleSheet("color: #64748b; padding-top: 10px; font-size: 12.5px;")
        lay.addWidget(foot)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor("#eef2f7"))

        # 深空科技蓝弧形英雄区
        h = 235
        g = QLinearGradient(0, 0, self.width(), h)
        g.setColorAt(0.0, QColor("#0b162c"))
        g.setColorAt(0.55, QColor("#15356b"))
        g.setColorAt(1.0, QColor("#2563eb"))
        path = QPainterPath()
        path.moveTo(0, 0)
        path.lineTo(self.width(), 0)
        path.lineTo(self.width(), h - 34)
        path.cubicTo(self.width() * 0.68, h + 14, self.width() * 0.32, h - 52, 0, h - 12)
        path.closeSubpath()
        p.fillPath(path, g)

        # 英雄区内微光网格与 FPV 飞行轨迹曲线
        p.save()
        p.setClipPath(path)
        rad = QRadialGradient(self.width() * 0.78, h * 0.25, self.width() * 0.36)
        rad.setColorAt(0, QColor(56, 189, 248, 52))
        rad.setColorAt(1, QColor(56, 189, 248, 0))
        p.fillRect(0, 0, self.width(), h + 20, rad)

        p.setPen(QPen(QColor(255, 255, 255, 14), 1))
        for gx in range(0, self.width(), 44):
            p.drawLine(gx, 0, gx, h + 20)
        for gy in range(0, h + 20, 44):
            p.drawLine(0, gy, self.width(), gy)

        for k, alpha in ((0, 55), (1, 32), (2, 18)):
            p.setPen(QPen(QColor(125, 211, 252, alpha), 2.2 - k * 0.4))
            q = QPainterPath()
            q.moveTo(self.width() * 0.42, 46 + k * 34)
            for x in range(60):
                t = x / 59
                q.lineTo(self.width() * (0.42 + 0.58 * t), 46 + k * 34 + 26 * math.sin(t * math.pi * 2.1 + k * 0.9))
            p.drawPath(q)
        p.restore()

        # 标题、副标题与版本胶囊
        f = QFont()
        f.setBold(True)
        f.setPixelSize(36)
        p.setFont(f)
        p.setPen(QColor("#ffffff"))
        p.drawText(QRectF(52, 42, self.width() - 104, 54), Qt.AlignLeft | Qt.AlignVCenter, self.name)

        f.setBold(False)
        f.setPixelSize(15.5)
        p.setFont(f)
        p.setPen(QColor(203, 213, 225))
        p.drawText(QRectF(54, 100, self.width() - 104, 28), Qt.AlignLeft | Qt.AlignVCenter,
                   "FPV 穿越机教学平台 · 打杆分析 · C5 竞速计时 · 3D 双层赛道搭建")

        f.setPixelSize(12.5)
        f.setBold(True)
        p.setFont(f)
        vw = p.fontMetrics().horizontalAdvance(self.version) + 26
        br = QRectF(54, 142, vw, 26)
        p.setPen(QPen(QColor(255, 255, 255, 70), 1))
        p.setBrush(QColor(255, 255, 255, 30))
        p.drawRoundedRect(br, 13, 13)
        p.setPen(QColor("#e0f2fe"))
        p.drawText(br, Qt.AlignCenter, self.version)
