"""训练电池记录：不录像也记下每一次解锁到锁桨，自动数用了几块电池、判断有没有炸机，按学员按天存。

怎么数电池：锁桨后隔了一阵（默认 60 秒）才再解锁，就算换了一块电池；很快又解锁（翻过来接着飞、落地调整）
算同一块。上一次像是炸机、这块电池又没飞多久时，多等一会儿才算换电池（去捡飞机也要时间）。
设了飞机电压通道（方案 B，见 VOLT_GUIDE）时，改看电压：解锁时电压比锁桨后高一截就是换了电池。
怎么判断炸机：只看打杆。锁桨时油门还推着、高油门突然收油就锁、锁桨前在猛打杆、起飞没多久就停、
锁了马上又解锁，这些加分；飞完一整块电池正常降落、落地后停了一会儿才锁，减分。
2 分以上算炸机。老师可以在「电池记录」里改，改过的以老师为准。

数据放在录像文件夹的 .训练记录/<学员>/<日期>.json（点开头，学员列表不会把它当成学员）。
多人同时飞：TrainingLog 按学员分开记，每个学员有自己的 PilotTracker。以后每个学员一个接收机时，
对每个学员各调一次 feed(学员, 时间, 解锁, 有信号, 取打杆) 就行，统计和窗口都不用改。
"""
import json
import os
import time
from datetime import datetime
from pathlib import Path

FOLDER = ".训练记录"
BATTERY_GAP_S = 60.0        # 锁桨超过这么久再解锁：换了一块电池
RETRIEVE_GAP_S = 150.0      # 上一次像炸机、这块电池还没飞够：可能是去捡飞机，放宽到这么久
BATTERY_MIN_FLY_S = 150.0   # 这块电池累计飞不到这么久，算「还没飞够」
FULL_BATTERY_S = 120.0      # 一块电池飞够这么久才换，最后一次锁桨多半是正常降落
ARM_TEST_THR = 0.12         # 整次解锁油门都没推过这么多（0~1）：解锁测试，不记
QUICK_REARM_S = 45.0        # 锁桨后这么快又解锁：像是炸机翻过来重飞
SHORT_FLIGHT_S = 15.0
LINK_STALE_S = 1.0          # 这么久没收到遥控器数据：算信号断了
CRASH_SCORE = 2
BREAK_S = 30 * 60           # 停了这么久算下课/休息，这段不算训练时间
# 方案 B：遥控器把飞机回传的电压混到一个空通道（见 VOLT_GUIDE）。不用调比例：
# 软件自己记下这个通道见过的最高、最低读数（一块电池从满飞到没电就学会了），按这个范围判断。
VOLT_SETTLE_S = 8.0         # 锁桨后等电压回升稳定再记「休息电压」
VOLT_JUMP = 0.25            # 解锁时比休息电压高出「学到的范围」的这么多：换了一块电池
VOLT_MIN_RANGE = 0.006      # 范围还没学到这么大：先不按电压判断
VOLT_VALID = 0.97           # 读数顶到 ±1 当成没有回传


VOLT_GUIDE = """用飞机电压判断换电池（每台遥控器弄一次，软件帮你设）

1. 遥控器用 USB 线插电脑，遥控器上弹出选项时选「USB 存储」（U 盘模式）。
   软件会自动把小程序 BatToCH 拷进遥控器，下面状态栏会提示「已拷好」。拔掉 USB。
2. 插上飞机电池，等遥控器收到回传（能看到飞机电压）。
3. 遥控器按 SYS（系统）→「工具」→ 选 BatToCH 运行。它会自己找飞机电压、找一个空通道（一般 CH8）、
   加好混控、调好比例，屏幕上显示 Done 就好了，按返回退出。每个模型运行一次。
4. 屏幕上会提醒：Betaflight「模式」页里对应的 AUX（CH8 就是 AUX4）不能用在任何开关上；
   用电脑上的 ELRS 接收机的话，遥控器 ELRS 设置里「开关模式」选 Wide。USB 线、无线教练口不用管这条。

之后照常上课：软件飞一次就自己找到电压通道，飞完一块电池就学会满电和没电是多少，然后按电压判断换电池。
没设的遥控器照旧按锁桨间隔猜。
"""

TOOL_NAME = "BatToCH.lua"


def tool_script() -> Path:
    return Path(__file__).with_name("遥控器脚本") / TOOL_NAME


def radio_sd_cards() -> list:
    """遥控器开了 USB 存储（U 盘模式）时的盘：根目录有 RADIO、MODELS、SCRIPTS"""
    out = []
    if os.name != "nt":
        return out
    try:
        import ctypes
        k32 = ctypes.windll.kernel32
        k32.SetThreadErrorMode(1, None)         # 读卡器里没卡时不要弹「请插入磁盘」
        mask = k32.GetLogicalDrives()
    except (AttributeError, OSError):
        mask = -1
    for n, letter in enumerate("ABCDEFGHIJKLMNOPQRSTUVWXYZ"):
        if n < 3 or not mask >> n & 1:
            continue
        root = Path(f"{letter}:/")
        try:
            if (root / "SCRIPTS").is_dir() and ((root / "RADIO").is_dir() or (root / "MODELS").is_dir()):
                out.append(root)
        except OSError:
            continue
    return out


def install_tool() -> list:
    """把 BatToCH 拷到每个插着的遥控器 SD 卡（已经有一样的就不拷）；返回新拷进去的盘"""
    src = tool_script()
    try:
        data = src.read_bytes()
    except OSError:
        return []
    done = []
    for root in radio_sd_cards():
        dst = root / "SCRIPTS" / "TOOLS" / TOOL_NAME
        try:
            if dst.is_file() and dst.read_bytes() == data:
                continue
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(data)
            done.append(root)
        except OSError:
            continue
    return done



class VoltFinder:
    """连上遥控器后自己找哪个通道是飞机电压：读数是连续值（不是开关的 -1/0/1）、
    解锁飞的时候往下掉（电池带载压降）。飞一次就能找到；遥控器没设就一直找不到，照旧按锁桨间隔猜。"""
    FIRST, LAST = 5, 16         # CH6..CH16（CH1-4 是摇杆，CH5 是解锁）
    DROP = 0.006                # 不知道遥控器的比例，掉一点点就算

    def __init__(self):
        self.hist: dict[int, list] = {}
        self.arm_val, self.min_val = {}, {}
        self.was_armed = False

    @staticmethod
    def _analog(v):
        return abs(v) <= VOLT_VALID and min(abs(v - k) for k in (-1.0, 0.0, 1.0)) > 0.02

    def feed(self, axes, armed: bool):
        """返回找到的通道序号（从 0 数，CH8 = 7），还没找到返回 None"""
        idx = range(self.FIRST, min(len(axes), self.LAST))
        for i in idx:
            h = self.hist.setdefault(i, [])
            h.append(axes[i])
            del h[:-150]
        found = None
        if armed and not self.was_armed:
            self.arm_val = {i: axes[i] for i in idx}
            self.min_val = dict(self.arm_val)
        elif armed:
            for i in self.min_val:
                if i < len(axes):
                    self.min_val[i] = min(self.min_val[i], axes[i])
        elif self.was_armed:
            for i, a in sorted(self.arm_val.items()):
                h = self.hist.get(i, [])
                if h and sum(map(self._analog, h)) / len(h) > 0.8 and self._analog(a) \
                        and a - self.min_val.get(i, a) >= self.DROP:
                    found = i
                    break
        self.was_armed = armed
        return found


# ---- 存取 ------------------------------------------------------------------
def pilot_dir(root, pilot) -> Path:
    return Path(root) / FOLDER / (pilot or "未选学员")


def day_file(root, pilot, day: str) -> Path:
    return pilot_dir(root, pilot) / f"{day}.json"


def load_day(root, pilot, day: str) -> list:
    try:
        d = json.loads(day_file(root, pilot, day).read_text(encoding="utf-8"))
        return [f for f in d.get("flights", []) if isinstance(f, dict) and "start" in f and "end" in f]
    except (OSError, ValueError, AttributeError):
        return []


def save_day(root, pilot, day: str, flights: list):
    path = day_file(root, pilot, day)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps({"pilot": pilot, "day": day, "flights": flights}, ensure_ascii=False, indent=1),
                   encoding="utf-8")
    os.replace(tmp, path)


def days_of(root, pilot) -> list:
    """这个学员有记录的日期，新的在前"""
    d = pilot_dir(root, pilot)
    if not d.is_dir():
        return []
    return sorted((p.stem for p in d.glob("????-??-??.json")), reverse=True)


def pilots_of(root) -> list:
    d = Path(root) / FOLDER
    if not d.is_dir():
        return []
    return sorted(p.name for p in d.iterdir() if p.is_dir() and not p.name.startswith("."))


def day_of(ts: float) -> str:
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d")


# ---- 一次飞行的打杆特征（锁桨时算一次，存起来） ---------------------------------
def thr01(v) -> float:
    return (v["thr"] + 1) / 2


def features(samples: list, start: float, end: float, link_lost: bool) -> dict:
    """samples: [(时间, {thr,yaw,pitch,roll,armed}), ...]，时间和 start/end 一样是 time.time()"""
    s = [(t, v) for t, v in samples if start - 0.05 <= t <= end + 0.05 and v]
    f = {"start": round(start, 2), "end": round(end, 2), "link_lost": bool(link_lost)}
    if not s:
        f.update(thr_max=0.0, thr_avg=0.0, thr_end=0.0, low_before=0.0, peak_before_cut=0.0, stick_peak=0.0,
                 no_sticks=True)
        return f
    thr = [thr01(v) for _, v in s]
    f["thr_max"] = round(max(thr), 3)
    f["thr_avg"] = round(sum(thr) / len(thr), 3)
    tail = [x for (t, _), x in zip(s, thr) if t >= end - 0.4] or thr[-1:]
    f["thr_end"] = round(sum(tail) / len(tail), 3)
    # 锁桨前油门在底下待了多久
    low_from = end
    for (t, _), x in zip(reversed(s), reversed(thr)):
        if x >= 0.12:
            break
        low_from = t
    f["low_before"] = round(end - low_from, 2)
    # 收油之前 1.5 秒里油门最高推到多少（高油门突然收油锁桨 = 撞了）
    win = [x for (t, _), x in zip(s, thr) if low_from - 1.5 <= t <= low_from]
    f["peak_before_cut"] = round(max(win), 3) if win else 0.0
    # 锁桨前 2.5 秒最大的横滚/俯仰杆量
    near = [max(abs(v["roll"]), abs(v["pitch"])) for t, v in s if t >= end - 2.5]
    f["stick_peak"] = round(max(near), 3) if near else 0.0
    return f


def is_arm_test(f: dict) -> bool:
    return not f.get("no_sticks") and f.get("thr_max", 0) < ARM_TEST_THR


# ---- 整天重新算：电池编号、炸机分数（老师改过的以老师为准） -----------------------
def _base_score(f: dict):
    """不靠电池分组就能算的部分"""
    score, why = 0, []
    if f.get("link_lost"):          # 电脑听不到遥控器了（遥控器关机或走远），不知道飞机怎么样，不加分
        why.append("电脑收不到遥控器信号，按锁桨算")
    if f.get("link_lost"):
        pass                        # 信号断时最后那点打杆不算数
    elif f.get("thr_end", 0) > 0.25:
        score += 2
        why.append("锁桨时油门还推着")
    elif f.get("low_before", 9) < 1.5 and f.get("peak_before_cut", 0) > 0.55:
        score += 1
        why.append("高油门突然收油就锁桨")
    if f.get("stick_peak", 0) > 0.85 and not f.get("link_lost"):
        score += 1
        why.append("锁桨前在猛打杆")
    dur = f["end"] - f["start"]
    if dur < SHORT_FLIGHT_S and f.get("thr_max", 0) > 0.3:
        score += 1
        why.append(f"起飞 {dur:.0f} 秒就停了")
    if f.get("low_before", 0) >= 3:
        score -= 1
        why.append("落地停稳才锁（像正常降落）")
    return score, why


def recompute(flights: list, gap_s: float = BATTERY_GAP_S) -> list:
    """按时间排好，给每次飞行填 battery（当天第几块）、gap_before、score、reasons、auto_crash、is_crash。"""
    flights.sort(key=lambda f: f["start"])
    battery, bat_fly, prev = 0, 0.0, None
    prelim = []
    for f in flights:
        base, why = _base_score(f)
        prelim.append((base, why))
        gap = f["start"] - prev["end"] if prev else None
        f["gap_before"] = round(gap, 1) if gap is not None else None
        if prev is None:
            new = True
        elif f.get("new_battery") is not None:          # 老师改过
            new = bool(f["new_battery"])
        elif f.get("volt_new") is not None:             # 飞机电压看得出来
            new = bool(f["volt_new"])
        else:
            prev_crash = prev.get("crash") if prev.get("crash") is not None else prev.get("_pre", 0) >= CRASH_SCORE
            need = RETRIEVE_GAP_S if prev_crash and bat_fly < BATTERY_MIN_FLY_S else gap_s
            new = gap >= need
        if new:
            battery += 1
            bat_fly = 0.0
        f["battery"] = battery
        bat_fly += f["end"] - f["start"]
        f["_pre"] = base
        prev = f
    # 第二遍：要看下一次飞行 / 这块电池总共飞了多久的部分
    fly_of = {}
    for f in flights:
        fly_of[f["battery"]] = fly_of.get(f["battery"], 0.0) + f["end"] - f["start"]
    for i, f in enumerate(flights):
        score, why = prelim[i]
        why = list(why)
        nxt = flights[i + 1] if i + 1 < len(flights) else None
        if nxt and nxt["battery"] == f["battery"] and nxt["start"] - f["end"] < QUICK_REARM_S:
            score += 1
            why.append(f"锁桨 {nxt['start'] - f['end']:.0f} 秒就重新解锁")
        last_of_battery = nxt is None or nxt["battery"] != f["battery"]
        if last_of_battery and nxt is not None and fly_of[f["battery"]] >= FULL_BATTERY_S:
            score -= 1
            why.append("这块电池飞完了才换（像正常降落）")
        f["score"] = score
        f["reasons"] = why
        f["auto_crash"] = score >= CRASH_SCORE
        f["is_crash"] = f["crash"] if f.get("crash") is not None else f["auto_crash"]
        f.pop("_pre", None)
    return flights


# ---- 统计 ------------------------------------------------------------------
def summary(flights: list) -> dict:
    """一天（或一节课）的数字"""
    out = dict(flights=len(flights), batteries=0, fly_s=0.0, span_s=0.0, per_hour=None, avg_battery_s=None,
               avg_swap_s=None, crashes=0, crash_per_battery=None, crash_per_10min=None, first=None, last=None)
    if not flights:
        return out
    fl = sorted(flights, key=lambda f: f["start"])
    bats = sorted({f["battery"] for f in fl})
    out["batteries"] = len(bats)
    out["fly_s"] = sum(f["end"] - f["start"] for f in fl)
    out["first"], out["last"] = fl[0]["start"], fl[-1]["end"]
    # 训练时间：第一次解锁到最后一次锁桨，中间停了半小时以上（午休、下课）的那段不算
    span = 0.0
    seg_start = fl[0]["start"]
    for a, b in zip(fl, fl[1:]):
        if b["start"] - a["end"] >= BREAK_S:
            span += a["end"] - seg_start
            seg_start = b["start"]
    out["span_s"] = span + fl[-1]["end"] - seg_start
    out["crashes"] = sum(1 for f in fl if f.get("is_crash"))
    out["avg_battery_s"] = out["fly_s"] / len(bats)
    swaps = [f["gap_before"] for f in fl if f.get("gap_before") is not None
             and f["battery"] != 1 and f is next(g for g in fl if g["battery"] == f["battery"])]
    out["avg_swap_s"] = sum(swaps) / len(swaps) if swaps else None
    # 每小时几块：从第一次解锁到最后一次锁桨，再加一个平均换电时间（最后一块飞完也要换）
    span = out["span_s"] + (out["avg_swap_s"] or 0)
    if span >= 15 * 60:
        out["per_hour"] = len(bats) / (span / 3600)
    out["crash_per_battery"] = out["crashes"] / len(bats)
    if out["fly_s"] > 0:
        out["crash_per_10min"] = out["crashes"] / (out["fly_s"] / 600)
    return out


# ---- 训练目标 ------------------------------------------------------------------
# {"hours": 1, "batteries": 15}：一节课（几小时）飞几块；hours 为 0 是「一天几块」
GOAL_PRESETS = [None, {"hours": 1, "batteries": 15}, {"hours": 2, "batteries": 30},
                {"hours": 0, "batteries": 60}, {"hours": 0, "batteries": 80}]


def goal_name(g) -> str:
    if not g or not g.get("batteries"):
        return "不设目标"
    h = g.get("hours") or 0
    return f"一天 {g['batteries']} 块" if not h else f"{h:g} 小时 {g['batteries']} 块"


DAY_HOURS = 4.0             # 「一天几块」按一天练 4 小时算速度（自定义时可以改）
WARN_PCT = 80               # 速度不到目标的这么多：效率不够，弹窗提醒
WARN_AFTER_S = 15 * 60      # 练满 15 分钟才开始算速度、才提醒


def goal_rate(g):
    """目标速度：每小时几块"""
    if not g or not g.get("batteries"):
        return None
    hours = g.get("hours") or g.get("day_hours") or DAY_HOURS
    return g["batteries"] / hours


def grade(score):
    return "优秀" if score >= 100 else "良好" if score >= 85 else "及格" if score >= WARN_PCT else "效率不够"


def evaluate(g, s: dict):
    """按目标打分。返回 dict：rate（现在每小时几块）、target（目标每小时几块）、pct（完成率）、
    score（得分 0~100）、grade（优秀/良好/及格/效率不够）、low（要不要提醒）；没设目标返回 None"""
    target = goal_rate(g)
    if not target:
        return None
    rate = s.get("per_hour")
    out = dict(rate=rate, target=target, pct=None, score=None, grade="练满 15 分钟才打分", low=False,
               done=s["batteries"], total=g["batteries"])
    if rate is not None:
        pct = rate / target * 100
        out.update(pct=pct, score=int(round(min(100.0, pct))), grade=grade(pct), low=pct < WARN_PCT)
    return out


def last_session(flights: list) -> list:
    """最近这一节课：最后一次停了半小时以上之后的飞行"""
    fl = sorted(flights, key=lambda f: f["start"])
    for i in range(len(fl) - 1, 0, -1):
        if fl[i]["start"] - fl[i - 1]["end"] >= BREAK_S:
            return fl[i:]
    return fl


def class_report(log, pilots, day, goal, this_class=False):
    """全班评分：[(学员, summary, evaluate)]，得分高的在前；没飞的学员不列"""
    rows = []
    for p in pilots:
        fl = log.flights(p, day)
        if this_class:
            fl = last_session(fl)
            if fl and fl[-1]["end"] < time.time() - 3 * 3600:
                fl = []                 # 这节课没飞（最近一次是好几个小时以前）
        s = summary(fl)
        if s["flights"]:
            rows.append((p, s, evaluate(goal, s)))
    rows.sort(key=lambda r: (-(r[2]["pct"] or 0) if r[2] and r[2]["pct"] is not None else 1, -r[1]["batteries"]))
    return rows


def fmt_s(s) -> str:
    if s is None:
        return "—"
    s = int(round(s))
    return f"{s // 3600}:{s // 60 % 60:02d}:{s % 60:02d}" if s >= 3600 else f"{s // 60}:{s % 60:02d}"


# ---- 实时记录 ----------------------------------------------------------------
class PilotTracker:
    """一个学员（一个遥控器）的解锁/锁桨状态。feed() 每 0.2 秒左右调一次。"""

    def __init__(self, log: "TrainingLog", pilot: str):
        self.log, self.pilot = log, pilot
        self.armed_at = None        # 正在飞：解锁的时间
        self.last_ok = None         # 最后一次有信号的时间
        self.sampler = None
        self.disarmed_at = None     # 上次锁桨的时间
        self.volt_rest = None       # 锁桨稳定后的电压读数（休息电压）
        self.volt_arm = None        # 解锁那一刻的读数
        self.volt_new = None        # 这次解锁按电压看是不是新电池（没设电压通道就是 None）
        self.volt_jump = None
        self.volt_last = None
        self.volt_hi = None         # 见过的最高、最低读数：学出这个通道的比例
        self.volt_lo = None
        self.volt_fly_s = 0.0       # 有电压读数以来飞了多久：飞够一块电池才信学到的范围

    def feed(self, now: float, armed: bool, link_ok: bool, sampler=None, volt=None):
        if sampler:
            self.sampler = sampler
        if volt is not None and (not link_ok or abs(volt) > VOLT_VALID):
            volt = None
        if volt is not None:
            self.volt_last = volt
            if not armed and self.armed_at is None:      # 只看锁桨时的读数（飞的时候带载压降不算）
                self.volt_hi = volt if self.volt_hi is None else max(self.volt_hi, volt)
                self.volt_lo = volt if self.volt_lo is None else min(self.volt_lo, volt)
            # 休息电压：锁桨后等几秒记一次就定住（换电池时新电池的电压会先上来，不能跟着变）；
            # 当天第一次解锁之前一直跟着读数走
            if not armed and self.armed_at is None:
                if self.disarmed_at is None:
                    self.volt_rest = volt
                elif self.volt_rest is None and now - self.disarmed_at >= VOLT_SETTLE_S:
                    self.volt_rest = volt
        if self.armed_at is not None:
            if not link_ok:
                self._end(self.last_ok or now, link_lost=True)
            elif not armed:
                self._end(now, link_lost=False)
        elif armed and link_ok:
            self.armed_at = now
            self.volt_arm, self.volt_new, self.volt_jump = volt, None, None
            if volt is not None:
                if self.disarmed_at is not None and now - self.disarmed_at < VOLT_SETTLE_S:
                    self.volt_new = False                   # 几秒就重新解锁，不可能换了电池
                elif self.volt_rest is not None and self.volt_range() >= VOLT_MIN_RANGE:
                    self.volt_jump = (volt - self.volt_rest) / self.volt_range()     # 按学到的范围算，0~1
                    # 跳得多：肯定换了；跳了一半、又隔了挺久：换了一块没怎么飞的电池
                    gap = now - self.disarmed_at if self.disarmed_at is not None else 1e9
                    self.volt_new = self.volt_jump >= VOLT_JUMP or (self.volt_jump >= VOLT_JUMP / 2
                                                                    and gap >= self.log.gap_s)
        if link_ok:
            self.last_ok = now

    def idle(self, now: float | None = None):
        """换学员、关软件、切到比赛模式：正在飞的这次就到这里为止"""
        if self.armed_at is not None:
            self._end(now or time.time(), link_lost=False)

    def volt_range(self):
        if self.volt_hi is None or self.volt_fly_s < FULL_BATTERY_S:
            return 0.0
        return self.volt_hi - self.volt_lo

    def volt_pct(self, v):
        """读数 -> 大约还剩百分之几（按学到的范围）"""
        r = self.volt_range()
        return None if v is None or r < VOLT_MIN_RANGE else max(0, min(100, round((v - self.volt_lo) / r * 100)))

    def _end(self, end: float, link_lost: bool):
        start, self.armed_at = self.armed_at, None
        self.disarmed_at = end
        self.volt_rest = None
        if end - start < 0.5:
            return
        try:
            samples = self.sampler(start, end) if self.sampler else []
        except Exception:  # noqa: BLE001  取打杆出错也要把这次记下来
            samples = []
        f = features(samples, start, end, link_lost)
        if self.volt_arm is not None:
            self.volt_fly_s += end - start
            f["volt_start"] = round(self.volt_arm, 4)
            if self.volt_last is not None:
                f["volt_end"] = round(self.volt_last, 4)
                if self.volt_pct(self.volt_last) is not None:
                    f["volt_pct_end"] = self.volt_pct(self.volt_last)
            if self.volt_new is not None:
                f["volt_new"] = bool(self.volt_new)
            if self.volt_jump is not None:
                f["volt_jump"] = round(self.volt_jump, 3)
        if is_arm_test(f):
            return
        self.log.add_flight(self.pilot, f)

    def flying_s(self, now: float) -> float:
        return now - self.armed_at if self.armed_at is not None else 0.0


class TrainingLog:
    """所有学员的训练记录。root: 返回录像文件夹的函数（文件夹可能中途改）。"""

    def __init__(self, root_fn, gap_s: float = BATTERY_GAP_S):
        self.root_fn = root_fn
        self.gap_s = gap_s
        self.trackers: dict[str, PilotTracker] = {}
        self._cache: dict[tuple, list] = {}
        self.on_change = None        # 有新飞行时调用 on_change(学员)

    def tracker(self, pilot: str) -> PilotTracker:
        if pilot not in self.trackers:
            self.trackers[pilot] = PilotTracker(self, pilot)
        return self.trackers[pilot]

    def feed(self, pilot: str, now: float, armed: bool, link_ok: bool, sampler=None, volt=None):
        """volt：飞机电压通道的读数（-1..1），没设电压通道就是 None"""
        self.tracker(pilot).feed(now, armed, link_ok, sampler, volt)

    def idle(self, pilot: str | None = None):
        for p, t in list(self.trackers.items()):
            if pilot is None or p == pilot:
                t.idle()

    def flights(self, pilot: str, day: str) -> list:
        key = (str(self.root_fn()), pilot, day)
        if key not in self._cache:
            self._cache[key] = recompute(load_day(self.root_fn(), pilot, day), self.gap_s)
        return self._cache[key]

    def _store(self, pilot, day, flights):
        recompute(flights, self.gap_s)
        save_day(self.root_fn(), pilot, day, [{k: v for k, v in f.items()} for f in flights])
        self._cache[(str(self.root_fn()), pilot, day)] = flights

    def add_flight(self, pilot: str, f: dict):
        day = day_of(f["start"])
        fl = self.flights(pilot, day)
        fl.append(f)
        try:
            self._store(pilot, day, fl)
        except OSError:
            pass
        if self.on_change:
            self.on_change(pilot)

    def edit(self, pilot: str, day: str, start: float, **changes):
        """老师改：crash=True/False/None（None = 交给软件判断），new_battery=True/False/None，delete=True"""
        fl = self.flights(pilot, day)
        for f in fl:
            if abs(f["start"] - start) < 0.01:
                if changes.get("delete"):
                    fl.remove(f)
                else:
                    f.update(changes)
                break
        self._store(pilot, day, fl)

    def set_gap(self, gap_s: float):
        self.gap_s = gap_s
        self._cache.clear()

    def status(self, pilot: str, now: float | None = None) -> dict:
        """训练画面下面那一行：第几块电池、这块飞了多久、今天几块、炸机几次"""
        now = now or time.time()
        t = self.trackers.get(pilot)
        fl = self.flights(pilot, day_of(now))
        flying = t.flying_s(now) if t else 0.0
        cur, cur_fly = 0, 0.0
        if fl:
            cur = fl[-1]["battery"]
            if flying and t.armed_at - fl[-1]["end"] >= self.gap_s:
                cur += 1                                 # 正在飞的这次已经是新电池
            else:
                cur_fly = sum(f["end"] - f["start"] for f in fl if f["battery"] == cur)
        elif flying:
            cur = 1
        s = summary(fl)
        return dict(battery=cur, battery_fly_s=cur_fly + flying, flying=bool(flying),
                    batteries=max(s["batteries"], cur), crashes=s["crashes"], fly_s=s["fly_s"] + flying)
