"""比赛模式：连接圈速计时器（ESP32 + RX5808），自动计圈、排名、保存成绩。

计时器原理：每个 RX5808 听一个选手的图传频道，飞机穿过计时门时信号最强，计时器记下那一刻（过门）。
起飞后第一次过门开始计时，以后每过一次门算一圈。
通信：每行一个 JSON，WiFi（TCP 5808）或 USB 串口都一样。
"""
import json
import math
import random
import sys
import threading
import time
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QObject, QPointF, QSize, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QFont, QIcon, QImage, QPainter, QPen, QPixmap, QPolygonF
from PySide6.QtNetwork import QHostAddress, QTcpSocket, QUdpSocket
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox,
                               QScrollArea, QSizePolicy, QToolButton,
                               QDoubleSpinBox, QFileDialog, QFormLayout, QGridLayout, QGroupBox, QHBoxLayout,
                               QHeaderView, QInputDialog, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QMenu, QMessageBox, QProgressBar, QPushButton, QSlider, QSpinBox,
                               QSplitter, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from app.event import Event, EventDialog, NewEventDialog
from app.history import GrowthDialog
from app.poster import make_poster
from app.speech import Speaker, seconds_text
from app.livegrid import LiveGrid, NONE as NO_VIEW
from app import ffmpeg_tools as ft
from app.library import NOT_STUDENTS
from app.marshal import LineCaptureDialog, MarshalDialog


def _skip_c5_ports():
    """训练模式读遥控器时会自动抓 USB 串口当 ELRS 接收机。C5 计时器（乐鑫自带 USB，VID 303A）不是接收机，别抓它，
    不然比赛模式连 C5 会「拒绝访问」。"""
    try:
        from app import sticks
        from serial.tools import list_ports
    except Exception:  # noqa: BLE001 - 没有 pyserial 就什么都不做
        return

    def crsf_ports():
        ports = sorted(p.device for p in list_ports.comports() if p.vid is not None and p.vid != 0x303A)
        if len(ports) == 1:
            return {sticks.CRSF_NAME: ports[0]}
        return {f"{sticks.CRSF_NAME}（{p}）": p for p in ports}

    sticks.crsf_ports = crsf_ports


_skip_c5_ports()

NODES = 4
TCP_PORT, BEACON_PORT = 5808, 5809
# HDZero / 模拟图传常用频道（MHz）。普通 RX5808 只收 5645~5945，L 频段要宽频版模块
CHANNELS = {"R1": 5658, "R2": 5695, "R3": 5732, "R4": 5769, "R5": 5806, "R6": 5843, "R7": 5880, "R8": 5917,
            "F2": 5760, "F4": 5800,
            "L1": 5362, "L2": 5399, "L3": 5436, "L4": 5473, "L5": 5510, "L6": 5547, "L7": 5584, "L8": 5621}
DEFAULT_CH = ["R1", "R3", "R6", "R8"]       # 4 个人同时飞，频道隔得越开越不干扰
COLORS = [QColor(255, 90, 90), QColor(80, 200, 255), QColor(120, 230, 100), QColor(255, 200, 60)]


def now_ms() -> float:
    return time.perf_counter() * 1000.0


def fmt(ms) -> str:
    if ms is None:
        return "-"
    s = ms / 1000.0
    return f"{int(s // 60)}:{s % 60:05.2f}" if s >= 60 else f"{s:.2f}"


# ============================================================ 计时器连接
class TimerLink(QObject):
    """连接计时器。所有消息都转成信号；计时器时间（毫秒）可以换算成电脑时间。"""
    status = Signal(bool, str)          # 连上了吗，说明
    cfg = Signal(dict)
    rssi = Signal(list, list, list)     # 当前、最近最低、最近最高（毫伏）
    passed = Signal(int, float, int)    # 第几路，过门时间（计时器毫秒），最高信号
    _line = Signal(str)

    def __init__(self):
        super().__init__()
        self.offset = None              # 电脑毫秒 - 计时器毫秒
        self._offsets = []
        self._line.connect(self._handle)
        self.connected = False

    # 计时器时间 <-> 电脑时间
    def to_pc(self, tms):
        return tms + (self.offset or 0)

    def timer_now(self):
        return now_ms() - (self.offset or 0)

    def _clock(self, tms):
        self._offsets.append(now_ms() - tms)
        self._offsets = self._offsets[-50:]
        self.offset = min(self._offsets)   # 网络延迟只会让差值变大，取最小最接近真实

    def _handle(self, line):
        try:
            m = json.loads(line)
        except ValueError:
            return
        t = m.get("t")
        if "ms" in m and t in ("rssi", "cfg", "time"):
            self._clock(m["ms"])
        if t == "rssi":
            self.last_rssi_ms = m.get("ms")
            self.rssi.emit(m.get("v", []), m.get("lo", []), m.get("hi", []))
        elif t == "cfg":
            self.cfg.emit(m)
        elif t == "pass":
            self.passed.emit(int(m["node"]), float(m["ms"]), int(m.get("peak", 0)))
        elif t == "msg":
            self.status.emit(self.connected, m.get("text", ""))

    def send(self, obj):
        pass

    def close(self):
        pass


class WifiLink(TimerLink):
    def __init__(self, host):
        super().__init__()
        self.host = host
        self.closed = False
        self.retry_on = False
        self.sock = QTcpSocket(self)
        self.sock.connected.connect(self._on_connected)
        self.sock.disconnected.connect(lambda: self._lost("断开了"))
        self.sock.errorOccurred.connect(lambda _e: self._lost(self.sock.errorString()))
        self.sock.readyRead.connect(self._read)
        self.sock.connectToHost(host, TCP_PORT)
        self.status.emit(False, f"正在连接 {host}…")

    def _on_connected(self):
        self.connected = True
        self.status.emit(True, f"已连接 WiFi 计时器 {self.host}")
        self.send({"c": "get"})

    def _lost(self, why):
        if self.closed:
            return
        if self.connected or why:
            self.connected = False
            self.status.emit(False, f"计时器没连上：{why}。自动重连中…（电脑要连着计时器所在的 WiFi）")
        if not self.retry_on:                   # 断了就每 2 秒重连一次，直到点「断开」
            self.retry_on = True
            QTimer.singleShot(2000, self._retry)

    def _retry(self):
        self.retry_on = False
        if not self.closed and self.sock.state() == QTcpSocket.UnconnectedState:
            self.sock.connectToHost(self.host, TCP_PORT)

    def _read(self):
        while self.sock.canReadLine():
            self._line.emit(bytes(self.sock.readLine()).decode("utf-8", "replace").strip())

    def send(self, obj):
        if self.connected:
            self.sock.write((json.dumps(obj, ensure_ascii=False) + "\n").encode())

    def close(self):
        self.closed = True
        self.connected = False
        self.sock.abort()


class SerialLink(TimerLink):
    def __init__(self, port):
        super().__init__()
        import serial
        self.port = port
        self.ser = None
        try:
            self.ser = serial.Serial(port, 115200, timeout=0.2)
        except (OSError, serial.SerialException) as ex:
            msg = f"打不开 {port}：{ex}"
            QTimer.singleShot(0, lambda: self.status.emit(False, msg))
            return
        self.connected = True
        self._stop = False
        threading.Thread(target=self._reader, daemon=True).start()
        QTimer.singleShot(0, lambda: self.status.emit(True, f"已连接 USB 计时器 {port}"))
        QTimer.singleShot(300, lambda: self.send({"c": "get"}))
        # 串口不主动报信号强度：每 0.1 秒问一次时间，保持时钟对齐
        self._clock_timer = QTimer(self, interval=1000, timeout=lambda: self.send({"c": "time"}))
        self._clock_timer.start()

    def _reader(self):
        buf = b""
        while not self._stop and self.ser:
            try:
                buf += self.ser.read(256)
            except Exception:  # noqa: BLE001 - 拔线等各种串口错误
                self.connected = False
                self.status.emit(False, "USB 计时器断开了")
                return
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                self._line.emit(line.decode("utf-8", "replace").strip())

    def send(self, obj):
        if self.ser and self.connected:
            try:
                self.ser.write((json.dumps(obj, ensure_ascii=False) + "\n").encode())
            except Exception:  # noqa: BLE001
                pass

    def close(self):
        self._stop = True
        self.connected = False
        if self.ser:
            self.ser.close()


def serial_ports():
    try:
        from serial.tools import list_ports
        return [(p.device, f"{p.device}  {p.description}") for p in list_ports.comports()]
    except Exception:  # noqa: BLE001
        return []


class BeaconListener(QObject):
    """计时器每秒广播「LAPTIMER ip 端口」，听到就知道它在哪"""
    found = Signal(str)

    def __init__(self):
        super().__init__()
        self.sock = QUdpSocket(self)
        self.sock.bind(QHostAddress.AnyIPv4, BEACON_PORT, QUdpSocket.ShareAddress | QUdpSocket.ReuseAddressHint)
        self.sock.readyRead.connect(self._read)

    def _read(self):
        while self.sock.hasPendingDatagrams():
            data = bytes(self.sock.receiveDatagram().data()).decode("utf-8", "replace").split()
            if len(data) >= 2 and data[0] == "LAPTIMER":
                self.found.emit(data[1])


class FakeLink(TimerLink):
    """模拟计时器：没有硬件也能试比赛模式。和真计时器一样的算法：信号过进门线找最高点，掉到出门线下记一次过门。"""

    def __init__(self):
        super().__init__()
        self.t0 = now_ms()
        self.mhz = [CHANNELS[c] for c in DEFAULT_CH]
        self.enter = [900] * NODES
        self.exit = [800] * NODES
        self.smooth = [600.0] * NODES
        self.lo = [9999] * NODES
        self.hi = [0] * NODES
        self.state = [dict(crossing=False, peak=0, pf=0, pl=0) for _ in range(NODES)]
        self.lap = [random.uniform(11, 15) for _ in range(NODES)]
        self.next_pass = [self._ms() + random.uniform(2000, 4000) for _ in range(NODES)]
        self.timer = QTimer(self, interval=10, timeout=self._tick)
        self.timer.start()
        self.report = 0
        self.connected = True
        QTimer.singleShot(0, lambda: (self.status.emit(True, "模拟计时器（假的飞机，用来试用）"), self._cfg()))

    def _ms(self):
        return now_ms() - self.t0

    def _cfg(self):
        self.cfg.emit({"t": "cfg", "ms": self._ms(), "nodes": [
            {"mhz": self.mhz[i], "enter": self.enter[i], "exit": self.exit[i]} for i in range(NODES)]})

    def send(self, obj):
        c, i = obj.get("c"), obj.get("node", -1)
        if c == "freq" and 0 <= i < NODES:
            self.mhz[i] = obj["mhz"]; self._cfg()
        elif c == "thr" and 0 <= i < NODES:
            self.enter[i] = obj["enter"]; self.exit[i] = min(obj["exit"], obj["enter"] - 10); self._cfg()
        elif c == "range":
            self.lo, self.hi = [9999] * NODES, [0] * NODES
        elif c == "get":
            self._cfg()

    def _tick(self):
        t = self._ms()
        for i in range(NODES):
            dt = (t - self.next_pass[i]) / 1000.0
            if dt > 1.5:
                self.lap[i] = max(6.0, self.lap[i] + random.uniform(-1.2, 1.0))
                self.next_pass[i] += self.lap[i] * 1000
                dt = (t - self.next_pass[i]) / 1000.0
            raw = 600 + random.gauss(0, 15) + 600 * math.exp(-(dt / 0.25) ** 2)
            self.smooth[i] = self.smooth[i] * 0.6 + raw * 0.4
            v = int(self.smooth[i])
            self.lo[i] = min(self.lo[i], v); self.hi[i] = max(self.hi[i], v)
            s = self.state[i]
            if not s["crossing"]:
                if v >= self.enter[i]:
                    s.update(crossing=True, peak=v, pf=t, pl=t)
            else:
                if v > s["peak"]:
                    s.update(peak=v, pf=t, pl=t)
                elif v == s["peak"]:
                    s["pl"] = t
                if v < self.exit[i]:
                    s["crossing"] = False
                    self._clock(t)
                    self.passed.emit(i, s["pf"] + (s["pl"] - s["pf"]) / 2, s["peak"])
        if t - self.report >= 100:
            self.report = t
            self._clock(t)
            self.last_rssi_ms = t
            self.rssi.emit([int(v) for v in self.smooth], [0 if v == 9999 else v for v in self.lo], list(self.hi))

    def close(self):
        self.timer.stop()
        self.connected = False


# ============================================================ 选手资料（DRA 编号、照片）
DRA_URL = "https://www.drafpv.com/"


class Roster:
    """选手资料存在录像文件夹里：选手资料/选手.json，照片在 选手资料/照片/"""

    def __init__(self, root: Path):
        self.dir = Path(root) / "选手资料"
        self.file = self.dir / "选手.json"
        try:
            self.data = json.loads(self.file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.data = {}

    def get(self, name):
        return self.data.setdefault(name, {"dra": "", "photo": ""})

    def number(self, name):
        return self.data.get(name, {}).get("dra", "")

    def label(self, name):
        n = self.number(name)
        return f"{n} {name}" if n else name

    def photo(self, name) -> QPixmap:
        f = self.data.get(name, {}).get("photo")
        return QPixmap(str(self.dir / f)) if f and (self.dir / f).exists() else QPixmap()

    def set_photo(self, name, img: QImage) -> bool:
        if img.isNull():
            return False
        (self.dir / "照片").mkdir(parents=True, exist_ok=True)
        img = img.scaled(320, 320, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        rel = f"照片/{name}.png"
        if not img.save(str(self.dir / rel)):
            return False
        self.get(name)["photo"] = rel
        return True

    def save(self):
        self.dir.mkdir(parents=True, exist_ok=True)
        self.file.write_text(json.dumps(self.data, ensure_ascii=False, indent=1), encoding="utf-8")


def round_icon(pm: QPixmap, size=48) -> QIcon:
    if pm.isNull():
        return QIcon()
    return QIcon(pm.scaled(size, size, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation))


class RosterDialog(QDialog):
    """选手资料：DRA 联赛编号、照片、图传频道。照片可以选文件、拖进来，或者从 DRA 官网复制后粘贴。"""

    def __init__(self, roster: Roster, names, channels: dict, root: Path, parent=None):
        super().__init__(parent)
        self.setWindowTitle("选手资料")
        self.resize(760, 560)
        self.setAcceptDrops(True)
        self.roster, self.channels, self.root = roster, dict(channels), Path(root)
        self.names = list(dict.fromkeys(list(names) + list(roster.data)))
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["照片", "姓名", "DRA 编号", "图传频道"])
        self.table.verticalHeader().setVisible(False)
        self.table.setIconSize(QSize(64, 64))
        self.table.verticalHeader().setDefaultSectionSize(70)
        self.table.setColumnWidth(0, 80); self.table.setColumnWidth(1, 160); self.table.setColumnWidth(2, 140)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self._fill()
        add = QPushButton("添加选手")
        add.clicked.connect(self._add)
        pick = QPushButton("选照片…")
        pick.clicked.connect(self._pick)
        paste = QPushButton("粘贴照片")
        paste.setToolTip("在 DRA 官网选手照片上右键「复制图片」，再点这里")
        paste.clicked.connect(self._paste)
        web = QPushButton("打开 DRA 官网")
        web.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(DRA_URL)))
        btns = QHBoxLayout()
        for b in (add, pick, paste, web):
            btns.addWidget(b)
        btns.addStretch()
        tip = QLabel("先点选一行，再「选照片」或「粘贴照片」；也可以把照片文件直接拖到这个窗口。\n"
                     "DRA 官网照片：在官网选手照片上右键「复制图片」，回来点「粘贴照片」。")
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self._ok)
        bb.rejected.connect(self.reject)
        lay = QVBoxLayout(self)
        lay.addLayout(btns)
        lay.addWidget(tip)
        lay.addWidget(self.table, 1)
        lay.addWidget(bb)

    def _fill(self):
        self.table.setRowCount(len(self.names))
        for r, n in enumerate(self.names):
            ph = QTableWidgetItem()
            ph.setIcon(round_icon(self.roster.photo(n), 64))
            ph.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            nm = QTableWidgetItem(n)
            nm.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            self.table.setItem(r, 0, ph)
            self.table.setItem(r, 1, nm)
            self.table.setItem(r, 2, QTableWidgetItem(self.roster.number(n)))
            box = QComboBox()
            for c, mhz in CHANNELS.items():
                box.addItem(c, c)
            box.setCurrentIndex(max(0, box.findData(self.channels.get(n, "R1"))))
            self.table.setCellWidget(r, 3, box)

    def _row_name(self):
        r = self.table.currentRow()
        if r < 0:
            QMessageBox.information(self, "选手资料", "先点一下要设照片的那一行。")
            return None
        return self.names[r]

    def _set(self, img: QImage):
        name = self._row_name()
        if not name:
            return
        if not self.roster.set_photo(name, img):
            QMessageBox.warning(self, "选手资料", "这张图片用不了，换一张试试。")
            return
        self.table.item(self.table.currentRow(), 0).setIcon(round_icon(self.roster.photo(name), 64))

    def _pick(self):
        if not self._row_name():
            return
        f, _ = QFileDialog.getOpenFileName(self, "选选手照片", "", "图片 (*.jpg *.jpeg *.png *.bmp *.webp)")
        if f:
            self._set(QImage(f))

    def _paste(self):
        md = QApplication.clipboard().mimeData()
        if md.hasImage():
            self._set(QImage(md.imageData()))
        elif md.hasUrls() and md.urls()[0].isLocalFile():
            self._set(QImage(md.urls()[0].toLocalFile()))
        else:
            QMessageBox.information(self, "选手资料", "剪贴板里没有图片。在网页照片上右键「复制图片」再试。")

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls() or e.mimeData().hasImage():
            e.acceptProposedAction()

    def dropEvent(self, e):
        pos = self.table.viewport().mapFrom(self, e.position().toPoint())
        r = self.table.rowAt(pos.y())
        if r >= 0:
            self.table.selectRow(r)
        md = e.mimeData()
        if md.hasImage():
            self._set(QImage(md.imageData()))
        elif md.hasUrls() and md.urls()[0].isLocalFile():
            self._set(QImage(md.urls()[0].toLocalFile()))

    def _add(self):
        name, ok = QInputDialog.getText(self, "添加选手", "选手姓名：")
        name = name.strip()
        if not ok or not name:
            return
        if name in self.names:
            QMessageBox.information(self, "选手资料", "已经有这个选手了。")
            return
        try:
            (self.root / name).mkdir(parents=True, exist_ok=True)   # 训练模式里也能选到，录像存这里
        except OSError:
            pass
        self.names.append(name)
        self.roster.get(name)
        self._fill()
        self.table.selectRow(len(self.names) - 1)

    def _ok(self):
        for r, n in enumerate(self.names):
            self.roster.get(n)["dra"] = self.table.item(r, 2).text().strip()
            self.channels[n] = self.table.cellWidget(r, 3).currentData()
        try:
            self.roster.save()
        except OSError as ex:
            QMessageBox.warning(self, "选手资料", f"保存失败：{ex}")
            return
        self.accept()


# ============================================================ 信号曲线
class RssiPlot(QWidget):
    """最近 20 秒每一路的信号强度，虚线是进门线/出门线"""
    SPAN = 200

    def __init__(self):
        super().__init__()
        self.hist = [[] for _ in range(NODES)]
        self.enabled = [True] * NODES
        self.thr = [(900, 800)] * NODES
        self.setMinimumHeight(150)

    def add(self, vals):
        for i in range(NODES):
            self.hist[i].append(vals[i] if i < len(vals) else 0)
            del self.hist[i][:-self.SPAN]
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor(32, 30, 44))
        idx = [i for i in range(NODES) if self.enabled[i]]
        vals = [v for i in idx for v in self.hist[i]] + [t for i in idx for t in self.thr[i]]
        if not vals:
            p.setPen(QColor(170, 170, 180))
            p.drawText(self.rect(), Qt.AlignCenter, "连上计时器后，这里显示每一路的信号强度")
            return
        lo, hi = min(vals) - 50, max(vals) + 50
        W, H = self.width(), self.height()
        Y = lambda v: H - 18 - (v - lo) / (hi - lo) * (H - 30)
        for i in idx:
            col = COLORS[i]
            for k, v in enumerate(self.thr[i]):
                pen = QPen(col, 1, Qt.DashLine if k == 0 else Qt.DotLine)
                p.setPen(pen)
                p.drawLine(0, Y(v), W, Y(v))
            h = self.hist[i]
            if len(h) > 1:
                p.setPen(QPen(col, 2))
                p.drawPolyline(QPolygonF([QPointF(W - (len(h) - 1 - k) * W / (self.SPAN - 1), Y(v)) for k, v in enumerate(h)]))
        p.setPen(QColor(170, 170, 180))
        p.drawText(6, H - 4, "最近 20 秒信号强度（毫伏）   虚线=进门线  点线=出门线：信号高过进门线再掉下出门线，就记一次过门")


# ============================================================ 比赛
class Pilot:
    def __init__(self, node, name):
        self.node, self.name = node, name
        self.passes = []        # 计时器毫秒，第一个是起飞后第一次过门（开始计时）
        self.peaks = []         # 每次过门的最高信号，和 passes 一一对应
        self.ignored = []       # 太快的误触发

    def laps(self):
        return [b - a for a, b in zip(self.passes, self.passes[1:])]

    def total(self, start):
        return self.passes[-1] - start if self.passes else None


class Fold(QWidget):
    """可以折叠的一块：点标题展开/收起"""
    toggled = Signal(bool)          # True = 收起

    def __init__(self, title, body: QWidget, shut=True):
        super().__init__()
        self.title = title
        self.body = body
        self.btn = QToolButton()
        self.btn.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.btn.setStyleSheet("QToolButton { border: none; font-weight: bold; text-align: left; padding: 4px; }")
        self.btn.clicked.connect(lambda: self.set_shut(self.body.isVisible()))
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(self.btn)
        lay.addWidget(body)
        self.set_shut(shut, emit=False)

    def set_shut(self, shut, emit=True):
        self.body.setVisible(not shut)
        self.btn.setArrowType(Qt.RightArrow if shut else Qt.DownArrow)
        self.btn.setText(self.title)
        if emit:
            self.toggled.emit(shut)


class RaceView(QWidget):
    """比赛模式页面"""

    def __init__(self, settings, students, data_dir, students_changed=None):
        super().__init__()
        self.s = settings
        self.students_changed = students_changed or (lambda: None)
        self.students = students            # 函数：返回选手名单
        self.data_dir = data_dir            # 函数：返回录像根目录
        cfg = self.s.data.setdefault("race", {})
        cfg.setdefault("host", "192.168.4.1")
        cfg.setdefault("link", "wifi")
        cfg.setdefault("laps", 3)
        cfg.setdefault("min_lap", 5.0)
        cfg.setdefault("countdown", 3)
        cfg.setdefault("voice", True)
        cfg.setdefault("track", "")
        cfg.setdefault("nodes", [{"on": i == 0, "pilot": "", "ch": DEFAULT_CH[i]} for i in range(NODES)])
        self.cfg = cfg
        self.link = None
        self.race = None                    # dict(start=计时器毫秒, pilots=[Pilot])
        self.lo = [0] * NODES
        self.hi = [0] * NODES
        self.calibrating = False
        self.voice = Speaker()
        self.cur_event = None                   # 当前赛事（分组、多轮）
        self.heat = None                    # 正在飞赛事里的第几组
        self.last_result = None             # 最近一场的成绩，用来出海报

        # ---- 计时器连接
        self.link_box = QComboBox()
        self.link_box.addItem("WiFi 计时器", "wifi")
        self.link_box.addItem("USB 线连接", "usb")
        self.link_box.addItem("C5 计时器（USB 线）", "c5")
        self.link_box.addItem("模拟计时器（没硬件时试用）", "fake")
        self.link_box.setCurrentIndex(max(0, self.link_box.findData(cfg["link"])))
        self.host = QLineEdit(cfg["host"])
        self.port_box = QComboBox()
        self.conn_btn = QPushButton("连接计时器")
        self.conn_btn.clicked.connect(self.toggle_connect)
        self.conn_label = QLabel("没有连接")
        self.conn_label.setWordWrap(True)
        self.link_box.currentIndexChanged.connect(self._link_kind_changed)
        conn = QGroupBox("计时器")
        cl = QGridLayout(conn)
        cl.addWidget(self.link_box, 0, 0)
        cl.addWidget(self.host, 0, 1)
        cl.addWidget(self.port_box, 0, 1)
        cl.addWidget(self.conn_btn, 0, 2)
        cl.addWidget(self.conn_label, 1, 0, 1, 2)
        wifi_btn = QPushButton("计时器连 WiFi…")
        wifi_btn.setToolTip("让计时器连你家或场地的 WiFi，电脑就不用换到 LapTimer 热点，还能照常上网")
        wifi_btn.clicked.connect(self._timer_wifi)
        cl.addWidget(wifi_btn, 1, 2)
        self._link_kind_changed()
        self.beacon = BeaconListener()
        self.beacon.found.connect(self._beacon)

        # ---- 选手（每一路一个）
        grid = QGridLayout()
        for c, h in enumerate(["用", "选手", "HDZero 频道", "信号"]):
            grid.addWidget(QLabel(h), 0, c)
        self.rows = []
        for i in range(NODES):
            n = cfg["nodes"][i]
            on = QCheckBox(f"{i + 1} 路")
            on.setChecked(n["on"])
            on.setStyleSheet(f"color: {COLORS[i].name()}; font-weight: bold;")
            pilot = QComboBox()
            pilot.setEditable(True)
            pilot.setMinimumWidth(110)
            ch = QComboBox()
            for name, mhz in CHANNELS.items():
                ch.addItem(name, name)
            ch.setCurrentIndex(max(0, ch.findData(n["ch"])))
            bar = QProgressBar()
            bar.setRange(0, 1500)
            bar.setTextVisible(True)
            bar.setFormat("%v")
            bar.setMinimumHeight(20)             # Windows 11 默认画成一根细线，看不到数字
            bar.setStyleSheet("QProgressBar { border: 1px solid #b8bec6; border-radius: 3px; background: #ffffff;"
                              " text-align: center; color: #222; }"
                              f"QProgressBar::chunk {{ background: {COLORS[i].name()}; }}")
            enter = QSpinBox(minimum=100, maximum=3000, singleStep=10, value=900)
            exit_ = QSpinBox(minimum=100, maximum=3000, singleStep=10, value=800)
            for c, w in enumerate([on, pilot, ch, bar]):
                grid.addWidget(w, i + 1, c)
            enter.setParent(self)               # 进门线/出门线不显示，由「校准信号」自动设
            exit_.setParent(self)
            enter.hide()
            exit_.hide()
            row = dict(on=on, pilot=pilot, ch=ch, bar=bar, enter=enter, exit=exit_)
            self.rows.append(row)
            on.toggled.connect(lambda _v, k=i: self._row_changed(k))
            pilot.currentTextChanged.connect(lambda _v, k=i: self._row_changed(k))
            ch.currentIndexChanged.connect(lambda _v, k=i: self._channel_changed(k))
            enter.editingFinished.connect(lambda k=i: self._thr_changed(k))
            exit_.editingFinished.connect(lambda k=i: self._thr_changed(k))
        self.fill_students()
        roster_btn = QPushButton("选手资料…")
        roster_btn.setToolTip("DRA 编号、照片、每人的图传频道")
        roster_btn.clicked.connect(self.open_roster)
        self.cal_btn = QPushButton("校准信号")
        self.cal_btn.setToolTip("点一下开始，让每架飞机都从计时门穿过几次，再点「校准完成」，软件自动设好进门线和出门线")
        self.cal_btn.clicked.connect(self.toggle_calibrate)
        self.cal_label = QLabel("第一次用、换了场地或者换了天线，都要校准一次。")
        self.cal_label.setWordWrap(True)
        pilots = QGroupBox("选手和频道（每人一个频道，计时器每一路听一个频道）")
        pl = QVBoxLayout(pilots)
        pl.addLayout(grid)
        cal_row = QHBoxLayout()
        cal_row.addWidget(roster_btn)
        cal_row.addWidget(self.cal_btn)
        line_btn = QPushButton("按距离设线…")
        line_btn.setToolTip("飞机放在离计时器 2 米设进门线、7 米设出门线（开源计时器常用的设法）")
        line_btn.clicked.connect(self.open_lines)
        cal_row.addWidget(line_btn)
        cal_row.addWidget(self.cal_label, 1)
        pl.addLayout(cal_row)
        # 灵敏度：校准后在「没飞机」和「过门」之间挪进门线，不用重新飞
        sens_row = QHBoxLayout()
        sens_row.addWidget(QLabel("灵敏度"))
        sens_row.addWidget(QLabel("迟钝（贴近才算）"))
        self.sens = QSlider(Qt.Horizontal, minimum=1, maximum=9, value=cfg.get("sens", 5), pageStep=1)
        self.sens.setTickPosition(QSlider.TicksBelow)
        self.sens.setToolTip("在家离得近、乱触发就往左调；飞场远、过门没记上就往右调。调完马上生效，不用重新校准")
        self.sens.valueChanged.connect(self._sens_changed)
        sens_row.addWidget(self.sens, 1)
        sens_row.addWidget(QLabel("灵敏（远一点也算）"))
        pl.addLayout(sens_row)

        # ---- 规则
        self.laps_box = QSpinBox(minimum=1, maximum=50, value=cfg["laps"], suffix=" 圈")
        self.min_lap = QDoubleSpinBox(minimum=1, maximum=120, singleStep=0.5, value=cfg["min_lap"], suffix=" 秒")
        self.min_lap.setToolTip("比这个还快的一圈当作误触发，不算（比如在门口晃了一下）")
        self.countdown = QSpinBox(minimum=0, maximum=10, value=cfg["countdown"], suffix=" 秒")
        self.race_name = QLineEdit(cfg.get("name", ""))
        self.race_name.setPlaceholderText("比如：周六训练赛")
        self.track_box = QComboBox()
        self.track_box.setEditable(True)
        self.track_box.addItems(cfg.get("tracks", []))
        self.track_box.setCurrentText(cfg["track"])
        self.track_box.lineEdit().setPlaceholderText("比如：余杭站（成长记录按赛道比）")
        self.voice_on = QCheckBox("过门报圈语音")
        self.voice_on.setChecked(cfg["voice"])
        self.voice_on.setToolTip("过门时念出「名字 第几圈 几秒」，用电脑自带的中文语音")
        voice_test = QPushButton("试听")
        voice_test.clicked.connect(lambda: self.voice.say("陈博言，第3圈，12.4秒，最快一圈"))
        voice_row = QHBoxLayout()
        voice_row.addWidget(self.voice_on)
        voice_row.addWidget(voice_test)
        voice_row.addStretch()
        rules = QWidget()
        rf = QFormLayout(rules)
        rf.addRow("比赛名称", self.race_name)
        rf.addRow("赛道", self.track_box)
        rf.addRow("飞几圈", self.laps_box)
        rf.addRow("最短一圈", self.min_lap)
        rf.addRow("开始倒计时", self.countdown)
        rf.addRow("", voice_row)
        rf.addRow(QLabel("起飞后第一次穿过计时门开始计时，以后每穿过一次算一圈。"))
        for w in (self.laps_box, self.min_lap, self.countdown):
            w.valueChanged.connect(self._save)
        self.race_name.editingFinished.connect(self._save)
        self.track_box.currentTextChanged.connect(lambda _t: self._save())
        self.voice_on.toggled.connect(self._save)

        # ---- 赛事：人多分组、多轮积分、决赛
        self.event_label = QLabel("没有进行中的赛事。人多于 4 个时，新建一个赛事，软件自动分组、算积分。")
        self.event_label.setWordWrap(True)
        new_ev = QPushButton("新建赛事…")
        new_ev.clicked.connect(self.new_event)
        open_ev = QPushButton("打开赛事…")
        open_ev.clicked.connect(self.open_event)
        self.ev_btn = QPushButton("分组和积分榜…")
        self.ev_btn.clicked.connect(self.show_event)
        self.next_btn = QPushButton("下一组")
        self.next_btn.clicked.connect(self.load_next_heat)
        self.quit_ev = QPushButton("退出赛事")
        self.quit_ev.clicked.connect(lambda: self.set_event(None))
        events = QWidget()
        el = QVBoxLayout(events)
        el.addWidget(self.event_label)
        er = QHBoxLayout()
        for b in (new_ev, open_ev, self.ev_btn, self.next_btn, self.quit_ev):
            er.addWidget(b)
        el.addLayout(er)

        # ---- 左下：名次和每一圈
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["名次", "选手", "圈数", "最快一圈", "总时间"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        tf = QFont()
        tf.setPointSize(11)
        self.table.setFont(tf)
        self.table.setIconSize(QSize(30, 30))
        self.table.verticalHeader().setDefaultSectionSize(36)
        self.laps_list = QListWidget()
        self.laps_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.laps_list.customContextMenuRequested.connect(self._lap_menu)
        self.plot = RssiPlot()
        self.plot.setMinimumHeight(150)
        results = QWidget()
        rsl = QVBoxLayout(results)
        rsl.setContentsMargins(0, 0, 0, 0)
        rsl.addWidget(QLabel("名次"))
        rsl.addWidget(self.table, 2)
        rsl.addWidget(QLabel("每一圈（右键可以删掉误记的一次过门）"))
        rsl.addWidget(self.laps_list, 3)

        self.folds = []
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(4, 4, 4, 4)
        ll.addWidget(conn)
        ll.addWidget(pilots)
        for key, title, w in (("rules", "比赛规则", rules), ("events", "赛事（分组、多轮积分）", events),
                              ("plot", "信号曲线", self.plot)):
            fold = Fold(title, w, not cfg.get("open", {}).get(key, False))
            fold.toggled.connect(lambda shut, k=key: self._fold_saved(k, shut))
            self.folds.append(fold)
            ll.addWidget(fold)
        ll.addWidget(results, 1)

        # ---- 右边：4 个选手的实时画面，最下面一排：总时间、提示、开始按钮
        self.live = LiveGrid(COLORS, [], cfg.get("views", []))
        self.live.device_changed.connect(self._view_device)
        self.clock = QLabel("0.00")
        self.clock.setAlignment(Qt.AlignCenter)
        f = QFont()
        f.setPointSize(26)
        f.setBold(True)
        self.clock.setFont(f)
        self.clock.setMinimumWidth(170)
        self.banner = QLabel("连上计时器，选好选手，点「开始比赛」")
        self.banner.setWordWrap(True)
        bf = QFont()
        bf.setPointSize(13)
        self.banner.setFont(bf)
        self.start_btn = QPushButton()
        self.start_btn.setMinimumSize(260, 60)
        self.start_btn.clicked.connect(self.start_or_stop)
        self._start_look(False)
        self.poster_btn = QPushButton("成绩海报")
        self.poster_btn.setToolTip("比赛结束后，生成一张带照片的成绩图，自动复制好，可以直接粘贴到微信")
        self.poster_btn.setEnabled(False)
        self.poster_btn.clicked.connect(self.race_poster)
        self.replay_btn = QPushButton("回放调线")
        self.replay_btn.setToolTip("比赛后看每一路整场的信号，圈数不对时拖线重算，再更新成绩")
        self.replay_btn.setEnabled(False)
        self.replay_btn.clicked.connect(self.open_replay)
        growth = QPushButton("成长记录")
        growth.clicked.connect(self.open_growth)
        views_btn = QPushButton("刷新采集卡")
        views_btn.setToolTip("新插了采集卡，点一下重新找")
        views_btn.clicked.connect(lambda: self.activate(force=True))
        side = QVBoxLayout()
        for b in (self.poster_btn, self.replay_btn, growth, views_btn):
            side.addWidget(b)
        bottom = QHBoxLayout()
        bottom.addWidget(self.clock)
        bottom.addWidget(self.banner, 1)
        bottom.addLayout(side)
        bottom.addWidget(self.start_btn)
        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(4, 4, 4, 4)
        rl.addWidget(self.live, 1)
        rl.addLayout(bottom)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(left)
        scroll.setMinimumWidth(420)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        split = QSplitter()
        split.addWidget(scroll)
        split.addWidget(right)
        split.setStretchFactor(1, 1)
        split.setSizes([610, 1300])
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(split)
        self.devices = None
        self.release_device = lambda name: None     # 主程序：训练模式正在用这个采集卡就先放开

        self.tick = QTimer(self, interval=50, timeout=self._tick)
        self.tick.start()
        self.count_left = 0
        self._refresh_plot_enabled()
        if self.voice_on.isChecked():
            self.voice.warm_up()
        if cfg.get("event"):
            try:
                self.set_event(Event.load(cfg["event"]), load=False)
            except (OSError, ValueError, KeyError):
                cfg.pop("event", None)
        self._event_ui()

    # ---- 设置
    @property
    def roster(self):
        if getattr(self, "_roster_dir", None) != self.data_dir():
            self._roster_dir = self.data_dir()
            self._roster = Roster(Path(self._roster_dir))
        return self._roster

    def open_roster(self):
        dlg = RosterDialog(self.roster, self.students(), self.s.data.get("student_channels", {}), Path(self.data_dir()), self)
        if dlg.exec():
            self.s.data["student_channels"] = dlg.channels
            self.s.save()
            self.students_changed()
            self.fill_students()
            for i in range(NODES):
                self._row_changed(i)
            self._refresh()

    def fill_students(self):
        names = list(dict.fromkeys(self.students() + list(self.roster.data)))
        for i, r in enumerate(self.rows):
            want = self.cfg["nodes"][i]["pilot"]
            if want in NOT_STUDENTS:            # 老版本把「选手资料」这类文件夹当成了选手
                want = ""
            r["pilot"].blockSignals(True)
            r["pilot"].clear()
            r["pilot"].addItems(names)
            r["pilot"].setCurrentText(want or (names[i] if i < len(names) else f"选手{i + 1}"))
            r["pilot"].blockSignals(False)
            ch = self.s.data.get("student_channels", {}).get(r["pilot"].currentText().strip())
            if ch and r["ch"].findData(ch) >= 0:
                r["ch"].blockSignals(True)
                r["ch"].setCurrentIndex(r["ch"].findData(ch))
                r["ch"].blockSignals(False)

    def _save(self):
        c = self.cfg
        c.update(laps=self.laps_box.value(), min_lap=self.min_lap.value(), countdown=self.countdown.value(),
                 name=self.race_name.text().strip(), link=self.link_box.currentData(), host=self.host.text().strip(),
                 voice=self.voice_on.isChecked(), track=self.track_box.currentText().strip())
        c["nodes"] = [{"on": r["on"].isChecked(), "pilot": r["pilot"].currentText().strip(), "ch": r["ch"].currentData()}
                      for r in self.rows]
        self.s.save()

    def _row_changed(self, i):
        # 选了学员：自动换成这个学员登记的频道
        ch = self.s.data.get("student_channels", {}).get(self.rows[i]["pilot"].currentText().strip())
        box = self.rows[i]["ch"]
        if ch and box.findData(ch) >= 0 and box.currentData() != ch:
            box.setCurrentIndex(box.findData(ch))
        self._save()
        self._refresh_plot_enabled()

    def _refresh_plot_enabled(self):
        self.plot.enabled = [r["on"].isChecked() for r in self.rows]
        self.plot.update()

    def _channel_changed(self, i):
        name = self.rows[i]["pilot"].currentText().strip()
        if name and self.rows[i]["on"].isChecked():   # 没打勾的那几路不算，免得同名的空路把频道改掉
            self.s.data.setdefault("student_channels", {})[name] = self.rows[i]["ch"].currentData()
        self._save()
        if self.link:
            self.link.send({"c": "freq", "node": i, "mhz": CHANNELS[self.rows[i]["ch"].currentData()]})

    def _thr_changed(self, i):
        r = self.rows[i]
        if r["exit"].value() >= r["enter"].value():
            r["exit"].setValue(r["enter"].value() - 50)
        self.plot.thr[i] = (r["enter"].value(), r["exit"].value())
        if self.link:
            self.link.send({"c": "thr", "node": i, "enter": r["enter"].value(), "exit": r["exit"].value()})

    # ---- 连接
    def _link_kind_changed(self):
        kind = self.link_box.currentData()
        self.host.setVisible(kind == "wifi")
        self.port_box.setVisible(kind in ("usb", "c5"))
        if kind in ("usb", "c5"):
            self.port_box.clear()
            for dev, label in serial_ports():
                self.port_box.addItem(label, dev)
            if not self.port_box.count():
                self.port_box.addItem("没找到 USB 设备，插上计时器后重选一下", "")

    def _beacon(self, ip):
        if not (self.link and self.link.connected) and self.link_box.currentData() == "wifi" and self.host.text() != ip:
            self.host.setText(ip)
            self.conn_label.setText(f"找到计时器：{ip}，点「连接计时器」")

    def toggle_connect(self):
        if self.link:
            self.link.close()
            self.link.deleteLater()
            self.link = None
            self.conn_btn.setText("连接计时器")
            self.conn_label.setText("没有连接")
            return
        self._save()
        kind = self.link_box.currentData()
        if kind == "wifi":
            self.link = WifiLink(self.host.text().strip() or "192.168.4.1")
        elif kind in ("usb", "c5"):
            if not self.port_box.currentData():
                QMessageBox.information(self, "比赛模式", "没找到计时器的 USB 口。插上 USB 线后，把连接方式重新选一下。")
                return
            if kind == "c5":
                from app.c5timer import C5Link
                self.link = C5Link(self.port_box.currentData(), NODES)
            else:
                self.link = SerialLink(self.port_box.currentData())
        else:
            self.link = FakeLink()
        self._c5_thr_done = False
        self.link.status.connect(self._status)
        self.link.cfg.connect(self._timer_cfg)
        self.link.rssi.connect(self._rssi)
        self.link.passed.connect(self._passed)
        self.conn_btn.setText("断开")
        if kind == "wifi":
            self.conn_label.setText("正在连接…  电脑要先连上计时器的 WiFi「LapTimer」（密码 12345678）")

    def _timer_wifi(self):
        """把场地 WiFi 告诉计时器，计时器重启后连过去，电脑和计时器在同一个 WiFi 里"""
        if not (self.link and self.link.connected) or isinstance(self.link, FakeLink):
            QMessageBox.information(self, "计时器连 WiFi",
                                    "先连上计时器再设置：\n用 USB 线连最方便（连接方式选「USB 线连接」），"
                                    "或者电脑先连计时器的热点 LapTimer。")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("计时器连 WiFi")
        form = QFormLayout(dlg)
        form.addRow(QLabel("填你家或场地的 WiFi，计时器会重启并连过去。\n"
                           "只能连 2.4G 的 WiFi（名字带 5G 的不行）。连不上的话 10 秒后它会自己变回 LapTimer 热点。"))
        ssid = QLineEdit()
        pwd = QLineEdit()
        pwd.setEchoMode(QLineEdit.Password)
        form.addRow("WiFi 名字", ssid)
        form.addRow("WiFi 密码", pwd)
        back = QCheckBox("改回 LapTimer 热点模式（不连 WiFi）")
        back.toggled.connect(lambda on: (ssid.setEnabled(not on), pwd.setEnabled(not on)))
        form.addRow(back)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        form.addRow(bb)
        if dlg.exec() != QDialog.Accepted:
            return
        name, pw = ("", "") if back.isChecked() else (ssid.text().strip(), pwd.text())
        if not back.isChecked() and not name:
            QMessageBox.information(self, "计时器连 WiFi", "WiFi 名字没填。")
            return
        if any(ch in name + pw for ch in '"\\'):
            QMessageBox.information(self, "计时器连 WiFi", "WiFi 名字或密码里有引号或反斜杠，计时器认不了，换一个 WiFi 试试。")
            return
        self.link.send({"c": "wifi", "ssid": name, "pass": pw})
        QTimer.singleShot(500, lambda: self.link and self.toggle_connect())
        if name:
            text = (f"计时器正在重启，去连「{name}」。\n\n电脑也连「{name}」，连接方式选「WiFi 计时器」，"
                    "等几秒软件会自己找到计时器的地址，再点「连接计时器」。")
        else:
            text = "计时器正在重启，变回 LapTimer 热点。电脑连 LapTimer（密码 12345678），地址填 192.168.4.1。"
        QMessageBox.information(self, "计时器连 WiFi", text)

    def _status(self, ok, text):
        if not ok:                              # 没数据时信号条别空着，免得以为是收不到信号
            for r in self.rows:
                r["bar"].setValue(0)
                r["bar"].setFormat("计时器没连上")
        self.conn_label.setText(text)
        self.conn_label.setStyleSheet("color: #248a3d;" if ok else "color: #d70015;")

    def _timer_cfg(self, m):
        """计时器报来自己的设置：频道按软件里选的改过去，进门线/出门线以计时器为准"""
        for i, n in enumerate(m.get("nodes", [])[:NODES]):
            r = self.rows[i]
            want = CHANNELS[r["ch"].currentData()]
            if n.get("mhz") != want and self.link:
                self.link.send({"c": "freq", "node": i, "mhz": want})
            for key, box in (("enter", r["enter"]), ("exit", r["exit"])):
                box.blockSignals(True)
                box.setValue(int(n.get(key, box.value())))
                box.blockSignals(False)
            self.plot.thr[i] = (r["enter"].value(), r["exit"].value())
        # C5 板子重启后进门线/出门线回到出厂值：用上次的校准结果重新设好
        if self.link_box.currentData() == "c5" and not getattr(self, "_c5_thr_done", False):
            self._c5_thr_done = True
            cal = self.cfg.get("cal_c5", {})
            for i in range(NODES):
                if str(i) in cal:
                    self._apply_sens(i, *cal[str(i)])

    def _rssi(self, v, lo, hi):
        for i, r in enumerate(self.rows):
            if i < len(v):
                r["bar"].setValue(int(v[i]))
                # 计时器这一路没焊 RX5808 时脚是下拉的，读数接近 0
                r["bar"].setFormat("这一路没装接收模块" if v[i] < 30 else "%v")
        self.lo, self.hi = lo, hi
        self.plot.add(v)
        r = self.race
        if r and self.link and r.get("hist") is not None and r["start"] is not None:
            t = getattr(self.link, "last_rssi_ms", None) or self.link.timer_now()
            if r.get("done") and t > r.get("end_ms", 0) + 3000:
                return                      # 结束后再多记 3 秒，最后一次过门的信号才完整
            for p in r["pilots"]:
                if p.node < len(v):
                    r["hist"].setdefault(p.node, []).append((t, int(v[p.node])))

    # ---- 校准：记下最近的最低（没飞机）和最高（飞机过门），线设在中间偏上
    def toggle_calibrate(self):
        if not self.link:
            QMessageBox.information(self, "比赛模式", "先连接计时器。")
            return
        if not self.calibrating:
            self.calibrating = True
            self.link.send({"c": "range"})
            self.cal_btn.setText("校准完成")
            self.cal_label.setText("正在校准：让每架飞机打开图传，从计时门穿过 3 次以上（贴近门飞），然后点「校准完成」。")
            return
        self.calibrating = False
        self.cal_btn.setText("校准信号")
        done, bad = [], []
        for i, r in enumerate(self.rows):
            if not r["on"].isChecked():
                continue
            lo, hi = (self.lo[i], self.hi[i]) if i < len(self.lo) else (0, 0)
            if hi - lo < 80:
                bad.append(f"{i + 1} 路")
                continue
            self.cfg.setdefault(self._cal_key(), {})[str(i)] = [lo, hi]
            self._apply_sens(i, lo, hi)
            done.append(f"{i + 1} 路（没飞机 {lo}，过门 {hi}）")
        text = ("已设好：" + "，".join(done)) if done else ""
        if bad:
            text += ("。" if text else "") + "，".join(bad) + " 信号变化太小：检查那一路的频道对不对、飞机有没有从门里穿过，再校准一次"
        self.cal_label.setText(text or "没有选中的路。")

    def _cal_key(self):
        """C5 计时器的信号单位和 RX5808 不一样，校准分开存"""
        return "cal_c5" if self.link_box.currentData() == "c5" else "cal"

    def _apply_sens(self, i, lo, hi):
        """灵敏度 5 = 进门线在没飞机和过门中间偏上（60%），每格挪 6%；出门线再低一大截（离得远才算出门，一次过门不会记成两圈）"""
        k = 0.84 - (self.sens.value() - 1) * 0.06
        r = self.rows[i]
        r["enter"].setValue(int(lo + k * (hi - lo)))
        r["exit"].setValue(int(lo + max(0.15, k - 0.35) * (hi - lo)))
        self._thr_changed(i)

    def _sens_changed(self, v):
        self.cfg["sens"] = v
        cal = self.cfg.get(self._cal_key(), {})
        done = [i for i in range(NODES) if str(i) in cal and self.rows[i]["on"].isChecked()]
        for i in done:
            self._apply_sens(i, *cal[str(i)])
        self.s.save()
        self.cal_label.setText(f"灵敏度 {v}，已用到 {'、'.join(f'{i + 1} 路' for i in done)}" if done
                               else "先点「校准信号」校准一次，灵敏度才能用。")

    # ---- 比赛
    def start_or_stop(self):
        if self.race and not self.race.get("done"):
            self.finish(early=True)
            return
        if not self.link or not self.link.connected:
            QMessageBox.information(self, "比赛模式", "先连接计时器（没有硬件可以选「模拟计时器」试一下）。")
            return
        on = [i for i, r in enumerate(self.rows) if r["on"].isChecked()]
        if not on:
            QMessageBox.information(self, "比赛模式", "至少勾选一路选手。")
            return
        chans = [self.rows[i]["ch"].currentData() for i in on]
        if len(set(chans)) < len(chans):
            QMessageBox.warning(self, "比赛模式", "有两个选手用了同一个频道，会互相干扰，计时也分不开。请每人用不同频道。")
            return
        self._save()
        self.race = dict(start=None, pilots=[Pilot(i, self.rows[i]["pilot"].currentText().strip() or f"选手{i + 1}") for i in on],
                         laps=self.laps_box.value(), min_lap=self.min_lap.value() * 1000, name=self.race_name.text().strip(),
                         began=datetime.now(), track=self.track_box.currentText().strip(),
                         heat=self.heat if self.cur_event else None, hist={})
        if r_track := self.race["track"]:
            tracks = self.cfg.setdefault("tracks", [])
            if r_track not in tracks:
                tracks.insert(0, r_track)
                self.track_box.blockSignals(True)
                self.track_box.insertItem(0, r_track)
                self.track_box.blockSignals(False)
        self.poster_btn.setEnabled(False)
        self.replay_btn.setEnabled(False)
        self.laps_list.clear()
        self.count_left = self.countdown.value()
        self._start_look(True)
        self._countdown_step()

    def _countdown_step(self):
        if not self.race:
            return
        if self.count_left > 0:
            self.banner.setText(f"准备…  {self.count_left}")
            self.clock.setText(str(self.count_left))
            beep(880, 150)
            self.count_left -= 1
            QTimer.singleShot(1000, self._countdown_step)
            return
        self.race["start"] = self.link.timer_now()
        self.banner.setText("开始！起飞后第一次穿过计时门开始计时")
        beep(1760, 500)
        self._refresh()

    def _passed(self, node, tms, peak):
        if not self.race or self.race.get("done") or self.race["start"] is None:
            return
        if tms < self.race["start"] - 300:
            return                          # 开始之前的过门（比如提前在门口晃）
        p = next((q for q in self.race["pilots"] if q.node == node), None)
        if not p or len(p.passes) > self.race["laps"]:
            return
        if p.passes and tms - p.passes[-1] < self.race["min_lap"]:
            # 两次过门离得太近，只算一次：留信号更强的那次（更像是真的穿过门）
            gap = fmt(tms - p.passes[-1])
            if p.peaks and peak > p.peaks[-1]:
                p.ignored.append(p.passes.pop())
                p.peaks.pop()
                p.passes.append(tms)
                p.peaks.append(peak)
                self.banner.setText(f"{p.name}：{gap} 秒内过门两次，算信号更强的后一次")
                self._refresh()
            else:
                p.ignored.append(tms)
                self.banner.setText(f"{p.name}：{gap} 秒就又过门，太快，当作误触发不算")
            return
        p.passes.append(tms)
        p.peaks.append(peak)
        n = len(p.passes) - 1
        view = self.live.views[node]
        view.flash_until = time.monotonic() + 0.8
        view.info["best_flash"] = n > 1 and min(p.laps()) == p.laps()[-1]
        if n == 0:
            self.banner.setText(f"{p.name} 过门，开始计时")
            beep(1320, 120)
            self.say(f"{p.name}，开始")
        else:
            lap = p.passes[-1] - p.passes[-2]
            best = min(p.laps()) == lap and n > 1
            self.banner.setText(f"{p.name} 第 {n} 圈  {fmt(lap)}" + ("  最快一圈！" if best else ""))
            beep(1320 if n < self.race["laps"] else 1760, 200 if n < self.race["laps"] else 600)
            self.say(f"{p.name}，" + (f"第{n}圈" if n < self.race["laps"] else "完成") + f"，{seconds_text(lap)}" +
                     ("，最快一圈" if best else ""))
            if n >= self.race["laps"] and all(len(q.passes) > self.race["laps"] for q in self.race["pilots"]):
                self.finish()
        self._refresh()

    def _standings(self):
        r = self.race
        rows = []
        for p in r["pilots"]:
            laps = p.laps()[:r["laps"]]
            total = p.passes[len(laps)] - r["start"] if p.passes else None
            rows.append(dict(p=p, laps=laps, total=total, best=min(laps) if laps else None,
                             last=laps[-1] if laps else None, done=len(laps) >= r["laps"]))
        rows.sort(key=lambda x: (-len(x["laps"]), x["total"] if x["total"] is not None else 1e18))
        return rows

    def _refresh(self):
        if not self.race:
            return
        rows = self._standings()
        self.table.setRowCount(len(rows))
        best_all = min((x["best"] for x in rows if x["best"] is not None), default=None)
        for k, x in enumerate(rows):
            p = x["p"]
            vals = [str(k + 1), self.roster.label(p.name), f"{len(x['laps'])} / {self.race['laps']}", fmt(x["best"]),
                    fmt(x["total"])]
            for c, v in enumerate(vals):
                it = QTableWidgetItem(v)
                it.setTextAlignment(Qt.AlignCenter)
                if c == 1:
                    it.setForeground(COLORS[p.node])
                    it.setIcon(round_icon(self.roster.photo(p.name), 30))
                if c == 3 and x["best"] is not None and x["best"] == best_all:
                    it.setForeground(QColor(170, 0, 200))
                self.table.setItem(k, c, it)
        self.laps_list.clear()
        for p in self.race["pilots"]:
            for n, lap in enumerate(p.laps()[:self.race["laps"]], 1):
                it = QListWidgetItem(f"{p.name}   第 {n} 圈   {fmt(lap)}")
                it.setForeground(COLORS[p.node])
                it.setData(Qt.UserRole, (p.node, n))
                self.laps_list.addItem(it)

    def _lap_menu(self, pos):
        it = self.laps_list.itemAt(pos)
        if not it or not self.race:
            return
        node, n = it.data(Qt.UserRole)
        m = QMenu(self)
        act = m.addAction(f"删掉第 {n} 圈结束时那次过门（误记）")
        if m.exec(self.laps_list.mapToGlobal(pos)) == act:
            p = next(q for q in self.race["pilots"] if q.node == node)
            if n < len(p.passes):
                p.ignored.append(p.passes.pop(n))
                if n < len(p.peaks):
                    p.peaks.pop(n)
            self._refresh()

    def finish(self, early=False):
        r = self.race
        r["done"] = True
        r["end_ms"] = self.link.timer_now() if self.link else 0
        self._start_look(False)
        if r["start"] is None:
            self.banner.setText("比赛取消")
            self.race = None
            return
        self._refresh()
        rows = self._standings()
        path = self.save_result(rows, early)
        win = rows[0]["p"].name if rows and rows[0]["laps"] else ""
        self.last_result = dict(rows=rows, title=r["name"] or "比赛", race=r, path=path)
        self.poster_btn.setEnabled(True)
        self.replay_btn.setEnabled(True)
        text = ("比赛结束" if not early else "比赛提前结束") + (f"，第一名：{win}" if win else "")
        if self.cur_event and r.get("heat") is not None:
            h = r["heat"]
            title = self.cur_event.heat_title(h)
            self.cur_event.record(h, [dict(pilot=x["p"].name, laps=len(x["laps"]),
                                       best=round(x["best"] / 1000, 3) if x["best"] else None,
                                       total=round(x["total"] / 1000, 3) if x["total"] else None) for x in rows],
                              str(path or ""))
            text = f"{title} 飞完" + (f"，第一名：{win}" if win else "")
            self.heat = None
            self._event_ui()
        self.banner.setText(text + (f"   成绩已保存：{path.name}" if path else ""))
        beep(1760, 800)
        self.say(text)

    # ---- 按距离设线 / 比赛回放调线（思路参考开源计时器的做法）
    def open_lines(self):
        if not self.link:
            QMessageBox.information(self, "比赛模式", "先连接计时器。")
            return
        lanes = [i for i, r in enumerate(self.rows) if r["on"].isChecked()] or [0]
        LineCaptureDialog(self, lanes).exec()

    def open_replay(self):
        r = self.race
        if not r or not r.get("done") or not r.get("hist"):
            QMessageBox.information(self, "回放调线", "这场比赛没有记到信号。")
            return
        MarshalDialog(self, r, r["hist"], COLORS).exec()

    def rescore(self, result):
        """回放里拖线重算后的过门时间，替换这场比赛的成绩"""
        r = self.race
        for p in r["pilots"]:
            if p.node in result:
                p.passes = list(result[p.node])
                p.peaks = []
        self._refresh()
        rows = self._standings()
        path = self.save_result(rows, None)
        self.last_result = dict(rows=rows, title=r["name"] or "比赛", race=r, path=path)
        if self.cur_event and r.get("heat") is not None:
            self.cur_event.record(r["heat"], [dict(pilot=x["p"].name, laps=len(x["laps"]),
                                                   best=round(x["best"] / 1000, 3) if x["best"] else None,
                                                   total=round(x["total"] / 1000, 3) if x["total"] else None) for x in rows],
                                  str(path or ""))
        win = rows[0]["p"].name if rows and rows[0]["laps"] else ""
        self.banner.setText("已按回放重算成绩" + (f"，第一名：{win}" if win else "") +
                            (f"   已更新：{path.name}" if path else ""))

    def save_result(self, rows, early):
        r = self.race
        if early is not None:
            r["early"] = early
        try:
            folder = Path(self.data_dir()) / "比赛成绩" / r["began"].strftime("%Y-%m-%d")
            folder.mkdir(parents=True, exist_ok=True)
            label = r["name"]
            if self.cur_event and r.get("heat") is not None:
                label = f"{self.cur_event.name}-{self.cur_event.heat_title(r['heat'])}".replace(" ", "")
            stem = r["began"].strftime("%H-%M-%S") + (f"-{label}" if label else "")
            if early is None:           # 回放重算：覆盖同一场的文件
                early = r.get("early", False)
            stem = "".join("_" if ch in '\\/:*?"<>|' else ch for ch in stem)
            out = dict(name=r["name"], began=r["began"].isoformat(timespec="seconds"), laps=r["laps"], track=r["track"],
                       event=self.cur_event.name if self.cur_event and r.get("heat") is not None else "",
                       heat=self.cur_event.heat_title(r["heat"]) if self.cur_event and r.get("heat") is not None else "",
                       min_lap_s=r["min_lap"] / 1000, ended_early=early, results=[],
                       rssi={str(k): v for k, v in r.get("hist", {}).items()},
                       start_ms=r["start"])
            lines = [f"{r['name'] or '比赛'}  {r['began']:%Y-%m-%d %H:%M}  {r['laps']} 圈", ""]
            for k, x in enumerate(rows, 1):
                p = x["p"]
                pc = self.link.to_pc if self.link else (lambda t: t)
                out["results"].append(dict(rank=k, pilot=p.name, dra=self.roster.number(p.name),
                                           channel=self.rows[p.node]["ch"].currentData(),
                                           laps_s=[round(v / 1000, 3) for v in x["laps"]],
                                           best_s=round(x["best"] / 1000, 3) if x["best"] else None,
                                           total_s=round(x["total"] / 1000, 3) if x["total"] else None,
                                           finished=x["done"],
                                           passes_pc_s=[round(pc(t) / 1000, 3) for t in p.passes],
                                           enter=self.rows[p.node]["enter"].value(),
                                           exit=self.rows[p.node]["exit"].value()))
                lines.append(f"第 {k} 名  {self.roster.label(p.name)}  {len(x['laps'])} 圈  总时间 {fmt(x['total'])}  最快一圈 {fmt(x['best'])}")
                lines.append("      每圈：" + "  ".join(fmt(v) for v in x["laps"]))
            (folder / (stem + ".json")).write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
            (folder / (stem + ".txt")).write_text("\n".join(lines) + "\n", encoding="utf-8")
            return folder / (stem + ".txt")
        except OSError:
            return None

    def _tick(self):
        r = self.race
        if r and r["start"] is not None and not r.get("done") and self.link:
            self.clock.setText(fmt(self.link.timer_now() - r["start"]))
        self._update_views()

    def _update_views(self):
        """每个选手画面上叠他自己的计时"""
        r = self.race
        ranks = {}
        if r and r["start"] is not None:
            for k, x in enumerate(self._standings(), 1):
                ranks[x["p"].node] = (k, x)
        now = self.link.timer_now() if self.link else 0
        mono = time.monotonic()
        self.live.refresh_frames()
        for i, (row, v) in enumerate(zip(self.rows, self.live.views)):
            name = row["pilot"].currentText().strip()
            inf = dict(on=row["on"].isChecked(), name=name, label=self.roster.label(name) if name else "", ch=row["ch"].currentData() or "")
            if i in ranks and r:
                k, x = ranks[i]
                p = x["p"]
                inf["rank"] = k if len(ranks) > 1 and p.passes else None
                inf["laps"] = f"第 {min(len(x['laps']) + 1, r['laps'])} / {r['laps']} 圈" if not x["done"] else f"{r['laps']} 圈完成"
                inf["last"] = f"上一圈 {fmt(x['last'])}" if x["last"] else ""
                inf["best"] = f"最快 {fmt(x['best'])}" if x["best"] else ""
                if x["done"]:
                    inf.update(state=True, big=fmt(x["total"]), state_text="完成！总时间")
                elif p.passes and not r.get("done"):
                    inf.update(state=True, big=fmt(now - p.passes[-1]))
                elif p.passes:
                    inf.update(state=True, big=fmt(x["total"]) if x["total"] else "-", state_text="比赛结束")
                else:
                    inf.update(state=True, big="--.--", state_text="等待过门开始计时" if not r.get("done") else "没有成绩")
            v.info = inf
            v.now = mono
            v.update()

    def shutdown(self):
        if self.link:
            self.link.close()
        self.live.stop_all()
        self.voice.close()

    def _start_look(self, running):
        self.start_btn.setText("■ 结束比赛" if running else "▶ 开始比赛")
        col = "#ff3b30" if running else "#34c759"
        self.start_btn.setStyleSheet(f"QPushButton {{ background: {col}; color: white; font-size: 22px; font-weight: bold;"
                                     f" border: none; border-radius: 12px; padding: 0 24px; }}")

    def _fold_saved(self, key, shut):
        self.cfg.setdefault("open", {})[key] = not shut
        self.s.save()

    # ---- 实时画面
    def activate(self, force=False, prefer=""):
        """切到比赛模式时：找采集卡，打开各路画面。prefer = 训练模式正在用的采集卡，哪一路都没选它就给第一个打勾的选手"""
        devices = ft.list_video_devices()           # 每次都重新找：中途插上的采集卡也能选
        if devices != self.devices or force:
            self.devices = devices
            self.live.stop_all()
            self.live.set_devices(self.devices, self.cfg.get("views", []))
        boxes = self.live.boxes
        if prefer and prefer != ft.TEST_DEVICE and prefer in devices and all(b.currentText() != prefer for b in boxes):
            on = [i for i, r in enumerate(self.rows) if r["on"].isChecked()] or [0]
            self.release_device(prefer)
            boxes[on[0]].setCurrentText(prefer)       # 会自己打开画面并记住
        for name in {b.currentText() for b in boxes} - {NO_VIEW, ft.TEST_DEVICE}:
            self.release_device(name)
        self.live.start_all()

    def deactivate(self):
        self.live.stop_all()

    def _view_device(self, i, name):
        views = self.cfg.setdefault("views", [NO_VIEW] * NODES)
        while len(views) < NODES:
            views.append(NO_VIEW)
        views[i] = name
        self.s.save()
        if name not in (NO_VIEW, ft.TEST_DEVICE):
            self.release_device(name)

    def say(self, text):
        if self.voice_on.isChecked():
            self.voice.say(text)

    # ---- 赛事
    def _event_ui(self):
        ev = self.cur_event
        for b in (self.ev_btn, self.next_btn, self.quit_ev):
            b.setEnabled(ev is not None)
        if not ev:
            self.event_label.setText("没有进行中的赛事。人多于 4 个时，新建一个赛事，软件自动分组、算积分。")
            return
        nxt = ev.next_heat()
        done = sum(h["done"] for h in ev.heats)
        now = f"现在飞：{ev.heat_title(self.heat)}（{'、'.join(ev.heats[self.heat]['pilots'])}）" if self.heat is not None else ""
        if nxt is None:
            tail = "全部飞完了。" + ("" if ev.has_final() else "打开「分组和积分榜」生成决赛。")
        else:
            tail = f"下一组：{ev.heat_title(nxt)}（{'、'.join(ev.heats[nxt]['pilots'])}）"
        self.event_label.setText(f"赛事「{ev.name}」 已飞 {done}/{len(ev.heats)} 组。" + (now or tail))
        self.next_btn.setEnabled(nxt is not None and self.heat is None)

    def set_event(self, ev, load=True):
        self.cur_event = ev
        self.heat = None
        if ev:
            self.cfg["event"] = str(ev.path)
        else:
            self.cfg.pop("event", None)
        self.s.save()
        self._event_ui()
        if ev and load:
            self.load_next_heat()

    def new_event(self):
        names = list(dict.fromkeys(self.students() + list(self.roster.data)))
        dlg = NewEventDialog(names, NODES, self)
        if not dlg.exec():
            return
        root = Path(self.data_dir())
        name = dlg.name.text().strip()
        if (root / "比赛成绩" / "赛事" / f"{name}.json").exists() and QMessageBox.question(
                self, "新建赛事", f"已经有一个叫「{name}」的赛事，覆盖它？") != QMessageBox.Yes:
            return
        ev = Event.create(root, name, dlg.pilots, dlg.rounds.value(), dlg.heat_size.value(), dlg.pts,
                          self.s.data.get("student_channels", {}))
        self.set_event(ev)
        self.show_event()

    def open_event(self):
        files = Event.list(self.data_dir())
        if not files:
            QMessageBox.information(self, "赛事", "还没有赛事，先点「新建赛事」。")
            return
        name, ok = QInputDialog.getItem(self, "打开赛事", "选一个赛事接着飞：", [f.stem for f in files], 0, False)
        if ok:
            self.set_event(Event.load(next(f for f in files if f.stem == name)), load=False)
            self.show_event()

    def show_event(self):
        if not self.cur_event:
            return
        dlg = EventDialog(self.cur_event, self.roster.label, self)
        dlg.exec()
        self._event_ui()
        if dlg.chosen is not None:
            self.load_heat(dlg.chosen)
        elif dlg.want_poster:
            self.event_poster()

    def load_next_heat(self):
        if self.cur_event and (i := self.cur_event.next_heat()) is not None:
            self.load_heat(i)

    def load_heat(self, i):
        if self.race and not self.race.get("done"):
            QMessageBox.information(self, "赛事", "先结束正在飞的这一场。")
            return
        h = self.cur_event.heats[i]
        if len(h["pilots"]) > NODES:
            QMessageBox.warning(self, "赛事", f"这一组有 {len(h['pilots'])} 人，计时器只有 {NODES} 路。")
            return
        for k, r in enumerate(self.rows):
            r["pilot"].blockSignals(True)
            r["on"].blockSignals(True)
            if k < len(h["pilots"]):
                if r["pilot"].findText(h["pilots"][k]) < 0:
                    r["pilot"].addItem(h["pilots"][k])
                r["pilot"].setCurrentText(h["pilots"][k])
            r["on"].setChecked(k < len(h["pilots"]))
            r["pilot"].blockSignals(False)
            r["on"].blockSignals(False)
            self._row_changed(k)
        self.heat = i
        self.race = None
        self.table.setRowCount(0)
        self.laps_list.clear()
        self.clock.setText("0.00")
        chans = [self.rows[k]["ch"].currentData() for k in range(len(h["pilots"]))]
        clash = len(set(chans)) < len(chans)
        self.banner.setText(f"{self.cur_event.heat_title(i)}：{'、'.join(h['pilots'])}" +
                            ("   注意：这一组有人频道相同，请先改开再开始" if clash else "   准备好就点「开始比赛」"))
        self.say(f"{self.cur_event.heat_title(i)}，" + "，".join(h["pilots"]) + "，请准备")
        self._event_ui()

    # ---- 海报和成长记录
    def _save_poster(self, img, folder: Path, stem: str):
        try:
            folder.mkdir(parents=True, exist_ok=True)
            path = folder / f"{stem}-海报.png"
            img.save(str(path))
        except OSError:
            path = None
        QApplication.clipboard().setImage(img)
        msg = "海报已经复制好了，打开微信直接粘贴（Ctrl+V）就能发。"
        if path:
            msg += f"\n\n也保存在：{path}"
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
        QMessageBox.information(self, "成绩海报", msg)

    def race_poster(self):
        res = self.last_result
        if not res:
            return
        r = res["race"]
        title = res["title"]
        if r.get("heat") is not None and self.cur_event:
            title = f"{self.cur_event.name} · {self.cur_event.heat_title(r['heat'])}"
        rows = [dict(rank=k, name=x["p"].name, label=self.roster.label(x["p"].name), photo=self.roster.photo(x["p"].name),
                     cells=[f"{len(x['laps'])} 圈", fmt(x["best"]), fmt(x["total"])],
                     podium=f"总时间 {fmt(x['total'])} 秒" if x["total"] else "")
                for k, x in enumerate(res["rows"], 1)]
        sub = f"{r['began']:%Y-%m-%d %H:%M}   {r['laps']} 圈" + (f"   {r['track']}" if r["track"] else "")
        img = make_poster(title, sub, rows, ["圈数", "最快一圈", "总时间"], "最快一圈、总时间单位：秒")
        folder = res["path"].parent if res["path"] else Path(self.data_dir()) / "比赛成绩"
        self._save_poster(img, folder, res["path"].stem if res["path"] else r["began"].strftime("%H-%M-%S"))

    def event_poster(self):
        ev = self.cur_event
        rows = ev.standings()
        has_final = any(t.get("final") for t in rows)
        out = [dict(rank=k, name=t["pilot"], label=self.roster.label(t["pilot"]), photo=self.roster.photo(t["pilot"]),
                    cells=[f"{t['points']} 分", f"{t['best']:.2f}" if t["best"] else "-"],
                    podium=f"积分 {t['points']}" + (f" · 决赛第 {t['final']}" if t.get("final") else ""))
               for k, t in enumerate(rows, 1)]
        done = sum(h["done"] for h in ev.heats)
        sub = ("总成绩（决赛定名次）" if has_final else f"积分榜（已飞 {done}/{len(ev.heats)} 组）") + \
            datetime.now().strftime("   %Y-%m-%d")
        img = make_poster(ev.name, sub, out, ["积分", "最快一圈"], "积分：每组第 1~4 名 " + "/".join(str(v) for v in ev.d["points"]) + " 分")
        self._save_poster(img, ev.path.parent, ev.name)

    def open_growth(self):
        names = list(dict.fromkeys(self.students() + list(self.roster.data)))
        current = self.rows[0]["pilot"].currentText().strip()
        GrowthDialog(self.data_dir(), names, current, self).exec()


def beep(freq, ms):
    if sys.platform == "win32":
        import winsound
        threading.Thread(target=winsound.Beep, args=(freq, ms), daemon=True).start()
