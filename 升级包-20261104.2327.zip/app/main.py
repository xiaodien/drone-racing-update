import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

from PySide6.QtCore import QEvent, QObject, Qt, QTimer, Signal
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (QCheckBox, QSizePolicy, QApplication, QButtonGroup, QComboBox, QDialog, QDialogButtonBox,
                               QDoubleSpinBox, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QMainWindow,
                               QMessageBox, QPlainTextEdit, QPushButton, QSpinBox, QSplitter, QStackedWidget, QTabWidget,
                               QVBoxLayout, QWidget, QFrame, QMenu)

from app import ffmpeg_tools as ft
from app.calibration import CalibrationWizard
from app.canvas import VideoCanvas
from app.capture import CaptureEngine
from app.config import APP_DIR, INSTALLED, IS_WINDOWS, Settings, desktop_dir
from app.library import LibraryPanel
from app.overlay import TRAIL_S
from app.recorder import FlightRecorder
from app.replay import ReplayView
from app.radio_test import RadioTestDialog
from app.sticks import SIM_NAME, Calibration, JoystickSource, edgetx_preset, is_wireless, is_known_radio

APP_NAME = "无人机竞速 · 打杆教学 V2"
def _version():
    """首页显示的版本：读 app/version.json 的 build（20261029.1150 -> V2 · 2026-10-29 11:50）"""
    import json
    try:
        b = str(json.loads((Path(__file__).parent / "version.json").read_text(encoding="utf-8")).get("build", ""))
        return f"V2 · {b[:4]}-{b[4:6]}-{b[6:8]} {b[9:11]}:{b[11:13]}" if len(b) == 13 else f"V2 · {b}"
    except (OSError, ValueError):
        return "V2"


VERSION = _version()


CAPTURE_STYLE = ("QPushButton { background: #34c759; color: white; font-weight: bold; border: none; border-radius: 8px;"
                 " padding: 5px 16px; } QPushButton:hover { background: #2fb350; }"
                 "QPushButton:disabled { background: #c7c7cc; color: white; }")


def _vline():
    """工具栏里分组的竖线"""
    f = QFrame()
    f.setFrameShape(QFrame.VLine)
    f.setStyleSheet("color: #d2d2d7;")
    f.setFixedWidth(12)
    return f


def _tag(text):
    """工具栏分组名（小一点、灰一点）"""
    lab = QLabel(text)
    lab.setStyleSheet("color: #6e6e73; font-weight: bold; padding-left: 2px;")
    return lab


class SettingsDialog(QDialog):
    def __init__(self, s: Settings, parent=None):
        super().__init__(parent)
        self.setWindowTitle("设置")
        self.s = s
        self.data_dir = QLineEdit(s["data_dir"])
        browse = QPushButton("选择…")
        browse.clicked.connect(self._browse)
        row = QHBoxLayout()
        row.addWidget(self.data_dir, 1)
        row.addWidget(browse)
        self.preroll = QDoubleSpinBox(minimum=0, maximum=10, singleStep=0.5, suffix=" 秒", value=s["preroll_s"])
        self.postroll = QDoubleSpinBox(minimum=0, maximum=10, singleStep=0.5, suffix=" 秒", value=s["postroll_s"])
        self.min_flight = QDoubleSpinBox(minimum=0, maximum=60, singleStep=1, suffix=" 秒", value=s["min_flight_s"])
        self.offset = QSpinBox(minimum=-1000, maximum=1000, singleStep=10, suffix=" 毫秒", value=s["sync_offset_ms"])
        form = QFormLayout(self)
        form.addRow("录像保存位置", row)
        form.addRow("解锁前多录", self.preroll)
        form.addRow("上锁后多录", self.postroll)
        form.addRow("短于这个时间不保存", self.min_flight)
        form.addRow("默认同步微调", self.offset)
        from app.updater import current_build
        self.update_url = QLineEdit(s.data.get("update_url", ""))
        self.update_url.setPlaceholderText("网址或共享文件夹，里面有 latest.json")
        self.auto_update = QCheckBox("打开软件时自动检查")
        self.auto_update.setChecked(s.data.get("auto_update", True))
        form.addRow("更新地址", self.update_url)
        form.addRow(f"现在版本 {current_build() or '未知'}", self.auto_update)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        form.addRow(bb)

    def _browse(self):
        d = QFileDialog.getExistingDirectory(self, "录像保存位置", self.data_dir.text())
        if d:
            self.data_dir.setText(d)

    def apply(self):
        self.s.data.update(data_dir=self.data_dir.text(), preroll_s=self.preroll.value(),
                           postroll_s=self.postroll.value(), min_flight_s=self.min_flight.value(),
                           sync_offset_ms=self.offset.value(), update_url=self.update_url.text().strip(),
                           auto_update=self.auto_update.isChecked())
        self.s.save()


CHANNEL_NAMES = [f"R{i}" for i in range(1, 9)] + ["F2", "F4"] + [f"L{i}" for i in range(1, 9)]


class AiCoachDialog(QDialog):
    """AI 教学和比对：入口先放好，功能以后做。"""
    PLANNED = [
        ("飞行比对", "选两段录像（学员和老师，或者自己最快的一圈），并排同步播放，打杆曲线叠在一起看差别。"),
        ("分段分析", "按门切成一段一段，看每个门比最快一圈慢了多少。"),
        ("打杆习惯", "找出油门太猛、转弯提前或太晚、摇杆抖动这些问题。"),
        ("AI 点评", "看录像自动指出哪个门飞得不好，给出练习建议。"),
        ("家里 NAS 同步", "飞完自动上传到家里 NAS，用 M5 Pro 训练模型，飞场电脑再同步下来使用。"),
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("AI 教学和比对")
        self.resize(560, 420)
        lay = QVBoxLayout(self)
        head = QLabel("AI 教学和比对（开发中）")
        head.setStyleSheet("font-size: 18px; font-weight: bold; color: #6a1b9a;")
        lay.addWidget(head)
        lay.addWidget(QLabel("下面这些功能还没做好，先留好入口："))
        for title, text in self.PLANNED:
            b = QPushButton(title)
            b.setEnabled(False)
            b.setMinimumHeight(34)
            b.setFixedWidth(120)
            t = QLabel(text)
            t.setWordWrap(True)
            t.setStyleSheet("color: #555;")
            row = QHBoxLayout()
            row.addWidget(b)
            row.addWidget(t, 1)
            lay.addLayout(row)
        lay.addStretch()
        close = QPushButton("关闭")
        close.clicked.connect(self.accept)
        lay.addWidget(close, 0, Qt.AlignRight)


class StudentChannelsDialog(QDialog):
    """每个学员的图传频道"""

    def __init__(self, names, chans, default, parent=None):
        super().__init__(parent)
        self.setWindowTitle("学员频道")
        self.boxes = {}
        form = QFormLayout(self)
        form.addRow(QLabel("给每个学员选好图传频道。切换学员时自动换过去，比赛模式选人时也自动带上。\n"
                           "同时飞的人要用不同频道；L 频段普通计时器模块收不到。"))
        for n in names:
            box = QComboBox()
            box.addItems(CHANNEL_NAMES)
            box.setCurrentText(chans.get(n, default))
            form.addRow(n, box)
            self.boxes[n] = box
        self.keep = {k: v for k, v in chans.items() if k not in names}
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        form.addRow(bb)

    def result_map(self):
        return dict(self.keep, **{n: b.currentText() for n, b in self.boxes.items()})


class MainWindow(QMainWindow):
    encoder_found = Signal(str)
    radio_tool_installed = Signal(str)

    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(1400, 860)
        self.s = Settings()
        # 录像文件夹被改名或者搬走了：先记下来，窗口打开后让用户重新选（不要悄悄建一个空的）
        if self.s.data.get("data_dir_chosen") and not Path(self.s["data_dir"]).is_dir():
            self._find_lost_dir()
        self.engine = CaptureEngine()
        self.source = JoystickSource(self.s["joystick_name"])
        self.calibration = Calibration(self.s["calibration"])
        self.recorder = FlightRecorder(self.engine, self.source)
        from app.battery import TrainingLog
        # 电池记录：不录像也记每次解锁到锁桨，数电池、判断炸机（按学员分开记，以后多人同时飞也用它）
        self.trainlog = TrainingLog(lambda: Path(self.s["data_dir"]), gap_s=float(self.s.data.get("battery_gap_s", 60)))
        self._volt_finder, self._volt_radio = None, None   # 自动找飞机电压在哪个通道（方案 B）
        self._sd_scan_n, self._sd_scanning = 0, False       # 遥控器插 U 盘模式：自动拷 BatToCH 小程序进去
        self._apply_recorder_settings()
        self._cal_for = ""
        self.modes: list[dict] = []

        # ---- top bar -------------------------------------------------------
        self.device_box = QComboBox()
        self.device_box.setMinimumWidth(220)
        self.mode_box = QComboBox()
        self.mode_box.setMinimumWidth(170)
        self.capture_btn = QPushButton("开始采集")
        self.capture_btn.clicked.connect(self.toggle_capture)
        self.capture_btn.setStyleSheet(CAPTURE_STYLE)
        refresh_btn = QPushButton("刷新")
        refresh_btn.clicked.connect(self.load_devices)
        self.channel_box = QComboBox()
        self.channel_box.addItems(CHANNEL_NAMES)
        self.channel_box.setCurrentText(self.s["vtx_channel"])
        self.channel_box.setStyleSheet("font-weight: bold;")
        self.channel_box.currentTextChanged.connect(self._channel_changed)
        self.radio_label = QLabel()
        calib_btn = QPushButton("遥控器校准")
        calib_btn.clicked.connect(self.open_wizard)
        test_btn = QPushButton("遥控器测试")
        test_btn.clicked.connect(lambda: RadioTestDialog(self.source, self).exec())
        self.rec_btn = QPushButton("● 开始录制")
        self.rec_btn.setMinimumHeight(34)
        self.rec_btn.setMinimumWidth(170)
        self.rec_btn.clicked.connect(self.recorder.toggle_manual)
        self.rec_mode = QComboBox()             # 录像方式：解锁开始、锁桨结束 / 只用按钮
        self.rec_mode.addItem("解锁录像（解锁开始，锁桨结束）", True)
        self.rec_mode.addItem("手动录像（点按钮开始/停止）", False)
        self.rec_mode.setCurrentIndex(0 if self.s["auto_record"] else 1)
        self.rec_mode.currentIndexChanged.connect(self._rec_mode_changed)
        self.arm_label = QLabel()               # 遥控器现在是解锁还是上锁（跟遥控器同步）
        self.arm_label.setMinimumWidth(150)
        self.rec_hint = QLabel()
        self.rec_hint.setStyleSheet("color: gray;")
        self.battery_label = QLabel()            # 🔋 第几块电池、这块飞了多久、今天几块、炸机几次
        self.battery_label.setStyleSheet("font-weight: bold; color: #1d1d1f;")
        self.battery_btn = QPushButton("🔋 电池记录")
        self.battery_btn.setToolTip("这节课用了几块电池、每小时几块、炸机率，不录像也会记")
        self.battery_btn.clicked.connect(self.open_battery)
        self._apply_recorder_settings()
        settings_btn = QPushButton("⚙ 设置")
        menu = QMenu(settings_btn)                  # 不常用的收进「设置」菜单，上面一排不挤
        menu.addAction("成长记录…", self.open_growth)
        menu.addAction("电池记录…", self.open_battery)
        menu.addAction("全班总结…", lambda: self._show_class_summary(False))
        menu.addSeparator()
        menu.addAction("设置…", self.open_settings)
        menu.addAction("录像保存位置…", self.choose_data_dir)
        menu.addAction("诊断", self.run_diagnose)
        menu.addSeparator()
        from app.updater import Updater
        self.updater = Updater(self)
        menu.addAction("检查更新…", lambda: self.updater.check(manual=True))
        settings_btn.setMenu(menu)

        # 训练模式 / 比赛模式
        self.mode_btns = QButtonGroup(self)
        mode_row = QHBoxLayout()
        for k, text in enumerate(("训练模式", "比赛模式")):
            b = QPushButton(text)
            b.setCheckable(True)
            b.setMinimumSize(b.fontMetrics().horizontalAdvance(text) * 2 + 48, 36)
            b.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            b.setStyleSheet("QPushButton { font-size: 15px; font-weight: bold; padding: 2px 16px; min-width: 92px;"
                            " min-height: 30px; border-radius: 10px; }"
                            "QPushButton:checked { background: #007aff; color: white; border-color: #007aff; }")
            self.mode_btns.addButton(b, k)
            mode_row.addWidget(b)
        self.mode_btns.idToggled.connect(lambda k, on: on and self.set_mode(k))

        # 第一排：模式按钮 + 训练用的工具按钮；第二排：采集卡、频道、遥控器（都只在训练模式显示）
        self.train_tools = QWidget()
        tt = QHBoxLayout(self.train_tools)
        tt.setContentsMargins(0, 0, 0, 0)
        for w in (settings_btn,):                # AI、成长记录、赛道搭建、黑羊都从首页进，这一排只留「设置」
            tt.addWidget(w)
        bar = QHBoxLayout()
        home_btn = QPushButton("⌂ 首页")
        home_btn.setToolTip("回到首页")
        home_btn.setMinimumHeight(36)
        home_btn.setStyleSheet("QPushButton { font-size: 15px; font-weight: bold; color: #007aff; border-radius: 10px;"
                               " padding: 2px 14px; }")
        home_btn.clicked.connect(lambda: self.root.setCurrentWidget(self.home))
        bar.addWidget(home_btn)
        bar.addSpacing(6)
        bar.addLayout(mode_row)
        from app.schedule import ClassClock
        self.clock = ClassClock(self.s)           # 日期、时间、星期几；点开设上课时间和铃声
        self.clock.rang.connect(lambda msg: self.statusBar().showMessage(f"🔔 {msg}", 15000))
        self.clock.rang.connect(self._class_over)          # 下课铃：弹出这节课的全班评分
        bar.addSpacing(12)
        bar.addWidget(self.clock)
        self.bell_btn = bell_btn = QPushButton("🔔 上课铃声")
        bell_btn.setToolTip("设上午上课、中午下课、下午上课、下午下课的时间和铃声")
        bell_btn.setMinimumHeight(34)
        bell_btn.clicked.connect(self.clock.edit)
        bar.addWidget(bell_btn)
        self.take_btn = QPushButton("📣 老师接管")
        self.take_btn.setToolTip("填老师接管的时间，到点响铃，接管期间顶上显示「老师接管中」")
        self.take_btn.setMinimumHeight(34)
        self.take_btn.clicked.connect(self.clock.edit_takeover)
        bar.addWidget(self.take_btn)
        bar.addStretch()
        bar.addWidget(self.train_tools)
        self.train_bar = QWidget()          # 训练模式才用的这一排，比赛模式整排藏起来
        tb = QHBoxLayout(self.train_bar)
        tb.setContentsMargins(0, 0, 0, 0)
        chans_btn = QPushButton("学员频道…")
        chans_btn.setToolTip("给每个学员填好自己的图传频道，切换学员时自动换过去，比赛时也自动用")
        chans_btn.clicked.connect(self.open_student_channels)
        for w in (_tag("图传画面"), self.device_box, self.mode_box, refresh_btn, self.capture_btn, _vline(),
                  _tag("图传频道"), self.channel_box, chans_btn, _vline(),
                  _tag("遥控器"), self.radio_label, calib_btn, test_btn):
            tb.addWidget(w)
        tb.addStretch()
        for btn in (refresh_btn, self.capture_btn, chans_btn, calib_btn, test_btn, 
                    settings_btn):
            btn.setMinimumWidth(btn.fontMetrics().horizontalAdvance(btn.text()) + 28)
        self.radio_label.setText("未连接")
        self.radio_label.setMinimumWidth(self.radio_label.fontMetrics().horizontalAdvance("未连接") + 8)
        self._set_rec_button("先点上面「开始采集」", "#aeaeb2")
        self.arm_label.setText("遥控器未连接")
        self.arm_label.setStyleSheet("color: #888; font-weight: bold;")

        # ---- main area -----------------------------------------------------
        self.library = LibraryPanel(self.s.data_dir, self.s["current_student"])
        self.library.student_changed.connect(self._student_changed)
        self.library.is_recording = lambda: self.recorder.state != "idle"
        self.library.releasing.connect(self._release_student)
        self.library.recording_opened.connect(self.open_recording)
        self.library.choose_folder.connect(self._apply_data_dir)
        self._student_changed(self.library.current)
        self.live = VideoCanvas("点上面的「开始采集」显示图传画面")
        self._shown_t, self._shown_n, self._shown_fps = time.perf_counter(), 0, 0.0
        self.live.channel = self.s["vtx_channel"]
        self.replay = ReplayView()
        self.replay.back_to_live.connect(lambda: self.tabs.setCurrentIndex(0))
        self.tabs = QTabWidget()
        live_page = QWidget()
        live_lay = QVBoxLayout(live_page)
        live_lay.setContentsMargins(0, 0, 0, 0)
        live_lay.addWidget(self.live, 1)
        rec_panel = QFrame()
        rec_panel.setObjectName("recPanel")
        rec_panel.setStyleSheet("#recPanel { background: #ffffff; border-top: 1px solid #e5e5ea;"
                                " border-bottom-left-radius: 10px; border-bottom-right-radius: 10px; }")
        rec_row = QHBoxLayout(rec_panel)
        rec_row.setContentsMargins(8, 4, 8, 4)
        rec_row.addWidget(QLabel("录像方式"))
        rec_row.addWidget(self.rec_mode)
        rec_row.addWidget(self.rec_btn)
        rec_row.addSpacing(12)
        rec_row.addWidget(self.arm_label)
        rec_row.addWidget(self.rec_hint, 1)
        rec_row.addWidget(self.battery_label)
        rec_row.addWidget(self.battery_btn)
        live_lay.addWidget(rec_panel)
        self.tabs.addTab(live_page, "实时")
        self.tabs.addTab(self.replay, "回看")
        split = QSplitter()
        split.addWidget(self.library)
        split.addWidget(self.tabs)
        split.setStretchFactor(1, 1)
        split.setSizes([260, 1140])

        from app.race import RaceView
        self.race = RaceView(self.s, lambda: [p.name for p in self.library.students()], lambda: self.s["data_dir"],
                             self.library.refresh)
        self.pages = QStackedWidget()
        self.pages.addWidget(split)
        self.pages.addWidget(self.race)
        self.race.release_device = self._release_device_for_race

        central = QWidget()
        lay = QVBoxLayout(central)
        lay.addLayout(bar)
        lay.addWidget(self.train_bar)
        lay.addWidget(self.pages, 1)
        from app.home import HomePage
        self.home = HomePage("无人机竞速 · 打杆教学", VERSION, clock=ClassClock(self.s, ring=False))
        self.home.chosen.connect(self.go_page)
        self.root = QStackedWidget()            # 最上面一层：首页 / 工作页面（训练、比赛）
        self.root.addWidget(self.home)
        self.root.addWidget(central)
        self.setCentralWidget(self.root)

        self.stat_label = QLabel()
        self.statusBar().addWidget(self.stat_label)

        # ---- wiring ----------------------------------------------------------
        self.engine.frame_ready.connect(self._on_frame)
        self.engine.stopped.connect(self._on_capture_stopped)
        self.recorder.saved.connect(self._on_saved)
        self.recorder.failed.connect(lambda msg: QMessageBox.warning(self, "录像", msg))
        self.recorder.notice.connect(lambda msg: self.statusBar().showMessage(msg, 10000))
        self.encoder_found.connect(self._on_encoder)
        self.radio_tool_installed.connect(self._on_radio_tool)
        self.device_box.currentTextChanged.connect(self._device_changed)
        self.slow_timer = QTimer(self, interval=200, timeout=self._tick)
        self.slow_timer.start()
        self.stick_timer = QTimer(self, interval=33, timeout=self._stick_tick)
        self.stick_timer.start()

        self.load_devices()
        if self.s["encoder"]:
            self._on_encoder(self.s["encoder"])
        else:
            self.capture_btn.setEnabled(False)
            self.capture_btn.setText("检测显卡中…")
            threading.Thread(target=lambda: self.encoder_found.emit(ft.detect_encoder()), daemon=True).start()

        self.mode_btns.button(1 if self.s.data.get("mode") == "race" else 0).setChecked(True)

    # ---- 模式 -------------------------------------------------------------
    def set_mode(self, k):
        self.pages.setCurrentIndex(k)
        self.s["mode"] = "race" if k == 1 else "train"
        self.bell_btn.setVisible(k == 0)
        self.take_btn.setVisible(k == 0)
        self.train_bar.setVisible(k == 0)
        self.train_tools.setVisible(k == 0)
        if k == 1:
            self.race.activate(prefer=self.device_box.currentText())
        else:
            self.race.deactivate()
        if k == 1:
            self.race.fill_students()

    def _release_device_for_race(self, name):
        """比赛模式要用这个采集卡：训练模式正在用就先停掉（一个采集卡同时只能一个程序打开）"""
        if self.engine.running and self.device_box.currentText() == name and self.recorder.state == "idle":
            self.toggle_capture()

    def open_battery(self):
        from app.battery_view import BatteryDialog

        def set_gap(v):
            self.s["battery_gap_s"] = v
            self.s.save()
        def add_student(name):
            """和左边学员列表一样：录像文件夹里一个学员一个文件夹"""
            (Path(self.s["data_dir"]) / name).mkdir(parents=True, exist_ok=True)
            self.library.refresh()
            return name

        def set_goal(g):
            self.s["battery_goal"] = g
            self.s.save()

        def volt_status():
            from app.battery import VOLT_VALID
            radio = self.source.connected_name
            if not radio:
                return "飞机电压：遥控器没连上"
            ch = self.s.data.get("volt_ch", {}).get(radio)
            if ch is None:
                return ("飞机电压：还没找到（这台遥控器没设，或者还没解锁飞过一次）。现在按锁桨间隔猜换电池。"
                        "点「怎么设」看遥控器怎么加。")
            latest = self.source.latest()
            v = latest[1][ch] if latest and ch < len(latest[1]) else None
            if v is None or abs(v) > VOLT_VALID:
                return f"飞机电压：CH{ch + 1}（自动找到），现在没有回传（飞机没插电？）。"
            t = self.trainlog.trackers.get(self.s["current_student"])
            pct = t.volt_pct(v) if t else None
            if pct is None:
                return f"飞机电压：CH{ch + 1}（自动找到），还在学满电和没电是多少（飞完一块电池就学会），先按锁桨间隔猜。"
            return f"飞机电压：CH{ch + 1}（自动找到），现在电量约 {pct}%。按电压判断换电池。"

        def volt_reset():
            self.s.data.setdefault("volt_ch", {}).pop(self.source.connected_name, None)
            self.s.save()
            self._volt_radio = None

        BatteryDialog(self.trainlog, [p.name for p in self.library.students()], self.s["current_student"], self,
                      on_gap=set_gap, volt_status=volt_status, volt_reset=volt_reset,
                      goal=self.s.data.get("battery_goal"), on_goal=set_goal, add_student=add_student).exec()

    def _battery_samples(self, t0, t1):
        """t0..t1（time.time()）之间的打杆，换算成 time.time() 时间，给炸机判断用"""
        off = time.time() - time.perf_counter()
        out = []
        for smp in self.source.between(t0 - off, t1 - off):
            v = self.calibration.apply(smp)
            if v:
                out.append((smp[0] + off, v))
        return out

    def _scan_radio_sd(self):
        try:
            from app.battery import install_tool
            done = install_tool()
        except Exception:  # noqa: BLE001
            done = []
        finally:
            self._sd_scanning = False
        if done:
            self.radio_tool_installed.emit(", ".join(str(d) for d in done))

    def _on_radio_tool(self, drives):
        msg = (f"已把小程序 BatToCH 拷进遥控器（{drives}）。拔掉 USB，插上飞机电池，"
               "在遥控器 SYS →「工具」里运行一次 BatToCH，它会自动加好电压混控。")
        self.statusBar().showMessage("🔋 " + msg, 60000)
        QMessageBox.information(self, APP_NAME, msg)

    def _class_over(self, msg):
        if "下课" in msg:
            self._show_class_summary(True)

    def _show_class_summary(self, this_class):
        from app import battery as B
        from app.battery_view import ClassSummary
        pilots = list(dict.fromkeys([p.name for p in self.library.students()] + B.pilots_of(self.s["data_dir"])))
        day = B.day_of(time.time())
        if this_class and not B.class_report(self.trainlog, pilots, day, None, True):
            return                      # 这节课没人飞，不弹
        dlg = ClassSummary(self.trainlog, pilots, day, self.s.data.get("battery_goal"), self, this_class)
        dlg.setModal(False)
        dlg.show()
        self._summary_dlg = dlg

    def _battery_warn(self, pilot, ev):
        """效率不够就弹窗提醒（同一个学员 15 分钟最多提醒一次，不挡操作）"""
        if not ev or not ev["low"]:
            return
        t = self.trainlog.trackers.get(pilot)
        flying = t is not None and t.armed_at is not None
        if not flying and ev.get("last_end", 0) < time.time() - 10 * 60:
            return                      # 这个学员已经不在飞了（下课、换人），不提醒
        last = getattr(self, "_warned", {})
        self._warned = last
        now = time.time()
        if now - last.get(pilot, 0) < 15 * 60:
            return
        last[pilot] = now
        box = QMessageBox(QMessageBox.Warning, "训练效率不够",
                          f"{pilot}：现在每小时 {ev['rate']:.1f} 块电池，目标 {ev['target']:g} 块"
                          f"（完成率 {ev['pct']:.0f}%）。\n\n少等待、换电池快一点，下一块马上飞。", QMessageBox.Ok, self)
        box.setModal(False)
        box.show()
        self._warn_box = box

    def _feed_battery(self, values):
        pilot = self.s["current_student"]
        if self.s.data.get("mode") == "race":           # 比赛模式有自己的成绩，这边不记
            self.trainlog.idle()
            return
        latest = self.source.latest()
        link = bool(values) and self.calibration.valid and latest is not None \
            and time.perf_counter() - latest[0] < 1.0
        lb = self.calibration.data.get("link_button") if self.calibration.valid else None
        if link and lb is not None:
            link = bool(latest[2] >> lb & 1)            # 无线 / ELRS 接收机：听得到遥控器才算有信号
        armed = bool(values and values["armed"])
        volt = None
        radio = self.source.connected_name
        if link and radio:
            chs = self.s.data.setdefault("volt_ch", {})     # 每台遥控器的电压通道，自动找到后记住
            ch = chs.get(radio)
            if ch is None:
                from app.battery import VoltFinder
                if self._volt_radio != radio:
                    self._volt_finder, self._volt_radio = VoltFinder(), radio
                found = self._volt_finder.feed(latest[1], armed)
                if found is not None:
                    chs[radio] = found
                    self.s.save()
                    self.statusBar().showMessage(f"🔋 找到飞机电压在 CH{found + 1}，以后按电压判断换电池", 15000)
            elif ch < len(latest[1]):
                volt = latest[1][ch]
        try:
            self.trainlog.feed(pilot, time.time(), armed, link, self._battery_samples, volt)
            st = self.trainlog.status(pilot)
        except OSError:
            return
        from app import battery as B
        goal = self.s.data.get("battery_goal")
        summ = B.summary(self.trainlog.flights(pilot, B.day_of(time.time())))
        ev = B.evaluate(goal, summ)
        if ev:
            ev["last_end"] = summ["last"] or 0
        if st["batteries"]:
            text = f"🔋 今天 {st['batteries']} 块" + (f"/{goal['batteries']}" if goal and goal.get("batteries") and not goal.get("hours") else "")
            if summ["per_hour"] is not None:
                text += f" · 每小时 {summ['per_hour']:.1f} 块"
            if ev and ev["score"] is not None:
                text += f" · {ev['score']} 分 {ev['grade']}"
        else:
            text = "🔋 今天还没飞"
        self._battery_warn(pilot, ev)
        if self.battery_label.text() != text:
            self.battery_label.setText(text)

    def open_growth(self):
        from app.history import GrowthDialog
        GrowthDialog(self.s["data_dir"], [p.name for p in self.library.students()], self.library.current, self).exec()

    # ---- capture ---------------------------------------------------------
    def load_devices(self):
        names = ft.list_video_devices()
        self.device_box.blockSignals(True)
        self.device_box.clear()
        self.device_box.addItems(names)
        if self.s["video_device"] in names:
            self.device_box.setCurrentText(self.s["video_device"])
        self.device_box.blockSignals(False)
        self._device_changed(self.device_box.currentText())

    def _device_changed(self, name):
        self.modes = ft.list_device_modes(name) if name else []
        self.mode_box.clear()
        for m in self.modes:
            self.mode_box.addItem(ft.mode_label(m), ft.mode_key(m))
        idx = self.mode_box.findData(self.s["video_mode"])
        self.mode_box.setCurrentIndex(max(idx, 0))

    def _on_encoder(self, enc):
        self.s["encoder"] = enc
        self.capture_btn.setEnabled(True)
        self.capture_btn.setText("开始采集")
        self.capture_btn.setStyleSheet(CAPTURE_STYLE)
        if self.s["video_device"] and self.s["video_device"] == self.device_box.currentText() \
                and self.s["video_device"] != ft.TEST_DEVICE and self.s.data.get("mode") != "race":
            self.toggle_capture()                  # 比赛模式下采集卡归各路画面用，训练这边先不抢

    def toggle_capture(self):
        if self.engine.running:
            if self.recorder.recording and QMessageBox.question(
                    self, APP_NAME, "正在录制，停止采集会结束这次录像，确定吗？") != QMessageBox.Yes:
                return
            self._finish_recording()
            self.engine.stop()
            return
        if not self.modes:
            QMessageBox.warning(self, APP_NAME, "没有找到可用的采集卡画面格式，请检查采集卡连接后点「刷新」。")
            return
        mode = self.modes[max(self.mode_box.currentIndex(), 0)]
        self.s.data.update(video_device=self.device_box.currentText(), video_mode=ft.mode_key(mode))
        self.s.save()
        self.engine.start(self.device_box.currentText(), mode, self.s["encoder"], self.s.buffer_dir)
        if self.engine.running:
            self.capture_btn.setText("停止采集")
            self.capture_btn.setStyleSheet(CAPTURE_STYLE.replace("#34c759", "#636366").replace("#2fb350", "#555558"))
            self.device_box.setEnabled(False)
            self.mode_box.setEnabled(False)

    def _on_capture_stopped(self, err):
        self.capture_btn.setText("开始采集")
        self.capture_btn.setStyleSheet(CAPTURE_STYLE)
        self.device_box.setEnabled(True)
        self.mode_box.setEnabled(True)
        self.live.image = None
        self.live.update()
        if err:
            QMessageBox.warning(self, APP_NAME, err + "\n\n如果一直连不上，点右上角「诊断」生成报告发给开发者。")

    def _on_frame(self):
        self.live.image = self.engine.latest_frame()
        self._update_live_sticks()

    # ---- sticks ----------------------------------------------------------
    def _current_sticks(self):
        latest = self.source.latest()
        if not latest or not self.source.connected_name:
            return None, []
        now = latest[0]
        samples = self.source.between(now - TRAIL_S, now)
        step = max(1, len(samples) // 20)
        trail = [self.calibration.apply(s) for s in samples[:-1:step]]
        return self.calibration.apply(latest), [t for t in trail if t]

    def _update_live_sticks(self):
        self.live.values, self.live.trail = self._current_sticks()
        self.live.update()

    def _stick_tick(self):
        if not self.engine.running:
            self._update_live_sticks()

    def _tracks_dir(self):
        return Path(self.s["data_dir"]) / "赛道搭建"

    def open_track_build(self):
        from app.trackbuild import TrackBuildDialog
        TrackBuildDialog(self._tracks_dir(), self).exec()

    def open_track_tool(self):
        from app.trackhub import TrackHub
        TrackHub(self._tracks_dir(), self).exec()

    def go_page(self, key):
        """首页点的卡片"""
        if key in ("train", "race", "timer"):
            self.root.setCurrentIndex(1)
            self.mode_btns.button(0 if key == "train" else 1).setChecked(True)
            if key == "timer":
                self.statusBar().showMessage("计时模式：先用比赛模式连计时器练圈速", 15000)
        elif key == "build":
            self.open_track_build()
        elif key == "track":
            self.open_track_tool()
        elif key == "ai":
            AiCoachDialog(self).exec()
        elif key == "guide":
            self.open_guide()
        elif key == "settings":
            self.open_settings()

    def open_guide(self):
        from app.guide import GuideDialog
        GuideDialog(self).exec()

    def open_wizard(self):
        wiz = CalibrationWizard(self.source, self)
        if wiz.exec():
            self._use_calibration(wiz.calibration())

    def _use_calibration(self, cal: dict):
        name = cal.get("device") or self.source.connected_name
        cals = self.s.data.setdefault("calibrations", {})
        cals[name] = cal
        self.s.data.update(calibration=cal, joystick_name=name)
        self.s.save()
        self.calibration = Calibration(cal)
        self.recorder.calibration = self.calibration
        self._cal_for = name

    def _sync_calibration(self):
        """When a radio connects, load its saved settings by model name, or set up a known EdgeTX radio automatically."""
        name = self.source.connected_name
        if not name or name == self._cal_for:
            return
        latest = self.source.latest()
        if not latest:
            return
        if is_wireless(name) and not latest[2] & 1:
            return  # wireless receiver not linked to the radio yet: the arm switch position is unknown
        self._cal_for = name
        cals = self.s.data.setdefault("calibrations", {})
        old = self.s["calibration"]
        if old and old.get("device") == name and name not in cals:
            cals[name] = old
        if name in cals:
            self._use_calibration(cals[name])
            self.statusBar().showMessage(f"已识别遥控器：{name}，使用这台遥控器上次的设置", 8000)
        elif is_known_radio(name) and len(latest[1]) >= 5:
            self._use_calibration(edgetx_preset(name, latest[1]))
            QMessageBox.information(
                self, APP_NAME,
                f"已自动识别遥控器：{name}\n\n已按 EdgeTX 默认通道设置好：横滚=通道1，俯仰=通道2，油门=通道3，偏航=通道4，解锁=通道5（SE）。\n"
                "现在 SE 的位置被当作「上锁」。\n\n动一下摇杆看画面上的方向对不对，不对就点「遥控器校准」重新校准。")
        elif name != SIM_NAME:
            self.open_wizard()

    # ---- recording -------------------------------------------------------
    def _apply_recorder_settings(self):
        r = self.recorder
        r.calibration = Calibration(self.s["calibration"])
        r.auto = bool(self.s["auto_record"])     # 解锁录像：解锁开始、锁桨结束
        if hasattr(self, "rec_hint"):
            self.rec_hint.setText(f"解锁不到 {self.s['min_flight_s']:g} 秒不保存（算解锁测试）" if r.auto
                                  else f"录不到 {self.s['min_flight_s']:g} 秒不保存")
        r.preroll, r.postroll, r.min_flight = self.s["preroll_s"], self.s["postroll_s"], self.s["min_flight_s"]
        r.sync_offset_ms = self.s["sync_offset_ms"]
        r.channel = self.s["vtx_channel"]

    def _rec_mode_changed(self, _i):
        self.s["auto_record"] = bool(self.rec_mode.currentData())
        self._apply_recorder_settings()

    def _channel_changed(self, ch):
        self.s.data.setdefault("student_channels", {})[self.s["current_student"]] = ch   # 每个学员记住自己的频道
        self.s["vtx_channel"] = ch
        self.recorder.channel = ch
        self.live.channel = ch
        self.live.update()

    def _set_rec_button(self, text, color):
        if self.rec_btn.text() != text:
            self.rec_btn.setText(text)
            self.rec_btn.setStyleSheet(f"QPushButton {{ background: {color}; color: white; font-size: 14px;"
                                       f" font-weight: bold; border: none; border-radius: 8px; padding: 5px 14px; }}"
                                       "QPushButton:disabled { color: white; }")

    def _student_changed(self, path: Path):
        if hasattr(self, "trainlog") and path.name != self.s["current_student"]:
            self.trainlog.idle(self.s["current_student"])     # 换学员：上一个学员正在飞的这次到此为止
        self.recorder.student_dir = path
        self.s["current_student"] = path.name
        ch = self.s.data.get("student_channels", {}).get(path.name)
        if ch and ch != self.channel_box.currentText():
            if hasattr(self, "live"):
                self.channel_box.setCurrentText(ch)
            else:                               # 启动时画面还没建好，只改设置
                self.channel_box.blockSignals(True)
                self.channel_box.setCurrentText(ch)
                self.channel_box.blockSignals(False)
                self.s["vtx_channel"] = ch

    def open_student_channels(self):
        names = [p.name for p in self.library.students()]
        dlg = StudentChannelsDialog(names, self.s.data.get("student_channels", {}), self.s["vtx_channel"], self)
        if dlg.exec():
            self.s.data["student_channels"] = dlg.result_map()
            self.s.save()
            ch = self.s.data["student_channels"].get(self.s["current_student"])
            if ch:
                self.channel_box.setCurrentText(ch)
            self.race.fill_students()

    def _release_student(self, path: Path):
        # The replay player keeps its file open, which stops Windows renaming or deleting the folder.
        if self.replay.video and path in self.replay.video.parents:
            self.replay.release()

    def _finish_recording(self):
        if self.recorder.state == "recording":
            self.recorder.manual = True
            self.recorder.toggle_manual()
        self.recorder.end_clock = min(self.recorder.end_clock, time.perf_counter())

    def _on_saved(self, path):
        self.library.refresh()
        self.statusBar().showMessage(f"已保存：{path}", 8000)

    def open_recording(self, path: Path):
        self.tabs.setCurrentWidget(self.replay)
        self.replay.load(path)
        self.replay.setFocus()

    def _tick(self):
        values = self.calibration.apply(self.source.latest()) if self.source.connected_name else None
        self.recorder.tick(bool(values and values["armed"]))
        self._feed_battery(values)
        self._sd_scan_n += 1
        if self._sd_scan_n % 15 == 0 and not self._sd_scanning:     # 每 3 秒看一次，后台看，不卡界面
            self._sd_scanning = True
            threading.Thread(target=self._scan_radio_sd, daemon=True).start()

        self._sync_calibration()

        r = self.recorder
        if r.state == "recording":
            secs = int(r.elapsed())
            self.live.badge = f"● 录制中 {secs // 60:02d}:{secs % 60:02d}"
            self._set_rec_button(f"■ 停止录制 {secs // 60:02d}:{secs % 60:02d}", "#1d1d1f")
        elif r.state == "finishing":
            self.live.badge = "● 正在保存…"
            self._set_rec_button("正在保存…", "#aeaeb2")
        elif self.engine.running:
            self.live.badge = ""
            self._set_rec_button("● 开始录制", "#ff3b30")
        else:
            self.live.badge = ""
            self._set_rec_button("先点上面「开始采集」", "#aeaeb2")
        self.rec_btn.setEnabled(self.engine.running and r.state != "finishing")
        armed = bool(values and values["armed"])
        if not self.source.connected_name:
            arm = ("遥控器未连接", "#888")
        elif not self.calibration.valid:
            arm = ("遥控器未校准", "#c77800")
        elif armed:
            arm = ("🔓 已解锁", "#ff3b30")
        else:
            arm = ("🔒 已锁桨", "#34c759")
        if self.arm_label.text() != arm[0]:
            self.arm_label.setText(arm[0])
            self.arm_label.setStyleSheet(f"color: {arm[1]}; font-weight: bold;")

        if self.source.connected_name:
            text = f"{self.source.connected_name}" + ("" if self.calibration.valid else "（未校准）")
        else:
            text = "未连接"
        self.radio_label.setText(text)

        st = self.engine.stats
        parts = [f"编码：{ft.encoder_label(self.s['encoder'])}" if self.s["encoder"] else "编码：检测中"]
        if self.engine.running:
            now = time.perf_counter()
            if now - self._shown_t >= 1.0:
                self._shown_fps = (self.live.painted - self._shown_n) / (now - self._shown_t)
                self._shown_t, self._shown_n = now, self.live.painted
            parts.insert(0, f"采集 {st['fps']:.1f} 帧/秒" + (f"（{self.engine.input_desc}）" if self.engine.input_desc else ""))
            parts.insert(1, f"画面 {self._shown_fps:.0f} 帧/秒")
            parts.insert(2, f"掉帧 {st['dropped']}")
            if st["speed"]:
                parts.append(f"编码速度 {st['speed']}")
        parts.append(f"保存到：{self.s['data_dir']}")
        self.stat_label.setText("    ".join(parts))
        self.stat_label.setStyleSheet("color: #d22;" if st["dropped"] else "")

    def run_diagnose(self):
        was_running = self.engine.running
        if was_running:
            if QMessageBox.question(self, APP_NAME, "诊断需要先停止采集，继续吗？") != QMessageBox.Yes:
                return
            self.toggle_capture()
        mode = self.modes[self.mode_box.currentIndex()] if self.modes and self.mode_box.currentIndex() >= 0 else None
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            text = ft.diagnose(self.device_box.currentText(), mode)
            text += "\n\n==== 遥控器 / ELRS 接收机 ====\n" + self.source.report()
        finally:
            QApplication.restoreOverrideCursor()
        path = desktop_dir() / "无人机竞速-诊断.txt"
        path.write_text(text, encoding="utf-8")
        dlg = QDialog(self)
        dlg.setWindowTitle("诊断报告")
        dlg.resize(820, 600)
        box = QPlainTextEdit(text)
        box.setReadOnly(True)
        copy_btn = QPushButton("复制全部")
        copy_btn.clicked.connect(lambda: QApplication.clipboard().setText(text))
        lay = QVBoxLayout(dlg)
        lay.addWidget(QLabel(f"报告已保存到：{path}\n把这个文件发给开发者，或者点「复制全部」后粘贴发送。"))
        lay.addWidget(box, 1)
        lay.addWidget(copy_btn)
        dlg.exec()

    def choose_data_dir(self):
        d = QFileDialog.getExistingDirectory(self, "选择录像文件夹（里面是一个个学员的文件夹）", self.s["data_dir"])
        if d:
            self._apply_data_dir(d)

    def _apply_data_dir(self, d: str):
        self.s.data.update(data_dir=d, data_dir_chosen=True)
        self.s.save()
        self.library.set_root(Path(d), self.s["current_student"])
        self.statusBar().showMessage(f"录像以后保存到：{d}", 8000)

    def _find_lost_dir(self):
        lost = self.s["data_dir"]
        QMessageBox.warning(None, APP_NAME, f"原来的录像文件夹找不到了：\n{lost}\n\n"
                            "可能是文件夹改了名字或者搬走了。请重新选择录像文件夹，以前的录像就都回来了。")
        d = QFileDialog.getExistingDirectory(None, "选择录像文件夹", Path(lost).anchor)
        if d:
            self.s.data.update(data_dir=d)
            self.s.save()

    def ask_data_dir_first_time(self):
        if self.s.data.get("data_dir_chosen"):
            return
        QMessageBox.information(self, APP_NAME, "第一次使用，请选择录像保存在哪个文件夹（建议选空间大的盘，比如 E 盘）。\n以后可以点上面的「保存位置…」修改。")
        d = QFileDialog.getExistingDirectory(self, "选择录像保存位置", self.s["data_dir"])
        self._apply_data_dir(d or self.s["data_dir"])

    def open_settings(self):
        dlg = SettingsDialog(self.s, self)
        if dlg.exec():
            old_dir = self.library.root
            dlg.apply()
            self._apply_recorder_settings()
            if Path(self.s["data_dir"]) != old_dir:
                self._apply_data_dir(self.s["data_dir"])

    def closeEvent(self, e):
        if self.recorder.recording:
            self._finish_recording()
        self.engine.stop()
        if self.recorder.state == "finishing":
            self.recorder.tick(False)
        deadline = time.time() + 15
        while self.recorder._jobs and time.time() < deadline:
            QApplication.processEvents()
            time.sleep(0.05)
        self.trainlog.idle()
        self.source.close()
        self.race.shutdown()
        super().closeEvent(e)


# 老版本留下的没用文件：早先手动解压时中文名变成乱码的重复文件、改过名的预载地图
OLD_FILES = ["黑羊样板-默认.json", "铃声", "预载地图"]
OLD_MAPS = ["01 绕杆掉头.赛道.json"]


def tidy_old_files():
    here = Path(__file__).resolve().parent
    for n in OLD_FILES:
        bad = n.encode("utf-8").decode("cp437", errors="replace")
        p = here / bad
        if bad == n or not p.exists():
            continue
        if p.is_dir():
            shutil.rmtree(p, ignore_errors=True)
        else:
            p.unlink(missing_ok=True)
    for n in OLD_MAPS:
        (here / "预载地图" / n).unlink(missing_ok=True)


def ensure_desktop_shortcut():
    """First start from the packaged exe: put a shortcut on the desktop."""
    exe = APP_DIR / "DroneRacing.exe"
    if not (INSTALLED and exe.exists()):
        return
    lnk = desktop_dir() / "无人机竞速.lnk"
    try:        # 已经有快捷方式，而且指着现在这个文件夹：不用动（程序文件夹改名后要重建，不然图标会没了）
        if lnk.exists() and str(APP_DIR).encode("utf-16-le") in lnk.read_bytes():
            return
    except OSError:
        return
    ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:LNK);"
          "$s.TargetPath=$env:EXE;$s.WorkingDirectory=$env:DIR;$s.IconLocation=$env:ICO;$s.Save()")
    env = dict(os.environ, LNK=str(lnk), EXE=str(exe), DIR=str(APP_DIR), ICO=str(APP_DIR / "app" / "icon.ico"))
    subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps], env=env,
                   creationflags=ft.NO_WINDOW, capture_output=True, timeout=30)


class DialogButtons(QObject):
    """每个弹出窗口都加上最小化、最大化按钮（Qt 的对话框默认只有关闭）"""

    def eventFilter(self, obj, ev):
        if ev.type() == QEvent.Polish and isinstance(obj, QDialog) and not isinstance(obj, (QMessageBox, QFileDialog)):
            want = obj.windowFlags() | Qt.WindowMinMaxButtonsHint | Qt.WindowCloseButtonHint
            if obj.windowFlags() != want and not obj.isVisible():
                obj.setWindowFlags(want)
        return False


def run():
    if IS_WINDOWS:
        # 不设这个，任务栏把软件当成 Python，显示的是 Python 的图标
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("DroneRacing.Teach.V2")
        except Exception:  # noqa: BLE001
            pass
    app = QApplication(sys.argv)
    app._dialog_buttons = DialogButtons()
    app.installEventFilter(app._dialog_buttons)
    app.setApplicationName(APP_NAME)
    from app import theme
    theme.apply(app)                        # 苹果式的浅色外观
    app.setWindowIcon(QIcon(str(Path(__file__).with_name("icon.ico" if IS_WINDOWS else "icon.png"))))
    w = MainWindow()
    w.show()
    w.updater.start()                       # 有更新地址就在后台查一下新版本
    if not w.s.data.get("guide_done"):
        w.open_guide()                      # 第一次打开：使用向导（里面会选录像位置）
    else:
        w.ask_data_dir_first_time()
    try:
        tidy_old_files()
    except OSError:
        pass
    try:
        ensure_desktop_shortcut()
    except (OSError, subprocess.SubprocessError):
        pass
    sys.exit(app.exec())
