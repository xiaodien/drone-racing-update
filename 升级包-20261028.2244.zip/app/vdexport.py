"""导出到黑羊（VelociDrone）：选场地地图、门框样式、方管/杆子、起飞台，导出 .trk

黑羊里每种东西都有一个内部编号（prefab）。官方没有列表，所以用「样板」学：
在黑羊里摆好想要的东西存成 .trk，这里读出来，把编号认成「门框 / 计时门 / 方管 / 起飞台」，记住以后一直用。
"""
import copy
import json
import math
import re
from pathlib import Path

from PySide6.QtWidgets import (QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox, QFileDialog, QFormLayout,
                               QGroupBox, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton, QSpinBox,
                               QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from app import trackconv as tc
from app import trackgen as tg
from app.config import USER_DIR

KIT = USER_DIR / "黑羊样板.json"
ROLES = {"gate": "门框（检查点）", "start": "计时门（起点/终点）", "bar": "方管 / 杆子", "pad": "起飞台", "skip": "不用"}
BUILTIN = {"gate": [(88, "标准检查门（88 号）"), (209, "绿色霓虹框")],
           "start": [(88, "标准检查门（88 号）"), (209, "绿色霓虹框")],
           "bar": [(54, "方块（默认）")],
           "pad": []}
NO_PAD = -1


def spread_model(model, types, path, k):
    """组委会的地图（没有门和顺序的记录）：门框大小不变，门的位置按比例 k 从中心往外拉（k<1 往里收）。
    挨着的零件（拼起来的组合门、门边的杆子）整堆一起挪；路线也拉开，靠近门的地方跟着那堆门走，保证还从门洞穿。
    返回 (新 model, 新 path)"""
    model = copy.deepcopy(model)
    # 组委会画的路线线条（带箭头）不跟着挪：路线已经单独算好、拉开了，留着它反而对不上
    model["parts"] = [p for p in model["parts"] if types.get(p["id"]) != "路线"]
    parts = model["parts"]
    if not parts:
        return model, path
    cen = [tc.frame_of(p, types.get(p["id"]))[0] for p in parts]
    cx = sum(c[0] for c in cen) / len(cen)
    cz = sum(c[2] for c in cen) / len(cen)
    up = list(range(len(parts)))

    def root(i):
        while up[i] != i:
            up[i] = up[up[i]]
            i = up[i]
        return i
    touch = tc.CAD_S + tc.CAD_T + 0.8
    for i in range(len(parts)):
        for j in range(i):
            if math.hypot(cen[i][0]-cen[j][0], cen[i][2]-cen[j][2]) < touch:
                up[root(i)] = root(j)
    heaps = {}
    for i in range(len(parts)):
        heaps.setdefault(root(i), []).append(i)
    moves = []                                  # 每堆：(中心, 挪多少)
    for idx in heaps.values():
        mx = sum(cen[i][0] for i in idx) / len(idx)
        mz = sum(cen[i][2] for i in idx) / len(idx)
        dx, dz = (mx-cx)*(k-1), (mz-cz)*(k-1)
        moves.append((mx, mz, dx, dz, max(math.hypot(cen[i][0]-mx, cen[i][2]-mz) for i in idx)))
        for i in idx:
            o = parts[i]["o"]
            parts[i]["o"] = [o[0]+dx, o[1], o[2]+dz]

    def warp(q):
        x, z = q[0], q[2]
        dx, dz = (x-cx)*(k-1), (z-cz)*(k-1)    # 离门远：整体按比例拉
        sw = sx = sz = 0.0
        near = 1e9
        for mx, mz, mdx, mdz, rad in moves:     # 靠近门：跟着最近的那堆门走（反距离加权，路线不会断，也不会从两个门中间穿空）
            dist = max(0.05, math.hypot(x-mx, z-mz) - rad)
            near = min(near, dist)
            w = dist ** -4
            sw += w
            sx += w*mdx
            sz += w*mdz
        a = 1.0 if near < 3 else 0.0 if near > 8 else (8-near)/5
        dx += a*(sx/sw - dx)
        dz += a*(sz/sw - dz)
        return [x+dx, q[1], z+dz]
    if not path:
        return model, path
    out = [warp(path[0])]
    for a, b in zip(path, path[1:]):           # 拉开以后点会变稀：原来连着的段（≤6 米）按 1 米再补点，免得断开
        n = max(1, math.ceil(math.dist(a, b)*max(k, 1)/1.0)) if math.dist(a, b) <= 6 else 1
        for j in range(1, n+1):
            out.append(warp([a[m] + (b[m]-a[m])*j/n for m in range(3)]))
    return model, out


def spread_out(meta, k, S, T):
    """门间距按比例 k 缩放：门框大小、高低不变，只把门（组合门整组）的位置从赛道中心往外拉，再重新连线。
    meta = 赛道搭建存的 meta（要有 items、route）。返回 (model, types, path, info)"""
    items = copy.deepcopy(meta["items"])
    route = copy.deepcopy(meta["route"])
    if not items:
        raise ValueError("没有门")
    cx = sum(it["x"] for it in items) / len(items)
    cz = sum(it["z"] for it in items) / len(items)
    # 组合门、贴在一起的门算一堆，整堆一起挪（不然并排、叠着的门会被拉散）
    up = list(range(len(items)))

    def root(i):
        while up[i] != i:
            up[i] = up[up[i]]
            i = up[i]
        return i
    touch = S + T + 0.6
    for i, a in enumerate(items):
        for j in range(i):
            b = items[j]
            if tg.TAKEOFF in (a["t"], b["t"]):
                continue
            if (a.get("grp") and a.get("grp") == b.get("grp")) or math.hypot(a["x"]-b["x"], a["z"]-b["z"]) < touch:
                up[root(i)] = root(j)
    heaps = {}
    for i in range(len(items)):
        heaps.setdefault(root(i), []).append(i)
    for idx in heaps.values():
        mx = sum(items[i]["x"] for i in idx) / len(idx)
        mz = sum(items[i]["z"] for i in idx) / len(idx)
        dx, dz = (mx-cx)*(k-1), (mz-cz)*(k-1)
        for i in idx:
            items[i]["x"] = round(items[i]["x"] + dx, 3)
            items[i]["z"] = round(items[i]["z"] + dz, 3)

    def sc(q):
        return [cx + (q[0]-cx)*k, q[1], cz + (q[2]-cz)*k]
    for st in route:                            # 手绘的线也一起拉开
        if st.get("via"):
            st["via"] = [sc(q) for q in st["via"]]
            if st.get("via_ab"):
                st["via_ab"] = [sc(q) for q in st["via_ab"]]
    return tg.build_manual(items, route, S=S, T=T, closed=meta.get("closed", True))


def load_kit():
    """用户学到的样板，加上软件自带的那份（从 2026 赛道里认出来的门框、杆子、起飞台）"""
    try:
        kit = json.loads(KIT.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        kit = {}
    kit.setdefault("scenes", {})
    kit.setdefault("items", [])
    try:
        d = json.loads((Path(__file__).parent / "黑羊样板-默认.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {"scenes": {}, "items": []}
    for sid, sc in d["scenes"].items():
        kit["scenes"].setdefault(sid, sc)
    kit["defaults"] = d.get("defaults", {})
    have = {(i["prefab"], i["role"]) for i in kit["items"]}
    kit["items"] += [i for i in d["items"] if (i["prefab"], i["role"]) not in have]
    for sid, s in kit["scenes"].items():          # 学过的地图也放进场景表，预览和导出都认得
        tc.SCENES.setdefault(int(sid), (s["name"], s["floor"]))
    return kit


def save_kit(kit):
    kit = {k: v for k, v in kit.items() if k != "defaults"}     # 默认选项跟着软件走，不存进用户的样板
    try:
        KIT.write_text(json.dumps(kit, ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError:
        pass


def read_trk(path):
    """黑羊 .trk -> (场景编号, 赛道名, {"gates": [...], "barriers": [...]})"""
    text = Path(path).read_text(encoding="utf-8", errors="replace").strip()
    raw = tc.base64.b64decode("".join(text.split()))
    k8 = "Velocidrone"[:8]
    plain = tc.aes.ecb_decrypt(raw, (k8 + k8[::-1]).encode())
    pad = plain[-1]
    if 1 <= pad <= 16 and plain.endswith(bytes([pad]) * pad):
        plain = plain[:-pad]
    s = plain.decode("utf-8", errors="replace")
    head, name, rest = s.split("\n", 2)
    js, _ = json.JSONDecoder().raw_decode(rest)
    return int(head), name, js


def learn(path):
    """读样板：每种编号一行（在样板里是门还是摆件、几个、一个的尺寸），猜一个用途"""
    scene, _name, js = read_trk(path)
    rows = {}
    for kind, objs in (("gate", js.get("gates", [])), ("bar", js.get("barriers", []))):
        for o in objs:
            key = (kind, o["prefab"])
            r = rows.setdefault(key, dict(prefab=o["prefab"], kind=kind, count=0, scale=o["trans"]["scale"],
                                          y=o["trans"]["pos"][1], start=False, curve="curve" in o))
            r["count"] += 1
            r["start"] = r["start"] or bool(o.get("start"))
    out = list(rows.values())
    for r in out:
        if r["kind"] == "gate":
            r["role"] = "start" if r["start"] else "gate"
        elif r["curve"]:
            r["role"] = "skip"
        else:
            r["role"] = "pad" if r["count"] == 1 else "bar"
    ys = [r["y"] for r in out if r["role"] in ("start", "pad")] or [r["y"] for r in out] or [0]
    return scene, min(ys), out


def _yaw_rot(d):
    """朝向 d（世界坐标，米）的旋转：黑羊里物体的正前方对着 d"""
    rz = tc.norm([d[0], 0, -d[2]])
    ry = [0, 1, 0]
    rx = tc.cross(ry, rz)
    return tc.quat(rx, ry, rz)


def style(track, gate, start, bar, pad, kit):
    """把 trackconv 算好的赛道换成选好的样式；起飞台放在路线起点，朝第一段的方向"""
    tr = copy.deepcopy(track)
    learned = {(i["role"], i["prefab"]): i for i in kit["items"]}

    def depth(role, prefab):
        if prefab == 88:
            return 100
        if prefab == 209:
            return 14
        it = learned.get((role, prefab))
        return it["scale"][0] if it else 14

    for g in tr["gates"]:
        role, pf = ("start", start) if g.get("start") else ("gate", gate)
        g["prefab"] = pf
        g["trans"]["scale"][0] = depth(role, pf)
        if pf == 88:                        # 标准地图的检查门：厚 100，比门洞每边大 0.15 米，擦边也算过
            sc = g["trans"]["scale"]
            up = tc.qrot(g["trans"]["rot"], (0, 0, 1))      # 门的「高」方向：底边往外挪 0.15 米，中心不变
            g["trans"]["pos"] = [round(g["trans"]["pos"][i] - 15 * up[i]) for i in range(3)]
            g["trans"]["scale"] = [100, sc[1] + 15, sc[2] + 15]
    for b in tr["barriers"]:
        b["prefab"] = bar
        if bar != 54:                       # 54 号方块按 2 米算（每米 50），黑羊的杆子按 1 米算（每米 100）
            b["trans"]["scale"] = [v * 2 for v in b["trans"]["scale"]]
    if pad != NO_PAD and tr["path"]:
        pts = tr["path"]
        a = pts[0]
        b = next((q for q in pts if math.dist((q[0], q[2]), (a[0], a[2])) > 2), None)
        d = [b[0] - a[0], 0, b[2] - a[2]] if b else [0, 0, 1]
        floor = tc.SCENES[tr["scene"]][1]
        it = learned.get(("pad", pad))
        tr["barriers"].append({"prefab": pad, "trans": {"pos": [round(a[0] * 100), round(floor), round(-a[2] * 100)],
                                                         "rot": _yaw_rot(d),
                                                         "scale": list(it["scale"]) if it else [100, 100, 100]}})
    return tr


class LearnDialog(QDialog):
    """读一个样板 .trk，认一下里面每种编号是什么"""

    def __init__(self, path, kit, parent=None):
        super().__init__(parent)
        self.setWindowTitle("认识黑羊样板")
        self.kit = kit
        self.scene, self.floor, self.rows = learn(path)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(f"样板文件：{Path(path).name}\n"
                             "下面是样板里每一种东西。给它起个名字（比如「红色方框」），选它当什么用。"))
        form = QFormLayout()
        known = tc.SCENES.get(self.scene)
        self.scene_name = QLineEdit(known[0] if known else f"地图 {self.scene}")
        form.addRow(f"地图（编号 {self.scene}）名字", self.scene_name)
        lay.addLayout(form)
        self.table = QTableWidget(len(self.rows), 5)
        self.table.setHorizontalHeaderLabels(["编号", "样板里是", "数量", "当作", "名字"])
        self.table.verticalHeader().setVisible(False)
        self.boxes, self.names = [], []
        for r, it in enumerate(self.rows):
            self.table.setItem(r, 0, QTableWidgetItem(str(it["prefab"])))
            self.table.setItem(r, 1, QTableWidgetItem("门（检查点）" if it["kind"] == "gate" else
                                                      ("线条（不导出）" if it["curve"] else "摆件")))
            self.table.setItem(r, 2, QTableWidgetItem(str(it["count"])))
            box = QComboBox()
            for k, label in ROLES.items():
                if it["kind"] == "gate" and k in ("bar", "pad"):
                    continue
                if it["kind"] == "bar" and k in ("gate", "start"):
                    continue
                box.addItem(label, k)
            box.setCurrentIndex(max(0, box.findData(it["role"])))
            self.table.setCellWidget(r, 3, box)
            name = QLineEdit()
            old = next((i for i in kit["items"] if i["prefab"] == it["prefab"]), None)
            name.setText(old["name"] if old else "")
            name.setPlaceholderText("比如：红色方框")
            self.table.setCellWidget(r, 4, name)
            self.boxes.append(box)
            self.names.append(name)
        self.table.resizeColumnsToContents()
        self.table.setColumnWidth(3, 170)
        self.table.setColumnWidth(4, 170)
        lay.addWidget(self.table)
        bb = QDialogButtonBox()
        bb.addButton("记住", QDialogButtonBox.AcceptRole)
        bb.addButton("取消", QDialogButtonBox.RejectRole)
        bb.accepted.connect(self._save)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.resize(720, 420)

    def _save(self):
        kit = self.kit
        kit["scenes"][str(self.scene)] = dict(name=self.scene_name.text().strip() or f"地图 {self.scene}",
                                              floor=self.floor)
        tc.SCENES[self.scene] = (kit["scenes"][str(self.scene)]["name"], self.floor)
        for it, box, name in zip(self.rows, self.boxes, self.names):
            role = box.currentData()
            kit["items"] = [i for i in kit["items"] if not (i["prefab"] == it["prefab"] and i["role"] == role)]
            if role == "skip":
                continue
            kit["items"].append(dict(prefab=it["prefab"], role=role, scale=it["scale"],
                                     name=name.text().strip() or f"样板 {it['prefab']} 号"))
        save_kit(kit)
        self.accept()


class ExportDialog(QDialog):
    """导出到黑羊：打开赛道，选地图、门框、方管、起飞台，看预览，导出 .trk"""

    def __init__(self, folder=None, parent=None, preset=None):
        super().__init__(parent)
        from app.track_tool import TopView, _load_memory
        self.setWindowTitle("导出到黑羊")
        self.resize(1200, 760)
        self.folder = Path(folder) if folder else None
        self.memory = _load_memory()
        self.kit = load_kit()
        self.model, self.types, self.built_path, self.track = None, {}, None, None
        self.meta = None                    # 赛道搭建存的门和顺序（能拉开门间距）

        open_btn = QPushButton("打开赛道…")
        open_btn.setMinimumHeight(40)
        open_btn.setToolTip("「赛道搭建」保存的赛道，或者组委会发的 eDrawings 赛道 exe")
        open_btn.clicked.connect(self.choose_file)
        self.file_label = QLabel("还没有选赛道")
        self.file_label.setWordWrap(True)

        self.scene = QComboBox()
        self.gap = QDoubleSpinBox(minimum=1.0, maximum=5.0, singleStep=0.1, decimals=2, value=2.5, suffix=" 米")
        self.bar_mm = QSpinBox(minimum=20, maximum=500, singleStep=10, value=200, suffix=" 毫米")
        self.gate = QComboBox()
        self.start = QComboBox()
        self.bar = QComboBox()
        self.pad = QComboBox()
        self.spread = QComboBox()             # 固定比例，0.5 一档
        for k in (0.5, 1.0, 1.5, 2.0, 2.5, 3.0):
            self.spread.addItem(f"1 : {k:g}" + ("（原样）" if k == 1 else ""), k)
        i = self.spread.findData(float(self.kit.get("last_spread", 1.0)))
        self.spread.setCurrentIndex(i if i >= 0 else 1)
        self.spread.setToolTip("门框大小不变，只按比例改门和门之间的距离（组合门整组一起挪，高低不变），路线跟着改。"
                               "赛道搭建的地图和组委会的地图都能用")
        self.name = QLineEdit()
        self.name.setPlaceholderText("赛道名（建议英文，黑羊里可能显示不了中文）")
        self._fill_choices()
        for w in (self.gap, self.bar_mm):
            w.valueChanged.connect(self.rebuild)
        for w in (self.scene, self.gate, self.start, self.bar, self.pad, self.spread):
            w.currentIndexChanged.connect(self.rebuild)

        form = QFormLayout()
        form.addRow("场地地图", self.scene)
        form.addRow("门洞宽高", self.gap)
        form.addRow("门间距比例", self.spread)
        form.addRow("方管 / 杆子粗细", self.bar_mm)
        form.addRow("门框", self.gate)
        form.addRow("计时门", self.start)
        form.addRow("方管 / 杆子", self.bar)
        form.addRow("起飞台", self.pad)
        form.addRow("赛道名", self.name)
        box = QGroupBox("黑羊里的样子")
        box.setLayout(form)

        learn_btn = QPushButton("导入黑羊样板…")
        learn_btn.setToolTip("在黑羊里摆好想要的门框、杆子、起飞台存成 .trk，这里读进来，以后就能选")
        learn_btn.clicked.connect(self.learn)
        learn_tip = QLabel("想要红色门框、别的杆子或起飞台：在黑羊里打开那张地图，新建赛道，各放一个，"
                           "保存后点上面的按钮读进来。")
        learn_tip.setWordWrap(True)
        learn_tip.setStyleSheet("color: #666;")

        self.export_btn = QPushButton("导出黑羊赛道（TRK）")
        self.export_btn.setMinimumHeight(48)
        self.export_btn.setEnabled(False)
        self.export_btn.clicked.connect(self.export)

        left = QWidget()
        ll = QVBoxLayout(left)
        ll.addWidget(open_btn)
        ll.addWidget(self.file_label)
        ll.addWidget(box)
        ll.addWidget(learn_btn)
        ll.addWidget(learn_tip)
        ll.addStretch(1)
        ll.addWidget(self.export_btn)
        left.setMaximumWidth(380)

        self.view = TopView()
        self.notes = QLabel()
        self.notes.setWordWrap(True)
        self.notes.setStyleSheet("color: #c77800;")
        right = QVBoxLayout()
        right.addWidget(self.view, 1)
        right.addWidget(self.notes)
        lay = QHBoxLayout(self)
        lay.addWidget(left)
        lay.addLayout(right, 1)

        dft = self.kit.get("defaults", {})
        for w, v in ((self.gap, dft.get("S")), (self.bar_mm, dft.get("T"))):
            if v:
                w.setValue(v)
        if preset:
            self.model, self.types, self.built_path = preset["model"], preset["types"], preset.get("path")
            self.file_label.setText(preset.get("label", ""))
            self.name.setText(preset.get("name", ""))
            for w, v in ((self.gap, preset.get("S")), (self.bar_mm, preset.get("T"))):
                if v:
                    w.blockSignals(True)
                    w.setValue(v)
                    w.blockSignals(False)
            self.rebuild()

    # ---- 选项
    def _fill_choices(self):
        def fill(box, items, keep):
            box.blockSignals(True)
            box.clear()
            for data, label in items:
                box.addItem(label, data)
            i = box.findData(keep)
            box.setCurrentIndex(i if i >= 0 else 0)
            box.blockSignals(False)

        kit = self.kit
        dft = kit.get("defaults", {})
        mine = lambda role: [(i["prefab"], i["name"]) for i in kit["items"] if i["role"] == role]
        fill(self.scene, [(sid, label) for sid, (label, _f) in tc.SCENES.items()],
             self.scene.currentData() or kit.get("last_scene", dft.get("scene", 42)))
        fill(self.gate, BUILTIN["gate"] + mine("gate"), self.gate.currentData() or kit.get("last_gate", dft.get("gate")))
        fill(self.start, BUILTIN["start"] + mine("start"),
             self.start.currentData() or kit.get("last_start", dft.get("start")))
        fill(self.bar, mine("bar") + BUILTIN["bar"], self.bar.currentData() or kit.get("last_bar", dft.get("bar")))
        fill(self.pad, mine("pad") + [(NO_PAD, "不放（用地图自带的）")],
             self.pad.currentData() if self.pad.currentData() is not None else kit.get("last_pad", dft.get("pad", NO_PAD)))

    def learn(self):
        docs = Path.home() / "Documents"
        f, _ = QFileDialog.getOpenFileName(self, "选黑羊样板", str(docs if docs.is_dir() else Path.home()),
                                           "VelociDrone 赛道 (*.trk);;所有文件 (*)")
        if not f:
            return
        try:
            dlg = LearnDialog(f, self.kit, self)
        except (OSError, ValueError, KeyError) as ex:
            QMessageBox.warning(self, "读不出来", f"这个文件读不出来，是黑羊保存的 .trk 吗？\n{ex}")
            return
        if dlg.exec():
            self.kit = load_kit()
            self.scene.blockSignals(True)
            self.scene.setCurrentIndex(-1)
            self.scene.blockSignals(False)
            self._fill_choices()
            i = self.scene.findData(dlg.scene)
            if i >= 0:
                self.scene.setCurrentIndex(i)
            self.rebuild()

    # ---- 赛道
    def choose_file(self):
        start = str(self.folder) if self.folder and self.folder.is_dir() else ""
        f, _ = QFileDialog.getOpenFileName(self, "打开赛道", start,
                                           f"赛道 (*{tg.SUFFIX} *.exe *.eprt *.easm);;所有文件 (*)")
        if f:
            self.open_file(f)

    def open_file(self, path):
        try:
            if str(path).endswith(tg.SUFFIX) or str(path).endswith(".json"):
                self.model, self.types, self.built_path, d = tg.load(path)
                meta = d.get("meta", {})
                self.meta = meta if meta.get("items") and "route" in meta else None
                self.file_label.setText(f"搭建的赛道：{d.get('name', '')}")
                self.name.setText(d.get("name") or "Track")
                for w, v in ((self.gap, meta.get("S")), (self.bar_mm, round(meta.get("T", 0) * 1000) or None)):
                    if v:
                        w.blockSignals(True)
                        w.setValue(v)
                        w.blockSignals(False)
            else:
                self.model = tc.load(path)
                self.meta = None
                self.built_path = None
                self.types = tc.default_types(self.model, self.memory)
                self.file_label.setText(Path(path).name)
                if not self.name.text().strip():
                    self.name.setText(re.sub(r"[^A-Za-z0-9 _-]", "", Path(path).stem).strip() or "Track")
        except Exception as ex:  # noqa: BLE001 - 文件格式各种各样，统一提示
            QMessageBox.warning(self, "读不出来", f"这个文件读不出赛道：\n{ex}")
            return
        self.rebuild()

    def rebuild(self):
        if not self.model:
            return
        S, T = self.gap.value(), self.bar_mm.value() / 1000
        model, types, path = self.model, self.types, self.built_path
        k = self.spread.currentData() or 1.0
        warn = []
        if self.meta is not None and abs(k - 1) > 1e-6:
            try:
                model, types, path, info = spread_out(self.meta, k, S, T)
                warn = info.get("warn", [])
            except ValueError:
                pass
        elif abs(k - 1) > 1e-6:                 # 组委会的地图：零件和路线一起按比例挪
            model, path = spread_model(model, types, path if path else tc.route_path(model, types), k)
        base = tc.build(model, types, S=S, T=T, scene=self.scene.currentData(),
                        name=self.name.text().strip() or "Track", path=path)
        self.track = style(base, self.gate.currentData(), self.start.currentData(), self.bar.currentData(),
                           self.pad.currentData(), self.kit)
        self.view.set_track(self.track)
        n = len(self.track["gates"])
        notes = [f"{n} 个检查点，{len(self.track['barriers'])} 个摆件"]
        if abs(k - 1) > 1e-6:
            notes.append(f"门间距比例 1 : {k:g}（门和门之间的距离是原来的 {k:g} 倍），门框大小不变；原来的地图文件不改。")
            notes += ["⚠ 拉开以后：" + w for w in warn]
        if self.pad.currentData() != NO_PAD:
            notes.append("起飞台放在路线起点。如果黑羊提示「只能有一个起点网格」，说明这张地图自带起飞台，把起飞台改成「不放」。")
        if self.bar.currentData() != 54:
            notes.append("杆子按标准地图的做法摆：0.2 米粗的方杆拼成门框，导出后在黑羊里看一眼。")
        self.notes.setText("\n".join(notes))
        self.export_btn.setEnabled(n >= 2)

    def export(self):
        name = self.name.text().strip() or "Track"
        self.track["name"] = name
        docs = Path.home() / "Documents"
        start = str((docs if docs.is_dir() else Path.home()) / (re.sub(r'[\\/:*?"<>|]', "_", name) + ".trk"))
        f, _ = QFileDialog.getSaveFileName(self, "保存黑羊赛道", start, "VelociDrone 赛道 (*.trk)")
        if not f:
            return
        Path(f).write_text(tc.trk_text(self.track), encoding="utf-8")
        self.kit.update(last_scene=self.scene.currentData(), last_gate=self.gate.currentData(),
                        last_start=self.start.currentData(), last_bar=self.bar.currentData(),
                        last_pad=self.pad.currentData(), last_spread=self.spread.currentData())
        save_kit(self.kit)
        QMessageBox.information(
            self, "导出好了",
            f"已保存：{f}\n\n在黑羊里：Track Editor → Import Track → 点「{name}」旁边的 Import。\n"
            "（文件要放在「文档」文件夹里，黑羊才找得到。）")
