"""赛道模拟飞行：打开组委会的 eDrawings 赛道 exe，或者「赛道搭建」搭好的赛道，模拟飞一遍，转成黑羊（VelociDrone）的 .trk"""
import bisect
import json
import math
import re
import subprocess
import time
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QFont, QImage, QPainter, QPen, QPolygonF
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QFileDialog, QFormLayout,
                               QGroupBox, QHBoxLayout,
                               QLabel, QLineEdit, QListWidget, QMessageBox, QProgressDialog, QPushButton, QSpinBox,
                               QSplitter,
                               QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from app import ffmpeg_tools as ft
from app import trackconv as tc
from app import trackgen as tg
from app.config import IS_WINDOWS, USER_DIR
from app.replay import SeekSlider

MEMORY = USER_DIR / "赛道门型.json"


def _load_memory():
    try:
        return json.loads(MEMORY.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


class TopView(QWidget):
    """3D 预览：路线、门框、检查点编号。左键拖动旋转，滚轮缩放。"""
    VIEWS = {"俯视": (0, 90), "斜视": (-30, 35), "正面": (0, 0), "侧面": (90, 0)}

    progress = Signal(str)

    def __init__(self):
        super().__init__()
        self.track = None
        self.yaw, self.pitch, self.zoom = 0.0, 90.0, 1.0
        self.sim_s = None          # 模拟飞机在路线上飞了多少米
        self.speed = 10.0          # 米/秒
        self.follow = False
        self.cam = None            # 跟随视角的平滑镜头 [x, y, z, yaw]
        self.pan = QPointF(0, 0)   # 拖动画面的偏移（像素）
        self.hand = False          # 「小手」：左键拖动画面而不是旋转
        self.yaw_off = 0.0         # 跟随飞机时，左键拖动绕飞机转的角度
        self.timer = QTimer(self)
        self.timer.setInterval(33)
        self.timer.timeout.connect(self._step)
        self._drag = None
        self.arrow_s = []
        self.clean = False         # 导出视频用：不画操作提示
        self.setMinimumSize(560, 420)

    def set_track(self, track):
        self.track = track
        self.stop_sim()
        pts = track['path'] if track else []
        self.arc = [0.0]
        for j in range(1, len(pts)):
            self.arc.append(self.arc[-1] + math.dist(pts[j-1], pts[j]))
        # 每个检查点在路线上的位置（按顺序往后找）
        self.gate_s = []
        j0 = 0
        floor = tc.SCENES[track['scene']][1] if track else 0
        for g in (track['gates'] if track else []):
            q = g['trans']['rot']; ext = tc.qrot(q, (0, 0, 1)); h = g['trans']['scale'][2]*2
            u = [g['trans']['pos'][i] + 0.5*h*ext[i] for i in range(3)]
            c = (u[0]/100, (u[1]-floor)/100, -u[2]/100)
            best = None
            for j in range(j0, len(pts)):
                d = math.dist(pts[j], c)
                if best is None or d < best[1]:
                    best = (j, d)
                elif best[1] < 2.5 and d > best[1] + 1:
                    break
            j0 = best[0] if best else j0
            self.gate_s.append(self.arc[j0] if pts else 0)
        # 组委会的箭头：贴到路线上（一个圆锥常常拆成好几块，靠得近的只留一个）
        self.arrow_s = []
        for tip, _d in (track.get('arrows') or []) if track and len(pts) > 1 else []:
            j, d = min(((j, math.dist(q, tip)) for j, q in enumerate(pts)), key=lambda x: x[1])
            if d < 1.5 and all(abs(self.arc[j] - s) > 2.0 for s in self.arrow_s):
                self.arrow_s.append(self.arc[j])
        self.update()

    # ---- 模拟飞行 ---------------------------------------------------------
    def start_sim(self):
        if not self.track or len(self.track['path']) < 2:
            return
        if self.sim_s is None or self.sim_s >= self.arc[-1]:
            self.sim_s = 0.0
        self.timer.start()

    def pause_sim(self):
        self.timer.stop()

    def stop_sim(self):
        self.timer.stop()
        self.sim_s = None
        self.cam = None
        self.update()

    def _step(self):
        self.sim_s += self.speed * 0.033
        if self.sim_s >= self.arc[-1]:
            self.sim_s = self.arc[-1]
            self.timer.stop()
        self._ease_camera(0.12, 0.035)
        self.update()

    def _target(self):
        pos, head = self._drone()
        yaw = math.degrees(math.atan2(-head[0], -head[2])) if (head[0] or head[2]) else (self.cam or [0]*4)[3]
        return pos + [yaw]

    def _ease_camera(self, a_pos, a_yaw):
        """镜头慢慢跟上飞机：位置和转向都只走剩下距离的一小部分，转弯不会一下子甩过去"""
        if self.sim_s is None:
            return
        t = self._target()
        if self.cam is None:
            self.cam = t
            return
        for i in range(3):
            self.cam[i] += (t[i] - self.cam[i]) * a_pos
        d = (t[3] - self.cam[3] + 180) % 360 - 180
        self.cam[3] += max(-3.0, min(3.0, d * a_yaw))     # 最多每秒转 90 度左右

    def _drone(self):
        """模拟飞机的位置和朝向"""
        pos = self._at(self.sim_s)
        a, b = self._at(self.sim_s - 1.5), self._at(self.sim_s + 3.0)
        return pos, [b[i]-a[i] for i in range(3)]

    def _at(self, s):
        pts = self.track['path']
        s = max(0.0, min(self.arc[-1], s))
        j = max(1, min(len(pts)-1, bisect.bisect_left(self.arc, s)))
        seg = self.arc[j] - self.arc[j-1] or 1
        t = (s - self.arc[j-1]) / seg
        return [pts[j-1][i] + t*(pts[j][i]-pts[j-1][i]) for i in range(3)]

    def _report(self):
        n = len(self.gate_s)
        done = sum(1 for g in self.gate_s if g <= self.sim_s + 0.3)
        nxt = self.track['labels'][done] if done < n else "完成"
        self.progress.emit(f"已过 {done}/{n} 个检查点   下一个：{nxt}   用时 {self.sim_s/self.speed:.1f} 秒")

    def set_view(self, name):
        self.yaw, self.pitch = self.VIEWS[name]
        self.zoom = 1.0
        self.pan = QPointF(0, 0)
        self.update()

    def mousePressEvent(self, e):
        moving = self.hand or e.button() in (Qt.RightButton, Qt.MiddleButton)
        self._drag = (e.position(), self.yaw_off if self.follow else self.yaw, self.pitch, QPointF(self.pan), moving)
        if moving:
            self.setCursor(Qt.ClosedHandCursor)

    def mouseMoveEvent(self, e):
        if self._drag:
            d = e.position() - self._drag[0]
            if self._drag[4]:
                self.pan = self._drag[3] + d
            else:
                if self.follow:
                    self.yaw_off = self._drag[1] - d.x()*0.4
                else:
                    self.yaw = self._drag[1] - d.x()*0.4
                self.pitch = max(-10.0, min(90.0, self._drag[2] + d.y()*0.4))
            self.update()

    def mouseReleaseEvent(self, _):
        self._drag = None
        self.setCursor(Qt.OpenHandCursor if self.hand else Qt.ArrowCursor)

    def set_hand(self, on):
        self.hand = on
        self.setCursor(Qt.OpenHandCursor if on else Qt.ArrowCursor)

    def wheelEvent(self, e):
        self.zoom = max(0.3, min(8.0, self.zoom * (1.15 if e.angleDelta().y() > 0 else 1/1.15)))
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor(32, 30, 44))
        tr = self.track
        if not tr:
            p.setPen(QColor(170, 170, 180))
            p.drawText(self.rect(), Qt.AlignCenter, "把组委会发的赛道 exe 拖到这个窗口里\n（或点左上角「打开赛道文件…」）")
            return
        floor = tc.SCENES[tr['scene']][1]
        C = lambda u: (u[0]/100, (u[1]-floor)/100, -u[2]/100)
        xs = [q[0] for q in tr['path']] + [b['trans']['pos'][0]/100 for b in tr['barriers']]
        zs = [q[2] for q in tr['path']] + [-b['trans']['pos'][2]/100 for b in tr['barriers']]
        if not xs:
            return
        cx, cz = (min(xs)+max(xs))/2, (min(zs)+max(zs))/2
        k = min(self.width()/(max(xs)-min(xs)+6), self.height()/(max(zs)-min(zs)+6)) * self.zoom
        drone = self._drone() if self.sim_s is not None else None
        cy0 = 0.0
        if drone and self.follow:
            if self.cam is None:
                self._ease_camera(1, 1)
            cx, cy0, cz, self.yaw = self.cam
            self.yaw += self.yaw_off
            k = min(self.width(), self.height()) / 14 * self.zoom
        cy_, sy_ = math.cos(math.radians(self.yaw)), math.sin(math.radians(self.yaw))
        cp, sp = math.cos(math.radians(self.pitch)), math.sin(math.radians(self.pitch))
        W2, H2 = self.width()/2 + self.pan.x(), self.height()/2 + self.pan.y()

        def P(x, y, z):
            x, z = x-cx, z-cz
            x1 = x*cy_ - z*sy_; z1 = x*sy_ + z*cy_
            return QPointF(W2 + x1*k, H2 + (z1*sp - (y-cy0)*cp)*k)
        # 地面边框
        p.setPen(QPen(QColor(70, 66, 90), 1))
        x0, x1_, z0, z1_ = min(xs)-3, max(xs)+3, min(zs)-3, max(zs)+3
        p.drawPolygon(QPolygonF([P(x0, 0, z0), P(x1_, 0, z0), P(x1_, 0, z1_), P(x0, 0, z1_)]))
        # 方管：沿最长的方向画一根粗线
        for b in tr['barriers']:
            per_m = 50 if b['prefab'] == 54 else 100       # 54 号方块按 2 米算，黑羊的杆子按 1 米算
            q = b['trans']['rot']; s = [v/per_m for v in b['trans']['scale']]; base = C(b['trans']['pos'])
            ax = [tc.qrot(q, (1, 0, 0)), tc.qrot(q, (0, 1, 0)), tc.qrot(q, (0, 0, 1))]
            ax = [(a[0], a[1], -a[2]) for a in ax]
            c = [base[i] + ax[1][i]*s[1]/2 for i in range(3)]
            i = max(range(3), key=lambda j: s[j]); thick = sorted(s)[1]
            e1 = [c[j] - ax[i][j]*s[i]/2 for j in range(3)]; e2 = [c[j] + ax[i][j]*s[i]/2 for j in range(3)]
            p.setPen(QPen(QColor(225, 225, 225), max(1.5, thick*k), Qt.SolidLine, Qt.FlatCap))
            p.drawLine(P(*e1), P(*e2))
        # 原图里认不出来的东西（刀旗等）：灰色网格
        segs = tr.get('scenery') or []
        if segs:
            p.setPen(QPen(QColor(150, 150, 160), 1))
            p.drawLines([v for a, b in segs for v in (P(*a), P(*b))])
        # 路线
        p.setPen(QPen(QColor(255, 70, 40), 2))
        pts = tr['path']
        for j in range(1, len(pts)):
            if math.dist(pts[j-1], pts[j]) < 6:
                p.drawLine(P(*pts[j-1]), P(*pts[j]))
        # 方向箭头：固定大小的小箭头，不管放多大都一样小巧
        def chevron(sv, col, size, width):
            q, ahead = self._at(sv), self._at(sv + 0.4)
            a_, b_ = P(*q), P(*ahead)
            dx, dy = b_.x() - a_.x(), b_.y() - a_.y()
            n = math.hypot(dx, dy)
            if n < 0.5:
                return
            dx, dy = dx/n, dy/n
            tip = QPointF(a_.x() + dx*size*0.5, a_.y() + dy*size*0.5)
            l = QPointF(tip.x() - dx*size - dy*size*0.7, tip.y() - dy*size + dx*size*0.7)
            r = QPointF(tip.x() - dx*size + dy*size*0.7, tip.y() - dy*size - dx*size*0.7)
            p.setPen(QPen(col, width, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
            p.drawPolyline(QPolygonF([l, tip, r]))
        if len(pts) > 1:
            for sv in self.arrow_s:          # 组委会画的箭头：青色，带一圈淡光
                chevron(sv, QColor(0, 220, 255, 70), 8, 6)
                chevron(sv, QColor(120, 240, 255), 8, 2)
        # 检查点
        for g in tr['gates']:
            q = g['trans']['rot']
            f, lat, ext = (tc.qrot(q, v) for v in ((-1, 0, 0), (0, 1, 0), (0, 0, 1)))
            f, lat, ext = ((a[0], a[1], -a[2]) for a in (f, lat, ext))
            h = g['trans']['scale'][2]/50; w = g['trans']['scale'][1]/50
            base = C(g['trans']['pos'])
            c = [base[i] + ext[i]*h/2 for i in range(3)]
            col = QColor(80, 230, 80) if g['start'] else QColor(255, 90, 90) if g['finish'] else QColor(255, 200, 40)
            if drone:
                gs = self.gate_s[g['gate']]; done = sum(1 for v in self.gate_s if v <= self.sim_s + 0.3)
                col = QColor(60, 220, 90) if gs <= self.sim_s + 0.3 else \
                    QColor(80, 200, 255) if g['gate'] == done else QColor(150, 140, 110)
            corners = [[c[i] + sa*lat[i]*w/2 + sb*ext[i]*h/2 for i in range(3)] for sa, sb in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
            p.setPen(QPen(col, 2))
            p.setBrush(Qt.NoBrush)
            p.drawPolygon(QPolygonF([P(*v) for v in corners]))
            tip = P(*[c[i] + f[i]*1.8 for i in range(3)])
            p.drawLine(P(*c), tip)
            p.setBrush(col)
            p.drawEllipse(tip, 3, 3)
            pc = P(*c)
            p.setPen(QColor(255, 255, 255))
            p.drawText(QRectF(pc.x()+5, pc.y()+2, 30, 16), str(g['gate']))
        if drone:
            pos, head = drone
            hn = math.sqrt(sum(v*v for v in head)) or 1
            head = [v/hn for v in head]
            side = [-head[2], 0, head[0]]
            sn = math.sqrt(side[0]**2 + side[2]**2) or 1
            side = [v/sn for v in side]
            nose = [pos[i] + head[i]*0.6 for i in range(3)]
            l = [pos[i] - head[i]*0.3 + side[i]*0.4 for i in range(3)]
            r = [pos[i] - head[i]*0.3 - side[i]*0.4 for i in range(3)]
            p.setPen(QPen(QColor(255, 255, 255), 2))
            p.setBrush(QColor(0, 230, 255))
            p.drawPolygon(QPolygonF([P(*nose), P(*l), P(*pos), P(*r)]))
            p.setPen(QPen(QColor(0, 230, 255, 120), 1, Qt.DashLine))
            p.drawLine(P(*pos), P(pos[0], 0, pos[2]))
            if not self.clean:
                self._report()
        if self.clean:
            return
        p.setPen(QColor(170, 170, 180))
        p.drawText(8, self.height()-8, "左键拖动转方向，右键拖动移动画面，滚轮缩放   红线=路线  青色小箭头=原图箭头  白=门框  灰=原图其他东西  黄框=检查点  绿=计时门")


VIDEO_SHAPES = {"横屏 16:9": (1280, 720), "竖屏 9:16（抖音）": (720, 1280)}
FPS = 30


def _overlay(img: QImage, title: str, now: float, done: int, n: int):
    """视频上叠赛道名、用时、过门数"""
    W, H = img.width(), img.height()
    p = QPainter(img)
    p.setRenderHint(QPainter.Antialiasing)
    s = min(W, H) / 720
    p.fillRect(QRectF(0, 0, W, 64 * s), QColor(0, 0, 0, 140))
    f = QFont("Microsoft YaHei")
    f.setBold(True)
    f.setPixelSize(int(32 * s))
    p.setFont(f)
    p.setPen(QColor(255, 255, 255))
    p.drawText(QRectF(20 * s, 0, W - 40 * s, 64 * s), Qt.AlignVCenter | Qt.AlignLeft, title)
    p.fillRect(QRectF(0, H - 80 * s, W, 80 * s), QColor(0, 0, 0, 140))
    f.setPixelSize(int(44 * s))
    p.setFont(f)
    p.drawText(QRectF(20 * s, H - 80 * s, W, 80 * s), Qt.AlignVCenter | Qt.AlignLeft, f"{now:.1f} 秒")
    f.setPixelSize(int(28 * s))
    p.setFont(f)
    p.setPen(QColor(120, 230, 140))
    p.drawText(QRectF(0, H - 80 * s, W - 20 * s, 80 * s), Qt.AlignVCenter | Qt.AlignRight,
               "完成！" if done >= n else f"第 {done + 1} / {n} 个门")
    f.setBold(False)
    f.setPixelSize(int(18 * s))
    p.setFont(f)
    p.setPen(QColor(200, 200, 210, 180))
    p.drawText(QRectF(0, 64 * s, W - 14 * s, 30 * s), Qt.AlignVCenter | Qt.AlignRight, "无人机竞速 · 赛道模拟")
    p.end()


class TrackDialog(QDialog):
    def __init__(self, folder=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("赛道模拟飞行")
        self.folder = Path(folder) if folder else None
        self.setAcceptDrops(True)
        self.resize(1250, 780)
        self.model = None
        self.src = None
        self.memory = _load_memory()
        self.types = {}
        self.built_path = None              # 「赛道搭建」的赛道自带飞行路线

        open_btn = QPushButton("打开赛道…")
        open_btn.setMinimumHeight(40)
        open_btn.setToolTip("「赛道搭建」保存的赛道，或者组委会发的 eDrawings 赛道 exe")
        open_btn.clicked.connect(self.choose_file)
        self.file_label = QLabel("还没有选文件")
        self.orig_btn = QPushButton("用 eDrawings 打开原图对照")
        self.orig_btn.setEnabled(False)
        self.orig_btn.clicked.connect(self.open_original)
        self.gap = QDoubleSpinBox()
        self.gap.setRange(1.0, 5.0); self.gap.setSingleStep(0.1); self.gap.setDecimals(2); self.gap.setValue(2.5)
        self.gap.setSuffix(" 米")
        self.bar = QSpinBox()
        self.bar.setRange(20, 500); self.bar.setSingleStep(10); self.bar.setValue(200); self.bar.setSuffix(" 毫米")
        self.scene = QComboBox()
        for sid, (label, _) in tc.SCENES.items():
            self.scene.addItem(label, sid)
        self.name = QLineEdit()
        self.name.setPlaceholderText("赛道名（建议用英文，黑羊里可能显示不了中文）")
        for w in (self.gap, self.bar):
            w.valueChanged.connect(self.rebuild)
        self.scene.currentIndexChanged.connect(self.rebuild)

        form = QFormLayout()
        form.addRow("门洞宽高", self.gap)
        form.addRow("方管粗细", self.bar)
        form.addRow("场景", self.scene)
        form.addRow("赛道名", self.name)
        size_box = QGroupBox("尺寸")
        size_box.setLayout(form)

        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["零件", "数量", "当作"])
        self.table.verticalHeader().setVisible(False)
        self.table.setColumnWidth(0, 150); self.table.setColumnWidth(1, 40); self.table.setColumnWidth(2, 170)
        # 零件类型表平时收起来（只有组委会 exe 认错零件时才用得到）
        self.part_box = QGroupBox("零件类型（认错了可以改，下次会记住）")
        pl = QVBoxLayout(self.part_box)
        pl.addWidget(self.table)
        self.part_box.setVisible(False)
        self.part_btn = QPushButton("零件认错了？点这里改")
        self.part_btn.setFlat(True)
        self.part_btn.setStyleSheet("color: gray; text-align: left;")
        self.part_btn.clicked.connect(lambda: self.part_box.setVisible(not self.part_box.isVisible()))
        self.part_btn.setVisible(False)
        self.order = QListWidget()
        order_box = QGroupBox("过门顺序")
        QVBoxLayout(order_box).addWidget(self.order)

        self.export_btn = QPushButton("转成黑羊赛道（导出 TRK）")
        self.export_btn.setToolTip("想换门框颜色、杆子或起飞台，用主界面的「导出到黑羊」")
        self.export_btn.setMinimumHeight(48)
        self.export_btn.setEnabled(False)
        self.export_btn.clicked.connect(self.export)

        left = QWidget()
        ll = QVBoxLayout(left)
        ll.addWidget(open_btn)
        ll.addWidget(self.file_label)
        ll.addWidget(self.orig_btn)
        ll.addWidget(size_box)
        ll.addWidget(order_box, 1)
        ll.addWidget(self.part_btn)
        ll.addWidget(self.part_box, 1)
        ll.addWidget(self.export_btn)

        self.view = TopView()
        self.notes = QLabel()
        self.notes.setWordWrap(True)
        self.notes.setStyleSheet("color: #c77800;")
        right = QWidget()
        rl = QVBoxLayout(right)
        rl.addWidget(self.view, 1)
        self.sim_label = QLabel("点「▶ 播放」，看一架飞机按顺序和方向穿过每个门（蓝框=下一个，绿框=已经过了）")
        self.view.progress.connect(self.sim_label.setText)
        self.view.timer.timeout.connect(self._sim_ended)
        bar = QHBoxLayout()
        self.seek = SeekSlider()
        self.seek.setRange(0, 1000)
        self.seek.sliderMoved.connect(self.seek_to)
        self.seek_time = QLabel("0.0 / 0.0 秒")
        bar.addWidget(self.seek, 1)
        bar.addWidget(self.seek_time)
        rl.addLayout(bar)
        # 所有按钮放在进度条下面一排
        ctl = QHBoxLayout()
        self.left_panel = left
        self.fold_btn = QPushButton("◀ 收起左栏")
        self.fold_btn.clicked.connect(self.toggle_left)
        hand = QPushButton("✋ 拖动画面")
        hand.setCheckable(True)
        hand.toggled.connect(self.view.set_hand)
        ctl.addWidget(self.fold_btn)
        ctl.addWidget(hand)
        for name in TopView.VIEWS:
            vb = QPushButton(name)
            vb.clicked.connect(lambda _c=False, n=name: self.view.set_view(n))
            ctl.addWidget(vb)
        ctl.addStretch()
        ctl2 = QHBoxLayout()           # 第二排：播放控制
        back = QPushButton("⏪ 快退 5 秒")
        back.clicked.connect(lambda: self.step_sim(-5))
        self.play_btn = QPushButton("▶ 播放")
        self.play_btn.setMinimumWidth(110)
        self.play_btn.clicked.connect(self.toggle_sim)
        fwd = QPushButton("快进 5 秒 ⏩")
        fwd.clicked.connect(lambda: self.step_sim(5))
        again = QPushButton("从头飞")
        again.clicked.connect(self.restart_sim)
        self.speed_box = QComboBox()
        for v in (5, 10, 15, 20):
            self.speed_box.addItem(f"{v} 米/秒", v)
        self.speed_box.setCurrentIndex(1)
        self.speed_box.currentIndexChanged.connect(self._speed_changed)
        follow = QCheckBox("跟着飞机看")
        follow.toggled.connect(self.set_follow)
        for w in (back, self.play_btn, fwd, again, self.speed_box, follow):
            ctl2.addWidget(w)
        ctl2.addStretch()
        rl.addLayout(ctl)
        rl.addLayout(ctl2)
        # 一键导出小视频：按现在的视角、速度，从头飞一遍录成 mp4
        vid = QHBoxLayout()
        self.shape_box = QComboBox()
        for label, size in VIDEO_SHAPES.items():
            self.shape_box.addItem(label, size)
        self.video_btn = QPushButton("🎬 一键导出小视频")
        self.video_btn.setMinimumHeight(34)
        self.video_btn.setToolTip("按现在的视角和速度从头飞一遍，存成 mp4，可以直接发微信、抖音")
        self.video_btn.setEnabled(False)
        self.video_btn.clicked.connect(self.export_video)
        vid.addWidget(self.video_btn)
        vid.addWidget(self.shape_box)
        vid.addWidget(QLabel("先选好视角（俯视、斜视、跟着飞机看）和速度，导出的视频就是这个样子。"))
        vid.addStretch()
        rl.addLayout(vid)
        rl.addWidget(self.sim_label)
        rl.addWidget(self.notes)

        split = QSplitter()
        split.addWidget(left)
        split.addWidget(right)
        split.setStretchFactor(1, 1)
        split.setSizes([380, 900])
        lay = QHBoxLayout(self)
        lay.addWidget(split)

    # ---- 模拟飞行 ---------------------------------------------------------
    def toggle_left(self):
        show = not self.left_panel.isVisible()
        self.left_panel.setVisible(show)
        self.fold_btn.setText("◀ 收起左栏" if show else "▶ 展开左栏")

    def toggle_sim(self):
        if self.view.timer.isActive():
            self.view.pause_sim()
        else:
            self.view.start_sim()
        self._sync_buttons()

    def _sync_buttons(self):
        v = self.view
        if v.timer.isActive():
            text = "⏸ 暂停"
        elif v.sim_s is None or (v.arc and v.sim_s >= v.arc[-1]):
            text = "▶ 播放"
        else:
            text = "▶ 继续"
        self.play_btn.setText(text)

    def step_sim(self, sec):
        v = self.view
        if not v.track or len(v.arc) < 2:
            return
        s = (v.sim_s or 0.0) + sec * v.speed
        self.seek_to(round(1000 * max(0.0, min(v.arc[-1], s)) / v.arc[-1]))

    def _speed_changed(self, _i):
        self.view.speed = self.speed_box.currentData()
        self._sync_seek()

    def _sync_seek(self):
        v = self.view
        if not v.track or len(v.arc) < 2:
            return
        total = v.arc[-1] / v.speed; now = (v.sim_s or 0) / v.speed
        if not self.seek.isSliderDown():
            self.seek.blockSignals(True)
            self.seek.setValue(round(1000 * (v.sim_s or 0) / v.arc[-1]))
            self.seek.blockSignals(False)
        self.seek_time.setText(f"{now:.1f} / {total:.1f} 秒")

    def seek_to(self, val):
        v = self.view
        if not v.track or len(v.arc) < 2:
            return
        v.sim_s = val / 1000 * v.arc[-1]
        v.cam = None
        v.update()
        self._sync_seek()
        self._sync_buttons()

    def _sim_ended(self):
        self._sync_seek()
        self._sync_buttons()

    def restart_sim(self):
        self.view.stop_sim()
        if self.view.timer.isActive() is False:
            self.view.start_sim()
        self._sync_buttons()
        self._sync_seek()

    def set_follow(self, on):
        self.view.follow = on
        self.view.cam = None
        self.view.yaw_off = 0.0
        if on:
            self.view.pitch, self.view.zoom, self.view.pan = 30, 1.0, QPointF(0, 0)
        else:
            self.view.set_view("斜视")
        self.view.update()

    def _video_file(self, name):
        base = self.folder.parent if self.folder else Path.home() / "Videos"
        out = base / "赛道视频"
        out.mkdir(parents=True, exist_ok=True)
        safe = re.sub(r'[\\/:*?"<>|]', "_", name)
        return out / f"{safe}-{time.strftime('%m%d-%H%M%S')}.mp4"

    def export_video(self):
        """离屏再画一遍整条路线，一帧一帧交给 FFmpeg 压成 mp4"""
        src = self.view
        exe = ft.ffmpeg_path()
        if not src.track or len(src.arc) < 2 or not exe:
            QMessageBox.warning(self, "导不出来", "没有赛道路线，或者找不到 FFmpeg。")
            return
        src.pause_sim()
        self._sync_buttons()
        W, H = self.shape_box.currentData()
        v = TopView()
        v.clean = True
        v.resize(W, H)
        v.set_track(src.track)
        v.yaw, v.pitch, v.zoom, v.follow, v.yaw_off = src.yaw, src.pitch, src.zoom, src.follow, src.yaw_off
        v.pan = QPointF(src.pan.x() * W / max(1, src.width()), src.pan.y() * H / max(1, src.height()))
        if not v.follow:
            v.zoom *= 0.85                                      # 给上下的字条让出位置
        title = self.src.stem if self.src else (self.name.text().strip() or "赛道")
        file = self._video_file(title)
        total = src.arc[-1]
        step = src.speed / FPS
        frames = int(total / step) + 1
        hold_a, hold_b = FPS // 2, FPS * 3 // 2                 # 开头停半秒、结尾停一秒半
        cmd = [exe, "-hide_banner", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra",
               "-s", f"{W}x{H}", "-r", str(FPS), "-i", "pipe:0", "-an", "-c:v", "libx264", "-preset", "veryfast",
               "-crf", "20", "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(file)]
        try:
            proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=ft.NO_WINDOW)
        except OSError as ex:
            QMessageBox.warning(self, "导不出来", f"打不开 FFmpeg：{ex}")
            return
        dlg = QProgressDialog("正在导出小视频…", "取消", 0, frames + hold_a + hold_b, self)
        dlg.setWindowTitle("导出小视频")
        dlg.setWindowModality(Qt.WindowModal)
        dlg.setMinimumDuration(0)
        img = QImage(W, H, QImage.Format_ARGB32)
        n = len(v.gate_s)
        ok = True
        try:
            for i in range(hold_a + frames + hold_b):
                k = min(max(0, i - hold_a), frames - 1)
                v.sim_s = min(total, k * step)
                v._ease_camera(0.12, 0.035)
                img.fill(QColor(0, 0, 0))
                v.render(img)
                done = sum(1 for g in v.gate_s if g <= v.sim_s + 0.3)
                _overlay(img, title, v.sim_s / src.speed, done, n)
                proc.stdin.write(bytes(img.constBits()))
                if i % 3 == 0:
                    dlg.setValue(i)
                    if dlg.wasCanceled():
                        ok = False
                        break
        except OSError:
            ok = False
        dlg.close()
        try:
            proc.stdin.close()
        except OSError:
            pass
        err = proc.stderr.read().decode("utf-8", "replace").strip()
        proc.wait()
        if not ok or proc.returncode != 0:
            file.unlink(missing_ok=True)
            if dlg.wasCanceled():
                return
            QMessageBox.warning(self, "导出失败", err[-300:] or "FFmpeg 出错了")
            return
        if IS_WINDOWS:
            subprocess.Popen(["explorer", "/select,", str(file)])
        else:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(file.parent)))
        QMessageBox.information(self, "导出好了", f"小视频已经保存：\n{file}\n\n可以直接发微信、抖音。")

    # ---- 拖文件 -----------------------------------------------------------
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        urls = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
        if urls:
            self.open_file(urls[0])

    def choose_file(self):
        start = str(self.folder) if self.folder and self.folder.is_dir() else ""
        f, _ = QFileDialog.getOpenFileName(self, "打开赛道", start,
                                           f"赛道 (*{tg.SUFFIX} *.exe *.eprt *.easm);;搭建的赛道 (*{tg.SUFFIX});;"
                                           "组委会 eDrawings 赛道 (*.exe *.eprt *.easm);;所有文件 (*)")
        if f:
            self.open_file(f)

    def open_file(self, path):
        if str(path).endswith(tg.SUFFIX) or str(path).endswith(".json"):
            return self.open_built(path)
        try:
            self.model = tc.load(path)
        except Exception as ex:  # noqa: BLE001 - 文件格式各种各样，统一提示
            QMessageBox.warning(self, "读不出来", f"这个文件读不出赛道：\n{ex}")
            return
        self.src = Path(path)
        self.built_path = None
        self.file_label.setText(self.src.name)
        self.orig_btn.setEnabled(True)
        if not self.name.text().strip():
            ascii_name = re.sub(r"[^A-Za-z0-9 _-]", "", self.src.stem).strip()
            self.name.setText(ascii_name or "Track")
        self.types = tc.default_types(self.model, self.memory)
        self.part_btn.setVisible(True)
        self.fill_table()
        self.rebuild()

    def open_built(self, path):
        """「赛道搭建」保存的赛道：门的位置和飞行路线都在文件里"""
        try:
            model, types, route, d = tg.load(path)
        except (OSError, ValueError, KeyError) as ex:
            QMessageBox.warning(self, "读不出来", f"这个赛道文件读不出来：\n{ex}")
            return
        self.model, self.types, self.built_path = model, types, route
        self.src = None
        self.part_btn.setVisible(False)
        self.part_box.setVisible(False)
        self.orig_btn.setEnabled(False)
        meta = d.get("meta", {})
        self.file_label.setText(f"搭建的赛道：{d.get('name', '')}" +
                                (f"（练习「{meta['focus']}」）" if meta.get("focus") else ""))
        self.name.setText(d.get("name") or "Track")
        for w, v in ((self.gap, meta.get("S")), (self.bar, round(meta.get("T", 0) * 1000) or None)):
            if v:
                w.blockSignals(True)
                w.setValue(v)
                w.blockSignals(False)
        self.fill_table()
        self.rebuild()

    def open_original(self):
        """组委会的 exe 本身就是 eDrawings 看图程序：打开它，和这里的预览对照"""
        if self.src and self.src.exists():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.src)))

    def fill_table(self):
        groups = {}
        for p in self.model['parts']:
            groups.setdefault(tc.name_key(p['name']), []).append(p['id'])
        self.groups = groups
        self.table.setRowCount(0)
        self.table.setRowCount(len(groups))
        for r, (key, ids) in enumerate(sorted(groups.items())):
            self.table.setItem(r, 0, QTableWidgetItem(key))
            self.table.setItem(r, 1, QTableWidgetItem(str(len(ids))))
            box = QComboBox()
            for t, label in tc.TYPES.items():
                box.addItem(label, t)
            box.setCurrentIndex(list(tc.TYPES).index(self.types[ids[0]]))
            box.currentIndexChanged.connect(lambda _i, k=key, b=box: self.set_type(k, b.currentData()))
            box.setEnabled(self.built_path is None)
            self.table.setCellWidget(r, 2, box)

    def set_type(self, key, t):
        for i in self.groups[key]:
            self.types[i] = t
        self.memory[key] = t
        try:
            MEMORY.write_text(json.dumps(self.memory, ensure_ascii=False, indent=1), encoding="utf-8")
        except OSError:
            pass
        self.rebuild()

    def rebuild(self):
        if not self.model:
            return
        self.track = tc.build(self.model, self.types, S=self.gap.value(), T=self.bar.value()/1000,
                              scene=self.scene.currentData(), name=self.name.text().strip() or "Track",
                              path=self.built_path)
        self.view.set_track(self.track)
        self._sync_seek()
        self._sync_buttons()
        self.order.clear()
        for i, lab in enumerate(self.track['labels']):
            self.order.addItem(f"{i:2d}  {lab}")
        n = len(self.track['gates'])
        self.notes.setText("\n".join(self.track['notes']))
        self.export_btn.setEnabled(n >= 2)
        self.video_btn.setEnabled(len(self.track['path']) > 1)
        if n < 2:
            self.notes.setText("没找到飞行路线或门，导不出来。看看左边零件类型认得对不对。")

    def export(self):
        name = self.name.text().strip() or "Track"
        self.track['name'] = name
        docs = Path.home() / "Documents"
        start = str((docs if docs.is_dir() else Path.home()) / (re.sub(r'[\\/:*?"<>|]', "_", name) + ".trk"))
        f, _ = QFileDialog.getSaveFileName(self, "保存黑羊赛道", start, "VelociDrone 赛道 (*.trk)")
        if not f:
            return
        Path(f).write_text(tc.trk_text(self.track), encoding="utf-8")
        QMessageBox.information(
            self, "导出好了",
            f"已保存：{f}\n\n在黑羊里：Track Editor → Import Track → 点「{name}」旁边的 Import。\n"
            "（文件要放在「文档」文件夹里，黑羊才找得到。）")
