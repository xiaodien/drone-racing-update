"""摆门（3D，照黑羊编辑器的用法）：左边一排门点一下，再点地上放；靠近别的门会磁吸，并排或者叠上去，拼成组合门。

左键点门框 = 选中，拖 = 在地上移动（组合门整组一起动），滚轮在门上 = 转方向（每格 15 度），
进门顺序照黑羊：左键点门洞（面）= 加进路线（青色框 + 箭头），再点一次 = 换方向，系统按顺序自动连线；
进门框和箭头只在编辑时显示，保存以后就藏起来。
路线先一个门一个门连，不连回起始门；最后点一下起始门（绿色 1 号）才收成一圈。
每个门旁边有把锁：关上 = 锁定（拖不动、转不了），点一下打开就能调。
手绘：选中顺序里的一步，点「手绘这一段」，按住左键在画面里画到下一步（斜视画平面，正面/侧面能画上下翻）。
放门的时候滚轮 = 转要放的门，右键点一下 / Esc = 不放了；右键拖 = 转视角，中键拖或 Shift+右键拖 = 移动画面，空地滚轮 = 缩放。
"""
import math

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QIcon, QPainter, QPen, QPixmap, QPolygonF
from PySide6.QtWidgets import QMessageBox, QToolButton, QWidget

from app import trackconv as tc
from app import trackgen as tg

GATES = ('单门', '日子门', '三联', '单重', '双重')
STACKABLE = ('单门', '日子门')          # 能并排、能叠起来拼组合门的
RED = QColor(229, 57, 53)


def footprint(t, S, T):
    """门在地上占的宽（横着，米）和厚（顺着飞的方向）"""
    w = S+2*T
    if t == '三联':
        return 3*S+4*T, T
    if t in ('单重', '双重'):
        return w, w
    if t in (tg.WP, tg.POLE, tg.FLAG):
        return 0.6, 0.6
    if t == tg.TAKEOFF:
        return 3.8, 0.5
    return w, T


def height(t, S, T):
    H = S+2*T
    if t == tg.FLAG:
        return 3.2
    if t == tg.TAKEOFF:
        return 1.2
    return 2*H-T if t in ('日子门', '双重') else H


def label(t):
    if t == tg.WP:
        return "路线点"
    if t == tg.POLE:
        return "绕杆"
    return tg.GATE_TYPES.get(t, t)


def flag_side(step):
    """刀旗那一步：从旗的哪边过（按飞的方向看）"""
    side = step.get('f') == '左'
    if (step.get('d') or 1) < 0:
        side = not side
    hand = "旗在左手边" if side else "旗在右手边"
    return ("掉头回来，" + hand) if (step.get('d') or 1) < 0 else ("过去，" + hand)


def icon(t, size=64, items=None):
    """左边那排按钮的小图：门斜着看的 3D 样子（和摆门画面一样的方管）；items = 组合门里的门"""
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    s = size
    if t == tg.WP:
        p.setPen(QPen(QColor(60, 160, 255), 3))
        p.drawEllipse(QPointF(s*.5, s*.5), s*.16, s*.16)
        p.end()
        return QIcon(pm)
    its = items or [dict(t='杆子' if t == tg.POLE else t, x=0, z=0, yaw=0)]
    cy, sy = math.cos(math.radians(58)), math.sin(math.radians(58))
    cp, sp = math.cos(math.radians(24)), math.sin(math.radians(24))
    segs = []
    for it in its:
        it = dict(it, x=it.get('x', 0), z=it.get('z', 0))
        for a3, b3, th in frames(it, 2.5, 0.2):
            segs.append((a3, b3))

    def proj(q):
        x1 = q[0]*cy - q[2]*sy
        z1 = q[0]*sy + q[2]*cy
        return x1, z1*sp - q[1]*cp, z1*cp + q[1]*sp
    pts = [proj(q) for sg in segs for q in sg]
    if t == tg.POLE:
        pts += [proj([1.3*math.cos(a), 1.2, 1.3*math.sin(a)]) for a in (0, 1.57, 3.14, 4.71)]
    x0, x1 = min(q[0] for q in pts), max(q[0] for q in pts)
    y0, y1 = min(q[1] for q in pts), max(q[1] for q in pts)
    k = (s-6) / max(x1-x0, y1-y0, 0.1)
    ox, oy = (s - (x1-x0)*k)/2 - x0*k, (s - (y1-y0)*k)/2 - y0*k
    dz = [proj(q)[2] for sg in segs for q in sg]
    d0, d1 = min(dz), max(dz)
    for a3, b3 in sorted(segs, key=lambda sg: -(proj(sg[0])[2] + proj(sg[1])[2])):
        A, B = proj(a3), proj(b3)
        near = 1 - ((A[2]+B[2])/2 - d0) / max(d1-d0, 1e-6)        # 近的深、远的淡
        col = QColor(230, 90, 40) if t not in (tg.POLE, tg.FLAG) else QColor(240, 150, 30)
        col.setAlpha(int(110 + 145*near))
        p.setPen(QPen(col, 4.2 if near > 0.5 else 3.0, Qt.SolidLine, Qt.RoundCap))
        p.drawLine(QPointF(A[0]*k+ox, A[1]*k+oy), QPointF(B[0]*k+ox, B[1]*k+oy))
    if t == tg.POLE:
        c = proj([0, 1.2, 0])
        p.setPen(QPen(QColor(60, 160, 255), 2))
        p.drawEllipse(QPointF(c[0]*k+ox, c[1]*k+oy), 1.3*k, 1.3*k*sp)
    p.end()
    return QIcon(pm)


def step_text(it, step):
    """过门顺序里一步的说明：日字门 · 下洞 / 绕杆（杆子在左手边绕）/ 路线点"""
    if it['t'] == tg.POLE:
        return "绕杆（" + tg.pole_label(it.get('how')) + "）"
    if it['t'] == tg.WP:
        return "路线点"
    if it['t'] == tg.FLAG:
        return "刀旗 · " + flag_side(step)
    fn = tg.face_name(step.get('f', ''))
    return (it.get('name') or label(it['t'])) + (" · " + fn if fn else "") + ("" if (step.get('d') or 1) > 0 else "（反着穿）")


def group_of(items, i):
    g = items[i].get('grp')
    return [j for j, it in enumerate(items) if g is not None and it.get('grp') == g] or [i]


def new_grp(items):
    return max([it.get('grp') or 0 for it in items] + [0]) + 1


def frames(it, S, T):
    """一个门的方管，世界坐标：[(端点1, 端点2, 粗细)]，画成一根根粗线"""
    t = it['t']
    kind = '杆子' if t == tg.POLE else t
    a = math.radians(it.get('yaw', 0))
    f = [math.cos(a), 0.0, math.sin(a)]
    lf = [-f[2], 0.0, f[0]]
    A, B = (f, lf) if t == '三联' else (lf, f)
    lift = it.get('lift', 0) or 0
    out = []
    for (cx, cy, cz), (sx, sy, sz) in tc.boxes(kind, S, T, lifted=lift > 0.01):
        s = (sx, sy, sz)
        i = max(range(3), key=lambda j: s[j])
        d = [0, 0, 0]
        d[i] = s[i]/2

        def W(u, v, w):
            return [it['x'] + u*A[0] + w*B[0], v + lift, it['z'] + u*A[2] + w*B[2]]
        out.append((W(cx-d[0], cy-d[1], cz-d[2]), W(cx+d[0], cy+d[1], cz+d[2]), sorted(s)[1]))
    return out


class FieldEditor(QWidget):
    changed = Signal()              # 门的位置、方向、数量、进门顺序变了（松开鼠标时发）
    selected = Signal(int)          # 选中第几个（-1 = 没选）
    helpers_changed = Signal(bool)  # 进门框、箭头显示 / 藏起来
    pen_clicked = Signal()          # 右上角画笔：手绘路线
    VIEWS = {"斜视": (-25, 40), "俯视": (0, 90), "正面": (0, 8), "侧面": (90, 8)}

    def __init__(self):
        super().__init__()
        self.items = []
        self.route = []                 # 进门顺序：[{id, f 门洞, d ±1}]，路线点、绕杆只有 id
        self.sel_step = None            # 选中的是顺序里的第几步
        self.helpers = True             # 进门框、箭头：编辑时显示，保存以后藏起来
        self.hover = None               # 鼠标指着的门洞 (第几个门, 标签)
        self.closed = False             # 路线收成一圈了没有（点一下起始门才收）
        self.drawing = None             # 手绘：正在画顺序里第几步到下一步那一段；'free' = 画笔直接画（画过的门洞加进顺序）
        self._fhits = []                # 直接画时经过的门洞 [(画到第几个点, 第几个门, 门洞)]
        self.stroke = []                # 正在画的点（世界坐标）
        self._locks = {}                # 锁的位置：第几个门 -> 屏幕上的框
        self.W, self.L = 30.0, 45.0
        self.S, self.T = 2.5, 0.2
        self.path = []
        self.sel = None
        self.zoom = 1.0
        self.yaw, self.pitch = self.VIEWS["斜视"]
        self.pan = QPointF(0, 0)
        self._drag = None
        self._bounds = (-22.5, 22.5, -15, 15)
        self.placing = None             # 正在放的东西：[相对位置的 item]（一个门 = 一个）
        self.ghost_yaw = None           # 放的时候滚轮转过：None = 自动朝向上一个门
        self.mouse = None
        self.snap_hint = ""
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setMinimumSize(560, 420)
        self.pen = QToolButton(self)    # 右上角画笔
        self.pen.setText("✏ 手绘路线")
        self.pen.setCheckable(True)
        self.pen.setToolTip("直接从最后一个门洞往后画，画过的门洞按先后加进顺序；选中顺序里中间一步再点 = 重画那一段；再点一下取消")
        self.pen.setStyleSheet("QToolButton { background: #2b3a36; color: #ffd54f; border: 1px solid #ffd54f;"
                               " border-radius: 4px; padding: 4px 8px; font-weight: bold; }"
                               "QToolButton:checked { background: #ffd54f; color: #222; }")
        self.pen.setFocusPolicy(Qt.NoFocus)
        self.pen.clicked.connect(lambda _c=False: self.pen_clicked.emit())

    def resizeEvent(self, e):
        self.pen.adjustSize()
        self.pen.move(self.width() - self.pen.width() - 12, 12)
        super().resizeEvent(e)

    def set_data(self, items, route, W, L, S, T, path=None, refit=False, closed=None):
        self.items, self.route, self.W, self.L, self.S, self.T = items, route, W, L, S, T
        if closed is not None:
            self.closed = closed
        if path is not None:
            self.path = path
        if self.sel is not None and self.sel >= len(items):
            self.sel = None
        if self.sel_step is not None and self.sel_step > len(route) - (0 if self.closed else 1):
            self.sel_step = None
        if refit or not self._drag:
            xs = [-L/2, L/2] + [it['x'] for it in items]
            zs = [-W/2, W/2] + [it['z'] for it in items]
            self._bounds = (min(xs), max(xs), min(zs), max(zs))
        self.update()

    def set_view(self, name):
        self.yaw, self.pitch = self.VIEWS[name]
        self.zoom = 1.0
        self.pan = QPointF(0, 0)
        self.update()

    def select(self, i):
        self.sel = i if i is not None and 0 <= i < len(self.items) else None
        self.update()

    def set_helpers(self, on):
        if on != self.helpers:
            self.helpers = on
            self.helpers_changed.emit(on)
            self.update()

    def locked(self, i):
        return any(self.items[j].get('lock') for j in group_of(self.items, i))

    def toggle_lock(self, i):
        on = not self.locked(i)
        for j in group_of(self.items, i):
            if on:
                self.items[j]['lock'] = True
            else:
                self.items[j].pop('lock', None)
        self.update()

    def step_point(self, st):
        """顺序里一步在哪（门洞中心 / 东西的位置）"""
        j = self.index_of(st.get('id'))
        if j is None:
            return None
        it = self.items[j]
        if st.get('f'):
            fc = {q[0]: q for q in tg.faces(it, self.S, self.T)}.get(st['f'])
            if fc:
                return fc[1]
        return [it['x'], it.get('h') or 1.6, it['z']]

    def start_draw(self, k):
        """手绘第 k 步到下一步那一段"""
        self.drawing = k
        self.stroke = []
        self.set_helpers(True)
        self.setFocus()
        self.update()

    def start_free(self):
        """画笔直接画：从顺序最后一步往后画，画过的门洞按先后加进顺序，路线照画的走"""
        self.drawing = 'free'
        self.stroke = []
        self._fhits = []
        self.set_helpers(True)
        self.setFocus()
        self.update()

    def _free_point(self, p):
        """画笔在屏幕上的点 -> 世界坐标：斜视/俯视画在门洞中间高度的平面上，正面/侧面画在上一步那个深度"""
        mid = self.T + self.S/2
        if self.pitch >= 25:
            x, z = self.W2(p, mid)
            return [x, mid, z]
        ref = self.step_point(self.route[-1]) if self.route else None
        self._setup()
        return self._unproject(p, self._depth(ref) if ref else 0.0)

    def _free_hit(self, p, q):
        """画笔经过哪个门洞：屏幕上在门洞里，而且画的点离门洞不远（不算从门前面、后面路过）"""
        cand = []
        for i, lab, C, N, poly in self._faces():
            if not poly.containsPoint(p, Qt.OddEvenFill):
                continue
            if math.hypot(q[0]-C[0], q[2]-C[2]) > max(2.5, tg._half(self.items[i], self.S, self.T) + 1.0):
                continue
            cand.append((self._depth(C), i, lab))
        return max(cand)[1:] if cand else None

    def _finish_free(self):
        pts, hits = self.stroke, self._fhits
        self.drawing = None
        self.stroke, self._fhits = [], []
        if len(pts) < 2:
            return
        steps = []
        for idx, i, lab in hits:
            fc = {q[0]: q for q in tg.faces(self.items[i], self.S, self.T)}.get(lab)
            if not fc:
                continue
            N = fc[2]
            mv = tc.sub(pts[min(len(pts)-1, idx+3)], pts[max(0, idx-3)])
            d = None if abs(N[1]) > 0.7 or math.hypot(mv[0], mv[2]) < 0.3 else (1 if tc.dot(mv, N) >= 0 else -1)
            steps.append((idx, i, lab, d))
        start = 0
        if steps and self.route and self.items[steps[0][1]].get('id') == self.route[-1].get('id') \
                and steps[0][2] == self.route[-1].get('f'):
            start = steps.pop(0)[0]                 # 从最后那个门洞开始画的：它不再加一次
        for idx, i, lab, d in steps:
            if self.closed:
                break
            faces_in = [k for k, st in enumerate(self.route) if st.get('f')]
            first = self.route[faces_in[0]] if faces_in else None
            if not self.route and self.items[i]['t'] == tg.FLAG:
                continue                            # 起始门要真门
            if first and first.get('id') == self.items[i].get('id') and first.get('f') == lab and len(faces_in) >= 2:
                self.closed = True                  # 画回起始门：收圈
                self._set_via(len(self.route)-1, pts[start:idx+1], 0)
                break
            self.route.append({'id': self.items[i]['id'], 'f': lab,
                               'd': d if d is not None else self._auto_dir(i, lab, len(self.route))})
            if len(self.route) > 1:
                self._set_via(len(self.route)-2, pts[start:idx+1], len(self.route)-1)
            start = idx
        self.sel_step = len(self.route) if self.closed else (len(self.route)-1 if self.route else None)

    def _set_via(self, k, seg, nxt):
        """第 k 步到第 nxt 步：用画的线（去掉贴着两头门洞 2 米以内的点，留给进出门）"""
        a, b = self.step_point(self.route[k]), self.step_point(self.route[nxt])
        if a is None or b is None:
            return
        pts = []
        for q in seg:
            if math.hypot(q[0]-a[0], q[2]-a[2]) < 2.0 or math.hypot(q[0]-b[0], q[2]-b[2]) < 2.0:
                continue
            if not pts or math.dist(q, pts[-1]) > 1.2:
                pts.append([round(v, 2) for v in q])
        if pts:
            self.route[k]['via'] = pts
            self.route[k]['via_ab'] = [[round(v, 2) for v in q] for q in (a, b)]
        else:
            self.route[k].pop('via', None)

    def _unproject(self, p, D):
        """屏幕上的点 -> 离看的人深度为 D 的那个面上的世界坐标（平行投影）"""
        self._setup()
        x1 = (p.x()-self._W2)/self.k
        v = (p.y()-self._H2)/self.k
        z1 = v*self._sp + D*self._cp
        y = D*self._sp - v*self._cp
        x = x1*self._cy + z1*self._sy
        z = -x1*self._sy + z1*self._cy
        return [x + self._c[0], max(0.4, y), z + self._c[1]]

    def _draw_depth(self):
        k = self.drawing
        n = len(self.route)
        a = self.step_point(self.route[k])
        b = self.step_point(self.route[(k+1) % n])
        if a is None or b is None:
            return None
        self._setup()
        return self._depth(tc.mul(tc.add(a, b), 0.5))

    def _ask_start(self):
        return QMessageBox.question(self, "起始门", "把这个门设成起始门（计时门）吗？\n"
                                    "起飞以后先穿它开始计时，最后再穿它算一圈。") == QMessageBox.Yes

    def index_of(self, iid):
        return next((k for k, it in enumerate(self.items) if it.get('id') == iid), None)

    def remove_item(self, i):
        """删掉一个东西，顺序里它的那几步也去掉"""
        iid = self.items.pop(i).get('id')
        self.route[:] = [s for s in self.route if s.get('id') != iid]
        self.sel = None
        self.sel_step = None

    def start_place(self, rel_items):
        self.placing = [dict(it) for it in rel_items]
        self.ghost_yaw = None
        self.setFocus()
        self.update()

    def stop_place(self):
        self.placing = None
        self.snap_hint = ""
        self.update()

    # ---- 3D 投影（和 3D 预览一样的平行投影）
    def _setup(self):
        x0, x1, z0, z1 = self._bounds
        self._c = ((x0+x1)/2, (z0+z1)/2)
        self.k = min(self.width()/(x1-x0+8), (self.height()-24)/(z1-z0+8)) * self.zoom
        self._cy, self._sy = math.cos(math.radians(self.yaw)), math.sin(math.radians(self.yaw))
        self._cp, self._sp = math.cos(math.radians(self.pitch)), math.sin(math.radians(self.pitch))
        self._W2, self._H2 = self.width()/2 + self.pan.x(), (self.height()-24)/2 + self.pan.y()

    def P3(self, x, y, z):
        x, z = x-self._c[0], z-self._c[1]
        x1 = x*self._cy - z*self._sy
        z1 = x*self._sy + z*self._cy
        return QPointF(self._W2 + x1*self.k, self._H2 + (z1*self._sp - y*self._cp)*self.k)

    def P(self, x, z, y=0.0):
        self._setup()
        return self.P3(x, y, z)

    def W2(self, p, y=0.0):
        """屏幕上的点 -> 地面（高 y）上的点"""
        self._setup()
        x1 = (p.x()-self._W2)/self.k
        z1 = ((p.y()-self._H2)/self.k + y*self._cp) / max(self._sp, 0.05)
        x = x1*self._cy + z1*self._sy
        z = -x1*self._sy + z1*self._cy
        return x + self._c[0], z + self._c[1]

    @staticmethod
    def _seg_dist(p, a, b):
        dx, dy = b.x()-a.x(), b.y()-a.y()
        l2 = dx*dx + dy*dy
        t = 0 if l2 == 0 else max(0, min(1, ((p.x()-a.x())*dx + (p.y()-a.y())*dy)/l2))
        return math.hypot(p.x()-a.x()-t*dx, p.y()-a.y()-t*dy)

    def _hits(self, p, dist=False):
        """鼠标底下的门框、杆子、路线点（近的在前）"""
        self._setup()
        out = []
        for i, it in enumerate(self.items):
            if it['t'] == tg.WP:
                q = self.P3(it['x'], it.get('h') or (self.T+self.S/2), it['z'])
                d = math.hypot(p.x()-q.x(), p.y()-q.y())
            else:
                d = min((self._seg_dist(p, self.P3(*a), self.P3(*b)) for a, b, _ in frames(it, self.S, self.T)),
                        default=99)
            if d < 12:
                out.append((d, i))
        out.sort()
        return out if dist else [i for _, i in out]

    # ---- 门洞（面）
    def _depth(self, q):
        """离看的人多近（越大越近）"""
        x, z = q[0]-self._c[0], q[2]-self._c[1]
        return (x*self._sy + z*self._cy)*self._cp + q[1]*self._sp

    def _faces(self):
        """所有门洞：[(第几个门, 标签, 中心, 法向, 屏幕上的框)]"""
        self._setup()
        h = self.S/2
        out = []
        for i, it in enumerate(self.items):
            for lab, C, N, Wd, U in tg.faces(it, self.S, self.T):
                cs = [tc.add(tc.add(C, tc.mul(Wd, sw*h)), tc.mul(U, su*h)) for sw, su in ((1, 1), (-1, 1), (-1, -1), (1, -1))]
                out.append((i, lab, C, N, QPolygonF([self.P3(*q) for q in cs])))
        return out

    def _face_at(self, p):
        cand = [(self._depth(C), i, lab, poly) for i, lab, C, N, poly in self._faces()
                if poly.containsPoint(p, Qt.OddEvenFill)]
        if not cand:
            return None
        _, i, lab, poly = max(cand, key=lambda c: c[0])
        r = poly.boundingRect()
        edge = min(self._seg_dist(p, poly[k], poly[(k+1) % 4]) for k in range(4))
        if edge < min(6.0, 0.15*min(r.width(), r.height())):     # 贴着门洞的边 = 点在门框上：那是选门
            return None
        return i, lab

    def _steps_on(self, i, lab):
        iid = self.items[i].get('id')
        return [k for k, s in enumerate(self.route) if s.get('id') == iid and s.get('f') == lab]

    def _click_face(self, i, lab, add):
        """点门洞：没在顺序里 = 加进去（接在选中的那步后面），已经在 = 选中它，再点一次 = 换方向；Shift = 再穿一次"""
        ks = self._steps_on(i, lab)
        faces_in = [k for k, st in enumerate(self.route) if st.get('f')]
        first = faces_in[0] if faces_in else None
        if first is not None and first in ks and not add and not self.closed and len(faces_in) >= 2 \
                and self.sel_step != first:
            self.closed = True                      # 最后点起始门：收成一圈
            self.sel_step = len(self.route)
            self.sel = i
            self.selected.emit(i)
            self.changed.emit()
            return
        if first is None and not ks:
            if self.items[i]['t'] == tg.FLAG:
                QMessageBox.information(self, "起始门", "起始门（计时门）要用真门，先点一个门的门洞。")
                return
            if not self._ask_start():
                return
        if ks and not add:
            k = self.sel_step if self.sel_step in ks else ks[0]
            if self.sel_step == k:
                self.route[k]['d'] = -(self.route[k].get('d') or 1)
            self.sel_step = k
        else:
            at = self.sel_step + 1 if self.sel_step is not None and self.sel_step < len(self.route) else len(self.route)
            self.route.insert(at, {'id': self.items[i]['id'], 'f': lab, 'd': self._auto_dir(i, lab, at)})
            self.sel_step = at
        self.sel = i
        self.selected.emit(i)
        self.changed.emit()

    def _auto_dir(self, i, lab, at):
        """新加的门洞往哪边穿：从上一步那边飞过来"""
        fc = {q[0]: q for q in tg.faces(self.items[i], self.S, self.T)}[lab]
        if at == 0:
            return 1
        prev = self.route[at-1]
        j = self.index_of(prev.get('id'))
        if j is None:
            return 1
        pit = self.items[j]
        if j == i and prev.get('f'):
            if pit['t'] == tg.FLAG and prev['f'] != lab:
                return -(prev.get('d') or 1)                # 刀旗另一边：绕过旗掉头回来
            return prev.get('d') or 1                      # 同一个门的另一个洞：默认同一个方向
        if prev.get('f'):
            pf = {q[0]: q for q in tg.faces(pit, self.S, self.T)}.get(prev['f'])
            src = pf[1] if pf else [pit['x'], 1.6, pit['z']]
        else:
            src = [pit['x'], pit.get('h') or 1.6, pit['z']]
        return 1 if tc.dot(tc.sub(fc[1], src), fc[2]) >= 0 else -1

    def _hit(self, p):
        hs = self._hits(p)
        if not hs:
            return None
        if self.sel in hs and len(hs) > 1:          # 叠着、挨着的：再点一下换下一个
            return hs[(hs.index(self.sel)+1) % len(hs)]
        return hs[0]

    # ---- 磁吸
    def _column_top(self, g, skip):
        S, T = self.S, self.T
        col = [k for k, q in enumerate(self.items) if k not in skip and q['t'] in STACKABLE
               and math.hypot(q['x']-g['x'], q['z']-g['z']) < 0.3]
        return max(self.items[k].get('lift', 0)+height(self.items[k]['t'], S, T) for k in col)

    def _snap(self, it, skip, over=None):
        """单门、日字门靠近别的单门/日字门：并排贴上（共用一根立杆）或者叠上去。
        over：鼠标正指着的门（3D 里指着门就是叠上去）。返回 (x, z, yaw, lift, 贴的是谁, 提示) 或 None"""
        if it['t'] not in STACKABLE:
            return None
        S, T = self.S, self.T
        if over is not None and over not in skip and self.items[over]['t'] in STACKABLE:
            g = self.items[over]
            return (g['x'], g['z'], g.get('yaw', 0), round(self._column_top(g, skip)-T, 3), over, "叠上去")
        best = None
        for j, g in enumerate(self.items):
            if j in skip or g['t'] not in STACKABLE:
                continue
            d = math.hypot(it['x']-g['x'], it['z']-g['z'])
            if d > 6:
                continue
            a = math.radians(g.get('yaw', 0))
            lx, lz = -math.sin(a), math.cos(a)
            if d < 1.0:
                cand = (d, (g['x'], g['z'], g.get('yaw', 0), round(self._column_top(g, skip)-T, 3), j, "叠上去"))
            else:
                cand = None
                for s in (-1, 1):
                    cx, cz = g['x']+s*lx*(S+T), g['z']+s*lz*(S+T)
                    dd = math.hypot(it['x']-cx, it['z']-cz)
                    if dd < 1.4 and (cand is None or dd < cand[0]):
                        cand = (dd, (round(cx, 3), round(cz, 3), g.get('yaw', 0), g.get('lift', 0), j, "并排贴上"))
            if cand and (best is None or cand[0] < best[0]):
                best = cand
        return best[1] if best else None

    def _ghost(self):
        """要放的东西现在在哪（跟着鼠标，带磁吸）"""
        if not self.placing or self.mouse is None:
            return []
        x, z = self.W2(self.mouse)
        yaw = self.ghost_yaw
        if yaw is None:
            last = self.index_of(self.route[-1].get('id')) if self.route else None
            ref = self.items[self.sel] if self.sel is not None else (self.items[last] if last is not None else None)
            yaw = round(math.degrees(math.atan2(z-ref['z'], x-ref['x'])) / 15) * 15 if ref and \
                math.hypot(z-ref['z'], x-ref['x']) > 1.5 else 0
        a = math.radians(yaw)
        out = []
        for r in self.placing:
            rx, rz = r.get('x', 0), r.get('z', 0)
            out.append(dict(r, x=round(x + rx*math.cos(a) - rz*math.sin(a), 2),
                            z=round(z + rx*math.sin(a) + rz*math.cos(a), 2), yaw=(r.get('yaw', 0)+yaw) % 360))
        self.snap_hint = ""
        if len(out) == 1:
            hs = [h for h in self._hits(self.mouse) if self.items[h]['t'] in STACKABLE]
            sn = self._snap(out[0], set(), hs[0] if hs else None)
            if sn:
                out[0].update(x=sn[0], z=sn[1], yaw=sn[2], lift=sn[3])
                out[0]['_to'] = sn[4]
                self.snap_hint = sn[5]
        return out

    # ---- 画
    def paintEvent(self, _):
        self.pen.setChecked(self.drawing is not None)
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor(30, 40, 36))
        self._setup()
        P = self.P3
        # 地面：5 米格子 + 场地边
        p.setPen(QPen(QColor(55, 75, 60), 1))
        for n in range(0, int(self.L)+1, 5):               # 格子和标尺对齐：从场地角上开始每 5 米
            gx = -self.L/2 + n
            p.drawLine(P(gx, 0, -self.W/2), P(gx, 0, self.W/2))
        for n in range(0, int(self.W)+1, 5):
            gz = -self.W/2 + n
            p.drawLine(P(-self.L/2, 0, gz), P(self.L/2, 0, gz))
        p.setPen(QPen(QColor(140, 180, 140), 2))
        L2, W2 = self.L/2, self.W/2
        p.drawPolygon(QPolygonF([P(-L2, 0, -W2), P(L2, 0, -W2), P(L2, 0, W2), P(-L2, 0, W2)]))
        self._paint_rulers(p)
        grp = set(group_of(self.items, self.sel)) if self.sel is not None else set()
        first = next((s.get('id') for s in self.route if s.get('f')), None)
        # 远的先画，近的后画
        idx = sorted(range(len(self.items)), key=lambda i: (self.items[i]['x']-self._c[0])*self._sy +
                     (self.items[i]['z']-self._c[1])*self._cy)
        for i in idx:
            self._paint_item(p, self.items[i], i == self.sel, i in grp)
        if self.helpers:
            self._paint_faces(p)
        self._paint_path(p)
        self._locks = {}
        shown = set()
        tops = {}
        for i, it in enumerate(self.items):                 # 组合门只在最高的那个上写一个名字
            g = it.get('grp')
            if g is not None and len(group_of(self.items, i)) > 1:
                top = (it.get('lift', 0) or 0) + height(it['t'], self.S, self.T)
                if g not in tops or top > tops[g][0]:
                    tops[g] = (top, i)
        for i in idx:
            it = self.items[i]
            g = it.get('grp')
            if g in tops:
                if tops[g][1] != i or g in shown:
                    continue
                shown.add(g)
                mem = group_of(self.items, i)
                self._paint_label(p, dict(it, name=it.get('combo') or "组合门"), any(j == self.sel for j in mem),
                                  any(self.items[j].get('id') == first for j in mem))
                continue
            self._paint_label(p, it, i == self.sel, it.get('id') == first)
        for it in self._ghost():
            self._paint_item(p, it, False, False, ghost=True)
        if len(self.stroke) > 1:
            p.setPen(QPen(QColor(255, 220, 60), 3))
            p.drawPolyline(QPolygonF([self.P3(*q) for q in self.stroke]))
        p.setPen(QColor(190, 210, 190))
        p.setFont(QFont())
        nfaces = sum(1 for st in self.route if st.get('f'))
        if self.drawing == 'free':
            hint = ("✏ 画笔：按住左键从最后一个门洞往后画，画过哪个门洞就按先后加进顺序，路线照画的走；"
                    "画回 1 号起始门就收圈；Esc 不画了")
        elif self.drawing is not None:
            hint = ("✏ 手绘：按住左键从这一步画到下一步（黄色）；斜视/俯视画平面，正面/侧面能画上下翻；"
                    "Esc 不画了")
        elif self.placing:
            hint = (f"放「{label(self.placing[0]['t']) if len(self.placing) == 1 else '组合门'}」：点地上放，"
                    "滚轮转方向，指着单门/日字门=叠上去，靠近旁边=并排贴上；右键点一下或 Esc 不放了")
            if self.snap_hint:
                hint = f"🧲 {self.snap_hint}    " + hint
        elif nfaces >= 2 and not self.closed:
            hint = ("最后一个门放好以后，点一下起始门（绿色 1 号）的门洞，把路线连回去收成一圈   "
                    "点门洞=加进顺序   拖门框=移动   🔒=锁定/解锁")
        else:
            hint = ("点门洞=加进顺序（再点=换方向，Shift+点=再穿一次）   拖门框=移动   门上滚轮=转方向   🔒=锁定/解锁   "
                    "右键拖=转视角   中键拖=移动画面   空地滚轮=缩放")
        p.drawText(8, self.height()-6, hint)

    def _paint_rulers(self, p):
        """标尺：场地上边（长）和左边（宽），每米一小格，每 5 米一个数字（从左上角 0 米算起）"""
        P = self.P3
        L2, W2 = self.L/2, self.W/2
        f = QFont()
        f.setPointSize(8)
        p.setFont(f)
        col = QColor(170, 210, 170)
        for n in range(int(self.L)+1):                      # 上边：沿长
            x = -L2 + n
            big = n % 5 == 0
            p.setPen(QPen(col, 1.5 if big else 1))
            p.drawLine(P(x, 0, -W2), P(x, 0, -W2 - (0.9 if big else 0.4)))
            if big:
                q = P(x, 0, -W2 - 1.6)
                p.drawText(QRectF(q.x()-20, q.y()-8, 40, 16), Qt.AlignCenter, f"{n}")
        for n in range(int(self.W)+1):                      # 左边：沿宽
            z = -W2 + n
            big = n % 5 == 0
            p.setPen(QPen(col, 1.5 if big else 1))
            p.drawLine(P(-L2, 0, z), P(-L2 - (0.9 if big else 0.4), 0, z))
            if big and n:
                q = P(-L2 - 1.9, 0, z)
                p.drawText(QRectF(q.x()-20, q.y()-8, 40, 16), Qt.AlignCenter, f"{n}")
        q = P(L2, 0, -W2 - 1.6)
        p.drawText(q + QPointF(16, 4), "米")
        p.setFont(QFont())

    def set_show_path(self, on):
        self.show_path = bool(on)
        self.update()

    def _paint_path(self, p):
        if len(self.path) < 2 or not getattr(self, 'show_path', True):
            return
        P = self.P3
        p.setPen(QPen(QColor(255, 80, 50), 2))
        p.drawPolyline(QPolygonF([P(*q) for q in self.path]))

    def _paint_item(self, p, it, is_sel, in_grp, ghost=False):
        P = self.P3
        S, T = self.S, self.T
        t = it['t']
        if t == tg.WP:
            y = it.get('h') or (T+S/2)
            col = RED if is_sel else QColor(90, 200, 255)
            if ghost:
                col = QColor(255, 220, 80)
            pen = QPen(col, 1)
            pen.setStyle(Qt.DashLine)
            p.setPen(pen)
            p.drawLine(P(it['x'], 0, it['z']), P(it['x'], y, it['z']))
            p.setPen(QPen(col, 2))
            p.setBrush(QColor(col.red(), col.green(), col.blue(), 120))
            p.drawEllipse(P(it['x'], y, it['z']), 6, 6)
            p.setBrush(Qt.NoBrush)
            return
        col = QColor(235, 235, 235)
        if t in (tg.POLE, tg.FLAG):
            col = QColor(255, 170, 40)
        if t == tg.TAKEOFF:
            col = QColor(120, 200, 120)
        if in_grp:
            col = QColor(255, 140, 140)
        if is_sel:
            col = RED
        if ghost:
            col = QColor(255, 220, 80, 200)
        for a, b, thick in frames(it, S, T):
            w = max(2.0, min(10.0, thick*self.k))
            p.setPen(QPen(col, w, Qt.SolidLine, Qt.FlatCap))
            p.drawLine(P(*a), P(*b))
        if t == tg.POLE and self.helpers:
            # 杆子周围画一圈虚线：路线贴着这圈绕（离杆子 1.8 米，和组委会图上一样）
            r = tg.POLE_R
            pts = [P(it['x'] + r*math.cos(math.radians(d)), 0.05, it['z'] + r*math.sin(math.radians(d)))
                   for d in range(0, 361, 15)]
            p.setPen(QPen(QColor(80, 220, 255) if not ghost else col, 1, Qt.DashLine))
            p.drawPolyline(QPolygonF(pts))

    def _paint_faces(self, p):
        """门洞：在顺序里的画青色实框 + 穿的方向箭头 + 第几个；没在顺序里的画淡虚框；鼠标指着的发亮"""
        P = self.P3
        steps = {}
        n = 0
        for k, s in enumerate(self.route):
            if s.get('f'):
                n += 1
                steps.setdefault((s.get('id'), s['f']), []).append((k, n, s.get('d') or 1))
        fs = sorted(self._faces(), key=lambda q: self._depth(q[2]))
        drawn = [(self.items[h[1]].get('id'), h[2]) for h in self._fhits if h[1] < len(self.items)] \
            if self.drawing == 'free' else []
        for i, lab, C, N, poly in fs:
            key = (self.items[i].get('id'), lab)
            mine = steps.get(key, [])
            hov = self.hover == (i, lab)
            sel = any(k == self.sel_step for k, _, _ in mine)
            if key in drawn:                        # 画笔正画过的门洞：亮起来（刚画到的黄，前面画过的蓝）
                col = QColor(255, 210, 60) if key == drawn[-1] else QColor(0, 200, 230)
                p.setPen(QPen(col, 3))
                p.setBrush(QColor(col.red(), col.green(), col.blue(), 90))
            elif mine:
                col = QColor(255, 210, 60) if sel else QColor(0, 200, 230)
                p.setPen(QPen(col, 3))
                p.setBrush(QColor(col.red(), col.green(), col.blue(), 70 if hov else 35))
            else:
                pen = QPen(QColor(0, 200, 230, 230 if hov else 90), 1.5, Qt.DashLine)
                p.setPen(pen)
                p.setBrush(QColor(0, 200, 230, 60) if hov else Qt.NoBrush)
            p.drawPolygon(poly)
            p.setBrush(Qt.NoBrush)
            for m, (k, num, d) in enumerate(mine):
                Nd = tc.mul(N, d)
                off = tc.mul([N[2], 0, -N[0]], 0.35*m)        # 同一个洞穿好几次：箭头错开一点
                a0, a1 = tc.add(tc.sub(C, tc.mul(Nd, 2.0)), off), tc.add(tc.add(C, tc.mul(Nd, 2.0)), off)
                A, B = P(*a0), P(*a1)
                col = QColor(255, 210, 60) if k == self.sel_step else (QColor(120, 255, 120) if num == 1 else QColor(80, 220, 255))
                p.setPen(QPen(col, 3))
                p.drawLine(A, B)
                dx, dy = B.x()-A.x(), B.y()-A.y()
                ln = math.hypot(dx, dy) or 1
                dx, dy = dx/ln, dy/ln
                for sg in (-1, 1):
                    p.drawLine(B, QPointF(B.x()-dx*11+sg*(-dy)*7, B.y()-dy*11+sg*dx*7))
                f = QFont()
                f.setBold(True)
                p.setFont(f)
                r = QRectF(A.x()-11, A.y()-11, 22, 22)
                p.setPen(Qt.NoPen)
                p.setBrush(QColor(46, 125, 50) if num == 1 else QColor(21, 101, 192))
                p.drawEllipse(r)
                p.setBrush(Qt.NoBrush)
                p.setPen(QColor(255, 255, 255))
                p.drawText(r, Qt.AlignCenter, str(num))
                p.setFont(QFont())

    def _paint_label(self, p, it, is_sel, timing):
        if it['t'] == tg.WP:
            q = self.P3(it['x'], it.get('h') or (self.T+self.S/2), it['z'])
            p.setPen(RED if is_sel else QColor(150, 220, 255))
            p.drawText(q + QPointF(8, -6), "路线点" + (f" {it['h']:.1f}米高" if it.get('h') else ""))
            return
        S, T = self.S, self.T
        lift = it.get('lift', 0) or 0
        top = self.P3(it['x'], lift + (3.0 if it['t'] == tg.POLE else height(it['t'], S, T)) + 0.3, it['z'])
        f = QFont()
        f.setBold(True)
        p.setFont(f)
        p.setPen(RED if is_sel else QColor(255, 255, 255))
        if it['t'] == tg.POLE:
            text = "绕杆 · " + tg.pole_label(it.get('how'))
        else:
            text = (it.get('name') or label(it['t'])) + (" · 计时门" if timing else "")
        pos = top + QPointF(-10, -6)
        p.drawText(pos, text)
        i = self.index_of(it.get('id'))
        if i is not None:
            # 锁：关着 = 锁定（拖不动、转不了），开着 = 能调
            w = p.fontMetrics().horizontalAdvance(text)
            r = QRectF(pos.x() + w + 6, pos.y() - 15, 18, 20)
            self._locks[i] = r
            self._paint_lock(p, r, self.locked(i))
        p.setFont(QFont())

    @staticmethod
    def _paint_lock(p, r, on):
        col = QColor(255, 200, 60) if on else QColor(170, 200, 170)
        body = QRectF(r.x()+2, r.y()+9, 14, 10)
        p.setPen(QPen(col, 2))
        p.setBrush(QColor(col.red(), col.green(), col.blue(), 160 if on else 40))
        p.drawRoundedRect(body, 2, 2)
        p.setBrush(Qt.NoBrush)
        arc = QRectF(r.x()+4, r.y()+2, 10, 13)
        if on:
            p.drawArc(arc, 0, 180*16)                       # 关着：锁梁扣在锁体上
        else:
            p.drawArc(arc.translated(5, -3), 0, 180*16)     # 开着：锁梁翘起来

    # ---- 鼠标
    def mousePressEvent(self, e):
        self.setFocus()
        self.mouse = e.position()
        view_drag = e.button() == Qt.MiddleButton or (e.button() == Qt.RightButton)
        if view_drag:
            pan = e.button() == Qt.MiddleButton or bool(e.modifiers() & Qt.ShiftModifier)
            self._drag = ('view', e.position(), QPointF(self.pan), self.yaw, self.pitch, pan, False)
            return
        if e.button() != Qt.LeftButton:
            return
        self.set_helpers(True)
        if self.drawing == 'free':
            q = self._free_point(e.position())
            self.stroke = [q]
            f = self._free_hit(e.position(), q)
            self._fhits = [(0,) + f] if f else []
            self._drag = ('free',)
            return
        if self.drawing is not None:
            D = self._draw_depth()
            self.stroke = [] if D is None else [self._unproject(e.position(), D)]
            self._drag = ('draw', D)
            return
        if self.placing:
            self._place()
            return
        for i, r in self._locks.items():
            if r.contains(e.position()) and i < len(self.items):
                self.toggle_lock(i)
                self.sel = i
                self.selected.emit(i)
                return
        fc = self._face_at(e.position())
        if fc:                                          # 点在门洞里（不是门框上）：进门顺序
            self._click_face(fc[0], fc[1], bool(e.modifiers() & Qt.ShiftModifier))
            self.update()
            return
        i = self._hit(e.position())
        self.sel = i
        self.sel_step = None
        self.selected.emit(-1 if i is None else i)
        if i is not None and not self.locked(i):
            x, z = self.W2(e.position())
            members = group_of(self.items, i)
            self._drag = ('move', i, x, z, {j: (self.items[j]['x'], self.items[j]['z']) for j in members}, False)
        self.update()

    def _place(self):
        g = self._ghost()
        if not g:
            return
        if len(g) == 1 and g[0]['t'] == tg.TAKEOFF:       # 起飞台只有一个：再放就是挪过去
            for j in [j for j, q in enumerate(self.items) if q['t'] == tg.TAKEOFF][::-1]:
                self.items.pop(j)
        at = self.sel + 1 if self.sel is not None and self.sel < len(self.items) else len(self.items)
        for it in g:
            it['id'] = tg.new_id(self.items + g)
        if len(g) == 1:
            it = g[0]
            to = it.pop('_to', None)
            if to is not None and not self.locked(to):     # 磁吸上了：并进那个组合门（锁住的只贴位置，不并组）
                gid = self.items[to].get('grp') or new_grp(self.items)
                for j in group_of(self.items, to):
                    self.items[j]['grp'] = gid
                self.items[to]['grp'] = gid
                it['grp'] = gid
                at = max(group_of(self.items, to)) + 1
            if it['t'] in (tg.WP, tg.POLE):        # 路线点、绕杆：直接接进顺序（选中的那步后面）
                k = self.sel_step + 1 if self.sel_step is not None else len(self.route)
                self.route.insert(k, {'id': it['id']})
                self.sel_step = k
        else:
            gid = new_grp(self.items)
            for it in g:
                it['grp'] = gid
        for k, it in enumerate(g):
            self.items.insert(at+k, it)
        first = g[0]
        if not any(st.get('f') for st in self.route) and first['t'] in tg.START_FACE and first['t'] != tg.FLAG:
            self.update()
            if self._ask_start():                   # 第一个门：设成起始门就直接加进顺序当 1 号
                self.route.insert(0, {'id': first['id'], 'f': tg.START_FACE[first['t']], 'd': 1})
                self.sel_step = 0
        self.sel = at
        self.selected.emit(at)
        self.changed.emit()
        self.update()

    def mouseMoveEvent(self, e):
        self.mouse = e.position()
        if self._drag and self._drag[0] == 'free':
            q = self._free_point(e.position())
            if not self.stroke or math.dist(q, self.stroke[-1]) > 0.3:
                self.stroke.append(q)
                f = self._free_hit(e.position(), q)
                if f and (not self._fhits or self._fhits[-1][1:] != f):
                    self._fhits.append((len(self.stroke)-1,) + f)
                self.hover = f
            self.update()
            return
        if self._drag and self._drag[0] == 'draw':
            if self._drag[1] is not None:
                q = self._unproject(e.position(), self._drag[1])
                if not self.stroke or math.dist(q, self.stroke[-1]) > 0.3:
                    self.stroke.append(q)
                self.update()
            return
        if self._drag and self._drag[0] == 'view':
            _, p0, pan0, yaw0, pitch0, pan, _m = self._drag
            d = e.position() - p0
            if pan:
                self.pan = pan0 + d
            else:
                self.yaw = yaw0 - d.x()*0.4
                self.pitch = max(5.0, min(90.0, pitch0 + d.y()*0.4))
            moved = abs(d.x()) + abs(d.y()) > 4
            self._drag = ('view', p0, pan0, yaw0, pitch0, pan, moved or _m)
            self.update()
            return
        if self.placing:
            self.update()
            return
        if not self._drag:
            hv = self._face_at(e.position()) if self.helpers else None
            if hv != self.hover:
                self.hover = hv
                self.update()
            return
        _, i, x0, z0, start, _m = self._drag
        x, z = self.W2(e.position())
        for j, (sx, sz) in start.items():
            self.items[j]['x'] = round(sx + x-x0, 2)
            self.items[j]['z'] = round(sz + z-z0, 2)
        self.snap_hint = ""
        if len(start) == 1:
            sn = self._snap(self.items[i], {i})
            if sn:
                self.items[i].update(x=sn[0], z=sn[1], yaw=sn[2], lift=sn[3])
                self.snap_hint = sn[5]
                self._drag = ('move', i, x0, z0, start, sn[4])
                self.update()
                return
            if self.items[i].get('lift') and _m is not False:
                self.items[i]['lift'] = 0
        self._drag = ('move', i, x0, z0, start, True)
        self.update()

    def mouseReleaseEvent(self, e):
        d, self._drag = self._drag, None
        self.snap_hint = ""
        if d and d[0] == 'free':
            self._finish_free()
            self.changed.emit()
            self.update()
            return
        if d and d[0] == 'draw':
            pts = []
            for q in self.stroke:                   # 每 1.2 米留一个点
                if not pts or math.dist(q, pts[-1]) > 1.2:
                    pts.append([round(v, 2) for v in q])
            if len(pts) >= 2 and self.drawing is not None and self.drawing < len(self.route):
                self.route[self.drawing]['via'] = pts
                n = len(self.route)                 # 画的时候两头在哪：以后挪门，手绘的线跟着变形
                ab = [self.step_point(self.route[self.drawing]), self.step_point(self.route[(self.drawing+1) % n])]
                if None not in ab:
                    self.route[self.drawing]['via_ab'] = [[round(v, 2) for v in q] for q in ab]
                self.sel_step = self.drawing
            self.drawing = None
            self.stroke = []
            self.changed.emit()
            self.update()
            return
        if d and d[0] == 'view':
            if not d[6] and e is not None and e.button() == Qt.RightButton and self.placing:
                self.stop_place()                   # 右键点一下（没拖）= 不放了
            return
        if d and d[0] == 'move' and d[5] is not False:
            if d[5] is not True and not self.locked(d[5]):     # 拖过去磁吸上了：并进那个组合门
                to = d[5]
                gid = self.items[to].get('grp') or new_grp(self.items)
                for j in group_of(self.items, to):
                    self.items[j]['grp'] = gid
                self.items[d[1]]['grp'] = gid
            self.changed.emit()
        self.update()

    def rotate(self, i, deg):
        """转一个门；组合门绕选中的门整组一起转"""
        members = group_of(self.items, i)
        cx, cz = self.items[i]['x'], self.items[i]['z']
        a = math.radians(deg)
        for j in members:
            it = self.items[j]
            dx, dz = it['x']-cx, it['z']-cz
            it['x'] = round(cx + dx*math.cos(a) - dz*math.sin(a), 2)
            it['z'] = round(cz + dx*math.sin(a) + dz*math.cos(a), 2)
            if it['t'] != tg.WP:
                it['yaw'] = (it.get('yaw', 0) + deg) % 360

    def wheelEvent(self, e):
        steps = e.angleDelta().y() / 120
        if self.placing:
            g = self._ghost()
            base = g[0]['yaw'] - self.placing[0].get('yaw', 0) if g else 0
            self.ghost_yaw = (base + 15*steps) % 360
            self.update()
            return
        i = self._hit(e.position())
        if i is not None and self.items[i]['t'] != tg.WP and not self.locked(i):
            self.rotate(i, 15*steps)
            self.sel = i
            self.selected.emit(i)
            self.changed.emit()
        else:
            self.zoom = max(0.3, min(8.0, self.zoom * (1.15 ** steps)))
        self.update()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            if self.drawing is not None:
                self.drawing = None
                self.stroke = []
                self.update()
            elif self.placing:
                self.stop_place()
            else:
                self.sel = None
                self.sel_step = None
                self.selected.emit(-1)
                self.update()
            return
        if e.key() in (Qt.Key_Delete, Qt.Key_Backspace) and self.sel_step is not None and \
                self.sel_step < len(self.route) and self.route[self.sel_step].get('f'):   # 门洞那一步：只从顺序里去掉
            self.route.pop(self.sel_step)
            self.sel_step = None
            self.changed.emit()
            self.update()
            return
        i = self.sel
        if i is None or self.locked(i):
            return
        if e.key() in (Qt.Key_Delete, Qt.Key_Backspace):
            self.remove_item(i)
            self.selected.emit(-1)
            self.changed.emit()
        elif e.key() in (Qt.Key_Q, Qt.Key_E) and self.items[i]['t'] != tg.WP:
            self.rotate(i, -15 if e.key() == Qt.Key_Q else 15)
            self.changed.emit()
        self.update()
