"""在线更新（OTA）：打开软件后去「更新地址」看有没有新版本，有就问一下，点「现在更新」自动下载、换掉 app 文件夹、重启。

更新地址可以是网址（指向 latest.json），也可以是共享文件夹（里面放 latest.json 和升级包）。
latest.json 长这样：{"build": "20261028.1440", "zip": "升级包.zip", "sha256": "…", "notes": "这次改了什么"}
zip 写的是相对 latest.json 的位置，也可以是完整网址。升级包里只认 app/ 下面的文件和两份说明。"""
import hashlib
import json
import os
import shutil
import sys
import tempfile
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

from PySide6.QtCore import QObject, QProcess, QThread, QTimer, Signal
from PySide6.QtWidgets import QApplication, QMessageBox, QProgressDialog

from app.config import APP_DIR

APP = Path(__file__).resolve().parent
VERSION_FILE = APP / "version.json"
DOCS = ("升级说明.txt", "使用说明.md")


def current_build():
    try:
        return str(json.loads(VERSION_FILE.read_text(encoding="utf-8")).get("build", ""))
    except (OSError, ValueError):
        return ""


def _is_url(src):
    return urllib.parse.urlparse(src).scheme in ("http", "https")


def _manifest_url(src):
    src = src.strip()
    if _is_url(src):
        return src if src.lower().endswith(".json") else src.rstrip("/") + "/latest.json"
    p = Path(src)
    return str(p if p.suffix.lower() == ".json" else p / "latest.json")


def _read(src, timeout=8):
    if _is_url(src):
        with urllib.request.urlopen(src, timeout=timeout) as r:
            return r.read()
    return Path(src).read_bytes()


def fetch_manifest(src):
    """返回 (manifest, zip 的完整位置)；拿不到就抛异常。可以写几个地址（空格或分号隔开）：
    每个都问一遍，用版本号最新的那个（jsDelivr 有时还给旧的 latest.json，不能问到一个就停）"""
    srcs = [x for x in src.replace("；", ";").replace(";", " ").split() if x]
    err, best = None, None
    for one in srcs:
        try:
            r = _fetch_one(one)
        except Exception as ex:  # noqa: BLE001
            err = ex
            continue
        if best is None or str(r[0].get("build", "")) > str(best[0].get("build", "")):
            best = r
    if best:
        return best
    raise err or ValueError("没有更新地址")


def _fetch_one(src):
    murl = _manifest_url(src)
    if murl.startswith("https://cdn.jsdelivr.net/"):     # jsDelivr 会缓存旧的 latest.json，先让它刷新一下
        try:
            _read(murl.replace("https://cdn.jsdelivr.net/", "https://purge.jsdelivr.net/", 1), timeout=5)
        except Exception:  # noqa: BLE001
            pass
    m = json.loads(_read(murl).decode("utf-8-sig"))
    z = m.get("zip") or "升级包.zip"
    if _is_url(murl):
        zurl = urllib.parse.urljoin(murl, urllib.parse.quote(z, safe=":/%?=&"))
    else:
        zurl = z if Path(z).is_absolute() else str(Path(murl).parent / z)
    return m, zurl


def newer(m):
    return str(m.get("build", "")) > current_build()


def apply_zip(path):
    """把升级包里 app/ 下面的文件换进去；先把现在的 app 备份成 app_上一版"""
    with zipfile.ZipFile(path) as z:
        names = [n for n in z.namelist() if not n.endswith("/")]
        ok = [n for n in names if (n.startswith("app/") or n in DOCS) and ".." not in Path(n).parts]
        if not any(n.startswith("app/") for n in ok):
            raise ValueError("升级包里没有 app 文件夹")
        bak = APP_DIR / "app_上一版"
        shutil.rmtree(bak, ignore_errors=True)
        shutil.copytree(APP, bak, ignore=shutil.ignore_patterns("__pycache__"))
        for n in ok:
            dst = APP_DIR / n
            dst.parent.mkdir(parents=True, exist_ok=True)
            tmp = dst.with_name(dst.name + ".new")
            with z.open(n) as src, open(tmp, "wb") as out:
                shutil.copyfileobj(src, out)
            os.replace(tmp, dst)


class _Download(QThread):
    progress = Signal(int, int)
    done = Signal(str, str)         # (文件, 出错信息)

    def __init__(self, src, sha):
        super().__init__()
        self.src, self.sha = src, (sha or "").lower()

    def run(self):
        fd, path = tempfile.mkstemp(suffix=".zip")
        os.close(fd)
        try:
            h = hashlib.sha256()
            if _is_url(self.src):
                r = urllib.request.urlopen(self.src, timeout=20)
            else:
                r = open(self.src, "rb")
            with r, open(path, "wb") as out:
                total = int(getattr(r, "headers", {}).get("Content-Length", 0) or 0) if _is_url(self.src) \
                    else os.path.getsize(self.src)
                got = 0
                while not self.isInterruptionRequested():
                    b = r.read(65536)
                    if not b:
                        break
                    out.write(b)
                    h.update(b)
                    got += len(b)
                    self.progress.emit(got, total)
            if self.isInterruptionRequested():
                raise RuntimeError("取消了")
            if self.sha and h.hexdigest() != self.sha:
                raise RuntimeError("下载的文件不完整（校验不对），再试一次")
            self.done.emit(path, "")
        except Exception as ex:  # noqa: BLE001
            self.done.emit("", str(ex))


class _Check(QThread):
    result = Signal(object, str, str)    # (manifest, zip 位置, 出错信息)

    def __init__(self, src):
        super().__init__()
        self.src = src

    def run(self):
        try:
            m, z = fetch_manifest(self.src)
            self.result.emit(m, z, "")
        except Exception as ex:  # noqa: BLE001
            self.result.emit(None, "", str(ex))


class Updater(QObject):
    """main 里建一个；start() 开机后自己查一次，check(manual=True) 给菜单「检查更新」用"""

    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self._t = None

    @property
    def src(self):
        return (self.main.s.data.get("update_url") or "").strip()

    def start(self):
        if self.src and self.main.s.data.get("auto_update", True):
            QTimer.singleShot(3000, lambda: self.check(manual=False))

    def check(self, manual=True):
        if not self.src:
            if manual:
                QMessageBox.information(self.main, "检查更新", "还没填「更新地址」。在「⚙ 设置 → 设置…」里填上。")
            return
        if self._t and self._t.isRunning():
            return
        self._t = _Check(self.src)
        self._t.result.connect(lambda m, z, err: self._checked(m, z, err, manual))
        self._t.start()

    def _checked(self, m, zurl, err, manual):
        if err:
            if manual:
                QMessageBox.warning(self.main, "检查更新", f"连不上更新地址：\n{err}")
            return
        if not newer(m):
            if manual:
                QMessageBox.information(self.main, "检查更新", f"已经是最新版本（{current_build() or '未知'}）。")
            return
        if not manual and self.main.s.data.get("skip_build") == m.get("build"):
            return
        box = QMessageBox(self.main)
        box.setWindowTitle("有新版本")
        box.setText(f"有新版本 {m.get('build')}（现在是 {current_build() or '未知'}）。\n\n{m.get('notes', '')}".strip())
        now = box.addButton("现在更新", QMessageBox.AcceptRole)
        box.addButton("以后再说", QMessageBox.RejectRole)
        skip = box.addButton("跳过这个版本", QMessageBox.DestructiveRole)
        box.setDefaultButton(now)
        box.exec()
        if box.clickedButton() is skip:
            self.main.s["skip_build"] = m.get("build")
        elif box.clickedButton() is now:
            self._download(m, zurl)

    def _download(self, m, zurl):
        if getattr(self.main.recorder, "recording", False):
            QMessageBox.information(self.main, "更新", "正在录像，录完再更新。")
            return
        dlg = QProgressDialog("正在下载新版本…", "取消", 0, 100, self.main)
        dlg.setWindowTitle("更新")
        dlg.setMinimumDuration(0)
        dlg.setAutoClose(False)
        t = _Download(zurl, m.get("sha256"))
        self._dl = t

        def prog(got, total):
            if total:
                dlg.setValue(int(got * 100 / total))
            dlg.setLabelText(f"正在下载新版本… {got / 1e6:.1f} MB")

        def done(path, err):
            dlg.close()
            if err:
                if err != "取消了":
                    QMessageBox.warning(self.main, "更新", f"下载失败：{err}")
                return
            try:
                apply_zip(path)
            except Exception as ex:  # noqa: BLE001
                QMessageBox.warning(self.main, "更新", f"换文件失败：{ex}\n\n更新前的版本备份在程序文件夹的「app_上一版」里。")
                return
            finally:
                try:
                    os.remove(path)
                except OSError:
                    pass
            if QMessageBox.question(self.main, "更新", "更新好了，要重启软件才生效。现在重启吗？") == QMessageBox.Yes:
                restart(self.main)

        t.progress.connect(prog)
        t.done.connect(done)
        dlg.canceled.connect(t.requestInterruption)
        t.start()


def restart(main):
    exe = APP_DIR / "DroneRacing.exe"
    if exe.exists():
        QProcess.startDetached(str(exe), [], str(APP_DIR))
    else:
        QProcess.startDetached(sys.executable, sys.argv, os.getcwd())
    main.close()
    QApplication.quit()
