import json
import os
import sys
from pathlib import Path

# Program folder (holds app/ and tools/ffmpeg.exe) and a writable folder for settings and logs.
INSTALLED = bool(os.environ.get("DRONERACING_INSTALLED"))
APP_DIR = Path(__file__).resolve().parent.parent
USER_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "无人机竞速" if INSTALLED else APP_DIR
USER_DIR.mkdir(parents=True, exist_ok=True)
SETTINGS_FILE = USER_DIR / "settings.json"
IS_WINDOWS = sys.platform == "win32"


def desktop_dir() -> Path:
    for d in (Path.home() / "Desktop", Path.home() / "OneDrive" / "Desktop", Path.home() / "OneDrive" / "桌面"):
        if d.is_dir():
            return d
    return USER_DIR


UPDATE_URL = "https://raw.githubusercontent.com/xiaodien/drone-racing-update/main/latest.json"
DEFAULTS = {
    "data_dir": str(Path.home() / "Documents" / "无人机竞速录像"),
    "video_device": "",
    "video_mode": "",          # e.g. "mjpeg|1920x1080|60"
    "encoder": "",             # detected on first run
    "auto_record": True,
    "preroll_s": 3.0,
    "postroll_s": 2.0,
    # 自动更新：直接从 GitHub 拿（jsDelivr 国内镜像会给旧版本，Ryan 说不用了）
    "update_url": UPDATE_URL,
    "auto_update": True,
    "min_flight_s": 10.0,      # 解锁不到 10 秒算解锁测试，不保存
    "sync_offset_ms": 0,       # added to stick time when matching video, for capture latency
    "joystick_name": "",
    "calibration": None,
    "current_student": "",
    "vtx_channel": "R1",
}


class Settings:
    def __init__(self):
        self.data = dict(DEFAULTS)
        if SETTINGS_FILE.exists():
            try:
                self.data.update(json.loads(SETTINGS_FILE.read_text(encoding="utf-8")))
            except (OSError, ValueError):
                pass
        if "jsdelivr" in str(self.data.get("update_url", "")):   # 老设置里的国内镜像：换成 GitHub
            self.data["update_url"] = UPDATE_URL
        if self.data.get("min_flight_s") == 3.0:      # 老默认 3 秒 -> 10 秒（区别解锁测试）
            self.data["min_flight_s"] = 10.0

    def __getitem__(self, key):
        return self.data[key]

    def __setitem__(self, key, value):
        self.data[key] = value
        self.save()

    def save(self):
        # 先写到旁边的临时文件再换过去：写到一半断电或者死机，原来的设置不会变成半个文件
        tmp = SETTINGS_FILE.with_name(SETTINGS_FILE.name + ".tmp")
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, SETTINGS_FILE)

    @property
    def data_dir(self) -> Path:
        p = Path(self.data["data_dir"])
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def buffer_dir(self) -> Path:
        p = self.data_dir / ".缓存"
        p.mkdir(parents=True, exist_ok=True)
        return p
