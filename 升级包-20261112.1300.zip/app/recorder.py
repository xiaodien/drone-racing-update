"""Turns arm/disarm (or the manual button) into one saved video + stick log per flight."""
import json
import shutil
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QObject, Signal

from app import ffmpeg_tools as ft
from app.capture import SEGMENT_S, CaptureEngine
from app.sticks import CHANNELS, Calibration, StickSource

KEEP_IDLE_S = 20  # ring buffer length when nothing is recording
LOW_DISK_GB = 5   # warn when starting a recording with less free space than this (~45 min at 15 Mbit/s)


class FlightRecorder(QObject):
    saved = Signal(str)      # path of new mp4
    failed = Signal(str)     # something the coach must see
    notice = Signal(str)     # minor, status bar only

    def __init__(self, engine: CaptureEngine, source: StickSource):
        super().__init__()
        self.engine = engine
        self.source = source
        self.calibration = Calibration(None)
        self.auto = True
        self.preroll = 3.0
        self.postroll = 2.0
        self.min_flight = 10.0
        self._hold = False        # 解锁录像时手动停了：等锁桨以后再自动录下一次
        self.sync_offset_ms = 0
        self.channel = ""
        self.student_dir: Path | None = None
        self.state = "idle"       # idle | recording | finishing
        self.manual = False
        self.start_clock = 0.0
        self.end_clock = 0.0
        self.started_wall = None
        self._jobs: list[float] = []  # start stream times still needed by pending saves

    @property
    def recording(self) -> bool:
        return self.state != "idle"

    def elapsed(self) -> float:
        return time.perf_counter() - self.start_clock - self.preroll if self.recording else 0.0

    def toggle_manual(self):
        if self.state == "recording":
            self._hold = self.auto
            self._stop()
        elif self.state == "idle":
            self.manual = True
            self._start()

    def tick(self, armed: bool):
        """Called ~5x per second from the UI thread."""
        self.engine.poll_segments()
        now = time.perf_counter()
        if not armed:
            self._hold = False
        if self.state == "idle" and self.auto and armed and self.engine.running and not self._hold:
            self.manual = False
            self._start()
        elif self.state == "recording" and not self.manual and not armed:
            self._stop()
        elif self.state == "finishing" and self._covered(self.end_clock):
            self._save()
        self._cleanup(now)

    def _start(self):
        if not self.engine.running or self.engine.anchor is None:
            return
        self.state = "recording"
        self.start_clock = time.perf_counter() - self.preroll
        self.started_wall = datetime.now()
        # Segments can start up to SEGMENT_S before the requested start, so keep a little extra.
        self.source.begin_capture(self.start_clock - SEGMENT_S - 1)
        target = self.student_dir or self.engine.buffer_dir
        try:
            free_gb = shutil.disk_usage(target).free / 1e9
        except OSError:
            free_gb = None
        if free_gb is not None and free_gb < LOW_DISK_GB:
            self.failed.emit(f"注意：保存录像的硬盘只剩 {free_gb:.1f}GB，录满就保存不了，请尽快清理。")

    def _stop(self):
        self.state = "finishing"
        self.end_clock = time.perf_counter() + self.postroll

    def _covered(self, clock: float) -> bool:
        a = self.engine.anchor
        if a is None or not self.engine.segments:
            return not self.engine.running
        return self.engine.segments[-1][2] >= clock - a or not self.engine.running

    def _cleanup(self, now):
        a = self.engine.anchor
        if a is None:
            return
        keep_from = now - a - KEEP_IDLE_S
        if self.recording:
            keep_from = min(keep_from, self.start_clock - a - SEGMENT_S)
        for s in self._jobs:
            keep_from = min(keep_from, s - SEGMENT_S)
        self.engine.delete_segments_before(keep_from)

    def _save(self):
        self.state = "idle"
        a = self.engine.anchor
        t0, t1 = self.start_clock - a, self.end_clock - a
        segs = [s for s in self.engine.segments if s[2] > t0 and s[1] < t1]
        if t1 - t0 - self.preroll - self.postroll < self.min_flight or not segs:
            self.source.end_capture(0, 0)
            if segs:
                self.notice.emit(f"解锁不到 {self.min_flight:g} 秒，算解锁测试，没有保存。" if not self.manual
                                 else f"录制不到 {self.min_flight:g} 秒，没有保存。")
            else:
                self.failed.emit("这次飞行没有录到画面（采集可能中断了）。")
            return
        student = self.student_dir or (self.engine.buffer_dir.parent / "未分组")
        day = student / self.started_wall.strftime("%Y-%m-%d")
        day.mkdir(parents=True, exist_ok=True)
        base = day / self.started_wall.strftime("%H-%M-%S")
        video_start_clock = a + segs[0][1]
        video_end_clock = a + segs[-1][2]
        samples = self.source.end_capture(video_start_clock, video_end_clock)
        meta = {
            "student": student.name,
            "start": self.started_wall.isoformat(timespec="seconds"),
            "duration_s": round(segs[-1][2] - segs[0][1], 2),
            "flight_s": round(t1 - t0 - self.preroll - self.postroll, 2),
            "armed_at_s": round(self.start_clock + self.preroll - video_start_clock, 3),
            "fps": self.engine.fps,
            "encoder": self.engine.encoder,
            "dropped_frames_total": self.engine.stats.get("dropped", 0),
            "sync_offset_ms": self.sync_offset_ms,
            "channel": self.channel,
            "calibration": self.calibration.data,
        }
        self._jobs.append(t0)
        threading.Thread(target=self._write, args=(base, segs, samples, video_start_clock, meta, t0),
                         daemon=True).start()

    def _write(self, base: Path, segs, samples, video_start_clock, meta, job):
        try:
            self._write_sticks(base.with_suffix(".sticks.csv"), samples, video_start_clock)
            base.with_suffix(".json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
            concat = "concat:" + "|".join(str(s[0]) for s in segs)
            p = subprocess.run([ft.ffmpeg_path(), "-hide_banner", "-loglevel", "error", "-y", "-i", concat,
                                "-c", "copy", "-movflags", "+faststart", str(base.with_suffix(".mp4"))],
                               capture_output=True, creationflags=ft.NO_WINDOW)
            if p.returncode != 0:
                self.failed.emit("保存视频失败：" + p.stderr.decode("utf-8", errors="replace")[-300:])
            else:
                self.saved.emit(str(base.with_suffix(".mp4")))
        except OSError as ex:                   # 硬盘满了、文件夹被删了：要告诉教练，不能悄悄没了
            self.failed.emit(f"保存录像失败：{ex}")
        finally:
            self._jobs.remove(job)

    def _write_sticks(self, path: Path, samples, t0):
        cal = self.calibration
        n_axes = max((len(s[1]) for s in samples), default=0)
        with open(path, "w", encoding="utf-8", newline="") as f:
            f.write("t," + ",".join(CHANNELS) + ",armed," + ",".join(f"raw{i + 1}" for i in range(n_axes)) + ",buttons\n")
            for s in samples:
                v = cal.apply(s) or {c: 0.0 for c in CHANNELS} | {"armed": False}
                row = [f"{s[0] - t0:.4f}"] + [f"{v[c]:.4f}" for c in CHANNELS] + [str(int(v["armed"]))]
                row += [f"{x:.4f}" for x in s[1]] + [""] * (n_axes - len(s[1])) + [str(s[2])]
                f.write(",".join(row) + "\n")
