"""「电池记录」窗口（精简版）：用了几块电池、练了多久、每小时几块、完成率和得分，下面是这个学员每天的记录。
数据和判断都在 battery.py。"""
from datetime import datetime

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox, QFormLayout,
                               QFrame, QGridLayout, QHBoxLayout, QHeaderView, QInputDialog, QLabel, QMenu, QMessageBox,
                               QProgressBar, QPushButton, QSpinBox, QTableWidget, QTableWidgetItem, QVBoxLayout)

from app import battery as B

SUB = "#6e6e73"
GRADE_COLOR = {"优秀": "#34c759", "良好": "#007aff", "及格": "#ff9500", "效率不够": "#ff3b30"}


def _hm(ts):
    return datetime.fromtimestamp(ts).strftime("%H:%M")


def _tile(title):
    box = QFrame()
    box.setStyleSheet("QFrame { background: #ffffff; border-radius: 12px; }")
    lay = QVBoxLayout(box)
    lay.setContentsMargins(16, 10, 16, 10)
    t = QLabel(title)
    t.setStyleSheet(f"color: {SUB}; font-size: 14px; background: transparent;")
    v = QLabel("—")
    v.setStyleSheet("font-size: 34px; font-weight: bold; background: transparent;")
    sub = QLabel("")
    sub.setStyleSheet(f"color: {SUB}; background: transparent;")
    for w in (t, v, sub):
        lay.addWidget(w)
    return box, v, sub


class BatteryDialog(QDialog):
    def __init__(self, log: B.TrainingLog, students: list, current: str, parent=None, on_gap=None,
                 volt_status=None, volt_reset=None, goal=None, on_goal=None, add_student=None):
        super().__init__(parent)
        self.setWindowTitle("电池记录")
        self.resize(980, 680)
        self.log, self.on_gap = log, on_gap
        self.volt_status, self.volt_reset = volt_status, volt_reset
        self.goal, self.on_goal = goal, on_goal
        self.add_student = add_student

        names = list(dict.fromkeys(list(students) + B.pilots_of(log.root_fn())))
        self.student = QComboBox()
        self.student.addItems(names or [current or "未选学员"])
        if current in names:
            self.student.setCurrentText(current)
        add_btn = QPushButton("＋ 增加学员")
        add_btn.clicked.connect(self._add_student)
        add_btn.setVisible(add_student is not None)
        self.day = QComboBox()
        self.goal_box = QComboBox()
        self._fill_goals()
        self.goal_box.activated.connect(self._goal_picked)
        sum_btn = QPushButton("📋 全班总结")
        sum_btn.clicked.connect(lambda: ClassSummary(self.log, [self.student.itemText(i) for i in range(self.student.count())],
                                                     self.day.currentText(), self.goal, self).exec())
        sum_btn.setAutoDefault(False)
        more_btn = QPushButton("⚙ 设置")
        more = QMenu(more_btn)
        more.addAction("换电池怎么算…", self._gap_dialog)
        more.addAction("用飞机电压判断换电池（遥控器怎么设）…", lambda: QMessageBox.information(self, "飞机电压", B.VOLT_GUIDE))
        more_btn.setMenu(more)

        top = QHBoxLayout()
        for w in (QLabel("学员"), self.student, add_btn, QLabel("日期"), self.day, QLabel("目标"), self.goal_box):
            top.addWidget(w)
        top.addStretch()
        top.addWidget(sum_btn)
        top.addWidget(more_btn)

        tiles = QGridLayout()
        self.t = {}
        for i, (k, title) in enumerate((("bat", "电池"), ("time", "训练时间"), ("rate", "每小时"), ("score", "得分"))):
            box, v, sub = _tile(title)
            self.t[k] = (v, sub)
            tiles.addWidget(box, 0, i)

        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(16)
        self.verdict = QLabel()
        self.verdict.setStyleSheet("font-size: 16px; font-weight: bold;")
        self.verdict.setWordWrap(True)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["日期", "电池", "训练时间", "每小时", "完成率", "得分"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.cellClicked.connect(lambda r, _c: self.day.setCurrentText(self.table.item(r, 0).text()))

        close = QPushButton("关闭")
        close.clicked.connect(self.accept)
        for b in (add_btn, more_btn):
            b.setAutoDefault(False)
        close.setDefault(True)
        foot = QHBoxLayout()
        note = QLabel("遥控器连着就会自动记，不用录像。训练时速度跟不上目标会弹窗提醒。")
        note.setStyleSheet(f"color: {SUB};")
        foot.addWidget(note, 1)
        foot.addWidget(close)

        lay = QVBoxLayout(self)
        lay.addLayout(top)
        lay.addLayout(tiles)
        lay.addWidget(self.bar)
        lay.addWidget(self.verdict)
        hist = QLabel("每天的记录（点一行看那一天）")
        hist.setStyleSheet(f"color: {SUB}; margin-top: 6px;")
        lay.addWidget(hist)
        lay.addWidget(self.table, 1)
        lay.addLayout(foot)

        self.student.currentTextChanged.connect(self._fill_days)
        self.day.currentTextChanged.connect(self._refresh)
        self._fill_days()
        self._timer = QTimer(self, interval=5000, timeout=self._refresh)   # 开着窗口上课：数字自己跟着变
        self._timer.start()

    # ---- 数据 ----
    def _pilot(self):
        return self.student.currentText()

    def _fill_days(self):
        days = B.days_of(self.log.root_fn(), self._pilot())
        today = datetime.now().strftime("%Y-%m-%d")
        if today not in days:
            days.insert(0, today)
        self.day.blockSignals(True)
        self.day.clear()
        self.day.addItems(days)
        self.day.blockSignals(False)
        self._refresh()

    def _refresh(self):
        pilot, day = self._pilot(), self.day.currentText()
        if not day:
            return
        s = B.summary(self.log.flights(pilot, day))
        ev = B.evaluate(self.goal, s)
        g = self.goal or {}
        day_goal = g.get("batteries") if g.get("batteries") and not g.get("hours") else None
        self._set("bat", f"{s['batteries']} 块" + (f" / {day_goal}" if day_goal else ""),
                  f"今天目标 {day_goal} 块，还差 {max(0, day_goal - s['batteries'])} 块" if day_goal
                  else f"起飞 {s['flights']} 次")
        self._set("time", B.fmt_s(s["span_s"]) if s["first"] else "—",
                  f"{_hm(s['first'])}–{_hm(s['last'])}" if s["first"] else "")
        self._set("rate", f"{s['per_hour']:.1f} 块" if s["per_hour"] is not None else "—",
                  (f"目标 {ev['target']:g} 块" if ev else "") + ("" if s["per_hour"] is not None else "（练满 15 分钟才算）"))
        if ev and ev["score"] is not None:
            color = GRADE_COLOR[ev["grade"]]
            self._set("score", f"{ev['score']} 分", f"完成率 {ev['pct']:.0f}% · {ev['grade']}")
            self.t["score"][0].setStyleSheet(f"font-size: 34px; font-weight: bold; color: {color}; background: transparent;")
            self.bar.setValue(int(min(100, ev["pct"])))
            self.bar.setStyleSheet("QProgressBar { background: #e5e5ea; border: none; border-radius: 8px; }"
                                   f"QProgressBar::chunk {{ background: {color}; border-radius: 8px; }}")
            if ev["low"]:
                need = ev["target"] - ev["rate"]
                self.verdict.setText(f"⚠ 效率不够：每小时 {ev['rate']:.1f} 块，目标 {ev['target']:g} 块，"
                                     f"每小时还差 {need:.1f} 块。少等待、换电池快一点。")
            else:
                self.verdict.setText(f"✓ 达到目标的 {ev['pct']:.0f}%（{ev['grade']}）")
            self.verdict.setStyleSheet(f"font-size: 16px; font-weight: bold; color: {color};")
        else:
            self._set("score", "—", "先选目标" if not ev else ev["grade"])
            self.t["score"][0].setStyleSheet("font-size: 34px; font-weight: bold; background: transparent;")
            self.bar.setValue(0)
            self.verdict.setText("上面「目标」选一个（比如 1 小时 15 块），就能打分。" if not ev else "")
            self.verdict.setStyleSheet(f"font-size: 15px; color: {SUB};")
        self._history(pilot)

    def _set(self, k, value, sub):
        self.t[k][0].setText(value)
        self.t[k][1].setText(sub)

    def _history(self, pilot):
        rows = []
        for d in B.days_of(self.log.root_fn(), pilot):
            s = B.summary(self.log.flights(pilot, d))
            if s["flights"]:
                rows.append((d, s, B.evaluate(self.goal, s)))
        self.table.setRowCount(len(rows))
        for i, (d, s, ev) in enumerate(rows):
            cells = [d, f"{s['batteries']} 块", B.fmt_s(s["span_s"]),
                     f"{s['per_hour']:.1f} 块" if s["per_hour"] is not None else "—",
                     f"{ev['pct']:.0f}%" if ev and ev["pct"] is not None else "—",
                     f"{ev['score']} 分 {ev['grade']}" if ev and ev["score"] is not None else "—"]
            for c, text in enumerate(cells):
                it = QTableWidgetItem(text)
                it.setTextAlignment(Qt.AlignCenter)
                if c == 5 and ev and ev["score"] is not None:
                    it.setForeground(QColor(GRADE_COLOR[ev["grade"]]))
                self.table.setItem(i, c, it)

    # ---- 增加学员 ----
    def _add_student(self):
        name, ok = QInputDialog.getText(self, "增加学员", "学员名字：")
        name = name.strip()
        if not ok or not name:
            return
        if any(c in name for c in '\\/:*?"<>|') or name.startswith("."):
            QMessageBox.warning(self, "增加学员", "名字里不能有 \\ / : * ? \" < > | ，也不能用点开头。")
            return
        try:
            name = self.add_student(name) or name
        except OSError as e:
            QMessageBox.warning(self, "增加学员", f"建不了这个学员：{e}")
            return
        if self.student.findText(name) < 0:
            self.student.addItem(name)
        self.student.setCurrentText(name)

    # ---- 目标 ----
    def _fill_goals(self):
        self.goal_box.blockSignals(True)
        self.goal_box.clear()
        items = list(B.GOAL_PRESETS)
        if self.goal and self.goal not in items:
            items.append(self.goal)
        for g in items:
            self.goal_box.addItem(B.goal_name(g), g)
        self.goal_box.addItem("自定义…", "custom")
        self.goal_box.setCurrentIndex(items.index(self.goal) if self.goal in items else 0)
        self.goal_box.blockSignals(False)

    def _goal_picked(self, i):
        g = self.goal_box.itemData(i)
        if g == "custom":
            g = self._ask_goal()
            if g is False:
                self._fill_goals()
                return
        self.goal = g
        if self.on_goal:
            self.on_goal(g)
        self._fill_goals()
        self._refresh()

    def _ask_goal(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("自定义目标")
        hours = QDoubleSpinBox()
        hours.setRange(0, 12)
        hours.setDecimals(1)
        hours.setSingleStep(0.5)
        hours.setSpecialValueText("一天")
        hours.setSuffix(" 小时")
        hours.setValue(self.goal.get("hours", 1) if self.goal else 1)
        bats = QSpinBox()
        bats.setRange(1, 500)
        bats.setSuffix(" 块电池")
        bats.setValue(self.goal.get("batteries", 15) if self.goal else 15)
        form = QFormLayout(dlg)
        form.addRow(QLabel(f"时长调到 0 就是「一天几块」，按一天练 {B.DAY_HOURS:g} 小时算速度。"))
        form.addRow("时长", hours)
        form.addRow("飞", bats)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        form.addRow(bb)
        if not dlg.exec():
            return False
        return {"hours": round(hours.value(), 1), "batteries": bats.value()}

    # ---- 设置 ----
    def _gap_dialog(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("换电池怎么算")
        gap = QDoubleSpinBox()
        gap.setRange(20, 600)
        gap.setDecimals(0)
        gap.setSuffix(" 秒")
        gap.setValue(self.log.gap_s)
        form = QFormLayout(dlg)
        form.addRow(QLabel("锁桨后隔这么久才再解锁，就算换了一块电池。\n换电池特别快的话调小一点。"))
        form.addRow("锁桨超过", gap)
        if self.volt_status:
            v = QLabel(self.volt_status())
            v.setWordWrap(True)
            v.setStyleSheet(f"color: {SUB};")
            form.addRow(v)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        if self.volt_reset:
            again = bb.addButton("电压通道重新找", QDialogButtonBox.ResetRole)
            again.clicked.connect(self.volt_reset)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        form.addRow(bb)
        if dlg.exec():
            self.log.set_gap(float(gap.value()))
            if self.on_gap:
                self.on_gap(float(gap.value()))
            self._refresh()


class ClassSummary(QDialog):
    """全班总结：每个学员各自的电池、训练时间、每小时几块、得分，最后一句总结。下课铃响时自动弹出（这节课）。"""

    def __init__(self, log, pilots, day, goal, parent=None, this_class=False):
        super().__init__(parent)
        self.setWindowTitle("全班总结" + ("（这节课）" if this_class else f"（{day}）"))
        self.resize(820, 520)
        rows = B.class_report(log, pilots, day, goal, this_class)
        lay = QVBoxLayout(self)
        head = QLabel(("这节课" if this_class else day) + (f"　目标：{B.goal_name(goal)}" if goal else "　没设目标，只列训练量"))
        head.setStyleSheet("font-size: 16px; font-weight: bold;")
        lay.addWidget(head)
        table = QTableWidget(len(rows), 6)
        table.setHorizontalHeaderLabels(["学员", "电池", "训练时间", "每小时", "完成率", "得分"])
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        for i, (p, s, ev) in enumerate(rows):
            cells = [p, f"{s['batteries']} 块", B.fmt_s(s["span_s"]),
                     f"{s['per_hour']:.1f} 块" if s["per_hour"] is not None else "—",
                     f"{ev['pct']:.0f}%" if ev and ev["pct"] is not None else "—",
                     f"{ev['score']} 分 {ev['grade']}" if ev and ev["score"] is not None else "—"]
            for c, text in enumerate(cells):
                it = QTableWidgetItem(text)
                it.setTextAlignment(Qt.AlignCenter)
                if c == 5 and ev and ev["score"] is not None:
                    it.setForeground(QColor(GRADE_COLOR[ev["grade"]]))
                table.setItem(i, c, it)
        lay.addWidget(table, 1)
        total = sum(s["batteries"] for _, s, _ in rows)
        scored = [(p, ev) for p, _, ev in rows if ev and ev["score"] is not None]
        text = f"一共 {len(rows)} 个学员飞了，{total} 块电池。" if rows else "这段时间没有学员飞。"
        if scored:
            avg = sum(ev["score"] for _, ev in scored) / len(scored)
            text += f"平均 {avg:.0f} 分。"
            good = [p for p, ev in scored if ev["grade"] == "优秀"]
            low = [p for p, ev in scored if ev["low"]]
            if good:
                text += f"\n达标（优秀）：{'、'.join(good)}。"
            if low:
                text += f"\n效率不够，要提速：{'、'.join(low)}。"
        summary = QLabel(text)
        summary.setWordWrap(True)
        summary.setStyleSheet("font-size: 15px;")
        lay.addWidget(summary)
        close = QPushButton("关闭")
        close.setDefault(True)
        close.clicked.connect(self.accept)
        row = QHBoxLayout()
        row.addStretch()
        row.addWidget(close)
        lay.addLayout(row)
