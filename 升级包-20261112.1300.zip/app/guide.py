"""使用向导：第一次打开软件时一步一步设好（录像位置、采集卡、遥控器、学员和频道），最后介绍各个功能。
以后在首页点「使用向导」还能再走一遍。每一步都能跳过。"""
from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QColor, QFont, QPainter
from PySide6.QtWidgets import QDialog, QFileDialog, QHBoxLayout, QLabel, QPushButton, QStackedWidget, QVBoxLayout, QWidget


class _Steps(QWidget):
    """上面那排步骤圆点"""

    def __init__(self, names):
        super().__init__()
        self.names, self.cur = names, 0
        self.setFixedHeight(64)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        n = len(self.names)
        w = self.width() / n
        f = QFont()
        f.setPixelSize(12)
        for k, name in enumerate(self.names):
            cx = w*k + w/2
            if k < n-1:
                p.setPen(QColor("#0a84ff") if k < self.cur else QColor("#d6dde8"))
                p.drawLine(int(cx+14), 20, int(cx+w-14), 20)
            done, now = k < self.cur, k == self.cur
            p.setPen(Qt.NoPen)
            p.setBrush(QColor("#0a84ff") if done or now else QColor("#e6ebf2"))
            p.drawEllipse(QRectF(cx-12, 8, 24, 24))
            f.setBold(True)
            p.setFont(f)
            p.setPen(QColor("white") if done or now else QColor("#8a98ab"))
            p.drawText(QRectF(cx-12, 8, 24, 24), Qt.AlignCenter, "✓" if done else str(k+1))
            f.setBold(now)
            p.setFont(f)
            p.setPen(QColor("#0b1f3a") if now else QColor("#8a98ab"))
            p.drawText(QRectF(cx-w/2, 36, w, 20), Qt.AlignCenter, name)


class GuideDialog(QDialog):
    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.setWindowTitle("使用向导")
        self.resize(760, 520)
        self.pages = QStackedWidget()
        steps = [
            ("欢迎", "欢迎使用 无人机竞速 · 打杆教学",
             "接下来几步把软件设好，大概两三分钟。每一步都可以先跳过，以后在首页点「使用向导」还能再来一遍。\n\n"
             "准备好：采集卡插上电脑、遥控器用 USB 线连电脑（或者连上无线接收器）。", None),
            ("录像位置", "录像存在哪里",
             "每次飞行的录像和打杆数据都存在这个文件夹，按学员、日期分好。建议选空间大的盘，比如 E 盘。",
             ("选择文件夹…", self._pick_dir)),
            ("采集卡", "选采集卡，看到图传画面",
             "在训练模式上面「图传画面」里选你的采集卡（推荐 1920×1080 60 帧），点绿色「开始采集」。\n"
             "下次打开软件会自动开始采集。看不到画面就点「刷新」，或者在「⚙ 设置 → 诊断」生成报告。",
             ("去训练模式选采集卡", self._go_train)),
            ("遥控器", "连接并校准遥控器",
             "遥控器用 USB 连电脑，选「USB 摇杆（HID）」模式。软件会自动认 EdgeTX 遥控器。\n"
             "点下面按钮校准：按提示把摇杆推到四个角、拨解锁开关。校准好以后录像里能同步看到打杆。",
             ("校准遥控器", lambda: self.main.open_wizard())),
            ("学员", "添加学员，填好图传频道",
             "训练模式左下角「添加学员」。每个学员可以填自己的图传频道（比如 R1、R3），切换学员时自动换频道，比赛时也自动用。",
             ("填学员频道", lambda: self.main.open_student_channels())),
            ("完成", "设好了！",
             "· 训练模式：解锁自动录像，锁桨停；回看能同步看打杆。\n"
             "· 比赛模式：连计时器，多路画面，自动记圈、排名、出成绩海报。\n"
             "· 赛道搭建：3D 摆门，点门洞定顺序，画笔画路线。\n"
             "· 黑羊导出 / 模拟飞行：模拟飞一遍，导出黑羊地图（门间距可以按比例拉开）。\n"
             "\n"
             "有问题点「⚙ 设置 → 诊断」生成报告发给开发者。", None),
        ]
        self.bar = _Steps([s[0] for s in steps])
        for _short, title, text, action in steps:
            w = QWidget()
            v = QVBoxLayout(w)
            v.setContentsMargins(36, 10, 36, 10)
            t = QLabel(title)
            t.setStyleSheet("font-size: 24px; font-weight: bold; color: #0b1f3a;")
            v.addWidget(t)
            v.addSpacing(10)
            b = QLabel(text)
            b.setWordWrap(True)
            b.setStyleSheet("font-size: 15px; color: #3c4a5c; line-height: 150%;")
            v.addWidget(b)
            v.addSpacing(16)
            if action:
                btn = QPushButton(action[0])
                btn.setMinimumHeight(40)
                btn.setStyleSheet("QPushButton { background: #eef5ff; color: #0a84ff; font-weight: bold; font-size: 15px;"
                                  " border: 1px solid #cfe2ff; border-radius: 10px; padding: 6px 22px; }"
                                  "QPushButton:hover { background: #e2eeff; }")
                btn.clicked.connect(action[1])
                row = QHBoxLayout()
                row.addWidget(btn)
                row.addStretch()
                v.addLayout(row)
            v.addStretch()
            self.pages.addWidget(w)
        self.dir_label = QLabel()
        self.dir_label.setStyleSheet("color: #0a84ff;")
        self.pages.widget(1).layout().insertWidget(4, self.dir_label)
        self._show_dir()
        self.back = QPushButton("上一步")
        self.skip = QPushButton("跳过向导")
        self.next = QPushButton("下一步")
        self.next.setDefault(True)
        self.next.setMinimumWidth(120)
        self.back.clicked.connect(lambda: self._go(-1))
        self.next.clicked.connect(lambda: self._go(1))
        self.skip.clicked.connect(self._finish)
        nav = QHBoxLayout()
        nav.addWidget(self.skip)
        nav.addStretch()
        nav.addWidget(self.back)
        nav.addWidget(self.next)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 18, 20, 18)
        lay.addWidget(self.bar)
        lay.addWidget(self.pages, 1)
        lay.addLayout(nav)
        self._go(0)

    def _show_dir(self):
        self.dir_label.setText("现在存在：" + str(self.main.s["data_dir"]))

    def _pick_dir(self):
        d = QFileDialog.getExistingDirectory(self, "选择录像保存位置", self.main.s["data_dir"])
        if d:
            self.main._apply_data_dir(d)
        self._show_dir()

    def _go_train(self):
        self.main.go_page("train")
        self.raise_()

    def _go(self, d):
        k = self.pages.currentIndex() + d
        if k >= self.pages.count():
            self._finish()
            return
        k = max(0, k)
        self.pages.setCurrentIndex(k)
        self.bar.cur = k
        self.bar.update()
        self.back.setEnabled(k > 0)
        self.next.setText("开始使用" if k == self.pages.count()-1 else "下一步")
        self.skip.setVisible(k < self.pages.count()-1)

    def _finish(self):
        self.main.s["guide_done"] = True
        if not self.main.s.data.get("data_dir_chosen"):
            self.main._apply_data_dir(self.main.s["data_dir"])
        self.accept()
