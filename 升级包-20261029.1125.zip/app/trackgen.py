"""随机赛道：选门数、门型、练习重点、场地大小，电脑自动摆一圈门和飞行路线。

做出来的东西和「组委会 exe 转换」一样：零件（门的位置朝向）+ 飞行路线，
交给 trackconv.build 去算过门顺序、摆黑羊的门框和检查点，所以预览、模拟飞、导出 TRK 都能直接用。
单位米，y 朝上。
"""
import math
import random

try:
    from . import trackconv as tc
except ImportError:
    import trackconv as tc

GATE_TYPES = {'单门': '单门', '日子门': '日字门', '三联': '三联门', '单重': '方框', '双重': '双层方框'}
FOCUS = ['综合', '直线加速', 'S 弯', '急转掉头', '高低穿越', '下翻塔']
# 每种门怎么穿：(代号, 显示的字)
HOWS = {'单门': [('', '穿过去')], '日子门': [('下', '穿下洞'), ('上', '穿上洞')],
        '三联': [('1', '穿第 1 个洞'), ('2', '穿中间洞'), ('3', '穿第 3 个洞')], '单重': [('', '直穿两面'), ('顶进', '从顶上钻进，前面出'), ('顶出', '前面进，从顶上钻出')],
        '双重': [('下翻', '从顶上钻下去'), ('上层', '直穿上层'), ('下层', '直穿下层')]}
FIELDS = {'小（30×20 米）': (30, 20), '中（45×30 米）': (45, 30), '大（60×40 米）': (60, 40),
          '超大（120×80 米）': (120, 80)}

# 每种练习重点喜欢用的门（会和勾选的门型取交集）
LEAD = {'S 弯': 1.3}
PREFER = {'综合': ['单门', '日子门', '三联', '单重', '双重'], '直线加速': ['单门', '三联', '单重'],
          'S 弯': ['单门'], '急转掉头': ['单门', '日子门'], '高低穿越': ['日子门', '双重', '三联'],
          '下翻塔': ['单门', '日子门']}


# ------------------------------------------------------------------ 小工具
def _h(v):
    l = math.hypot(v[0], v[2]) or 1
    return [v[0]/l, 0.0, v[2]/l]


def _left(f):
    return [-f[2], 0.0, f[0]]


def _chaikin(pts, n=4):
    for _ in range(n):
        out = []
        for i in range(len(pts)):
            a, b = pts[i], pts[(i+1) % len(pts)]
            out += [[a[0]*.75+b[0]*.25, 0, a[2]*.75+b[2]*.25], [a[0]*.25+b[0]*.75, 0, a[2]*.25+b[2]*.75]]
        pts = out
    return pts


def _resample(loop, step=0.5):
    """闭合曲线按弧长等距取点"""
    seg = [math.dist(loop[i], loop[(i+1) % len(loop)]) for i in range(len(loop))]
    total = sum(seg)
    n = max(8, int(total/step))
    out, i, acc = [], 0, 0.0
    for k in range(n):
        s = k*total/n
        while acc+seg[i] < s:
            acc += seg[i]; i += 1
        t = (s-acc)/(seg[i] or 1)
        a, b = loop[i], loop[(i+1) % len(loop)]
        out.append([a[0]+t*(b[0]-a[0]), 0.0, a[2]+t*(b[2]-a[2])])
    return out, total


def _snake(W, L, lanes, m=4.0):
    """门很多时：来回的蛇形，最后沿外圈绕回起点（lanes 是单数，每条间隔 g 米）"""
    x0, x1, z0, z1 = -L/2+m, L/2-m, -W/2+m, W/2-m
    g = (z1-z0)/(lanes+1)
    xa = x0+g
    pts = []
    for i in range(lanes):
        z = z0+i*g
        pts += [[xa, 0, z], [x1, 0, z]] if i % 2 == 0 else [[x1, 0, z], [xa, 0, z]]
    return pts + [[x1, 0, z1], [x0, 0, z1], [x0, 0, z0]]


def _outline(focus, W, L, rnd, lanes=0):
    """场地里的一圈中心线（多边形，后面再磨圆）"""
    m = 4.0
    if lanes:
        return _snake(W, L, lanes, m)
    x0, x1, z0, z1 = -L/2+m, L/2-m, -W/2+m, W/2-m
    if focus == '急转掉头':
        # 一来一回的发夹弯：中间凹进去两道，形成 3 条平行的来回
        g = (z1-z0)/3
        k = rnd.choice([0, 1])
        if k == 0:
            return [[x0, 0, z0], [x1, 0, z0], [x1, 0, z0+g], [x0+L*0.3, 0, z0+g], [x0+L*0.3, 0, z0+2*g],
                    [x1, 0, z0+2*g], [x1, 0, z1], [x0, 0, z1]]
        return [[x0, 0, z0], [x1, 0, z0], [x1, 0, z1], [x0+L*0.45, 0, z1], [x0+L*0.45, 0, z0+g*1.2],
                [x0+L*0.3, 0, z0+g*1.2], [x0+L*0.3, 0, z1], [x0, 0, z1]]
    if focus in ('直线加速', 'S 弯'):
        return [[x0, 0, z0], [x1, 0, z0], [x1, 0, z1], [x0, 0, z1]]
    # 其它：不规则的一圈（8~10 个角，每个角随机往里收一点）
    n = rnd.randint(7, 10)
    pts = []
    for i in range(n):
        a = 2*math.pi*i/n + rnd.uniform(-0.15, 0.15)
        r = rnd.uniform(0.65, 1.0)
        pts.append([math.cos(a)*(x1)*r, 0, math.sin(a)*(z1)*r])
    return pts


def _catmull(P, step=0.3):
    """过所有控制点的平滑曲线（向心 Catmull-Rom）"""
    if len(P) < 2:
        return P
    P = [P[0]] + P + [P[-1]]
    out = []
    for i in range(1, len(P)-2):
        p0, p1, p2, p3 = P[i-1], P[i], P[i+1], P[i+2]
        d = math.dist(p1, p2)
        n = max(1, int(d/step))

        def tj(ti, a, b):
            return ti + max(math.dist(a, b), 1e-4)**0.5
        t0 = 0; t1 = tj(t0, p0, p1); t2 = tj(t1, p1, p2); t3 = tj(t2, p2, p3)
        for k in range(n):
            t = t1 + (t2-t1)*k/n
            A1 = [((t1-t)*p0[j]+(t-t0)*p1[j])/(t1-t0) for j in range(3)]
            A2 = [((t2-t)*p1[j]+(t-t1)*p2[j])/(t2-t1) for j in range(3)]
            A3 = [((t3-t)*p2[j]+(t-t2)*p3[j])/(t3-t2) for j in range(3)]
            B1 = [((t2-t)*A1[j]+(t-t0)*A2[j])/(t2-t0) for j in range(3)]
            B2 = [((t3-t)*A2[j]+(t-t1)*A3[j])/(t3-t1) for j in range(3)]
            out.append([((t2-t)*B1[j]+(t-t1)*B2[j])/(t2-t1) for j in range(3)])
    out.append(P[-2])
    return out


def _part(pid, t, pos, a, up, b):
    """一个零件：局部 X=a，Y=up，Z=b，原点在地面中心"""
    return dict(id=pid, name=f"{GATE_TYPES.get(t, t)}-{pid}", m=list(a)+list(up)+list(b), o=list(pos),
                lc=[0.0, 0.0, 0.0], bodies=[], ext=[0, 0, 0])


# ------------------------------------------------------------------ 生成
def _elements(n, focus, allowed, rnd):
    """这一圈每个位置放什么：(门型, 怎么穿)"""
    pref = [t for t in PREFER[focus] if t in allowed] or list(allowed)
    out = []
    towers = 0
    for i in range(n):
        if i == 0:
            t = '单门' if '单门' in allowed else pref[0]      # 第一个门 = 计时门，用简单的门
        elif focus == '下翻塔' and '双重' in allowed and i % 3 == 1 and towers < 3:
            t = '双重'
        else:
            t = rnd.choice(pref)
        if t == '双重':
            towers += 1
        if t == '日子门':
            how = rnd.choice(['上', '下']) if focus != '高低穿越' else ('上' if i % 2 else '下')
        elif t == '三联':
            how = rnd.choice(['1', '2', '3'])
        elif t == '双重':
            how = '下翻' if (focus == '下翻塔' or (focus == '综合' and rnd.random() < 0.4)) else \
                rnd.choice(['上层', '下层'])
        else:
            how = ''
        out.append((t, how))
    if focus == '高低穿越' and not any(h in ('上', '上层') for _, h in out[1:]) and n > 2:
        out[2] = ('日子门', '上') if '日子门' in allowed else out[2]
    return out


def _place(ctr, total, n, focus, rnd):
    """在中心线上挑 n 个位置（弧长），尽量放在直的地方；S 弯时连续几个门挨着放"""
    N = len(ctr)

    def bend(i):
        a, b, c = ctr[(i-6) % N], ctr[i], ctr[(i+6) % N]
        u, v = _h(tc.sub(b, a)), _h(tc.sub(c, b))
        return 1-tc.dot(u, v)
    spacing = total/n
    if focus == 'S 弯':
        # 在直道上一组一组地摆：每组 3~4 个门，间隔 8 米，左右交替偏开 2.3 米
        step = max(1, int(round(8.0/(total/N))))
        straight = [bend(i) < 0.01 for i in range(N)]
        runs, i0 = [], None
        for i in range(N*2):
            ok = straight[i % N]
            if ok and i0 is None:
                i0 = i
            if (not ok or i == N*2-1) and i0 is not None:
                if i0 < N:
                    runs.append((i0, i-1))
                i0 = None
        runs.sort(key=lambda r: r[0]-r[1])
        idx, offs = [], []
        for a, b in runs:
            k = min(4, (b-a-6)//step + 1, n-len(idx))
            if k < 2:
                continue
            first = a + (b-a-(k-1)*step)//2
            side = rnd.choice([-1, 1])
            for q in range(k):
                idx.append((first+q*step) % N)
                offs.append(side*((-1)**q)*2.3)
            if len(idx) >= n:
                break
        # 剩下的门：单个摆在离 S 弯组远的地方
        gapi = int(9.0/(total/N))
        while len(idx) < n:
            free = [i for i in range(N) if all(min(abs(i-j), N-abs(i-j)) > gapi for j in idx)]
            if not free:
                return None, None
            far = max(free, key=lambda i: min(min(abs(i-j), N-abs(i-j)) for j in idx) + 3*(bend(i) < 0.01))
            idx.append(far)
            offs.append(0.0)
        return idx, offs
    start = rnd.random()*N
    idx = []
    for j in range(n):
        base = int(start + j*N/n) % N
        win = int(spacing/(total/N)*0.3)
        best = min(range(base-win, base+win+1), key=lambda i: bend(i % N) + rnd.random()*0.01)
        idx.append(best % N)
    return idx, [0.0]*n


def generate(n_gates=10, allowed=('单门', '日子门', '三联', '单重', '双重'), focus='综合', field='中（45×30 米）',
             seed=1, S=2.5, T=0.2, elems=None):
    """返回 (model, types, path, info)。路线没穿好（撞门框、漏门）就换个摆法再试。
    elems：指定每个门的门型和穿法 [(门型, 穿法)]，不给就随机挑"""
    allowed = [t for t in allowed if t in GATE_TYPES] or ['单门']
    W, L = FIELDS.get(field, (30, 45))
    W, L = min(W, L), max(W, L)
    n = len(elems) if elems else n_gates
    W0 = W
    # 门多：场地按比例放大到够用（每个门大约要 9 米路线、80 平方米地方），路线改成来回的蛇形
    lanes = 0
    if n > 16:
        k = max(1.0, math.sqrt(n*80/(W*L)))
        W, L = W*k, L*k
        lanes = max(3, int((n*9)/(L-8-W/6)) | 1)
        while (W-8)/(lanes+1) < 8:
            W += 8
    # 门多、场地放不下：场地按比例放大再试（每次大 1.3 倍），信息里告诉用的是多大的场地
    for grow in range(10):
        for attempt in range(60 if grow == 0 else 25):
            rnd = random.Random(f"{seed}-{grow}-{attempt}" if grow else f"{seed}-{attempt}")
            res = _try(n, allowed, focus, W, L, rnd, S, T, elems, lanes)
            if res:
                res[3].update(attempt=attempt, field=(round(L), round(W)), grown=W > W0)
                return res
        W, L = W*1.3, L*1.3
    raise ValueError("摆不下这么多门：换小一点的门数、大一点的场地，或者多勾几种门型再试")


def _try(n, allowed, focus, W, L, rnd, S, T, fixed=None, lanes=0):
    loop = _chaikin(_outline(focus, W, L, rnd, lanes))
    ctr, total = _resample(loop, 0.5)
    if total < n*6:
        return None
    if rnd.random() < 0.5:                       # 一半机会反着飞
        ctr = ctr[::-1]
    idx, offs = _place(ctr, total, n, focus, rnd)
    if idx is None:
        return None
    elems = [tuple(e) for e in fixed] if fixed else _elements(n, focus, allowed, rnd)
    order = sorted(range(n), key=lambda j: idx[j])
    idx = [idx[j] for j in order]
    offs = [offs[j] for j in order]
    if len(set(idx)) < n:
        return None
    N = len(ctr)
    H = S+2*T
    mid = T+S/2
    top = 2*H-T
    parts, types, ctrl, expect = [], {}, [], []
    up = [0.0, 1.0, 0.0]
    ld = LEAD.get(focus, 2.5)
    for j, ((t, how), i) in enumerate(zip(elems, idx)):
        f = _h(tc.sub(ctr[(i+3) % N], ctr[(i-3) % N]))
        lf = _left(f)
        c = tc.add(ctr[i], tc.mul(lf, offs[j]))
        pid = j+1
        if t in ('单门', '日子门'):
            parts.append(_part(pid, t, c, lf, up, f))
            y = mid if (t == '单门' or how == '下') else H+S/2
            P = [c[0], y, c[2]]
            ctrl.append([tc.sub(P, tc.mul(f, ld)), P, tc.add(P, tc.mul(f, ld))])
            expect.append(1)
        elif t == '三联':
            k = int(how or 2)-1
            c = tc.sub(c, tc.mul(lf, (1-k)*(S+T)))             # 整个门横着挪，让要穿的洞正好在路线上
            parts.append(_part(pid, t, c, f, up, lf))          # 三联：门洞法向是局部 X
            P = tc.add([c[0], mid, c[2]], tc.mul(lf, (1-k)*(S+T)))
            ctrl.append([tc.sub(P, tc.mul(f, ld)), P, tc.add(P, tc.mul(f, ld))])
            expect.append(1)
        elif t == '单重' or (t == '双重' and how in ('上层', '下层')):
            parts.append(_part(pid, t, c, lf, up, f))
            y = mid if (t == '单重' or how == '下层') else H-T+mid
            P = [c[0], y, c[2]]
            ctrl.append([tc.sub(P, tc.mul(f, 4.0)), tc.sub(P, tc.mul(f, 1.6)), P, tc.add(P, tc.mul(f, 1.6)),
                         tc.add(P, tc.mul(f, 4.0))])
            expect.append(2)
        else:                                               # 双层方框：从顶上钻进去，从下层侧面出来
            parts.append(_part(pid, '双重', c, lf, up, f))
            hi = top+1.8
            ctrl.append([tc.add([c[0], hi, c[2]], tc.mul(f, -4.5)), [c[0], hi, c[2]], [c[0], top-0.6, c[2]],
                         [c[0], mid+0.4, c[2]], tc.add([c[0], mid, c[2]], tc.mul(f, 1.6)),
                         tc.add([c[0], mid, c[2]], tc.mul(f, 4.5))])
            expect.append(2)
        types[pid] = t
    # 起飞台：第一个门前面 9 米
    f0 = _h(tc.sub(ctr[(idx[0]+3) % N], ctr[(idx[0]-3) % N]))
    g0 = ctr[idx[0]]
    take = tc.sub(g0, tc.mul(f0, 9.0))
    parts.append(_part(0, '起飞台', take, _left(f0), up, f0))
    parts[-1]['name'] = '起飞台'
    types[0] = '起飞台'
    # 路线控制点：起飞 → 每个门（中间顺着中心线补点）→ 再过一次计时门
    P = [[take[0], 1.4, take[2]], tc.add([take[0], mid, take[2]], tc.mul(f0, 3))]
    seq = list(range(n)) + [0]
    for k, j in enumerate(seq):
        h = len(ctrl[j])//2+1
        P += ctrl[j] if k < n else ctrl[j][:h] + ([ctrl[j][h]] if expect[j] == 1 else [])
        if k == n:
            break
        nxt = seq[k+1]
        a, b = idx[j], idx[nxt] + (N if idx[nxt] <= idx[j] else 0)
        ya, yb = ctrl[j][-1][1], ctrl[nxt][0][1]
        gap = (b-a)*total/N
        m_ = int(gap/6)
        for q in range(1, m_):
            s = a + (b-a)*q/m_
            if min(abs(s-a), abs(b-s))*total/N < 4.5:
                continue
            w = q/m_
            pt = ctr[int(s) % N]
            P.append([pt[0], ya+(yb-ya)*w if focus != '高低穿越' else max(ya, yb), pt[2]])
    path = _catmull(P, 0.3)
    for q in path:
        q[1] = max(0.4, q[1])
    model = dict(parts=parts, bodies={}, edges={}, pieces=[], preview=None)
    # 检查：每个门都按顺序穿到了，路线没有擦到别的门框
    cr = tc.crossings(model, types, path)
    want = []
    for k, j in enumerate(seq):
        want += [j+1]*(expect[j] if k < n else 1)       # 最后再过一次计时门：只算进门那一下
    got = [c[1] for c in cr]
    if got != want:
        return None
    if _hits_frame(model, types, path, S, T):
        return None
    xs = [q[0] for q in path]; zs = [q[2] for q in path]
    if max(xs)-min(xs) > L+2 or max(zs)-min(zs) > W+2:
        return None
    info = dict(focus=focus, n=n, length=sum(math.dist(path[i], path[i+1]) for i in range(len(path)-1)),
                kinds=[f"{GATE_TYPES[t]}{('（'+h+'）') if h else ''}" for t, h in elems], elems=[list(e) for e in elems])
    return model, types, path, info


# ------------------------------------------------------------------ 手工布置
WP = '路线点'          # 不是门：路线从这里经过（拉弯、抬高用）
POLE = '绕杆'          # 一根杆子（组委会图上的刀旗）：路线贴着它绕过去，转多少看下一个门在哪
POLE_R = 1.8           # 组委会的线离刀旗 1.4～2 米
FLAG = '刀旗'          # 刀旗：两边各一个看不见的进门框（左 / 右），点哪边就从哪边过
TAKEOFF = '起飞台'      # 自己摆的起飞台（没摆就自动放在计时门前面 9 米）
# 第一个门设成起始门时默认穿哪个洞
START_FACE = {'单门': '门', '日子门': '下', '三联': '2', '单重': '后', '双重': '下层后', FLAG: '右'}
HOWS[POLE] = [('左', '杆子在左手边绕'), ('右', '杆子在右手边绕'), ('左一圈', '左手边绕一整圈'), ('右一圈', '右手边绕一整圈')]


def pole_label(how):
    how = how or '左'
    side = '左手边' if how.startswith('左') else '右手边'
    return f"杆子在{side}" + ("，绕一整圈" if how.endswith('一圈') else "绕")


def pole_arc(c, how, prev, nxt, r=POLE_R, y=1.6):
    """绕杆：从 prev 飞过来，杆子在左手边/右手边，贴着杆子 r 米绕过去，朝 nxt 飞走（一圈 = 多绕 360 度）"""
    left = (how or '左').startswith('左')
    def unit(v):
        l = math.hypot(v[0], v[2]) or 1
        return [v[0]/l, 0.0, v[2]/l]
    u_in, u_out = unit(tc.sub(c, prev)), unit(tc.sub(nxt, c))
    sg = 1 if left else -1
    e0 = tc.sub(c, tc.mul(_left(u_in), sg*r))          # 进弯：杆子在左手边 -> 人在杆子右边
    e1 = tc.sub(c, tc.mul(_left(u_out), sg*r))
    a0 = math.atan2(e0[2]-c[2], e0[0]-c[0])
    a1 = math.atan2(e1[2]-c[2], e1[0]-c[0])
    rot = 1 if left else -1                             # 杆子在左手边就一直往左拐（角度变大）
    sweep = (a1-a0)*rot % (2*math.pi)
    if (how or '').endswith('一圈'):
        sweep += 2*math.pi
    n = max(2, int(sweep/math.radians(30)))
    arc = [[c[0]+r*math.cos(a0+rot*sweep*k/n), y, c[2]+r*math.sin(a0+rot*sweep*k/n)] for k in range(n+1)]
    return [[e0[0]-u_in[0]*1.5, y, e0[2]-u_in[2]*1.5]] + arc + [[e1[0]+u_out[0]*1.5, y, e1[2]+u_out[2]*1.5]]


def heading(yaw):
    a = math.radians(yaw)
    return [math.cos(a), 0.0, math.sin(a)]


FACE_NAMES = {'门': '', '下': '下洞', '上': '上洞', '1': '第 1 个洞', '2': '中间洞', '3': '第 3 个洞', '顶': '顶上'}


def face_name(lab):
    """门洞标签 -> 给人看的字：下洞、中间洞、前面……"""
    if lab in FACE_NAMES:
        return FACE_NAMES[lab]
    return lab + '面'


def gate_height(t, S, T):
    H = S+2*T
    return 2*H-T if t in ('日子门', '双重') else H


def faces(it, S=2.5, T=0.2):
    """一个门的门洞（面），世界坐标：[(标签, 中心, 法向, 宽方向, 高方向)]；法向 = 门朝的方向（yaw）为正"""
    if it['t'] not in GATE_TYPES and it['t'] != FLAG:
        return []
    f = heading(it.get('yaw', 0))
    lf = _left(f)
    A, B = (f, lf) if it['t'] == '三联' else (lf, f)
    lift = float(it.get('lift', 0) or 0)

    def V(v):
        return [v[0]*A[0]+v[2]*B[0], v[1], v[0]*A[2]+v[2]*B[2]]
    out = []
    for lab, c, n, w in tc.openings(it['t'], S, T):
        C = V(c)
        N, Wd = V(n), V(w)
        out.append((lab, [it['x']+C[0], C[1]+lift, it['z']+C[2]], N, Wd, tc.norm(tc.cross(N, Wd))))
    return out


def new_id(items):
    return max([it.get('id', 0) for it in items] + [0]) + 1


def legacy_route(items):
    """老格式（每个门自己记 how/wrap/pass）-> 新格式：items 带 id + route 门洞顺序 [{id, f, d}]"""
    items = [dict(it) for it in items]
    for it in items:
        if 'id' not in it:
            it['id'] = new_id(items)
    route = []
    for it in items:
        t, how, w, i = it['t'], it.get('how') or '', it.get('wrap') or '', it['id']
        ok = it.get('pass', True) or t == WP
        if t not in (WP, POLE):
            for k in ('how', 'wrap', 'pass'):
                it.pop(k, None)
        else:
            it.pop('pass', None)
        if not ok:
            continue
        if t in (WP, POLE):
            route.append({'id': i})
            continue

        def F(f, d=1):
            return {'id': i, 'f': f, 'd': d}
        if t == '单门':
            route += [F('门')] * (2 if w in ('右', '左', '上') else 1)
        elif t == '日子门':
            a = how or '下'
            b = '上' if a == '下' else '下'
            route += {'右': [F(a), F(b)], '左': [F(a), F(b)], '折': [F(a), F(b, -1)], '上': [F(a), F(a)]}.get(w, [F(a)])
        elif t == '三联':
            route += {'翻右': [F('1'), F('2'), F('3')], '翻左': [F('3'), F('2'), F('1')]}.get(w, [F(how or '2')])
        elif t == '单重':
            route += {'顶进': [F('顶', -1), F('前')], '顶出': [F('后'), F('顶')]}.get(how, [F('后'), F('前')])
        elif t == '双重':
            route += {'上层': [F('上层后'), F('上层前')], '下层': [F('下层后'), F('下层前')]}.get(how, [F('顶', -1), F('下层前')])
    return items, route


def _lead(r, s, ld):
    """进洞前（s=-1）/ 出洞后（s=1）的引导点；顶上的洞（竖着穿）：先飞到洞的正上方，再顺着门的朝向平着进出"""
    C, N = r['C'], r['N']
    if abs(N[1]) < 0.7:
        return [tc.add(C, tc.mul(N, s*ld))]
    f = heading(r['it'].get('yaw', 0))
    hi = tc.add(C, tc.mul(N, s*1.8))
    pts = [hi, tc.add(hi, tc.mul(f, s*4.5))]
    return pts if s > 0 else pts[::-1]


def _around(r, Q, s, S, T, ld):
    """r 是门洞；s=1：出洞以后要去的点 Q 在门的后面（进来那边）→ 从门的一头绕过去；
    s=-1：从 Q 过来要进洞，但 Q 在门的出口那边 → 先绕到门前面。返回绕的点（按飞的顺序）"""
    C, N = r['C'], r['N']
    Nh = [N[0], 0.0, N[2]]
    if math.hypot(Nh[0], Nh[2]) < 0.5:          # 顶上的洞：不管
        return []
    Nh = tc.norm(Nh)
    dq = s*tc.dot(tc.sub(Q, C), Nh)
    if dq > -0.3:                               # 在顺路的那边（或者旁边）：直接连
        return []
    it = r['it']
    if it['t'] == FLAG:                         # 刀旗：掉头要两边都点（先一边、再另一边反着过）
        return []
    f = heading(it.get('yaw', 0))
    lf = _left(f)
    lat = (3*S+4*T)/2 if it['t'] == '三联' else S/2+T
    E = tc.add(C, tc.mul(Nh, s*ld))
    X = tc.add(E, tc.mul(tc.sub(Q, E), ld/(ld-dq)))     # 直着连过去的话，在哪穿过这个门的平面
    if abs(tc.dot(tc.sub(X, [it['x'], C[1], it['z']]), lf)) > lat + 1.2:
        return []                               # 从门旁边过去，不会再穿这个门
    dep = {'三联': 1.6, '单重': S/2+T, '双重': S/2+T}.get(it['t'], 1.3)
    side = tc.norm([Nh[2], 0.0, -Nh[0]])        # 右手边
    if tc.dot(tc.sub(Q, C), side) < 0:
        side = tc.mul(side, -1)                 # Q 在左边就从左边绕
    G = [it['x'], C[1], it['z']]
    ext = max(tc.dot(tc.sub(tc.add(tc.add(G, tc.mul(lf, a*lat)), tc.mul(f, b*dep)), C), side)
              for a in (-1, 1) for b in (-1, 1)) + 2.0
    y = [0.0, 0.0, 0.0]
    pts = [tc.add(tc.add(C, tc.mul(Nh, s*(ld+1.5))), tc.mul(side, ext*0.6)), tc.add(tc.add(C, tc.mul(side, ext)), y),
           tc.add(tc.add(C, tc.mul(Nh, -s*2.0)), tc.mul(side, ext))]
    return pts if s > 0 else pts[::-1]


def _top(it, S, T):
    return float(it.get('lift', 0) or 0) + gate_height(it['t'], S, T)


def _half(it, S, T):
    """门横着的半宽（门框外沿）"""
    return (3*S+4*T)/2 if it['t'] == '三联' else S/2+T


def _loop(A, B, S, T, top):
    """同一个方向连着穿两个洞：洞上下叠着就从旁边绕，洞并排（或同一个洞）就从顶上翻过去。
    A['over']：这一段翻不翻，True = 从上面翻，False = 不翻（分开的门从中间空当切，贴着的从旁边绕），
    None = 自动（门之间空当够宽就切，贴着就翻）"""
    Ca, Cb, Na, Nb = A['C'], B['C'], A['N'], B['N']
    o = tc.sub(Cb, Ca)
    M = tc.mul(tc.add(Ca, Cb), 0.5)
    over = A.get('over')
    if abs(o[1]) > 0.5 and abs(o[1]) > math.hypot(o[0], o[2]) and over is not True:
        s = tc.norm([Na[2], 0.0, -Na[0]])                       # 右手边
        Ms = tc.add(M, tc.mul(s, S/2 + T + 1.6))
    else:
        oh = [o[0], 0.0, o[2]]
        dist = math.hypot(o[0], o[2])
        ga, gb = A['it'], B['it']
        if ga is gb:
            gap = 0.0
        else:
            u = tc.norm(oh) if dist > 1e-6 else [1.0, 0.0, 0.0]
            cab = tc.sub([gb['x'], 0.0, gb['z']], [ga['x'], 0.0, ga['z']])
            gap = abs(tc.dot(cab, u)) - _half(ga, S, T) - _half(gb, S, T)
        if over is None:
            over = gap < 1.2
        if over:
            Ms = [M[0], top + 1.6, M[2]]
        elif gap >= 0.8:                                        # 分开的门：从中间空当切过去
            u = tc.norm(oh)
            Pa = tc.add([ga['x'], 0.0, ga['z']], tc.mul(u, _half(ga, S, T)))
            Pb = tc.sub([gb['x'], 0.0, gb['z']], tc.mul(u, _half(gb, S, T)))
            G = tc.mul(tc.add(Pa, Pb), 0.5)
            Ms = [G[0], (Ca[1]+Cb[1])/2, G[2]]
        else:                                                   # 贴着的：从这个门外边（背着下一个门那头）绕回去
            u = tc.norm(oh) if dist > 1e-6 else tc.norm([Na[2], 0.0, -Na[0]])
            G = tc.sub([ga['x'], 0.0, ga['z']], tc.mul(u, _half(ga, S, T) + 1.6))
            Ms = [G[0], Ca[1], G[2]]
    return [tc.add(Ca, tc.mul(Na, 2.4)), tc.add(Ms, tc.mul(Na, 1.6)), tc.sub(Ms, tc.mul(Na, 1.6)),
            tc.sub(Cb, tc.mul(Nb, 2.4))]


def _flag_circle(A, B):
    """同一面刀旗同一边连着过两次：绕旗整整一圈"""
    G = [A['it']['x'], A['C'][1], A['it']['z']]
    u = tc.sub(A['C'], G)
    R = math.hypot(u[0], u[2]) or 1.8
    u = tc.norm([u[0], 0.0, u[2]])
    N = tc.norm([A['N'][0], 0.0, A['N'][2]])
    return [tc.add(G, tc.add(tc.mul(u, R*math.cos(math.radians(a))), tc.mul(N, R*math.sin(math.radians(a)))))
            for a in range(40, 330, 40)]


def _between(A, B, S, T, ld=2.5, around=True, around_in=True):
    """路线上一步 A 到下一步 B 中间怎么连（不含两头的门洞中心）"""
    if A.get('via'):                            # 手绘的这一段：照着画的走
        via = [list(q) for q in A['via']]
        ab = A.get('via_ab')
        if ab and len(via) > 1:                 # 画完以后挪过门：两头差多少，中间的点按远近跟着挪
            da, db = tc.sub(A['C'], ab[0]), tc.sub(B['C'], ab[1])
            via = [tc.add(q, tc.add(tc.mul(da, 1-k/(len(via)-1)), tc.mul(db, k/(len(via)-1))))
                   for k, q in enumerate(via)]
        return (_lead(A, 1, ld) if A['k'] == 'gate' else []) + via + \
            (_lead(B, -1, ld) if B['k'] == 'gate' else [])
    if A['k'] == 'gate' and B['k'] == 'gate' and A['it'] is not B['it'] and FLAG not in (A['it']['t'], B['it']['t']):
        o = tc.sub(B['C'], A['C'])
        if tc.dot(A['N'], B['N']) > 0.9 and abs(tc.dot(o, A['N'])) < 1.0 and math.hypot(o[0], o[2]) < 10:
            # 挨着的两个门（比如三联旁边贴个单门）同一个方向连着穿：从顶上翻过去，不从旁边兜
            return _loop(A, B, S, T, max(_top(A['it'], S, T), _top(B['it'], S, T)))
    if A['k'] != 'gate' or B['k'] != 'gate' or A['it'] is not B['it']:
        out = _lead(A, 1, ld) if A['k'] == 'gate' else []
        inn = _lead(B, -1, ld) if B['k'] == 'gate' else []
        Q = inn[0] if inn else B['C']
        if A['k'] == 'gate' and around:         # 下一个在身后：从门外侧绕过来，不原路穿回去
            out += _around(A, Q, 1, S, T, ld)
        P0 = out[-1] if out else A['C']
        if B['k'] == 'gate' and around and around_in:     # 从下一个门的背面过来：先绕到它前面再进
            inn = _around(B, P0, -1, S, T, ld) + inn
        return out + inn
    Ca, Cb, Na, Nb = A['C'], B['C'], A['N'], B['N']
    o = tc.sub(Cb, Ca)
    nn = tc.dot(Na, Nb)
    if tc.dot(o, Na) > 0.3 and tc.dot(o, Nb) > 0.3:
        # 往前飞就到下一个洞：方框直穿两面、顶上钻进前面出
        return [] if nn > 0.9 else [tc.add(Ca, tc.mul(Na, tc.dot(o, Na)))]
    M = tc.mul(tc.add(Ca, Cb), 0.5)
    if nn < -0.5:
        # 掉头：出来拐个弯，从旁边那个洞反着穿回去（日字门上下折返）
        return [tc.add(Ca, tc.mul(Na, 1.4)), tc.add(M, tc.mul(Na, 2.3)), tc.add(Cb, tc.mul(Na, 1.4))]
    if nn > 0.5:
        if A['it']['t'] == FLAG:
            return _flag_circle(A, B) if A['lab'] == B['lab'] else [tc.add(Ca, tc.mul(Na, 1.2)), tc.sub(Cb, tc.mul(Nb, 1.2))]
        return _loop(A, B, S, T, _top(A['it'], S, T))
    return [tc.add(Ca, tc.mul(Na, 1.2)), tc.sub(Cb, tc.mul(Nb, 1.2))]


def build_manual(items, route, S=2.5, T=0.2, closed=True):
    """见 _build_manual；自动从门外绕过去反而撞到别的门时，换回直接连，挑报警少的那个"""
    r = _build_manual(items, route, S, T, True, closed)
    if r[3]['warn']:
        r2 = _build_manual(items, route, S, T, False, closed)
        if len(r2[3]['warn']) < len(r[3]['warn']):
            return r2
    return r


def _build_manual(items, route, S, T, around, closed=True):
    """手工摆的门：items = [{id, t, x, z, yaw, lift, grp, h, how(绕杆)}]，route = 进门顺序 [{id, f 门洞, d ±1}]
    （路线点、绕杆只有 id）。系统按顺序自动连线：起飞台 → 每个门洞 → 回到第 1 个门洞（计时门）。
    返回 (model, types, path, info)，路线有问题写在 info['warn']"""
    byid = {it['id']: it for it in items}
    up = [0.0, 1.0, 0.0]
    parts, types, pid_of = [], {}, {}
    pid = 0
    for it in items:
        if it['t'] in (WP, TAKEOFF):
            continue
        pid += 1
        c = [it['x'], 0.0, it['z']]
        f = heading(it.get('yaw', 0))
        lf = _left(f)
        if it['t'] == POLE:
            parts.append(_part(pid, '杆子', c, lf, up, f))
            types[pid] = '杆子'
            continue
        parts.append(_part(pid, it['t'], c, f, up, lf) if it['t'] == '三联' else _part(pid, it['t'], c, lf, up, f))
        if it.get('lift'):
            parts[-1]['lift'] = float(it['lift'])
        types[pid] = it['t']
        pid_of[it['id']] = pid
    mid = T+S/2
    R = []
    for s in route:
        it = byid.get(s.get('id'))
        if it is None:
            continue
        if it['t'] == WP:
            R.append(dict(k='wp', it=it, C=[it['x'], it.get('h') or mid, it['z']]))
        elif it['t'] == POLE:
            R.append(dict(k='pole', it=it, C=[it['x'], 1.6, it['z']]))
        else:
            fc = {q[0]: q for q in faces(it, S, T)}.get(s.get('f'))
            if fc:
                d = -1 if (s.get('d') or 1) < 0 else 1
                R.append(dict(k='gate', it=it, C=fc[1], N=tc.mul(fc[2], d), lab=fc[0], d=d, pid=pid_of[it['id']]))
        if R and R[-1]['it'] is it and s.get('via'):
            R[-1]['via'] = s['via']
            R[-1]['via_ab'] = s.get('via_ab')
        if R and R[-1]['it'] is it and s.get('over') is not None:
            R[-1]['over'] = bool(s['over'])
    gates = [r for r in R if r['k'] == 'gate']
    if not gates:
        raise ValueError("先点一个门洞")
    if closed and len(gates) < 2:
        closed = False
    no = 0
    for r in R:
        if r['k'] == 'gate':
            no += 1
            r['no'] = no
    k0 = R.index(gates[0])
    R = R[k0:] + R[:k0]
    # 一段一段连起来：[门洞/路线点/绕杆本身, 到下一步中间的点]
    g0 = R[0]
    # 最后一步回计时门：直接穿过去结束这一圈，不绕到它后面（从背面过来就反着穿，计时一样算）
    A = R[-1]
    end = g0
    if A['it'] is not g0['it'] and abs(g0['N'][1]) < 0.7:     # 顶上的洞（下翻塔）照常从上面钻
        Pa = (_lead(A, 1, 2.5)[-1] if A['k'] == 'gate' else A['C'])
        if tc.dot(tc.sub(Pa, g0['C']), g0['N']) > 0:
            end = dict(g0, N=tc.mul(g0['N'], -1), d=-g0['d'])
    segs = []
    for k, r in enumerate(R):
        segs.append([r['C']] if r['k'] != 'pole' else None)
        if k < len(R)-1:
            segs.append(_between(r, R[k+1], S, T, around=around))
        elif closed:
            segs.append(_between(r, end, S, T, around=around, around_in=False))
        else:                                   # 还没收圈：最后一个门出来往前飞一点就停
            segs.append(_lead(r, 1, 2.5)[:1] if r['k'] == 'gate' else [])
    for k in range(0, len(segs), 2):            # 绕杆：看前后飞过来、飞过去的方向，贴着杆子绕
        if segs[k] is not None:
            continue
        r = R[k//2]
        prev = next((sg[-1] for sg in reversed(segs[:k]) if sg), None) or \
            next((sg[-1] for sg in reversed(segs[k+1:]) if sg), r['C'])
        nxt = next((sg[0] for sg in segs[k+1:] if sg), None) or next((sg[0] for sg in segs[:k] if sg), r['C'])
        segs[k] = pole_arc([r['it']['x'], 0.0, r['it']['z']], r['it'].get('how', '左'), prev, nxt)
    f0 = [g0['N'][0], 0.0, g0['N'][2]]
    if math.hypot(f0[0], f0[2]) < 0.3:
        f0 = heading(g0['it'].get('yaw', 0))
    f0 = tc.norm(f0)
    take = tc.sub([g0['C'][0], 0.0, g0['C'][2]], tc.mul(f0, 9.0))
    pad = next((it for it in items if it['t'] == TAKEOFF), None)
    if pad:                                     # 自己摆了起飞台：从那儿起飞，朝它摆的方向
        take, f0 = [pad['x'], 0.0, pad['z']], heading(pad.get('yaw', 0))
    parts.append(_part(0, '起飞台', take, _left(f0), up, f0))
    parts[-1]['name'] = '起飞台'
    types[0] = '起飞台'
    P = [[take[0], 1.4, take[2]], tc.add([take[0], mid, take[2]], tc.mul(f0, 3))] + _lead(g0, -1, 2.5)
    for sg in segs:
        P += sg
    if closed:
        P += [g0['C']] + _lead(end, 1, 2.5)[:1]              # 最后再过一次计时门
    path = _catmull(P, 0.3)
    for q in path:
        q[1] = max(0.4, q[1])
    model = dict(parts=parts, bodies={}, edges={}, pieces=[], preview=None)
    warn = []
    cr = tc.crossings(model, types, path)
    want = [(r['pid'], r['lab'], r['d']) for r in R if r['k'] == 'gate'] + ([(end['pid'], end['lab'], end['d'])] if closed else [])
    flag_pids = {pid_of[it['id']] for it in items if it['t'] == FLAG}
    # 刀旗的进门框是看不见的：没点进顺序的那边擦过去不算
    got = [tuple(c[1:4]) for c in cr if c[1] not in flag_pids or tuple(c[1:4]) in want]
    if want[0] in got:                          # 起飞到计时门之间擦过的不算
        got = got[got.index(want[0]):]
    if got != want:
        name = {(r['pid'], r['lab'], r['d']): r['no'] for r in R if r['k'] == 'gate'}
        miss = [w for w in dict.fromkeys(want) if w not in got]
        rev = [w for w in miss if (w[0], w[1], -w[2]) in got]
        extra = [g for g in dict.fromkeys(got) if g not in want and (g[0], g[1], -g[2]) not in want]
        if rev:
            warn.append("第 " + "、".join(str(name[w]) for w in rev) + " 个门洞穿反了：路线从另一面穿过去的，前后的门挪一挪")
        elif miss:
            warn.append("路线没穿过第 " + "、".join(str(name[w]) for w in miss) + " 个门洞：门转一下朝向路线，或者挪近一点")
        elif extra:
            warn.append("路线穿过了没点进顺序的门洞：挪开一点，或者用右上角「✏ 手绘路线」把这段画开")
        else:
            warn.append("路线穿门洞的顺序不对：检查门的朝向和顺序")
    if _hits_frame(model, types, path, S, T):
        warn.append("路线擦到门框了：门之间离远一点，或者用右上角「✏ 手绘路线」把这段画开")
    info = dict(focus='手工', n=len(gates), length=sum(math.dist(path[i], path[i+1]) for i in range(len(path)-1)),
                elems=[[it['t'], it.get('how', '')] for it in items], warn=warn, closed=closed)
    return model, types, path, info


def to_items(model, types):
    """电脑摆好的赛道 -> 手工布置的门（接着手工改）"""
    out = []
    for p in sorted(model['parts'], key=lambda q: q['id']):
        t = types.get(p['id'])
        if t not in GATE_TYPES:
            continue
        m = p['m']
        f = m[0:3] if t == '三联' else m[6:9]
        out.append(dict(t=t, how='', x=round(p['o'][0], 2), z=round(p['o'][2], 2),
                        yaw=round(math.degrees(math.atan2(f[2], f[0])), 1)))
    return out


def _hits_frame(model, types, path, S, T):
    """路线有没有穿过任何门的方管（按实际门洞尺寸，留 0.25 米余量）"""
    for p in model['parts']:
        t = types[p['id']]
        if t == '起飞台':                       # 本来就是从起飞台上飞起来的
            continue
        C, a, b = tc.frame_of(p, t)
        bx = tc.boxes(t, S, T, lifted=C[1] > 0.01)
        if not bx:
            continue
        near = [q for q in path if math.hypot(q[0]-C[0], q[2]-C[2]) < 6]
        for q in near:
            v = tc.sub(q, C)
            lx, ly, lz = tc.dot(v, a), q[1]-C[1], tc.dot(v, b)
            for (cx, cy, cz), (sx, sy, sz) in bx:
                if abs(lx-cx) < sx/2+0.25 and abs(ly-cy) < sy/2+0.25 and abs(lz-cz) < sz/2+0.25:
                    return True
    return False


# ------------------------------------------------------------------ 存取
SUFFIX = ".赛道.json"


def save(file, name, model, types, path, meta):
    import json
    from pathlib import Path
    d = dict(kind="drone-track", name=name, meta=meta, types={str(k): v for k, v in types.items()},
             parts=[{k: p[k] for k in ('id', 'name', 'm', 'o', 'lc', 'lift') if k in p} for p in model['parts']],
             path=[[round(v, 3) for v in q] for q in path])
    Path(file).write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")


def load(file):
    """读「赛道搭建」保存的赛道：返回 (model, types, path, data)"""
    import json
    from pathlib import Path
    d = json.loads(Path(file).read_text(encoding="utf-8"))
    if d.get("kind") != "drone-track":
        raise ValueError("不是「赛道搭建」保存的赛道文件")
    parts = [dict(p, bodies=[], ext=[0, 0, 0]) for p in d["parts"]]
    model = dict(parts=parts, bodies={}, edges={}, pieces=[], preview=None)
    return model, {int(k): v for k, v in d["types"].items()}, d["path"], d


if __name__ == '__main__':
    import sys
    for foc in FOCUS:
        try:
            m, ty, pa, inf = generate(10, focus=foc, seed=int(sys.argv[1]) if len(sys.argv) > 1 else 1)
            tr = tc.build(m, ty, path=pa, name='Random')
            print(foc, inf['attempt'], len(tr['gates']), round(inf['length']), inf['kinds'])
        except ValueError as e:
            print(foc, 'FAIL', e)
