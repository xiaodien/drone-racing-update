"""看图纸：自动适配不同主办方的赛道图纸，认出场地框、门框符号和指引线（只用 Qt，不用别的库）。

支持两类主流图纸风格（自动判断）：
1. 国赛深蓝粉线风格（navy_pink）：蓝色尺寸线、深蓝门框、粉色指引线。
2. FAI / 多色分层风格（color_multi）：规则 10m 灰网格、按门型分色（绿/蓝/紫/黑）、橙色一层 + 灰带蓝色二层路线。
"""
import colorsys
import math

from PySide6.QtCore import Qt
from PySide6.QtGui import QImage

WORK_W = 1600          # 认图时把图缩到这么宽
JUMP = 45              # 线断了（被门框挡住）最多往前接多少像素
LOOK = 10              # 岔口往每条路看多远比方向


LINE_PPM = 9.0         # 认线时每米几像素（线宽 2~3 像素，太细太粗都不好追）


def pink_pixels(img: QImage, px_per_m=None):
    """返回 (粉色像素集合, 缩放比例 原图像素/工作像素)"""
    ww = int(img.width() * LINE_PPM / px_per_m) if px_per_m else WORK_W
    work = img.scaledToWidth(ww) if img.width() > ww else img   # 不平滑：线的颜色不被冲淡
    work = work.convertToFormat(QImage.Format_RGB888)
    w, h, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())
    px = set()
    for y in range(h):
        row = data[y*bpl:y*bpl + w*3]
        for x in range(0, w*3, 3):
            r = row[x]
            if r > 150:
                g, b = row[x+1], row[x+2]
                if g < 100 and 60 < b < 210 and r - g > 90:
                    px.add((x // 3, y))
    return px, img.width() / w


N8 = ((0, -1), (1, -1), (1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0), (-1, -1))


def thin(px):
    """把粗线削成一个像素宽（Zhang-Suen）"""
    px = set(px)
    changed = True
    while changed:
        changed = False
        for step in (0, 1):
            kill = []
            for (x, y) in px:
                nb = [(x+dx, y+dy) in px for dx, dy in N8]
                b = sum(nb)
                if b < 2 or b > 6:
                    continue
                a = sum(1 for k in range(8) if not nb[k] and nb[(k+1) % 8])
                if a != 1:
                    continue
                P2, P4, P6, P8 = nb[0], nb[2], nb[4], nb[6]
                if step == 0 and (P2 and P4 and P6 or P4 and P6 and P8):
                    continue
                if step == 1 and (P2 and P4 and P8 or P2 and P6 and P8):
                    continue
                kill.append((x, y))
            if kill:
                changed = True
                px.difference_update(kill)
    return px


def _groups(px, link=3):
    left = set(px)
    out = []
    while left:
        seed = left.pop()
        grp, todo = [seed], [seed]
        while todo:
            cx, cy = todo.pop()
            for dx in range(-link, link+1):
                for dy in range(-link, link+1):
                    c = (cx+dx, cy+dy)
                    if c in left:
                        left.remove(c)
                        grp.append(c)
                        todo.append(c)
        out.append(grp)
    return sorted(out, key=len, reverse=True)


def _nbrs(sk, p):
    return [(p[0]+dx, p[1]+dy) for dx, dy in N8 if (p[0]+dx, p[1]+dy) in sk]


def _unit(dx, dy):
    n = math.hypot(dx, dy) or 1.0
    return dx/n, dy/n


def _ang(h, d):
    return abs(math.atan2(h[0]*d[1] - h[1]*d[0], h[0]*d[0] + h[1]*d[1]))


def _walk(sk, prev, cur, n, avoid=()):
    """从 prev->cur 顺着骨架往前走 n 步（岔口挑最直的），返回走到的点"""
    path = [prev, cur]
    for _ in range(n):
        h = _unit(path[-1][0]-path[max(0, len(path)-4)][0], path[-1][1]-path[max(0, len(path)-4)][1])
        c = [q for q in _nbrs(sk, path[-1]) if q not in path[-4:] and q not in avoid]
        if not c:
            break
        path.append(min(c, key=lambda q: _ang(h, (q[0]-path[-1][0], q[1]-path[-1][1]))))
    return path


def _loops_back(sk, cur, q, used):
    """从岔口 cur 往 q 那条路走下去（断了也接上），走一小圈又回到 cur 附近 = 图纸上的小圈"""
    w = trace(sk, [cur, q], used=set(used) | {cur}, limit=260, probe=True)
    return any(math.dist(z, cur) < 30 for z in w[60:])


def trace(sk, start, used=None, limit=200000, probe=False):
    """从线头顺着骨架追到底。start 可以是一个点，也可以是已经走的几个点"""
    path = list(start) if isinstance(start, list) else [start]
    used = set(path) if used is None else used | set(path)
    while len(path) < limit:
        cur = path[-1]
        back = path[max(0, len(path)-8)]
        h = _unit(cur[0]-back[0], cur[1]-back[1]) if len(path) > 1 else None
        cand = [q for q in _nbrs(sk, cur) if q not in path[-6:]]
        nxt = None
        if cand:
            if len(cand) == 1 or h is None:
                fresh = [q for q in cand if q not in used]
                nxt = (fresh or cand)[0]
            else:                                # 岔口：每条路往前看一段，挑最直、没走过的；没走过的小圈先绕
                best = None
                for q in cand:
                    w = _walk(sk, cur, q, LOOK, avoid=set(path[-6:]))
                    d = _unit(w[-1][0]-cur[0], w[-1][1]-cur[1])
                    old = sum(1 for z in w[1:] if z in used) / len(w)
                    score = _ang(h, d) + 1.5*old + (0.6 if len(w) < LOOK//2 else 0)   # 短叉（箭头）扣分
                    if not probe and old == 0 and len(w) >= LOOK//2 and _loops_back(sk, cur, q, used):
                        score -= 3
                    if best is None or score < best[0]:
                        best = (score, q)
                nxt = best[1]
            if nxt in used and h is not None and _ang(h, _unit(nxt[0]-cur[0], nxt[1]-cur[1])) > math.radians(100):
                nxt = None                       # 掉头了：不走
        if nxt is None:                          # 线断了：往前找最近、方向对得上的线
            if h is None:
                break
            best = None
            for q in sk:
                dx, dy = q[0]-cur[0], q[1]-cur[1]
                if abs(dx) > JUMP or abs(dy) > JUMP or q in used:
                    continue
                d = math.hypot(dx, dy)
                if d < 2 or d > JUMP:
                    continue
                a = _ang(h, (dx, dy))
                if a > math.radians(35) and not (d < 22 and a < math.radians(65)):
                    continue
                score = d * (1 + 2*a)
                if best is None or score < best[0]:
                    best = (score, q)
            if best is None:
                break
            nxt = best[1]
        path.append(nxt)
        used.add(nxt)
    return path


def detect_style(img: QImage) -> str:
    """自动识别图纸风格：'navy_pink'（深蓝门+粉线）或 'color_multi'（多色门+橙/蓝分层线）"""
    work = img.scaledToWidth(600) if img.width() > 600 else img
    work = work.convertToFormat(QImage.Format_RGB888)
    w, h, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())
    pink = navy = orange = green = purple = 0
    for y in range(h):
        row = data[y*bpl:y*bpl + w*3]
        for x in range(0, w*3, 3):
            r, g, b = row[x], row[x+1], row[x+2]
            if r > 150 and g < 100 and 60 < b < 210 and r - g > 90:
                pink += 1
            elif r < 120 and g < 120 and b < 160 and b - r >= 15 and b - g >= 10:
                navy += 1
            else:
                mx, mn = max(r, g, b), min(r, g, b)
                if mx - mn < 26 or (mx > 225 and mx - mn < 36):
                    continue
                if r > g > b and r > 130 and r - b > 35 and (g - b) * 2 >= (r - g):
                    orange += 1
                elif g > r + 12 and g > b + 12 and g < 210:
                    green += 1
                elif r > g + 22 and b > g + 18 and abs(r - b) < 70:
                    purple += 1
    if pink >= 60 and navy >= (green + purple):
        return "navy_pink"
    if (green + purple) >= 120 and (orange >= 100 or (green + purple) > navy * 0.6):
        return "color_multi"
    return "navy_pink"


def _multi_route_pixels(img: QImage, px_per_m=None):
    """提取多色分层图纸的路线像素：橙色（一层）+ 灰带上的深蓝（二层）"""
    ww = int(img.width() * LINE_PPM / px_per_m) if px_per_m else WORK_W
    work = img.scaledToWidth(ww) if img.width() > ww else img
    work = work.convertToFormat(QImage.Format_RGB888)
    w, h, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())
    px = set()
    blue_cand = []
    grey = set()
    for y in range(h):
        row = data[y*bpl:y*bpl + w*3]
        for x in range(w):
            r, g, b = row[3*x], row[3*x+1], row[3*x+2]
            mx, mn = max(r, g, b), min(r, g, b)
            diff = mx - mn
            if 130 <= r <= 198 and 130 <= g <= 198 and 130 <= b <= 198 and diff < 18:
                grey.add((x, y))
                continue
            if diff < 28:
                continue
            hh, ss, vv = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
            deg = hh * 360.0
            if 10.0 <= deg <= 45.0 and ss > 0.30 and vv > 0.32:
                px.add((x, y))
            elif 195.0 <= deg <= 255.0 and ss > 0.30 and vv < 0.85:
                blue_cand.append((x, y))
    # 落在灰带（二层）旁边的蓝色像素才算二层路线（避免把外面的蓝门当成路线）
    for x, y in blue_cand:
        if any((x + dx, y + dy) in grey for dx in (-2, 0, 2) for dy in (-2, 0, 2)):
            px.add((x, y))
    return px, img.width() / w


def read_line(img: QImage, start_hint=None, px_per_m=None):
    """认指引线（自动支持粉色线与橙/蓝分层线）。start_hint = 原图像素坐标，返回 [(x, y) 原图像素]"""
    style = detect_style(img)
    px, k = _multi_route_pixels(img, px_per_m) if style == "color_multi" else pink_pixels(img, px_per_m)
    if len(px) < 100:
        return []
    sk = thin(px)
    groups = _groups(sk)
    keep = set(groups[0])                        # 从最大那截开始，离得近（门框挡断的）一截截接上；指北针、图例离得远不要
    near = {(x//25, y//25) for x, y in keep}
    rest = [g for g in groups[1:] if len(g) >= 4]
    grown = True
    while grown:
        grown = False
        for g in list(rest):
            if any((x//25+dx, y//25+dy) in near for x, y in g for dx in (-1, 0, 1) for dy in (-1, 0, 1)):
                keep.update(g)
                near.update((x//25, y//25) for x, y in g)
                rest.remove(g)
                grown = True
    def is_end(p):
        nb = _nbrs(keep, p)
        return len(nb) == 1 or (len(nb) == 2 and max(abs(nb[0][0]-nb[1][0]), abs(nb[0][1]-nb[1][1])) == 1)
    def long_enough(p, n=30):                    # 虚线（去降落点那段）的小短截不算线头
        seen, todo = {p}, [p]
        while todo and len(seen) < n:
            for q in _nbrs(keep, todo.pop()):
                if q not in seen:
                    seen.add(q)
                    todo.append(q)
        return len(seen) >= n
    ends = [p for p in keep if is_end(p) and long_enough(p)] or list(keep)
    if start_hint is not None:
        sx, sy = start_hint[0]/k, start_hint[1]/k
        start = min(ends, key=lambda c: math.hypot(c[0]-sx, c[1]-sy))
    else:
        start = max(ends, key=lambda c: c[1])    # 没有提示就从最下面那个线头开始
    path = trace(keep, start)
    return [((x+0.5)*k, (y+0.5)*k) for x, y in path[::3]]


def _find_grid_field(work: QImage, k: float):
    """找图纸内部的规则正方形 10m 灰色网格框（适用于绿色/灰色/无蓝色尺寸线的各类主办方图纸）"""
    w, h, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())
    mx, my = max(4, int(w * 0.04)), max(4, int(h * 0.04))
    grey_r, grey_c = [0] * h, [0] * w
    for y in range(my, h - my):
        row = data[y*bpl:y*bpl + w*3]
        for x in range(mx, w - mx):
            r, g, b = row[3*x], row[3*x+1], row[3*x+2]
            if 150 < r < 236 and abs(r - g) < 16 and abs(g - b) < 16:
                grey_r[y] += 1
                grey_c[x] += 1

    def peaks(prof, min_v, sep=12):
        cand = [(prof[i], i) for i in range(1, len(prof) - 1)
                if prof[i] >= min_v and prof[i] >= prof[i - 1] and prof[i] >= prof[i + 1]]
        out = []
        for _v, i in sorted(cand, reverse=True):
            if all(abs(i - j) >= sep for j in out):
                out.append(i)
        return sorted(out)

    pr = peaks(grey_r, int(w * 0.22))
    pc = peaks(grey_c, int(h * 0.22))
    diffs = []
    for arr in (pr, pc):
        for i in range(len(arr)):
            for j in range(i + 1, min(len(arr), i + 3)):
                d = arr[j] - arr[i]
                if min(w, h) * 0.04 <= d <= min(w, h) * 0.22:
                    diffs.append(d)
    best = None
    for d in sorted(set(diffs)):
        tol = max(3, d * 0.08)

        def chain(arr):
            best_c = []
            for s in arr:
                c, cur = [s], s
                while True:
                    nxt = [p for p in arr if p > cur and abs((p - cur) - d) <= tol]
                    if nxt:
                        cur = min(nxt, key=lambda p: abs((p - cur) - d))
                        c.append(cur)
                        continue
                    nxt2 = [p for p in arr if p > cur and abs((p - cur) - 2 * d) <= tol * 1.5]
                    if nxt2:
                        cur = min(nxt2, key=lambda p: abs((p - cur) - 2 * d))
                        c.append(cur)
                        continue
                    nxt_h = [p for p in arr if p > cur and abs((p - cur) - 0.5 * d) <= tol]
                    if nxt_h and len(c) >= 4:
                        cur = min(nxt_h, key=lambda p: abs((p - cur) - 0.5 * d))
                        c.append(cur)
                    break
                if len(c) > len(best_c):
                    best_c = c
            return best_c

        rc, cc = chain(pr), chain(pc)
        if len(rc) >= 4 and len(cc) >= 4:
            # 校验列是否在 [rc[0]..rc[-1]] 行带内真的有顶/底灰线相连（去掉左侧图例虚线误并进来的列）
            y_top, y_bot = rc[0], rc[-1]

            def has_hseg(xa, xb):
                if xb <= xa + 2:
                    return False
                for yy in (y_top, y_bot):
                    hit = 0
                    for x in range(xa, xb + 1):
                        for dy in (-1, 0, 1):
                            y = yy + dy
                            if 0 <= y < h:
                                o = y * bpl + 3 * x
                                r, g, b = data[o], data[o + 1], data[o + 2]
                                if 140 < r < 240 and abs(r - g) < 18 and abs(g - b) < 18:
                                    hit += 1
                                    break
                    if hit / max(1, xb - xa + 1) < 0.35:
                        return False
                return True

            while len(cc) >= 4 and not has_hseg(cc[0], cc[1]):
                cc = cc[1:]
            while len(cc) >= 4 and not has_hseg(cc[-2], cc[-1]):
                cc = cc[:-1]
            if len(cc) < 4:
                continue
            score = (len(rc) + len(cc)) * 1000 + (cc[-1] - cc[0]) + (rc[-1] - rc[0])
            if best is None or score > best[0]:
                best = (score, cc[0], rc[0], cc[-1], rc[-1])
    if not best:
        return None
    _, x0, y0, x1, y1 = best
    if x1 - x0 < w * 0.2 or y1 - y0 < h * 0.2:
        return None
    return int(x0 * k), int(y0 * k), int((x1 + 1) * k), int((y1 + 1) * k)


def estimate_field_size(img: QImage, box):
    """按场地框内的 10 米正方形灰网格自动推算场地长×宽（米），推不出返回 None"""
    x0, y0, x1, y1 = box
    if x1 - x0 < 60 or y1 - y0 < 60:
        return None
    sub = img.copy(x0, y0, x1 - x0, y1 - y0)
    work = sub.scaledToWidth(1000) if sub.width() > 1000 else sub
    work = work.convertToFormat(QImage.Format_RGB888)
    w, h, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())
    gr, gc = [0] * h, [0] * w
    for y in range(h):
        row = data[y * bpl:y * bpl + w * 3]
        for x in range(w):
            r, g, b = row[3 * x], row[3 * x + 1], row[3 * x + 2]
            if 145 < r < 238 and abs(r - g) < 16 and abs(g - b) < 16:
                gr[y] += 1
                gc[x] += 1

    def line_peaks(prof, span):
        mx = max(prof) or 1
        pks = [i for i in range(2, len(prof) - 2)
               if prof[i] >= mx * 0.38 and prof[i] >= prof[i - 1] and prof[i] >= prof[i + 1]]
        out = []
        for p in pks:
            if not out or p - out[-1] > max(6, int(span * 0.025)):
                out.append(p)
            elif prof[p] > prof[out[-1]]:
                out[-1] = p
        return out

    pr, pc = line_peaks(gr, h), line_peaks(gc, w)
    # 枚举常见的 10m 网格步长（每格 10m，场地边长 30~150m，即宽/高为 3~15 格，支持半格如 10.5 格 = 105m）
    diffs = []
    for arr in (pr, pc):
        for i in range(len(arr)):
            for j in range(i + 1, min(len(arr), i + 3)):
                d = arr[j] - arr[i]
                if min(w, h) / 16.0 <= d <= min(w, h) / 2.8:
                    diffs.append(d)
    if not diffs:
        return None
    best = None
    for d in sorted(set(diffs)):
        tol = max(2.5, d * 0.06)
        # 用相近间距的平均步长，提高精度
        near = [v for v in diffs if abs(v - d) <= tol]
        if len(near) < 4:
            continue
        d_avg = sum(near) / len(near)
        cw, ch = w / d_avg, h / d_avg
        rw, rh = round(cw * 2) / 2.0, round(ch * 2) / 2.0
        if not (3.0 <= rw <= 15.0 and 3.0 <= rh <= 15.0):
            continue
        err = abs(cw - rw) + abs(ch - rh)
        if err > 0.22:
            continue
        # 优先选择支持线最多、且能整除/半格拟合最好、且格数落在标准 10m 网格的步长
        score = len(near) * 10.0 - err * 40.0 + (2.0 if abs(rw - round(rw)) < 1e-6 else 0.0) + (2.0 if abs(rh - round(rh)) < 1e-6 else 0.0)
        if best is None or score > best[0]:
            best = (score, int(round(rw * 10)), int(round(rh * 10)))
    return (best[1], best[2]) if best else None


def find_field(img: QImage):
    """找图纸上的场地框：
    1. 优先找蓝色尺寸箭头线并贴到灰色场地边线（国赛标准图纸）；
    2. 找不到蓝色尺寸线时，找内部规则正方形网格（FAI / 绿色尺寸线等各类图纸）；
    3. 都没有时退回最长的灰色外框线。
    返回原图像素 (左, 上, 右, 下)，找不到返回 None"""
    W0 = 2000
    work = img.scaledToWidth(W0) if img.width() > W0 else img
    k = img.width() / work.width()
    work = work.convertToFormat(QImage.Format_RGB888)
    w, h, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())
    blue_r, blue_c = [[] for _ in range(h)], [[] for _ in range(w)]
    grey_r, grey_c = [0]*h, [0]*w
    for y in range(h):
        row = data[y*bpl:y*bpl + w*3]
        for x in range(w):
            r, g, b = row[3*x], row[3*x+1], row[3*x+2]
            if b > 130 and r < 100 and 60 < g < 160 and b - r > 60:
                blue_r[y].append(x)
                blue_c[x].append(y)
            elif 150 < r < 232 and abs(r-g) < 14 and abs(g-b) < 14:
                grey_r[y] += 1
                grey_c[x] += 1

    def run(vals, gap=6):
        """一串坐标里最长的一段（中间断开不超过 gap）"""
        best, cur = (0, 0, 0), None
        for v in sorted(vals):
            if cur and v - cur[1] <= gap:
                cur = (cur[0], v)
            else:
                cur = (v, v)
            if cur[1] - cur[0] > best[2]:
                best = (cur[0], cur[1], cur[1]-cur[0])
        return best

    gx, gy = max(6, w//14), max(6, h//14)        # 线中间写着「85m」断开一截，也算一根
    hy = max(range(h), key=lambda y: run(blue_r[y], gx)[2])
    vx = max(range(w), key=lambda x: run(blue_c[x], gy)[2])
    x0, x1, lx = run(blue_r[hy], gx)
    y0, y1, ly = run(blue_c[vx], gy)
    if lx < w*0.25 or ly < h*0.25:               # 没有蓝色尺寸线：先找内部规则正方形网格
        grid = _find_grid_field(work, k)
        if grid:
            return grid
        top = max(grey_r)
        rows = [y for y in range(h) if grey_r[y] > top*0.45]
        topc = max(grey_c)
        cols = [x for x in range(w) if grey_c[x] > topc*0.45]
        if len(rows) < 2 or len(cols) < 2:
            return None
        x0, x1, y0, y1 = cols[0], cols[-1], rows[0], rows[-1]
    else:
        def snap(v, prof, lim):                  # 贴到附近最明显的灰色边线
            cand = [(prof[i], i) for i in range(max(0, v-6), min(lim, v+7))]
            best = max(cand)
            return best[1] if best[0] > max(prof)*0.3 else v
        x0, x1 = snap(x0, grey_c, w), snap(x1, grey_c, w)
        y0, y1 = snap(y0, grey_r, h), snap(y1, grey_r, h)
    if x1 - x0 < w*0.2 or y1 - y0 < h*0.2:
        return None
    return int(x0*k), int(y0*k), int((x1+1)*k), int((y1+1)*k)


def _mask(img: QImage, test):
    img = img.convertToFormat(QImage.Format_RGB888)
    w, h, bpl = img.width(), img.height(), img.bytesPerLine()
    data = bytes(img.constBits())
    px = set()
    for y in range(h):
        row = data[y*bpl:y*bpl + w*3]
        for x in range(w):
            if test(row[3*x], row[3*x+1], row[3*x+2]):
                px.add((x, y))
    return px


def _blobs(px):
    """8 邻接连成块"""
    left = set(px)
    out = []
    while left:
        s = left.pop()
        grp, todo = [s], [s]
        while todo:
            x, y = todo.pop()
            for dx, dy in N8:
                q = (x+dx, y+dy)
                if q in left:
                    left.remove(q)
                    grp.append(q)
                    todo.append(q)
        out.append(grp)
    return out


def is_navy(r, g, b):
    # 深蓝色门符号（组委会图纸多为 #202050 左右）：必须明显偏蓝，不能把场地黑框、深灰辅助线吸进来
    return r < 120 and g < 120 and b < 160 and b - r >= 15 and b - g >= 10


def _corners(x0, y0, x1, y1, pts):
    """外框四个角（各占 22%）里深蓝像素的占比：[左上, 右上, 左下, 右下]"""
    bw, bh = x1 - x0 + 1, y1 - y0 + 1
    cw, ch = max(2, int(bw * 0.22)), max(2, int(bh * 0.22))
    area = cw * ch
    tl = tr = bl = br = 0
    for x, y in pts:
        if x < x0 + cw:
            if y < y0 + ch:
                tl += 1
            elif y > y1 - ch:
                bl += 1
        elif x > x1 - cw:
            if y < y0 + ch:
                tr += 1
            elif y > y1 - ch:
                br += 1
    return (tl / area, tr / area, bl / area, br / area)


def glyphs(img: QImage, px_per_m, memory=()):
    """图纸上的门符号（自动适配深蓝单色图纸与多色分层图纸）：
    返回 [dict(kind, x, y 原图像素中心, w, h 米, fill, n 几块, lift=bool)]"""
    if detect_style(img) == "color_multi":
        return _glyphs_color(img, px_per_m, memory)
    return _glyphs_navy(img, px_per_m, memory)


def _merge_boxes(blobs, gap_px, ppm, max_m=16.0):
    boxes = []
    for b in blobs:
        xs = [p[0] for p in b]
        ys = [p[1] for p in b]
        x0, y0, x1, y1 = min(xs), min(ys), max(xs), max(ys)
        if max((x1 - x0 + 1) / ppm, (y1 - y0 + 1) / ppm) > max_m:
            continue
        boxes.append([x0, y0, x1, y1, len(b), 1, [len(b)], set(b)])
    merged = True
    while merged:
        merged = False
        for i in range(len(boxes)):
            for j in range(i + 1, len(boxes)):
                a, c = boxes[i], boxes[j]
                if a[0] - gap_px <= c[2] and c[0] - gap_px <= a[2] and a[1] - gap_px <= c[3] and c[1] - gap_px <= a[3]:
                    nx0, ny0, nx1, ny1 = min(a[0], c[0]), min(a[1], c[1]), max(a[2], c[2]), max(a[3], c[3])
                    if max((nx1 - nx0 + 1) / ppm, (ny1 - ny0 + 1) / ppm) > max_m:
                        continue
                    boxes[i] = [nx0, ny0, nx1, ny1, a[4] + c[4], a[5] + c[5], a[6] + c[6], a[7] | c[7]]
                    boxes.pop(j)
                    merged = True
                    break
            if merged:
                break
    return boxes


def _split_purple_slalom(x0, y0, x1, y1, pts, ppm):
    """把连在一起的紫红色蛇形门按真实门柱位置拆成一个个独立的门，并按各自高度分单门/日字门"""
    bw = x1 - x0 + 1
    col_cnt = [0] * bw
    col_y0 = [y1] * bw
    col_y1 = [y0] * bw
    for x, y in pts:
        ix = x - x0
        col_cnt[ix] += 1
        if y < col_y0[ix]:
            col_y0[ix] = y
        if y > col_y1[ix]:
            col_y1[ix] = y
    # 平滑列高与列像素数，找出竖直门框所在的列段（忽略门之间细斜线）
    rad = max(1, int(round(0.35 * ppm)))
    sm = [sum(col_cnt[max(0, i - rad):min(bw, i + rad + 1)]) / (min(bw, i + rad + 1) - max(0, i - rad)) for i in range(bw)]
    peak_v = max(sm) or 1.0
    thr = peak_v * 0.34
    active = [i for i in range(bw) if sm[i] >= thr]
    if not active:
        return []
    # 把间隔小于 1.5m 的活跃列并成一个门
    gap_m = max(2, int(round(1.5 * ppm)))
    segs = [[active[0], active[0]]]
    for i in active[1:]:
        if i - segs[-1][1] <= gap_m:
            segs[-1][1] = i
        else:
            segs.append([i, i])
    # 若某段仍超过 7.5m（两个门靠得很近），在中间最低谷切开
    final_segs = []
    max_one = 7.5 * ppm
    while segs:
        a, b = segs.pop(0)
        if b - a + 1 > max_one:
            margin = max(2, int(round(2.0 * ppm)))
            if b - a > 2 * margin:
                cut = min(range(a + margin, b - margin + 1), key=lambda i: sm[i])
                segs.insert(0, [cut + 1, b])
                segs.insert(0, [a, cut - 1])
                continue
        if (b - a + 1) / ppm >= 1.0:
            final_segs.append((a, b))
    if not final_segs:
        return []
    infos = []
    for a, b in final_segs:
        s_pts = [(x, y) for x, y in pts if x0 + a <= x <= x0 + b]
        if not s_pts:
            continue
        sy0 = min(y for _x, y in s_pts)
        sy1 = max(y for _x, y in s_pts)
        sw = (b - a + 1) / ppm
        sh = (sy1 - sy0 + 1) / ppm
        infos.append((x0 + (a + b + 1) / 2.0, (sy0 + sy1 + 1) / 2.0, sw, sh, len(s_pts) / max(1, (b - a + 1) * (sy1 - sy0 + 1))))
    if not infos:
        return []
    min_h = min(it[3] for it in infos)
    out = []
    for cx, cy, sw, sh, fill in infos:
        # 蛇形门中间两座是上下两层的日字门（明显比两侧单门高，通常 >= 5.2m）
        kind = '日字门' if (sh >= 5.2 or (len(infos) >= 3 and sh >= min_h * 1.28 and sh >= 4.6)) else '单门'
        out.append((kind, cx, cy, sw, sh, fill, None))
    # 检查相邻两个门之间是否有宽阔缺口（>= 6.5m）且内部有紫红像素：补齐中间 2 个 V 字对角放的单门
    extras = []
    ordered = sorted(zip(final_segs, infos), key=lambda z: z[0][0])
    for idx in range(len(ordered) - 1):
        (_, b0), _inf0 = ordered[idx]
        (a1, _), _inf1 = ordered[idx + 1]
        gap_m = (a1 - b0) / ppm
        if gap_m >= 6.5:
            mid_pts = [(x, y) for x, y in pts if x0 + b0 < x < x0 + a1]
            if len(mid_pts) >= max(12, int(10 * ppm)):
                my0 = min(y for _x, y in mid_pts)
                my1 = max(y for _x, y in mid_pts)
                mh = (my1 - my0 + 1) / ppm
                if mh >= 1.8:
                    cy_mid = (my0 + my1 + 1) / 2.0
                    cx1 = x0 + b0 + (a1 - b0) * 0.32
                    cx2 = x0 + b0 + (a1 - b0) * 0.68
                    extras.append(('单门', cx1, cy_mid, 3.0, mh, 0.35, -30.0))
                    extras.append(('单门', cx2, cy_mid, 3.0, mh, 0.35, 30.0))
    return out + extras


def _split_hex_chain(x0, y0, x1, y1, pts, ppm):
    """把紧挨在一起的一串蓝色六边形门拆成一个个独立六边门（按封闭内洞或步距切分）"""
    # 1. 先对蓝色像素做 1px 膨胀，把被橙色线切断的小缺口补齐，再找每个六边形内部的白洞
    bw, bh = x1 - x0 + 5, y1 - y0 + 5
    grid = [[0] * bw for _ in range(bh)]
    for x, y in pts:
        gx, gy = x - x0 + 2, y - y0 + 2
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                grid[gy + dy][gx + dx] = 1
    stack = [(0, 0)]
    grid[0][0] = 2
    while stack:
        cx, cy = stack.pop()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = cx + dx, cy + dy
            if 0 <= nx < bw and 0 <= ny < bh and grid[ny][nx] == 0:
                grid[ny][nx] = 2
                stack.append((nx, ny))
    min_hole = max(6, int(1.6 * ppm * ppm))
    max_hole = max(40, int(14.0 * ppm * ppm))
    holes = []
    for y in range(bh):
        for x in range(bw):
            if grid[y][x] == 0:
                st = [(x, y)]
                grid[y][x] = 3
                xs, ys = [], []
                while st:
                    cx, cy = st.pop()
                    xs.append(cx)
                    ys.append(cy)
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = cx + dx, cy + dy
                        if 0 <= nx < bw and 0 <= ny < bh and grid[ny][nx] == 0:
                            grid[ny][nx] = 3
                            st.append((nx, ny))
                if min_hole <= len(xs) <= max_hole:
                    hw = (max(xs) - min(xs) + 1) / ppm
                    hh = (max(ys) - min(ys) + 1) / ppm
                    if 1.0 <= min(hw, hh) and max(hw, hh) <= 4.5:
                        holes.append((x0 - 2 + sum(xs) / len(xs), y0 - 2 + sum(ys) / len(ys), hw + 0.6, hh + 0.6))
    if len(holes) >= 2:
        return holes
    # 2. 如果有洞被橙线切开没封闭，沿长轴按每个六边形 ~3.0m 切分并取每段质心
    w, h = (x1 - x0 + 1) / ppm, (y1 - y0 + 1) / ppm
    vertical = h >= w
    span = h if vertical else w
    cnt = max(2, min(8, int(round(span / 3.0))))
    out = []
    for k_i in range(cnt):
        if vertical:
            a = y0 + (y1 - y0 + 1) * k_i / cnt
            b = y0 + (y1 - y0 + 1) * (k_i + 1) / cnt
            sub = [(x, y) for x, y in pts if a <= y <= b]
        else:
            a = x0 + (x1 - x0 + 1) * k_i / cnt
            b = x0 + (x1 - x0 + 1) * (k_i + 1) / cnt
            sub = [(x, y) for x, y in pts if a <= x <= b]
        if sub:
            cx = sum(x for x, _y in sub) / len(sub)
            cy = sum(y for _x, y in sub) / len(sub)
            out.append((cx, cy, 3.0, 3.0))
    return out


def _glyphs_color(img: QImage, px_per_m, memory=()):
    """多色分层图纸（如 FAI 锦标赛）：按绿/蓝/紫/黑分通道提取门框，按灰带判断二层叠高"""
    if px_per_m > 20.0:
        work = img.scaledToWidth(max(50, int(img.width() * 20.0 / px_per_m)), Qt.SmoothTransformation)
        ppm = 20.0
    else:
        work = img
        ppm = float(px_per_m)
    k = img.width() / work.width()
    work = work.convertToFormat(QImage.Format_RGB888)
    ww, wh, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())

    chans = {c: set() for c in ("green", "blue", "purple", "black", "greyband")}
    for y in range(wh):
        row = data[y*bpl:y*bpl + ww*3]
        for x in range(ww):
            r, g, b = row[3*x], row[3*x+1], row[3*x+2]
            mx, mn = max(r, g, b), min(r, g, b)
            diff = mx - mn
            if 130 <= r <= 198 and 130 <= g <= 198 and 130 <= b <= 198 and diff < 18:
                chans["greyband"].add((x, y))
            if mx < 110 and diff < 28:
                chans["black"].add((x, y))
                continue
            if diff < 24 or (mx > 225 and diff < 35):
                continue
            hh, ss, vv = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
            deg = hh * 360.0
            if 65.0 <= deg <= 165.0 and ss > 0.20 and vv < 0.82:
                chans["green"].add((x, y))
            elif 195.0 <= deg <= 255.0 and ss > 0.28 and vv < 0.85:
                chans["blue"].add((x, y))
            elif 270.0 <= deg <= 335.0 and ss > 0.24 and vv < 0.88:
                chans["purple"].add((x, y))

    min_px = max(8, int(20 * (ppm / 20.0) ** 2))
    gap_px = max(2, int(round(0.45 * ppm)))
    pad = max(2, int(round(0.5 * ppm)))

    def grey_ratio(x0, y0, x1, y1):
        xa, xb = max(0, x0 - pad), min(ww, x1 + pad + 1)
        ya, yb = max(0, y0 - pad), min(wh, y1 + pad + 1)
        area = max(1, (xb - xa) * (yb - ya))
        cnt = sum(1 for x in range(xa, xb) for y in range(ya, yb) if (x, y) in chans["greyband"])
        return cnt / area

    raw = []  # (priority, dict)

    # 1. 绿色：方形单门 / F形门（三连门） / 刀旗 / 双层高架交汇处的上下双单门
    for x0, y0, x1, y1, n, parts, _sz, pts in _merge_boxes([b for b in _blobs(chans["green"]) if len(b) >= min_px], gap_px, ppm):
        w, h = (x1 - x0 + 1) / ppm, (y1 - y0 + 1) / ppm
        fill = n / ((x1 - x0 + 1) * (y1 - y0 + 1))
        if max(w, h) < 1.8:
            continue
        gr = grey_ratio(x0, y0, x1, y1)
        if w <= 1.3 and h >= 1.8 and h / max(w, 0.1) >= 1.8:
            kind = '刀旗'
        elif max(w, h) >= 5.5 and w >= 5.0 and h >= 5.0 and gr >= 0.10:
            # 灰带二层高架交汇处的大绿块：不是三连门，而是高架上 1 个二层单门 + 高架底下 1 个一层地面单门
            cx_hi, cy_hi = (x0 + (x1 - x0) * 0.35) * k, (y0 + (y1 - y0) * 0.35) * k
            cx_lo, cy_lo = (x0 + (x1 - x0) * 0.65) * k, (y0 + (y1 - y0) * 0.65) * k
            # 判断哪半边压在灰带上（二层）
            g_tl = grey_ratio(x0, y0, (x0 + x1) // 2, (y0 + y1) // 2)
            g_br = grey_ratio((x0 + x1) // 2, (y0 + y1) // 2, x1, y1)
            tl_elev = g_tl >= g_br
            raw.append((3, dict(kind='单门', x=cx_hi, y=cy_hi, w=3.2, h=3.2, fill=round(fill, 2), n=1, lift=tl_elev)))
            raw.append((3, dict(kind='单门', x=cx_lo, y=cy_lo, w=3.2, h=3.2, fill=round(fill, 2), n=1, lift=not tl_elev)))
            continue
        elif max(w, h) >= 5.5 and w >= 5.0:
            kind = '三连门' if w >= 6.5 else '双连门'
        elif max(w, h) >= 2.2 and min(w, h) >= 1.0:
            kind = '单门'
        else:
            continue
        lift = kind not in ('刀旗',) and gr >= 0.14
        raw.append((2, dict(kind=kind, x=(x0 + x1 + 1) / 2 * k, y=(y0 + y1 + 1) / 2 * k,
                            w=round(w, 2), h=round(h, 2), fill=round(fill, 2), n=parts, lift=lift)))

    # 2. 紫色：双联门 2×2 / 蛇形门（合并整排蛇形门后按真实门柱切分并按高度分单门/日字门）
    p_gap = max(3, int(round(0.8 * ppm)))
    for x0, y0, x1, y1, n, parts, _sz, pts in _merge_boxes([b for b in _blobs(chans["purple"]) if len(b) >= min_px], p_gap, ppm, max_m=38.0):
        w, h = (x1 - x0 + 1) / ppm, (y1 - y0 + 1) / ppm
        fill = n / ((x1 - x0 + 1) * (y1 - y0 + 1))
        if max(w, h) < 2.2 or min(w, h) < 1.2:
            continue
        if w >= 8.5:
            for kind, cx, cy, sw, sh, sfill, yaw_deg in _split_purple_slalom(x0, y0, x1, y1, pts, ppm):
                d_it = dict(kind=kind, x=cx * k, y=cy * k, w=round(sw, 2), h=round(sh, 2),
                            fill=round(sfill, 2), n=1, lift=False)
                if yaw_deg is not None:
                    d_it['yaw'] = yaw_deg
                raw.append((3, d_it))
            continue
        kind = '双连门' if w >= 4.2 else ('日字门' if h >= 4.7 else '单门')
        lift = grey_ratio(x0, y0, x1, y1) >= 0.14
        raw.append((3, dict(kind=kind, x=(x0 + x1 + 1) / 2 * k, y=(y0 + y1 + 1) / 2 * k,
                            w=round(w, 2), h=round(h, 2), fill=round(fill, 2), n=parts, lift=lift)))

    # 3. 蓝色：六边形单门（按个拆分！） / 双联门 1×1（日字门） / 田字门（过滤 P 降落区与二层蓝箭头）
    for x0, y0, x1, y1, n, parts, _sz, pts in _merge_boxes([b for b in _blobs(chans["blue"]) if len(b) >= min_px], gap_px, ppm):
        w, h = (x1 - x0 + 1) / ppm, (y1 - y0 + 1) / ppm
        fill = n / ((x1 - x0 + 1) * (y1 - y0 + 1))
        lo, hi = min(w, h), max(w, h)
        R = hi / max(lo, 0.1)
        cr = _corners(x0, y0, x1, y1, pts)
        if R < 1.25 and fill >= 0.52 and max(cr) < 0.30:   # 圆形 P 降落区
            continue
        gr = grey_ratio(x0, y0, x1, y1)
        if gr >= 0.08 and lo < 2.6:                        # 二层灰带里的蓝色路线段/箭头
            continue
        if hi < 2.5 or lo < 1.6:
            continue
        # 紧挨着排成一串的蓝色六边形门（空心、填充率较低且跨度大）：拆成一个个独立六边门
        if hi >= 5.2 and lo >= 2.8 and fill < 0.34:
            for cx, cy, hw, hh in _split_hex_chain(x0, y0, x1, y1, pts, ppm):
                raw.append((3, dict(kind='六边门', x=cx * k, y=cy * k, w=round(hw, 2), h=round(hh, 2),
                                    fill=round(fill, 2), n=1, lift=False)))
            continue
        if (lo >= 4.0 and R < 1.35) or (h >= 7.5 and fill >= 0.38):
            kind = '田字门'
        elif h > w * 1.6 and h >= 5.0:
            kind = '日字门'
        elif w > h * 1.5 and w >= 4.0:
            kind = '双连门'
        elif lo >= 2.4 and R < 1.5:
            kind = '六边门'
        else:
            continue
        raw.append((2, dict(kind=kind, x=(x0 + x1 + 1) / 2 * k, y=(y0 + y1 + 1) / 2 * k,
                            w=round(w, 2), h=round(h, 2), fill=round(fill, 2), n=parts, lift=gr >= 0.14)))

    # 4. 深黑色：计时门 / 起飞台（最多保留 1 个最明显的棋盘格长条） / 土形魔方门（双重）
    takeoffs = []
    for x0, y0, x1, y1, n, parts, _sz, pts in _merge_boxes([b for b in _blobs(chans["black"]) if len(b) >= min_px], gap_px, ppm):
        w, h = (x1 - x0 + 1) / ppm, (y1 - y0 + 1) / ppm
        fill = n / ((x1 - x0 + 1) * (y1 - y0 + 1))
        if max(w, h) < 2.4 or min(w, h) < 0.8:
            continue
        cy_rel = (y0 + y1) / 2 / max(1, wh)
        if h > w * 1.8 and w >= 1.1 and (parts >= 2 or h >= 4.5) and (cy_rel > 0.78 or cy_rel < 0.22):
            takeoffs.append((parts * 10 + h, dict(kind='起飞台', x=(x0 + x1 + 1) / 2 * k, y=(y0 + y1 + 1) / 2 * k,
                                                  w=round(w, 2), h=round(h, 2), fill=round(fill, 2), n=parts, lift=False)))
            continue
        if max(w, h) >= 4.5 and min(w, h) >= 2.8:
            kind = '双重'
        elif fill >= 0.35 and min(w, h) >= 1.2:
            kind = '计时门'
        else:
            continue
        raw.append((4, dict(kind=kind, x=(x0 + x1 + 1) / 2 * k, y=(y0 + y1 + 1) / 2 * k,
                            w=round(w, 2), h=round(h, 2), fill=round(fill, 2), n=parts, lift=False)))
    if takeoffs:
        raw.append((5, max(takeoffs, key=lambda t: t[0])[1]))

    # 跨颜色通道去重（如多色组合门重合位置，保留高优先级那一个）
    out = []
    min_dist = 2.0 * px_per_m
    for _prio, g in sorted(raw, key=lambda t: (-t[0], -(t[1]['w'] * t[1]['h']))):
        if any(math.hypot(g['x'] - o['x'], g['y'] - o['y']) < min_dist for o in out):
            continue
        for m in memory:
            if abs(m['w'] - g['w']) < 0.5 and abs(m['h'] - g['h']) < 0.5 and abs(m['fill'] - g['fill']) < 0.06:
                g['kind'] = m['kind']
                break
        out.append(g)
    return out


def read_bridges(img: QImage, px_per_m):
    """提取多色分层图纸上的二层灰带高架桥中心线：返回 [{'pts': [(x, y) 原图像素], 'w': 桥宽(米)}]"""
    if detect_style(img) != "color_multi" or px_per_m <= 0:
        return []
    bppm = 3.0
    work = img.scaledToWidth(max(40, int(img.width() * bppm / px_per_m)), Qt.FastTransformation).convertToFormat(QImage.Format_RGB888)
    k = img.width() / work.width()
    w, h, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())
    raw = [[0] * w for _ in range(h)]
    for y in range(h):
        row = data[y * bpl:y * bpl + w * 3]
        for x in range(w):
            r, g, b = row[3 * x], row[3 * x + 1], row[3 * x + 2]
            if 120 <= r <= 204 and 120 <= g <= 204 and 120 <= b <= 204 and max(r, g, b) - min(r, g, b) < 20:
                raw[y][x] = 1

    def morph(grid, dilate=True, rad=1):
        out = [[0] * w for _ in range(h)]
        for y in range(h):
            for x in range(w):
                if dilate:
                    v = 0
                    for dy in range(-rad, rad + 1):
                        ny = y + dy
                        if 0 <= ny < h:
                            row = grid[ny]
                            for dx in range(-rad, rad + 1):
                                nx = x + dx
                                if 0 <= nx < w and row[nx]:
                                    v = 1
                                    break
                            if v:
                                break
                else:
                    v = 1
                    for dy in range(-rad, rad + 1):
                        ny = y + dy
                        if 0 <= ny < h:
                            row = grid[ny]
                            for dx in range(-rad, rad + 1):
                                nx = x + dx
                                if 0 <= nx < w and not row[nx]:
                                    v = 0
                                    break
                            if not v:
                                break
                out[y][x] = v
        return out

    # 1. 闭运算 1px 修补灰带里细蓝线；2. 开运算 2px 清掉细灰网格线；3. 闭运算 6px 接通被绿门框隔断的桥段
    g1 = morph(morph(raw, True, 1), False, 1)
    g2 = morph(morph(g1, False, 2), True, 2)
    g3 = morph(morph(g2, True, 6), False, 6)
    pts = {(x, y) for y in range(h) for x in range(w) if g3[y][x]}
    blobs = [b for b in _blobs(pts) if len(b) >= int(16 * bppm * bppm)]
    chains = []
    for b in blobs:
        sk = thin(set(b))
        if len(sk) < 4:
            continue
        ends = [p for p in sk if len(_nbrs(sk, p)) == 1] or list(sk)
        start = min(ends, key=lambda p: (p[0], p[1]))
        traced = trace(sk, start)
        samp = [traced[0]]
        for q in traced[1:]:
            if math.dist(samp[-1], q) >= 5.5:
                samp.append(q)
        if math.dist(samp[-1], traced[-1]) > 2.0:
            samp.append(traced[-1])
        if len(samp) >= 2:
            chains.append(samp)
    # 端点相距 <= 7.5 米的相邻桥段接成一条连续高架桥
    join_d = 7.5 * bppm
    merged = True
    while merged:
        merged = False
        for i in range(len(chains)):
            for j in range(i + 1, len(chains)):
                a, b = chains[i], chains[j]
                pairs = [
                    (math.dist(a[-1], b[0]), a + b),
                    (math.dist(a[-1], b[-1]), a + b[::-1]),
                    (math.dist(a[0], b[-1]), b + a),
                    (math.dist(a[0], b[0]), a[::-1] + b),
                ]
                best_d, comb = min(pairs, key=lambda t: t[0])
                if best_d <= join_d:
                    chains[i] = comb
                    chains.pop(j)
                    merged = True
                    break
            if merged:
                break
    out = []
    for ch in chains:
        ln = sum(math.dist(ch[i], ch[i + 1]) for i in range(len(ch) - 1)) / bppm
        if ln < 4.5:
            continue
        out.append(dict(pts=[((p[0] + 0.5) * k, (p[1] + 0.5) * k) for p in ch], w=3.8))
    return out


def _glyphs_navy(img: QImage, px_per_m, memory=()):
    """国赛深蓝图纸上的门符号：[dict(kind, x, y 原图像素中心, w, h 米, fill, n 几块)]
    kind：单门 / 日字门 / 田字门 / 双连门 / 三连门 / 单重 / 双重 / 双层单门 / 计时门 / 起飞台 / ?"""
    ppm = 20.0
    k = px_per_m / ppm                           # 原图像素 / 工作像素
    work = img.scaledToWidth(max(50, int(img.width() / k)), Qt.SmoothTransformation)
    k = img.width() / work.width()
    navy = _mask(work, is_navy)
    blobs = [b for b in _blobs(navy) if len(b) >= 25]
    # 粉色线压断的几块并回一个：外框挨着（6 像素内）的算一个符号；超大块（如顶部标题栏/底色）直接跳过
    boxes = _merge_boxes(blobs, 6, ppm, max_m=16.0)
    out = []
    small = []
    for x0, y0, x1, y1, n, parts, sizes, pts in boxes:
        w, h = (x1-x0+1)/ppm, (y1-y0+1)/ppm
        fill = n / ((x1-x0+1)*(y1-y0+1))
        if max(w, h) < 1.2 or min(w, h) < 0.6:  # 太小、细线（尺寸标注的短竖线）不是门
            continue
        if max(w, h) < 2.5:                      # 小符号（起飞台前面的 ^ 箭头）先记下
            small.append(((x0+x1+1)/2, y1, (x1-x0+1)/2))
            continue
        lo, hi = min(w, h), max(w, h)
        R = hi / lo
        cr = _corners(x0, y0, x1, y1, pts)
        # 圆形「P 降落点」图标：实心圆填充高但四角几乎为空，不是门框
        if R < 1.25 and fill >= 0.55 and max(cr) < 0.30:
            continue
        if parts >= 4 and sum(1 for s in sizes if s < 150) >= 2:
            kind = '起飞台'
        elif R < 1.25 and lo > 5.0 and min(cr) < 0.15 and max(cr) < 0.25:
            kind = '起飞台'                        # 斜着画的起飞箭头带（对角为空，区别于四角满的田字门）
        elif fill >= 0.58 and h > w*1.5 and w >= 2.0:
            kind = '双层单门'
        elif fill >= 0.43 and R < 1.3 and lo > 3.6:
            kind = '单重'
        elif fill >= 0.45 and h > w*1.5 and lo > 3.6:
            kind = '双重'
        elif w > h and 1.25 <= R < 1.6 and fill >= 0.4:
            kind = '计时门'
        elif R < 1.25 and lo > 5.2:
            kind = '田字门'
        elif w <= 2.4 and h < 6.4 and R >= 1.9:
            kind = '单门'                         # 又瘦又高的平行四边形：斜着放的单门
        elif w <= 2.4 and h >= 6.4:
            kind = '日字门'                        # 斜着放的两层日字门
        elif R < 1.45:
            kind = '单门'
        elif h > w:
            kind = '日字门'
        elif R < 2.4:
            kind = '双连门'
        else:
            kind = '三连门'
        for m in memory:                         # 学过的：这种符号操作者改成过别的，照改过的来
            if abs(m['w']-w) < 0.5 and abs(m['h']-h) < 0.5 and abs(m['fill']-fill) < 0.06:
                kind = m['kind']
                break
        out.append(dict(kind=kind, x=(x0+x1+1)/2*k, y=(y0+y1+1)/2*k, w=round(w, 2), h=round(h, 2),
                        fill=round(fill, 2), n=parts))
    if len(small) >= 2 and not any(g['kind'] == '起飞台' for g in out):   # 一串 ^ 箭头 = 起飞方向，起飞台在最下面那个后面
        best = []
        for a in small:                          # 竖着排成一串的小符号（左右差不到 1 米、上下挨着）
            col = sorted([q for q in small if abs(q[0]-a[0]) < ppm], key=lambda q: q[1])
            if len(col) > len(best) and all(col[i+1][1]-col[i][1] < 3*ppm for i in range(len(col)-1)):
                best = col
        if len(best) >= 2:
            xs = [q[0] for q in best]
            out.append(dict(kind='起飞台', x=sum(xs)/len(xs)*k, y=(best[-1][1] + 1.5*ppm)*k, w=2.0, h=2.0, fill=0, n=len(best)))
    return out
