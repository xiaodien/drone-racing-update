import re
import shutil
import subprocess

from app.config import APP_DIR, IS_WINDOWS

TEST_DEVICE = "测试画面（没有采集卡时用）"
NO_WINDOW = subprocess.CREATE_NO_WINDOW if IS_WINDOWS else 0

# Encoders in order of preference. All use no B-frames and fixed GOP so the
# 2-second ring-buffer segments can be joined without re-encoding.
# FPV footage is noisy, so quality-based modes balloon to ~47 Mbit/s; cap at ~15 Mbit/s instead.
RATE = ["-b:v", "15M", "-maxrate", "20M", "-bufsize", "30M"]
ENCODERS = [
    ("h264_nvenc", "NVIDIA 显卡", ["-preset", "p4", "-rc", "vbr", *RATE, "-forced-idr", "1"]),
    ("h264_qsv", "Intel 核显", ["-preset", "faster", *RATE]),
    ("h264_amf", "AMD 显卡", ["-quality", "speed", "-rc", "vbr_peak", *RATE]),
    ("libx264", "CPU 软件编码", ["-preset", "veryfast", "-crf", "21", "-maxrate", "15M", "-bufsize", "30M"]),
]


def ffmpeg_path() -> str | None:
    local = APP_DIR / "tools" / ("ffmpeg.exe" if IS_WINDOWS else "ffmpeg")
    if local.exists():
        return str(local)
    return shutil.which("ffmpeg")


def _run(args, timeout=20) -> str:
    exe = ffmpeg_path()
    if not exe:
        return ""
    try:
        p = subprocess.run([exe, "-hide_banner", *args], capture_output=True, timeout=timeout,
                           creationflags=NO_WINDOW)
    except (OSError, subprocess.TimeoutExpired):
        return ""
    return (p.stderr + p.stdout).decode("utf-8", errors="replace")


def list_video_devices() -> list[str]:
    names = []
    if IS_WINDOWS:
        out = _run(["-list_devices", "true", "-f", "dshow", "-i", "dummy"])
        section = None
        for line in out.splitlines():
            if "DirectShow video devices" in line:
                section = "video"
            elif "DirectShow audio devices" in line:
                section = "audio"
            if "Alternative name" in line:
                continue
            m = re.search(r'"([^"]+)"(\s+\((video|audio|none)[^)]*\))?', line)
            if not m:
                continue
            kind = m.group(3) or section
            if kind == "video":
                # 几个一模一样的采集卡名字相同，第 2 个起叫「名字 #2」「名字 #3」
                k = sum(1 for n in names if _split(n)[0] == m.group(1))
                names.append(m.group(1) + (f" #{k + 1}" if k else ""))
    names.append(TEST_DEVICE)
    return names


def _split(device: str) -> tuple[str, int]:
    """「名字 #3」→（名字, 2）：同名采集卡里的第几个（从 0 数）"""
    m = re.fullmatch(r"(.+) #(\d+)", device)
    return (m.group(1), int(m.group(2)) - 1) if m else (device, 0)


def _video_input(device: str) -> list[str]:
    name, k = _split(device)
    return (["-video_device_number", str(k)] if k else []) + ["-i", f"video={name}"]


def list_device_modes(device: str) -> list[dict]:
    """Return capture modes as dicts: fmt_kind ('vcodec'|'pixel_format'), fmt, w, h, fps."""
    if device == TEST_DEVICE or not IS_WINDOWS:
        return [{"kind": "test", "fmt": "test", "w": 1280, "h": 720, "fps": 60}, DEFAULT_MODE] if not IS_WINDOWS \
            else [{"kind": "test", "fmt": "test", "w": 1280, "h": 720, "fps": 60}]
    out = _run(["-f", "dshow", "-list_options", "true", *_video_input(device)])
    modes, seen = [], set()
    pat = re.compile(r"(vcodec|pixel_format)=(\S+)\s+min s=(\d+)x(\d+) fps=([\d.]+)\s+max s=(\d+)x(\d+) fps=([\d.]+)")
    for m in pat.finditer(out):
        kind, fmt = m.group(1), m.group(2)
        w, h, fps = int(m.group(6)), int(m.group(7)), float(m.group(8))
        key = (kind, fmt, w, h, round(fps))
        if key in seen:
            continue
        seen.add(key)
        modes.append({"kind": kind, "fmt": fmt, "w": w, "h": h, "fps": round(fps)})
    modes.sort(key=lambda d: (d["fps"] >= 59, d["w"] * d["h"], d["fps"], d["kind"] == "pixel_format"), reverse=True)
    # "Device default" opens the card without forcing a format, exactly like OBS does.
    # Put it first when the card reports no 60 fps mode we can rely on.
    if modes and modes[0]["fps"] >= 59:
        return modes + [DEFAULT_MODE]
    return [DEFAULT_MODE] + modes


DEFAULT_MODE = {"kind": "default", "fmt": "", "w": 0, "h": 0, "fps": 60}


def mode_key(mode: dict) -> str:
    return f'{mode["kind"]}|{mode["fmt"]}|{mode["w"]}x{mode["h"]}|{mode["fps"]}'


def mode_label(mode: dict) -> str:
    if mode["kind"] == "test":
        return "1280x720 60帧（测试）"
    if mode["kind"] == "default":
        return "设备默认（和 OBS 一样）"
    fmt = "MJPEG" if mode["fmt"] == "mjpeg" else mode["fmt"]
    return f'{mode["w"]}x{mode["h"]} {mode["fps"]}帧 {fmt}'


def detect_encoder() -> str:
    for name, _label, opts in ENCODERS:
        try:
            p = subprocess.run([ffmpeg_path(), "-hide_banner", "-loglevel", "error",
                                "-f", "lavfi", "-i", "testsrc2=size=1280x720:rate=60", "-t", "0.5",
                                "-vf", "format=nv12", "-c:v", name, *opts, "-f", "null", "-"],
                               capture_output=True, timeout=30, creationflags=NO_WINDOW)
        except (OSError, TypeError, subprocess.TimeoutExpired):
            continue
        if p.returncode == 0:
            return name
    return "libx264"


def encoder_label(name: str) -> str:
    for n, label, _ in ENCODERS:
        if n == name:
            return label
    return name


def encoder_opts(name: str) -> list[str]:
    for n, _label, opts in ENCODERS:
        if n == name:
            return opts
    return ENCODERS[-1][2]


def diagnose(device: str, mode: dict | None) -> str:
    """Collect everything needed to debug a capture card that won't open."""
    import platform
    parts = [f"系统：{platform.platform()}", f"FFmpeg：{ffmpeg_path()}"]
    parts.append(_run(["-version"]).splitlines()[0] if ffmpeg_path() else "没有 FFmpeg")
    parts.append("\n==== 设备列表 ====\n" + _run(["-list_devices", "true", "-f", "dshow", "-i", "dummy"]))
    if device and device != TEST_DEVICE:
        parts.append(f"\n==== {device} 支持的格式 ====\n"
                     + _run(["-f", "dshow", "-list_options", "true", *_video_input(device)]))
        tries = [DEFAULT_MODE] + ([mode] if mode and mode["kind"] not in ("default", "test") else [])
        for m in tries:
            parts.append(f"\n==== 试采集 3 秒：{mode_label(m)} ====\n"
                         + _run([*dshow_input_args(device, m), "-t", "3", "-f", "null", "-"], timeout=30))
    for name, label, opts in ENCODERS[:-1]:
        parts.append(f"\n==== 编码器 {label} ====\n"
                     + (_run(["-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=size=1280x720:rate=60",
                              "-t", "0.5", "-vf", "format=nv12", "-c:v", name, *opts, "-f", "null", "-"])
                        or "可用"))
    return "\n".join(parts)


def dshow_input_args(device: str, mode: dict) -> list[str]:
    args = ["-f", "dshow", "-rtbufsize", "1024M"]
    if mode["kind"] in ("vcodec", "pixel_format"):
        args += ["-video_size", f"{mode['w']}x{mode['h']}", "-framerate", str(mode["fps"])]
        args += ["-vcodec", mode["fmt"]] if mode["kind"] == "vcodec" else ["-pixel_format", mode["fmt"]]
    return args + _video_input(device)
