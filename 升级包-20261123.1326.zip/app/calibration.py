"""First-connection stick calibration wizard, simulator style."""
from PySide6.QtCore import QRectF, QTimer
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import (QComboBox, QDialog, QHBoxLayout, QLabel, QProgressBar, QPushButton,
                               QVBoxLayout, QWidget)

from app.overlay import draw_overlay
from app.sticks import CH_LABEL, Calibration, StickSource

STEPS = [
    ("device", "第 1 步：连接遥控器",
     "用 USB 线连接遥控器和电脑，遥控器上弹出选项时选「USB 摇杆 (Joystick)」，不要选「U盘 (Storage)」。\n"
     "下拉框里选中你的遥控器后，动一动摇杆，下面的条会跟着动。"),
    ("range", "第 2 步：摇杆行程",
     "把两个摇杆都沿着最外圈慢慢转 3 圈，每个方向都推到底。"),
    ("thr", "第 3 步：油门", "左摇杆：把油门推到最上面，保持住。"),
    ("yaw", "第 4 步：偏航", "左摇杆：往右推到底，保持住。"),
    ("pitch", "第 5 步：俯仰", "右摇杆：往上推到底，保持住。"),
    ("roll", "第 6 步：横滚", "右摇杆：往右推到底，保持住。"),
    ("arm", "第 7 步：解锁开关", "先确认 SE 在上锁位置，然后把 SE 拨到解锁位置。"),
    ("done", "完成", "动一动摇杆，确认画面里的方向和你手上一致，然后点「保存」。"),
]


class StickPreview(QWidget):
    def __init__(self):
        super().__init__()
        self.values = None
        self.trail = []
        self.setMinimumHeight(220)

    def paintEvent(self, _):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(30, 30, 30))
        draw_overlay(p, QRectF(self.rect()), self.values, self.trail)


class CalibrationWizard(QDialog):
    def __init__(self, source: StickSource, parent=None):
        super().__init__(parent)
        self.setWindowTitle("遥控器校准")
        self.resize(640, 520)
        self.source = source
        self.step = 0
        self.mins: dict[int, float] = {}
        self.maxs: dict[int, float] = {}
        self.result = {"axes": {}}
        self.snapshot = None
        self.detected = None

        self.title = QLabel()
        self.title.setStyleSheet("font-size: 18px; font-weight: bold;")
        self.text = QLabel()
        self.text.setWordWrap(True)
        self.text.setStyleSheet("font-size: 14px;")
        self.device_box = QComboBox()
        self.device_box.currentTextChanged.connect(self._device_chosen)
        self.status = QLabel()
        self.status.setStyleSheet("font-size: 14px; color: #0a7;")
        self.bars_widget = QWidget()
        self.bars_layout = QVBoxLayout(self.bars_widget)
        self.bars_layout.setContentsMargins(0, 0, 0, 0)
        self.bars: list[QProgressBar] = []
        self.preview = StickPreview()

        self.back_btn = QPushButton("上一步")
        self.next_btn = QPushButton("下一步")
        self.back_btn.clicked.connect(lambda: self._goto(self.step - 1))
        self.next_btn.clicked.connect(self._next)

        lay = QVBoxLayout(self)
        lay.addWidget(self.title)
        lay.addWidget(self.text)
        lay.addWidget(self.device_box)
        lay.addWidget(self.bars_widget)
        lay.addWidget(self.preview, 1)
        lay.addWidget(self.status)
        lay.addStretch()
        btns = QHBoxLayout()
        btns.addStretch()
        btns.addWidget(self.back_btn)
        btns.addWidget(self.next_btn)
        lay.addLayout(btns)

        self.timer = QTimer(self, interval=33, timeout=self._tick)
        self.timer.start()
        self._goto(0)

    # ---- steps -----------------------------------------------------------
    def _key(self):
        return STEPS[self.step][0]

    def _goto(self, i):
        self.step = max(0, min(i, len(STEPS) - 1))
        key, title, text = STEPS[self.step]
        self.title.setText(title)
        self.text.setText(text)
        self.device_box.setVisible(key == "device")
        self.bars_widget.setVisible(key in ("device", "range"))
        self.preview.setVisible(key == "done")
        self.back_btn.setEnabled(self.step > 0)
        self.next_btn.setText("保存" if key == "done" else "下一步")
        self.status.setText("")
        self.detected = None
        latest = self.source.latest()
        self.snapshot = latest[1:] if latest else None
        if key == "range":
            self.mins, self.maxs = {}, {}
        if key in CH_LABEL:
            self.result["axes"].pop(key, None)
        if key == "arm":
            self.result.pop("arm", None)
        if key == "device":
            self._refresh_devices()

    def _next(self):
        key = self._key()
        if key == "done":
            self.result["device"] = self.source.connected_name
            self.accept()
            return
        if key in CH_LABEL:
            self.result["axes"][key] = self.detected
        elif key == "arm":
            self.result["arm"] = self.detected
        self._goto(self.step + 1)

    def calibration(self) -> dict:
        return self.result

    # ---- live update -------------------------------------------------------
    def _refresh_devices(self):
        names = self.source.device_names or []
        self.device_box.blockSignals(True)
        self.device_box.clear()
        self.device_box.addItems(names)
        if self.source.connected_name in names:
            self.device_box.setCurrentText(self.source.connected_name)
        self.device_box.blockSignals(False)

    def _device_chosen(self, name):
        if name:
            self.source.select(name)

    def _tick(self):
        key = self._key()
        latest = self.source.latest()
        if key == "device" and self.device_box.count() != len(self.source.device_names):
            self._refresh_devices()
        if not latest or not self.source.connected_name:
            self.status.setText("还没读到遥控器，请检查 USB 线和遥控器上的模式。")
            self.next_btn.setEnabled(False)
            return
        _t, axes, buttons = latest
        if self.snapshot is None:
            self.snapshot = (axes, buttons)
        self._update_bars(axes)

        if key == "device":
            self.status.setText(f"已连接：{self.source.connected_name}（{len(axes)} 个通道）")
            self.next_btn.setEnabled(len(axes) >= 4)
        elif key == "range":
            for i, v in enumerate(axes):
                self.mins[i] = min(self.mins.get(i, v), v)
                self.maxs[i] = max(self.maxs.get(i, v), v)
            moved = sum(1 for i in self.mins if self.maxs[i] - self.mins[i] > 1.0)
            self.status.setText(f"已检测到 {moved}/4 个摇杆方向走满行程")
            self.next_btn.setEnabled(moved >= 4)
        elif key in CH_LABEL:
            self._detect_axis(key, axes)
        elif key == "arm":
            self._detect_arm(axes, buttons)
        elif key == "done":
            cal = Calibration(self.result)
            self.preview.trail = (self.preview.trail + [self.preview.values])[-15:] if self.preview.values else []
            self.preview.values = cal.apply(latest)
            self.preview.update()
            self.next_btn.setEnabled(True)

    def _update_bars(self, axes):
        while len(self.bars) < len(axes):
            bar = QProgressBar(minimum=-1000, maximum=1000)
            bar.setFormat(f"通道 {len(self.bars) + 1}")
            self.bars.append(bar)
            self.bars_layout.addWidget(bar)
        for bar, v in zip(self.bars, axes):
            bar.setValue(int(v * 1000))

    def _detect_axis(self, key, axes):
        used = {a["axis"] for a in self.result["axes"].values()}
        base = self.snapshot[0]
        best, best_move = None, 0.0
        for i, v in enumerate(axes):
            if i in used or i not in self.mins or i >= len(base):
                continue
            rng = self.maxs[i] - self.mins[i]
            if rng < 1.0:
                continue
            move = abs(v - base[i]) / rng
            if move > best_move:
                best, best_move = i, move
        if best is not None and best_move > 0.35:
            center = (self.mins[best] + self.maxs[best]) / 2
            invert = axes[best] < center
            self.detected = {"axis": best, "min": self.mins[best], "max": self.maxs[best], "invert": invert}
            self.status.setText(f"检测到：{CH_LABEL[key]} = 通道 {best + 1}{'（反向）' if invert else ''}")
            self.next_btn.setEnabled(True)
        else:
            self.status.setText("等待动作…")
            self.next_btn.setEnabled(self.detected is not None)

    def _detect_arm(self, axes, buttons):
        used = {a["axis"] for a in self.result["axes"].values()}
        base_axes, base_btn = self.snapshot
        best, best_move = None, 0.4
        for i, v in enumerate(axes):
            if i in used or i >= len(base_axes):
                continue
            if abs(v - base_axes[i]) > best_move:
                best, best_move = i, abs(v - base_axes[i])
        if best is not None:
            self.detected = {"type": "axis", "index": best, "armed_value": axes[best],
                             "disarmed_value": base_axes[best]}
            self.status.setText(f"检测到：解锁开关 = 通道 {best + 1}")
        elif buttons != base_btn:
            changed = buttons ^ base_btn
            idx = (changed & -changed).bit_length() - 1
            self.detected = {"type": "button", "index": idx, "armed_pressed": bool(buttons >> idx & 1)}
            self.status.setText(f"检测到：解锁开关 = 按键 {idx + 1}")
        else:
            self.status.setText("等待拨动 SE…")
        self.next_btn.setEnabled(self.detected is not None)
