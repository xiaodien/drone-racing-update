"""Left panel: students → dates → recordings, straight from the folders on disk."""
import json
from pathlib import Path

from PySide6.QtCore import QFile, QUrl, Qt, Signal
from PySide6.QtGui import QDesktopServices, QFont
from PySide6.QtWidgets import (QFileDialog, QHBoxLayout, QInputDialog, QLabel, QMenu, QMessageBox, QPushButton, QTreeWidget,
                               QTreeWidgetItem, QVBoxLayout, QWidget)

ROLE_PATH = Qt.UserRole
ROLE_KIND = Qt.UserRole + 1


def _fmt_s(s: float) -> str:
    s = int(round(s))
    return f"{s // 60}分{s % 60:02d}秒" if s >= 60 else f"{s}秒"


# 录像文件夹里这些是软件自己用的文件夹，不是学员
NOT_STUDENTS = {"比赛成绩", "选手资料", "赛道搭建", "赛道视频"}


def _is_student_dir(d: Path) -> bool:
    """学员文件夹：里面有日期文件夹，日期文件夹里有录像"""
    try:
        return any(c.is_dir() and any(c.glob("*.mp4")) for c in d.iterdir())
    except OSError:
        return False


class LibraryPanel(QWidget):
    student_changed = Signal(object)    # Path
    recording_opened = Signal(object)   # Path to mp4
    releasing = Signal(object)          # Path of a student folder about to be renamed or deleted
    choose_folder = Signal(str)         # 换录像文件夹：参数是新的录像文件夹


    def __init__(self, root: Path, current_student: str):
        super().__init__()
        self.root = root
        self.current: Path | None = None
        self.is_recording = lambda: False   # set by the main window
        self.current_label = QLabel()
        f = QFont()
        f.setPixelSize(15)
        f.setBold(True)
        self.current_label.setFont(f)
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.itemClicked.connect(self._clicked)
        self.tree.itemDoubleClicked.connect(self._double_clicked)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._context_menu)
        add_btn = QPushButton("添加学员")
        add_btn.clicked.connect(self._add_student)
        open_btn = QPushButton("导入学员…")
        open_btn.setToolTip("找到学员名字的文件夹（比如「陈博言」），选中后导入，他的录像就都显示出来")
        open_btn.clicked.connect(self._import_student)
        btns = QHBoxLayout()
        btns.addWidget(add_btn)
        btns.addWidget(open_btn)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.current_label)
        lay.addWidget(self.tree, 1)
        lay.addLayout(btns)
        tip = QLabel("点学员 = 展开他的录像，录像也存给他\n双击录像或右键 → 回看，右键学员可以打开文件夹")
        tip.setStyleSheet("color: gray;")
        lay.addWidget(tip)

        self.set_root(root, current_student)

    def set_root(self, root: Path, current_student: str = ""):
        self.root = root
        root.mkdir(parents=True, exist_ok=True)
        if not self.students():
            (root / "陈博言").mkdir(parents=True, exist_ok=True)
        names = [p.name for p in self.students()]
        self.set_student(root / (current_student if current_student in names else names[0]))
        self.refresh()

    def students(self) -> list[Path]:
        return sorted(p for p in self.root.iterdir()
                      if p.is_dir() and not p.name.startswith(".") and p.name not in NOT_STUDENTS)

    def set_student(self, path: Path):
        self.current = path
        self.current_label.setText(f"当前学员：{path.name}")
        self.student_changed.emit(path)

    def refresh(self):
        expanded = {it.data(0, ROLE_PATH) for it in self._all_items() if it.isExpanded()}
        self.tree.clear()
        for s in self.students():
            s_item = QTreeWidgetItem([s.name])
            s_item.setData(0, ROLE_PATH, str(s))
            s_item.setData(0, ROLE_KIND, "student")
            f = s_item.font(0)
            f.setBold(True)
            s_item.setFont(0, f)
            self.tree.addTopLevelItem(s_item)
            days = sorted((d for d in s.iterdir() if d.is_dir()), reverse=True)
            for d in days:
                vids = sorted(d.glob("*.mp4"), reverse=True)
                d_item = QTreeWidgetItem([f"{d.name}（{len(vids)} 次）"])
                d_item.setData(0, ROLE_PATH, str(d))
                d_item.setData(0, ROLE_KIND, "day")
                s_item.addChild(d_item)
                for v in vids:
                    v_item = QTreeWidgetItem([self._video_label(v)])
                    v_item.setData(0, ROLE_PATH, str(v))
                    v_item.setData(0, ROLE_KIND, "video")
                    d_item.addChild(v_item)
            if s == self.current:
                s_item.setExpanded(True)
                if days:
                    s_item.child(0).setExpanded(True)
        for it in self._all_items():
            if it.data(0, ROLE_PATH) in expanded:
                it.setExpanded(True)

    def _video_label(self, v: Path) -> str:
        label = v.stem.replace("-", ":")
        try:
            meta = json.loads(v.with_suffix(".json").read_text(encoding="utf-8"))
            if meta.get("channel"):
                label += f"   {meta['channel']}"
            label += f"   飞行 {_fmt_s(meta.get('flight_s', meta.get('duration_s', 0)))}"
        except (OSError, ValueError):
            pass
        return label

    def _all_items(self):
        stack = [self.tree.topLevelItem(i) for i in range(self.tree.topLevelItemCount())]
        while stack:
            it = stack.pop()
            yield it
            stack.extend(it.child(i) for i in range(it.childCount()))

    def _student_of(self, item) -> Path:
        while item.parent():
            item = item.parent()
        return Path(item.data(0, ROLE_PATH))

    def _clicked(self, item, _col):
        student = self._student_of(item)
        if student != self.current:
            self.set_student(student)
        if item.data(0, ROLE_KIND) in ("student", "day"):      # 点一下就展开 / 收起，不用找小箭头
            item.setExpanded(not item.isExpanded())

    def _import_student(self):
        """选学员名字的文件夹：它所在的录像文件夹整个换过来，并选中这个学员。
        选的如果是录像文件夹本身（里面是一个个学员），就直接换成它。"""
        d = QFileDialog.getExistingDirectory(self, "找到学员名字的文件夹（比如「陈博言」），选中后点「选择文件夹」",
                                             str(self.root))
        if not d:
            return
        d = Path(d)
        if _is_student_dir(d):
            root, name = d.parent, d.name
        elif any(_is_student_dir(c) for c in d.iterdir() if c.is_dir()):
            root, name = d, ""
        else:
            QMessageBox.warning(self, "导入学员", f"这个文件夹里没有找到录像：\n{d}\n\n"
                                "请选学员名字的文件夹，里面应该是一个个日期文件夹（比如 2026-10-18）。")
            return
        if root != self.root:
            self.choose_folder.emit(str(root))
        names = [p.name for p in self.students()]
        if name in names:
            self.set_student(self.root / name)
            self.refresh()

    def _context_menu(self, pos):
        item = self.tree.itemAt(pos)
        if not item:
            return
        path = Path(item.data(0, ROLE_PATH))
        menu = QMenu(self)
        if item.data(0, ROLE_KIND) == "video":
            menu.addAction("▶ 回看", lambda: self.recording_opened.emit(path))
            menu.addAction("打开所在文件夹", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(path.parent))))
        else:
            if item.data(0, ROLE_KIND) == "student":
                menu.addAction("录像存给这个学员", lambda: self.set_student(path))
            menu.addAction("打开文件夹", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(path))))
            if item.data(0, ROLE_KIND) == "student":
                menu.addSeparator()
                menu.addAction("添加学员", self._add_student)
                menu.addAction("重新命名", lambda: self._rename_student(path))
                menu.addAction("删除", lambda: self._delete_student(path))
        menu.exec(self.tree.viewport().mapToGlobal(pos))

    def _double_clicked(self, item, _col):
        if item.data(0, ROLE_KIND) == "video":
            self.recording_opened.emit(Path(item.data(0, ROLE_PATH)))

    def _ask_name(self, title: str, text: str = "") -> str:
        name, ok = QInputDialog.getText(self, title, "学员名字：", text=text)
        name = name.strip()
        if not ok or not name:
            return ""
        if any(c in name for c in '\\/:*?"<>|') or name.startswith("."):
            QMessageBox.warning(self, title, "名字里不能有 \\ / : * ? \" < > | 这些符号。")
            return ""
        return name

    def _busy(self, path: Path, title: str) -> bool:
        if path == self.current and self.is_recording():
            QMessageBox.warning(self, title, "正在给这个学员录像，录完再改。")
            return True
        return False

    def _rename_student(self, path: Path):
        if self._busy(path, "重新命名"):
            return
        name = self._ask_name("重新命名", path.name)
        if not name or name == path.name:
            return
        new = self.root / name
        if new.exists() and new.name.lower() != path.name.lower():
            QMessageBox.warning(self, "重新命名", f"已经有叫「{name}」的学员了。")
            return
        self.releasing.emit(path)
        try:
            path.rename(new)
        except OSError as e:
            QMessageBox.warning(self, "重新命名", f"改不了名字，可能有文件正被打开：\n{e}")
            return
        # Recordings remember whose they are; keep the replay title in step with the new name.
        for meta_path in new.glob("*/*.json"):
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
                if meta.get("student") == path.name:
                    meta["student"] = name
                    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
            except (OSError, ValueError):
                pass
        if path == self.current:
            self.set_student(new)
        self.refresh()

    def _delete_student(self, path: Path):
        if self._busy(path, "删除学员"):
            return
        others = [p for p in self.students() if p != path]
        if not others:
            QMessageBox.warning(self, "删除学员", "至少要留一个学员。先添加一个新学员再删。")
            return
        n = sum(1 for _ in path.glob("*/*.mp4"))
        msg = f"删除学员「{path.name}」？"
        msg += f"\n\n这个学员的 {n} 个录像也会一起删掉（会放进回收站，还能找回来）。" if n else ""
        if QMessageBox.question(self, "删除学员", msg) != QMessageBox.Yes:
            return
        self.releasing.emit(path)
        if not QFile.moveToTrash(str(path)):
            QMessageBox.warning(self, "删除学员", "删不掉，可能有文件正被打开。关掉回看或文件夹窗口再试。")
            return
        if path == self.current:
            self.set_student(others[0])
        self.refresh()

    def _add_student(self):
        name = self._ask_name("添加学员")
        if not name:
            return
        path = self.root / name
        path.mkdir(parents=True, exist_ok=True)
        self.set_student(path)
        self.refresh()
