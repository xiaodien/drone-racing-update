"""Replay a saved flight with the stick overlay, slow motion, frame stepping and A-B loop."""
import csv
import json
from bisect import bisect_left
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QPainter
from PySide6.QtMultimedia import QMediaPlayer, QVideoSink
from PySide6.QtWidgets import (QComboBox, QStyle, QHBoxLayout, QLabel, QMessageBox, QProgressDialog, QPushButton, QSlider,
                               QSpinBox, QVBoxLayout, QWidget)

from app.canvas import VideoCanvas
from app.export import Exporter
from app.overlay import CURVE_COLORS, TRAIL_S, draw_curves, shadow_text
from app.sticks import CH_LABEL, CHANNELS

CH_COLORS = CURVE_COLORS


def _fmt(ms: int) -> str:
    s = ms / 1000
    return f"{int(s // 60):02d}:{s % 60:05.2f}"


class StickLog:
    def __init__(self, path: Path):
        self.t = [0.0]
        self.ch = {c: [0.0] for c in CHANNELS}
        self.armed = [0.0]
        try:
            with open(path, encoding="utf-8", newline="") as f:
                rows = csv.reader(f)
                head = next(rows)
                cols = [head.index(n) for n in ("t", *CHANNELS, "armed")]
                data = []
                for row in rows:
                    try:
                        data.append([float(row[i]) for i in cols])
                    except (ValueError, IndexError):
                        continue
            if len(data) >= 2:
                self.t = [r[0] for r in data]
                self.ch = {c: [r[k + 1] for r in data] for k, c in enumerate(CHANNELS)}
                self.armed = [r[-1] for r in data]
        except (OSError, ValueError, StopIteration):
            pass

    def at(self, t: float) -> dict:
        ts = self.t
        i = bisect_left(ts, t)
        if i <= 0 or i >= len(ts):
            j = 0 if i <= 0 else len(ts) - 1
            out = {c: self.ch[c][j] for c in CHANNELS}
        else:
            a, b = ts[i - 1], ts[i]
            f = (t - a) / (b - a) if b > a else 0.0
            out = {c: self.ch[c][i - 1] + (self.ch[c][i] - self.ch[c][i - 1]) * f for c in CHANNELS}
        out["armed"] = bool(self.armed[min(max(i - 1, 0), len(ts) - 1)])
        return out

    def trail(self, t: float) -> list[dict]:
        step = TRAIL_S / 15
        return [self.at(t - TRAIL_S + k * step) for k in range(15)]


class SeekSlider(QSlider):
    """Progress bar: a click anywhere jumps there and the handle keeps following the mouse."""

    def __init__(self):
        super().__init__(Qt.Horizontal)
        self.setFocusPolicy(Qt.NoFocus)   # ← → stay frame steps for the replay view

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            handle = self.style().pixelMetric(QStyle.PM_SliderLength, None, self)
            x = e.position().x() - handle / 2
            v = QStyle.sliderValueFromPosition(self.minimum(), self.maximum(), round(x),
                                               max(1, self.width() - handle))
            self.setValue(v)
            self.sliderMoved.emit(v)
        super().mousePressEvent(e)


class StickGraph(QWidget):
    """Stick channels drawn see-through on top of the video. The play position stays fixed in the
    middle of the picture (between the two stick boxes) and the curves scroll past it.
    Click to jump, drag to scrub, wheel to show more or fewer seconds, double-click to reset."""
    seek = Signal(int)
    MIN_VIEW_MS = 2000
    DEFAULT_VIEW_MS = 10000

    def __init__(self, parent=None):
        super().__init__(parent)
        self.log: StickLog | None = None
        self.duration_ms = 1
        self.pos_ms = 0
        self.offset_s = 0.0
        self.loop = (None, None)
        self.length_ms = self.DEFAULT_VIEW_MS   # seconds of flight across the picture
        self.label_x = 6.0                      # keeps the labels clear of the curve switches
        self.shown: list[str] = []  # channels switched on, drawn top to bottom in CHANNELS order
        self.gain = {c: 1.0 for c in CHANNELS}
        self._buttons: list[tuple[QRectF, str, float]] = []   # (-)/(+) hit boxes from the last paint
        self._drag = None           # (press x, position at press, moved?)
        self.setCursor(Qt.PointingHandCursor)

    def _window(self):
        return self.pos_ms - self.length_ms / 2, float(self.length_ms)

    def _x(self, ms: float) -> float:
        a, n = self._window()
        return (ms - a) / n * self.width()

    def _ms(self, x: float) -> int:
        a, n = self._window()
        return int(min(max(0, a + x / self.width() * n), self.duration_ms))

    def follow(self, pos_ms: int):
        self.pos_ms = pos_ms
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        self._buttons = []
        chans = [c for c in CHANNELS if c in self.shown]
        if not self.log or not chans:
            return
        w, h = self.width(), self.height()
        start, length = self._window()
        a, b = self.loop
        if a is not None and b is not None:
            p.fillRect(QRectF(self._x(a), 0, self._x(b) - self._x(a), h), QColor(255, 255, 255, 40))
        fm = p.fontMetrics()
        # offset_s shifts the stick log against the video; shifting start and play position keeps them aligned
        labels = draw_curves(p, QRectF(0, 0, w, h), self.log, chans, self.gain, start / 1000 + self.offset_s,
                             length / 1000, self.pos_ms / 1000 + self.offset_s, self.label_x)
        for x_end, y0, c in labels:
            bx = x_end + 8
            for sign, factor in (("－", 1 / 1.4), ("＋", 1.4)):
                box = QRectF(bx, y0, 20, 16)
                p.setPen(QColor(255, 255, 255, 120))
                p.setBrush(QColor(0, 0, 0, 70))
                p.drawRoundedRect(box, 3, 3)
                p.setPen(QColor(255, 255, 255, 220))
                p.drawText(box, Qt.AlignCenter, sign)
                self._buttons.append((box, c, factor))
                bx += 24
        hint = f"显示 {length / 1000:.0f} 秒   滚轮缩放   双击还原"
        tw = fm.horizontalAdvance(hint)
        shadow_text(p, QPointF(w - 8 - tw, 14), hint)

    def mousePressEvent(self, e):
        if e.button() != Qt.LeftButton:
            return
        for box, c, factor in self._buttons:
            if box.contains(e.position()):
                self.gain[c] = min(max(0.5, round(self.gain[c] * factor, 2)), 5.0)
                self.update()
                return
        self._drag = (e.position().x(), self.pos_ms, False)

    def mouseMoveEvent(self, e):
        if self._drag and e.buttons() & Qt.LeftButton:
            x0, pos0, _ = self._drag
            dx = e.position().x() - x0
            if abs(dx) > 3:
                self._drag = (x0, pos0, True)
                # Grab and pull: dragging left moves forward in time, like pulling the curves along
                self.seek.emit(int(min(max(0, pos0 - dx / self.width() * self.length_ms), self.duration_ms)))

    def mouseReleaseEvent(self, e):
        if self._drag and not self._drag[2] and e.button() == Qt.LeftButton:
            self.seek.emit(self._ms(e.position().x()))
        self._drag = None

    def mouseDoubleClickEvent(self, e):
        if any(box.contains(e.position()) for box, _c, _f in self._buttons):
            return self.mousePressEvent(e)   # fast clicks on (+)/(-) count as two clicks
        self.length_ms = self.DEFAULT_VIEW_MS
        self.update()

    def wheelEvent(self, e):
        factor = 0.8 if e.angleDelta().y() > 0 else 1.25
        self.length_ms = min(max(self.MIN_VIEW_MS, self.length_ms * factor), max(self.MIN_VIEW_MS, 2 * self.duration_ms))
        self.update()


class ReplayView(QWidget):
    back_to_live = Signal()

    def __init__(self):
        super().__init__()
        self.meta_path: Path | None = None
        self.video: Path | None = None
        self.exporter: Exporter | None = None
        self.meta: dict = {}
        self.log: StickLog | None = None
        self.loop_a = self.loop_b = None
        self.fps = 60
        self.frame_ms = 0

        self.canvas = VideoCanvas("在左边双击一个录像开始回看")
        self.sink = QVideoSink()
        self.sink.videoFrameChanged.connect(self._on_frame)
        self.player = QMediaPlayer()
        self.player.setVideoSink(self.sink)
        self.player.durationChanged.connect(self._on_duration)
        self.player.positionChanged.connect(self._on_position)
        self.player.playbackStateChanged.connect(self._on_state)
        self.player.errorOccurred.connect(self._on_error)

        self.title = QLabel()
        self.title.setStyleSheet("font-size: 14px; font-weight: bold;")
        self.graph = StickGraph(self.canvas)
        self.canvas.bottom_widget = self.graph
        self.graph.hide()   # off by default; the 油门/偏航/俯仰/横滚曲线 buttons show each line
        self.graph.seek.connect(self.player.setPosition)
        self.slider = SeekSlider()
        self.slider.sliderPressed.connect(self._drag_start)
        self.slider.sliderMoved.connect(self._drag_move)
        self.slider.sliderReleased.connect(self._drag_end)
        # Seeking a 1080p recording takes a moment, so while dragging only the latest spot is
        # sent to the player a few times a second instead of every mouse move piling up.
        self._seek_timer = QTimer(self, singleShot=True, interval=60)
        self._seek_timer.timeout.connect(lambda: self.player.setPosition(self.slider.value()))
        self._resume_after_drag = False
        self.time_label = QLabel("00:00.00 / 00:00.00")

        self.play_btn = QPushButton("播放")
        self.play_btn.clicked.connect(self.toggle_play)
        back = QPushButton("◀ 上一帧")
        back.clicked.connect(lambda: self.step(-1))
        fwd = QPushButton("下一帧 ▶")
        fwd.clicked.connect(lambda: self.step(1))
        self.speed = QComboBox()
        for label, rate in (("0.1 倍速", 0.1), ("0.25 倍速", 0.25), ("0.5 倍速", 0.5), ("1 倍速", 1.0)):
            self.speed.addItem(label, rate)
        self.speed.setCurrentIndex(3)
        self.speed.currentIndexChanged.connect(lambda _: self.player.setPlaybackRate(self.speed.currentData()))
        a_btn = QPushButton("设 A 点")
        a_btn.clicked.connect(lambda: self._set_loop("a"))
        b_btn = QPushButton("设 B 点")
        b_btn.clicked.connect(lambda: self._set_loop("b"))
        clear_btn = QPushButton("取消循环")
        clear_btn.clicked.connect(lambda: self._set_loop(None))
        self.offset = QSpinBox(minimum=-1000, maximum=1000, singleStep=10, suffix=" 毫秒")
        self.offset.setToolTip("如果摇杆比画面早或晚，调这里。正数 = 摇杆往后挪。")
        self.offset.valueChanged.connect(self._offset_changed)
        # Curve switches sit at the left edge of the picture: one master switch plus one per line
        side = QWidget(self.canvas)
        side_lay = QVBoxLayout(side)
        side_lay.setContentsMargins(0, 0, 0, 0)
        side_lay.setSpacing(6)
        btn_css = ("QPushButton {{ background: rgba(0,0,0,110); color: #ddd; border: 1px solid rgba(255,255,255,70);"
                   " border-radius: 4px; padding: 4px 10px; }}"
                   " QPushButton:checked {{ background: {bg}; color: black; border-color: {bg}; }}")
        self.all_curves_btn = QPushButton("全部曲线")
        self.all_curves_btn.setCheckable(True)
        self.all_curves_btn.setStyleSheet(btn_css.format(bg="#eeeeee"))
        self.all_curves_btn.setToolTip("一次打开或关闭四根曲线")
        self.all_curves_btn.clicked.connect(self._toggle_all_curves)
        side_lay.addWidget(self.all_curves_btn)
        side_lay.addSpacing(6)
        self.curve_btns = {}
        for c in CHANNELS:
            b = QPushButton(CH_LABEL[c])
            b.setCheckable(True)
            b.setToolTip(f"在画面上显示或隐藏{CH_LABEL[c]}曲线")
            b.setStyleSheet(btn_css.format(bg=CH_COLORS[c].name()))
            b.toggled.connect(lambda on, ch=c: self._toggle_curve(ch, on))
            side_lay.addWidget(b)
            self.curve_btns[c] = b
        side.adjustSize()
        self.canvas.left_widget = side
        export_btn = QPushButton("导出带摇杆视频")
        export_btn.setToolTip("生成一个摇杆画在画面里的视频，可以直接发微信。打开的曲线也会画进去。设了 A、B 点就只导出那一段。")
        export_btn.clicked.connect(self.export)

        row1 = QHBoxLayout()
        row1.addWidget(self.slider, 1)
        row1.addWidget(self.time_label)
        row2 = QHBoxLayout()
        for w in (self.play_btn, back, fwd, self.speed, a_btn, b_btn, clear_btn):
            row2.addWidget(w)
        row2.addStretch()
        row2.addWidget(QLabel("同步微调"))
        row2.addWidget(self.offset)
        row2.addWidget(export_btn)
        live_btn = QPushButton("◀ 回到实时画面")
        live_btn.setStyleSheet("font-size: 14px; font-weight: bold; padding: 4px 14px;"
                               "background: #1a8f3c; color: white; border-radius: 4px;")
        live_btn.setToolTip("暂停回看，切回实时飞行画面（快捷键 Esc）")
        live_btn.clicked.connect(self.go_live)
        head = QHBoxLayout()
        head.addWidget(live_btn)
        head.addWidget(self.title, 1)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addLayout(head)
        lay.addWidget(self.canvas, 1)
        lay.addLayout(row1)
        lay.addLayout(row2)
        tip = QLabel("快捷键：空格 播放/暂停，← → 逐帧，Esc 回到实时画面")
        tip.setStyleSheet("color: gray;")
        lay.addWidget(tip)

    # ---- loading -------------------------------------------------------
    def load(self, video: Path):
        self.player.stop()
        self.video = video
        self.meta_path = video.with_suffix(".json")
        try:
            self.meta = json.loads(self.meta_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.meta = {}
        self.fps = self.meta.get("fps", 60)
        self.log = StickLog(video.with_suffix(".sticks.csv"))
        self.graph.log = self.log
        self.offset.blockSignals(True)
        self.offset.setValue(int(self.meta.get("sync_offset_ms", 0)))
        self.offset.blockSignals(False)
        self.graph.offset_s = -self.offset.value() / 1000
        self._set_loop(None)
        student = self.meta.get("student", video.parent.parent.name)
        channel = self.meta.get("channel", "")
        self.canvas.channel = channel
        self.title.setText(f"{student}   {video.parent.name}  {video.stem.replace('-', ':')}"
                           + (f"   频道 {channel}" if channel else ""))
        # Opening the same file again is ignored by the player and leaves a stale or black picture,
        # so drop the old source first and every double-click really reloads.
        self.player.setSource(QUrl())
        self.frame_ms = 0
        self.player.setSource(QUrl.fromLocalFile(str(video)))
        self.player.play()

    # ---- controls --------------------------------------------------------
    def toggle_play(self):
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()
        else:
            self.player.play()

    def step(self, frames: int):
        # A paused seek shows the last frame that starts before the target, so aim at the
        # middle of the wanted frame; seeking exactly to its start shows the previous one.
        self.player.pause()
        frame = 1000 / self.fps
        target = self.frame_ms + frames * frame
        target = min(max(0.0, target), max(0.0, self.player.duration() - frame))
        self.player.setPosition(int(target + frame / 2))

    def _toggle_all_curves(self, on):
        for b in self.curve_btns.values():
            b.setChecked(on)

    def _toggle_curve(self, ch, on):
        shown = self.graph.shown
        if on and ch not in shown:
            shown.append(ch)
        elif not on and ch in shown:
            shown.remove(ch)
        self.graph.setVisible(bool(shown))
        self.all_curves_btn.setChecked(len(shown) == len(CHANNELS))
        self.graph.update()
        self.canvas.update()

    def export(self):
        if not self.video or not self.log or self.exporter:
            return
        self.player.pause()
        a, b = self.loop_a, self.loop_b
        whole = a is None or b is None
        start, end = (0, self.player.duration()) if whole else (a, b)
        if end - start < 500:
            QMessageBox.information(self, "导出", "A 到 B 太短了，至少要半秒。")
            return
        part = "" if whole else f"-{start // 1000}到{end // 1000}秒"
        student = self.meta.get("student", self.video.parent.parent.name)
        out = self.video.parent / "导出" / f"{student}-{self.video.parent.name}-{self.video.stem}{part}.mp4"
        g = self.graph
        curves = [c for c in CHANNELS if c in g.shown]
        self.exporter = Exporter(self.video, self.log, self.fps, self.offset.value(), self.meta.get("channel", ""),
                                 start, end, out, curves, dict(g.gain), g.length_ms)
        dlg = QProgressDialog("正在导出带摇杆的视频…", "取消", 0, 100, self)
        dlg.setWindowTitle("导出")
        dlg.setWindowModality(Qt.WindowModal)
        dlg.setMinimumDuration(0)
        dlg.setValue(0)
        self.exporter.progress.connect(dlg.setValue)
        dlg.canceled.connect(lambda: setattr(self.exporter, "cancelled", True))
        self.exporter.done.connect(lambda path, err: self._export_done(dlg, path, err))
        self.exporter.start()

    def _export_done(self, dlg, path, err):
        self.exporter = None
        dlg.reset()
        if err == "已取消":
            return
        if err:
            QMessageBox.warning(self, "导出", err)
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(path).parent)))

    def _set_loop(self, which):
        pos = self.player.position()
        if which == "a":
            self.loop_a = pos
        elif which == "b":
            self.loop_b = pos
        else:
            self.loop_a = self.loop_b = None
        if self.loop_a is not None and self.loop_b is not None and self.loop_b < self.loop_a:
            self.loop_a, self.loop_b = self.loop_b, self.loop_a
        self.graph.loop = (self.loop_a, self.loop_b)
        self.graph.update()

    def _offset_changed(self, v):
        self.graph.offset_s = -v / 1000
        self.graph.update()
        self._update_overlay(self.frame_ms)
        if self.meta_path and self.meta_path.exists():
            self.meta["sync_offset_ms"] = v
            self.meta_path.write_text(json.dumps(self.meta, ensure_ascii=False, indent=2), encoding="utf-8")

    def release(self):
        self.player.stop()
        self.player.setSource(QUrl())
        self.video = self.meta_path = None
        self.log = self.graph.log = None
        self.canvas.image = None
        self.title.setText("")
        self.canvas.update()

    def go_live(self):
        self.player.pause()
        self.back_to_live.emit()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.go_live()
        elif e.key() == Qt.Key_Space:
            self.toggle_play()
        elif e.key() == Qt.Key_Left:
            self.step(-1)
        elif e.key() == Qt.Key_Right:
            self.step(1)
        else:
            super().keyPressEvent(e)

    # ---- player callbacks ----------------------------------------------
    def _on_frame(self, frame):
        if not frame.isValid():
            return
        img = frame.toImage()
        if img.isNull():
            return
        self.canvas.image = img
        t_us = frame.startTime()
        self.frame_ms = t_us // 1000 if t_us >= 0 else self.player.position()
        self._update_overlay(self.frame_ms)

    def _update_overlay(self, ms):
        if self.log:
            t = ms / 1000 - self.offset.value() / 1000
            self.canvas.values = self.log.at(t)
            self.canvas.trail = self.log.trail(t)
        self.canvas.update()

    def _drag_start(self):
        self._resume_after_drag = self.player.playbackState() == QMediaPlayer.PlayingState
        if self._resume_after_drag:
            self.player.pause()

    def _drag_move(self, pos):
        self.time_label.setText(f"{_fmt(pos)} / {_fmt(self.player.duration())}")
        if not self._seek_timer.isActive():
            self._seek_timer.start()

    def _drag_end(self):
        self._seek_timer.stop()
        self.player.setPosition(self.slider.value())
        if self._resume_after_drag:
            self.player.play()

    def _on_duration(self, d):
        self.slider.setRange(0, d)
        self.graph.duration_ms = max(1, d)

    def _on_position(self, pos):
        if self.loop_a is not None and self.loop_b is not None and pos >= self.loop_b:
            self.player.setPosition(self.loop_a)
            return
        if not self.slider.isSliderDown():
            self.slider.setValue(pos)
        self.time_label.setText(f"{_fmt(pos)} / {_fmt(self.player.duration())}")
        self.graph.follow(pos)

    def _on_error(self, _err, text):
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.warning(self, "回看", f"这个录像播放不了：{text}\n\n请截图发给开发者。")

    def _on_state(self, state):
        self.play_btn.setText("暂停" if state == QMediaPlayer.PlayingState else "播放")
