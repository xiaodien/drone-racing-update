"""Transmitter input.

The radio is read as a USB joystick (EdgeTX "USB Joystick" mode). Everything that
reads the radio lives behind StickSource, so a wireless source can be added later
without touching the rest of the program.
"""
import math
import os
import threading
import time
from collections import deque

CHANNELS = ("thr", "yaw", "pitch", "roll")
CH_LABEL = {"thr": "油门", "yaw": "偏航", "pitch": "俯仰", "roll": "横滚"}
SIM_NAME = "模拟遥控器（测试用）"
CRSF_NAME = "ELRS 接收机"

# A raw sample: (perf_counter time, axes tuple in -1..1, buttons bitmask)


class StickSource:
    """Base: keeps a time-stamped ring of raw samples."""

    def __init__(self):
        self.samples: deque = deque(maxlen=400_000)
        self.lock = threading.Lock()
        self.connected_name = ""
        self.device_names: list[str] = []
        self._capture: list | None = None   # every sample since begin_capture, however long

    def _push(self, axes, buttons):
        s = (time.perf_counter(), axes, buttons)
        with self.lock:
            self.samples.append(s)
            if self._capture is not None:
                self._capture.append(s)

    def begin_capture(self, t0: float):
        """Keep all samples from t0 on, so a long recording never loses its start to the ring buffer."""
        with self.lock:
            older = [s for s in self.samples if s[0] < t0]
            self._capture = older[-1:] + [s for s in self.samples if s[0] >= t0]

    def end_capture(self, t0: float, t1: float) -> list:
        """Stop capturing; return samples in [t0, t1] plus the one just before t0."""
        with self.lock:
            cap, self._capture = self._capture, None
        if cap is None:
            return self.between(t0, t1)
        before = [s for s in cap if s[0] < t0]
        return before[-1:] + [s for s in cap if t0 <= s[0] <= t1]

    def latest(self):
        with self.lock:
            return self.samples[-1] if self.samples else None

    def between(self, t0: float, t1: float) -> list:
        """Samples in [t0, t1] plus the one just before t0. Scans from the newest end."""
        out = []
        with self.lock:
            for s in reversed(self.samples):
                if s[0] > t1:
                    continue
                out.append(s)
                if s[0] < t0:
                    break
        out.reverse()
        return out

    def select(self, name: str):
        pass

    def close(self):
        pass


class JoystickSource(StickSource):
    POLL_S = 0.002          # 500 Hz
    KEEPALIVE_S = 0.02      # store at least 50 Hz even when sticks don't move
    MIN_STORE_S = 0.005     # store at most 200 Hz (4 samples per video frame) to bound memory

    def __init__(self, wanted_name: str = ""):
        super().__init__()
        os.environ.setdefault("SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS", "1")
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
        import pygame  # noqa: F401  (import on the main thread; the poll thread only uses it)
        self.wanted = wanted_name
        self._stop = False
        self._reopen = True
        self._sim_t0 = time.perf_counter()
        self._crsf: CrsfReader | None = None
        self._ports: dict[str, str] = {}
        self.port_error = ""
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def select(self, name: str):
        self.wanted = name
        self._reopen = True

    def close(self):
        self._stop = True
        if self._crsf:
            self._crsf.stop = True

    def _run(self):
        os.environ.setdefault("SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS", "1")
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
        import pygame
        pygame.display.init()
        pygame.joystick.init()
        joy = None
        last_axes, last_btn, last_push = None, None, 0.0
        last_scan = 0.0
        while not self._stop:
            if time.perf_counter() - last_scan > 3.0:
                last_scan = time.perf_counter()
                ports = crsf_ports()
                if ports != self._ports:
                    self._ports = ports
                    self._reopen = True
            if self._crsf and not self._crsf.ok:
                self.port_error = f"{self._crsf.port} 打不开：{self._crsf.error}"
                self._crsf, self.connected_name = None, ""
                self._reopen = True
            for ev in pygame.event.get():
                if ev.type in (pygame.JOYDEVICEADDED, pygame.JOYDEVICEREMOVED):
                    self._reopen = True
            if self._reopen:
                self._reopen = False
                joys = [pygame.joystick.Joystick(i) for i in range(pygame.joystick.get_count())]
                self.device_names = [j.get_name() for j in joys] + list(self._ports) + [SIM_NAME]
                joy = self._pick(joys)
                port_name = self._pick_port(joy)
                if self._crsf and (not port_name or self._crsf.port != self._ports[port_name]):
                    self._crsf.stop = True
                    self._crsf = None
                if port_name:
                    joy = None
                    if not self._crsf:
                        self._crsf = CrsfReader(self._ports[port_name], self._push, self.MIN_STORE_S,
                                                self.KEEPALIVE_S)
                    self.connected_name = port_name
                else:
                    self.connected_name = SIM_NAME if self.wanted == SIM_NAME else (joy.get_name() if joy else "")
            now = time.perf_counter()
            if self._crsf:
                time.sleep(0.05)        # the receiver has its own reader thread
                continue
            if self.connected_name == SIM_NAME:
                axes, btn = self._simulate(now)
            elif joy is not None:
                try:
                    axes = tuple(round(joy.get_axis(i), 4) for i in range(joy.get_numaxes()))
                    btn = 0
                    for i in range(min(joy.get_numbuttons(), 32)):
                        if joy.get_button(i):
                            btn |= 1 << i
                except pygame.error:
                    joy, self.connected_name = None, ""
                    continue
            else:
                time.sleep(0.2)
                continue
            if btn != last_btn or (axes != last_axes and now - last_push >= self.MIN_STORE_S) \
                    or now - last_push >= self.KEEPALIVE_S:
                self._push(axes, btn)
                last_axes, last_btn, last_push = axes, btn, now
            time.sleep(self.POLL_S)

    def report(self) -> str:
        lines = [f"当前使用：{self.connected_name or '无'}", "能选的设备：" + "、".join(getattr(self, "device_names", []))]
        if self.port_error:
            lines.append(self.port_error + "（可能被别的软件占着，比如 ExpressLRS 配置器、Betaflight，关掉再试）")
        return "\n".join(lines + ["", serial_report(self._crsf)])

    def _pick_port(self, joy) -> str:
        """An ELRS receiver is used when chosen, or when no radio is plugged in by USB."""
        if self.wanted in self._ports:
            return self.wanted
        if self.wanted == SIM_NAME or (joy is not None and (self.wanted == joy.get_name() or is_known_radio(joy.get_name()))):
            return ""
        return next(iter(self._ports), "")

    def _pick(self, joys):
        if self.wanted == SIM_NAME:
            return None
        for j in joys:
            if self.wanted and j.get_name() == self.wanted:
                return j
        for j in joys:
            if is_known_radio(j.get_name()):
                return j
        return joys[0] if joys else None

    def _simulate(self, now):
        t = now - self._sim_t0
        thr = -1 + 1.2 * (0.5 + 0.5 * math.sin(t * 0.7)) if (t % 30) > 4 else -1.0
        yaw = 0.6 * math.sin(t * 1.3)
        pitch = 0.5 * math.sin(t * 0.9 + 1)
        roll = 0.7 * math.sin(t * 1.7)
        arm = 1.0 if (t % 30) > 3 and (t % 30) < 26 else -1.0
        return (round(roll, 4), round(-pitch, 4), round(thr, 4), round(yaw, 4), arm, -1.0), 0


# ---- ELRS receiver on a USB serial adapter (CRSF protocol) ------------------
CRSF_SYNC = (0xC8, 0xEA, 0xEE, 0xEC)
CRSF_RC_CHANNELS = 0x16
CRSF_MID, CRSF_SPAN = 992, 819.5                # 172..1811 is -100%..+100%
CRSF_LINK_TIMEOUT_S = 0.3


def crsf_ports() -> dict[str, str]:
    """Display name -> COM port for USB serial adapters that might have a receiver on them."""
    try:
        from serial.tools import list_ports
    except ImportError:
        return {}
    # Any USB serial port counts (adapters sold as "CP2102" often carry another chip); Bluetooth and
    # built-in COM ports have no USB vendor id and are skipped. Also skip Espressif native USB
    # (VID 0x303A, used by the XIAO ESP32-C5 lap timer) so training mode never grabs its COM port.
    ports = sorted(p.device for p in list_ports.comports() if p.vid is not None and p.vid != 0x303A)
    if len(ports) == 1:
        return {CRSF_NAME: ports[0]}
    return {f"{CRSF_NAME}（{p}）": p for p in ports}


def serial_report(reader: "CrsfReader | None") -> str:
    """Every COM port Windows sees, plus what the receiver reader has received, for the diagnose report."""
    try:
        from serial.tools import list_ports
    except ImportError:
        return "没有 pyserial（runtime\\Lib\\site-packages\\serial 缺失）"
    lines = []
    for p in sorted(list_ports.comports(), key=lambda p: p.device):
        ids = f"VID={p.vid:04X} PID={p.pid:04X}" if p.vid is not None else "不是 USB 串口"
        lines.append(f"{p.device}  {p.description}  {ids}")
    if not any("VID=" in l for l in lines):
        lines.append("没有看到 USB 串口：USB 转串口模块没插好，或者驱动没装（CP210x / CH340 驱动）")
    if reader:
        st = reader.stats
        lines.append(f"正在读 {reader.port}：当前波特率 {st['baud']}，收到 {st['bytes']} 字节，"
                     f"有效遥控帧 {st['frames']} 个")
        if st["last"]:
            lines.append("最近一帧前 8 通道：" + "  ".join(f"{v:+.2f}" for v in st["last"][:8]))
        if st["bytes"] and not st["frames"]:
            lines.append("有数据但解不出遥控帧：多半是波特率对不上（CP2102 老芯片跑不了 420000），"
                         "或者接收机串口协议不是 CRSF")
        elif not st["bytes"]:
            lines.append("一个字节都没收到：检查接线 接收机 TX → 模块 RXD，GND 要接，接收机要通电亮灯")
    return "\n".join(lines)


def _crc8(data) -> int:
    crc = 0
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = ((crc << 1) ^ 0xD5) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


def crsf_frames(buf: bytearray):
    """Pull complete, CRC-checked frames out of buf; yields (type, payload). Leaves any partial frame in buf."""
    while len(buf) >= 4:
        if buf[0] not in CRSF_SYNC or not 2 <= buf[1] <= 62:
            del buf[0]
            continue
        end = buf[1] + 2
        if len(buf) < end:
            return
        body = bytes(buf[2:end - 1])
        if _crc8(body) == buf[end - 1]:
            yield body[0], body[1:]
            del buf[:end]
        else:
            del buf[0]


def crsf_channels(payload: bytes) -> tuple:
    """16 channels of 11 bits, little-endian bit stream, as -1..1."""
    bits = int.from_bytes(payload[:22], "little")
    return tuple(round(max(-1.0, min(1.0, (((bits >> (11 * i)) & 0x7FF) - CRSF_MID) / CRSF_SPAN)), 4)
                 for i in range(16))


class CrsfReader:
    """Reads an ELRS receiver wired to a USB serial adapter. Button 1 is set while the radio is heard,
    the same convention as our ESP32 wireless receiver."""
    BAUDS = (420000, 115200, 400000)

    def __init__(self, port: str, push, min_store_s: float, keepalive_s: float):
        self.port, self.push = port, push
        self.min_store_s, self.keepalive_s = min_store_s, keepalive_s
        self.stop = False
        self.ok = True            # False once the port can't be opened
        self.error = ""
        self.stats = {"baud": self.BAUDS[0], "bytes": 0, "frames": 0, "last": None}
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        import serial
        baud_i, last_frame, last_push, last_axes = 0, 0.0, 0.0, None
        idle = (0.0, 0.0, -1.0, 0.0, 0.0) + (0.0,) * 11
        while not self.stop:
            try:
                ser = serial.Serial(self.port, self.BAUDS[baud_i], timeout=0.02)
                self.stats["baud"] = self.BAUDS[baud_i]
            except (OSError, serial.SerialException) as e:
                self.error = str(e)
                self.ok = False
                return
            buf, tried = bytearray(), time.perf_counter()
            with ser:
                while not self.stop:
                    try:
                        chunk = ser.read(256)
                        buf += chunk
                        self.stats["bytes"] += len(chunk)
                    except (OSError, serial.SerialException):
                        self.ok = False
                        return
                    now = time.perf_counter()
                    for kind, payload in crsf_frames(buf):
                        if kind == CRSF_RC_CHANNELS and len(payload) >= 22:
                            axes = crsf_channels(payload)
                            last_frame = now
                            self.stats["frames"] += 1
                            self.stats["last"] = axes
                            if (axes != last_axes and now - last_push >= self.min_store_s) \
                                    or now - last_push >= self.keepalive_s:
                                self.push(axes, 1)
                                last_axes, last_push = axes, now
                    if now - last_frame > CRSF_LINK_TIMEOUT_S and now - last_push >= self.keepalive_s:
                        self.push(last_axes or idle, 0)
                        last_push = now
                    # Nothing valid for 2 s right after opening: try the next baud rate.
                    if not last_frame and now - tried > 2.0:
                        break
                    if len(buf) > 4096:
                        del buf[:-64]
            if not last_frame:
                baud_i = (baud_i + 1) % len(self.BAUDS)


RADIO_KEYWORDS = ("edgetx", "opentx", "radiomaster", "jumper", "frsky", "betafpv", "tbs", "v16", "elrs")


def is_known_radio(name: str) -> bool:
    n = name.lower()
    return any(k in n for k in RADIO_KEYWORDS)


def is_wireless(name: str) -> bool:
    """Our ESP32 receiver ("EdgeTX Wireless"): button 1 is set while it hears the radio."""
    return "wireless" in name.lower() or name.startswith(CRSF_NAME)


def edgetx_preset(name: str, axes) -> dict:
    """EdgeTX/OpenTX USB joystick default: channels 1-4 = roll, pitch, throttle, yaw (AETR), arm switch on CH5.
    The arm switch is assumed to be in the safe (disarmed) position when the radio is plugged in."""
    full = {"min": -1.0, "max": 1.0, "invert": False}
    arm_now = axes[4] if len(axes) > 4 else -1.0
    disarmed = -1.0 if arm_now < 0 else 1.0
    return {
        "device": name,
        "preset": "edgetx",
        "axes": {"roll": {"axis": 0, **full}, "pitch": {"axis": 1, **full},
                 "thr": {"axis": 2, **full}, "yaw": {"axis": 3, **full}},
        "arm": {"type": "axis", "index": 4, "armed_value": -disarmed, "disarmed_value": disarmed},
        "link_button": 0 if is_wireless(name) else None,
    }


class Calibration:
    """Maps raw joystick axes to throttle/yaw/pitch/roll in -1..1 and the arm switch."""

    def __init__(self, data: dict | None):
        self.data = data or {}

    @property
    def valid(self) -> bool:
        return all(c in self.data.get("axes", {}) for c in CHANNELS) and "arm" in self.data

    def channel(self, ch: str, axes) -> float:
        a = self.data["axes"][ch]
        i = a["axis"]
        if i >= len(axes):
            return 0.0
        lo, hi = a["min"], a["max"]
        v = (axes[i] - lo) / (hi - lo) * 2 - 1 if hi != lo else 0.0
        v = max(-1.0, min(1.0, v))
        return -v if a["invert"] else v

    def armed(self, axes, buttons) -> bool:
        arm = self.data.get("arm")
        if not arm:
            return False
        if arm["type"] == "button":
            pressed = bool(buttons >> arm["index"] & 1)
            return pressed == arm["armed_pressed"]
        i = arm["index"]
        if i >= len(axes):
            return False
        return abs(axes[i] - arm["armed_value"]) < abs(axes[i] - arm["disarmed_value"])

    def apply(self, sample) -> dict | None:
        if not sample or not self.valid:
            return None
        _t, axes, buttons = sample
        link = self.data.get("link_button")
        if link is not None and not buttons >> link & 1:
            return {c: (-1.0 if c == "thr" else 0.0) for c in CHANNELS} | {"armed": False}
        out = {c: self.channel(c, axes) for c in CHANNELS}
        out["armed"] = self.armed(axes, buttons)
        return out
