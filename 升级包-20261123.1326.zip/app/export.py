"""Export a recording with the stick overlay burned into the picture, for sharing (e.g. WeChat).

ffmpeg decodes the clip to raw frames, each frame gets the same overlay as the replay
screen, and a second ffmpeg encodes the result as a normal 720p H.264 mp4.
"""
import subprocess
import tempfile
import threading
from pathlib import Path

from PySide6.QtCore import QObject, QRectF, Signal
from PySide6.QtGui import QImage, QPainter

from app import ffmpeg_tools as ft
from app.canvas import paint_frame
from app.overlay import draw_curves

OUT_W, OUT_H = 1280, 720


class Exporter(QObject):
    progress = Signal(int)          # percent
    done = Signal(str, str)         # output path, error text ("" on success)

    def __init__(self, video: Path, log, fps: float, offset_ms: int, channel: str,
                 start_ms: int, end_ms: int, out: Path, curves: list[str] | None = None,
                 gain: dict | None = None, window_ms: float | None = None):
        super().__init__()
        self.video, self.log, self.fps = video, log, fps
        self.offset_s = offset_ms / 1000
        self.channel = channel
        self.start_s, self.end_s = start_ms / 1000, end_ms / 1000
        self.out = out
        self.curves = curves or []        # stick curves switched on in replay, drawn into the video too
        self.gain = gain or {}
        self.window_s = window_ms / 1000 if window_ms else None   # seconds across the picture, as in replay
        self.cancelled = False

    def start(self):
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        try:
            err = self._export()
        except Exception as e:  # noqa: BLE001  (report anything to the user instead of dying silently)
            err = str(e)
        if err:
            self.out.unlink(missing_ok=True)
        self.done.emit(str(self.out), err)

    def _export(self) -> str:
        exe = ft.ffmpeg_path()
        dur = self.end_s - self.start_s
        total = max(1, round(dur * self.fps))
        dec = subprocess.Popen([exe, "-hide_banner", "-loglevel", "error", "-ss", f"{self.start_s:.3f}",
                                "-i", str(self.video), "-t", f"{dur:.3f}",
                                "-vf", f"scale={OUT_W}:{OUT_H}:force_original_aspect_ratio=decrease,"
                                       f"pad={OUT_W}:{OUT_H}:(ow-iw)/2:(oh-ih)/2",
                                "-f", "rawvideo", "-pix_fmt", "rgb24", "pipe:1"],
                               stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=ft.NO_WINDOW)
        self.out.parent.mkdir(parents=True, exist_ok=True)
        enc_log = tempfile.TemporaryFile()
        enc = subprocess.Popen([exe, "-hide_banner", "-loglevel", "error", "-y",
                                "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{OUT_W}x{OUT_H}",
                                "-r", f"{self.fps:g}", "-i", "pipe:0",
                                "-c:v", "libx264", "-preset", "veryfast", "-crf", "22", "-pix_fmt", "yuv420p",
                                "-movflags", "+faststart", str(self.out)],
                               stdin=subprocess.PIPE, stderr=enc_log, creationflags=ft.NO_WINDOW)
        size = OUT_W * OUT_H * 3
        img = QImage(OUT_W, OUT_H, QImage.Format_RGB888)
        n = 0
        try:
            while not self.cancelled:
                raw = dec.stdout.read(size)
                if len(raw) < size:
                    break
                frame = QImage(raw, OUT_W, OUT_H, OUT_W * 3, QImage.Format_RGB888)
                t = self.start_s + n / self.fps - self.offset_s
                p = QPainter(img)
                paint_frame(p, QRectF(0, 0, OUT_W, OUT_H), frame, self.log.at(t), self.log.trail(t), self.channel)
                if self.curves:
                    self._draw_curves(p, self.start_s + n / self.fps)
                p.end()
                enc.stdin.write(bytes(img.constBits())[:size])
                n += 1
                if n % 10 == 0:
                    self.progress.emit(min(99, n * 100 // total))
        finally:
            dec.kill()
            try:
                enc.stdin.close()
            except OSError:
                pass
            enc.wait()
        if self.cancelled:
            return "已取消"
        if enc.returncode != 0 or n == 0:
            enc_log.seek(0)
            return "导出失败：" + enc_log.read().decode("utf-8", errors="replace")[-300:]
        self.progress.emit(100)
        return ""

    def _draw_curves(self, p: QPainter, video_t: float):
        """Same curves as the replay screen: play line fixed in the middle, curves scrolling past."""
        length = self.window_s or 10.0
        gh = OUT_H * 0.44
        rect = QRectF(0, (OUT_H - gh) / 2, OUT_W, gh)
        draw_curves(p, rect, self.log, self.curves, self.gain, video_t - length / 2 - self.offset_s, length,
                    video_t - self.offset_s, 24)
