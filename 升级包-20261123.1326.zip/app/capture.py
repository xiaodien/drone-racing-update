"""Live capture: one ffmpeg process owns the capture card.

ffmpeg splits the signal in two: a full-quality hardware-encoded stream written
continuously as 2-second segments into a ring buffer, and a small raw RGB preview
sent to this program over a pipe. Recording a flight later just joins the segments
that cover it, so starting or stopping a recording never touches the live encoder.
"""
import csv
import re
import subprocess
import threading
import time
from pathlib import Path

from PySide6.QtCore import QObject, Signal
from PySide6.QtGui import QImage

from app import ffmpeg_tools as ft
from app.config import IS_WINDOWS

SEGMENT_S = 2
PREVIEW_W, PREVIEW_H = 960, 540


class CaptureEngine(QObject):
    frame_ready = Signal()
    stopped = Signal(str)  # error text, empty when stopped normally

    def __init__(self):
        super().__init__()
        self.proc = None
        self.buffer_dir: Path | None = None
        self.fps = 60
        self.encoder = ""
        self._lock = threading.Lock()
        self._latest: QImage | None = None
        self.frame_count = 0
        self.anchor = None          # perf_counter value at stream time 0
        self.segments: list[tuple[Path, float, float]] = []
        self._list_pos = 0
        self.stats = {"fps": 0.0, "dropped": 0, "speed": ""}
        self._dshow_drops = 0
        self._stderr_tail: list[str] = []
        self._stopping = False

    # ---- control -------------------------------------------------------
    def start(self, device: str, mode: dict, encoder: str, buffer_dir: Path):
        self.stop()
        exe = ft.ffmpeg_path()
        if not exe:
            self.stopped.emit("找不到 FFmpeg，请重新运行「启动.bat」让它自动下载。")
            return
        self.buffer_dir = buffer_dir
        for f in buffer_dir.glob("seg_*.ts"):
            f.unlink(missing_ok=True)
        (buffer_dir / "list.csv").unlink(missing_ok=True)
        self.fps = mode["fps"]
        self.encoder = encoder
        self.segments, self._list_pos = [], 0
        self.frame_count, self.anchor, self._latest = 0, None, None
        self._dshow_drops = 0
        self._stderr_tail = []
        self.stats = {"fps": 0.0, "dropped": 0, "speed": ""}
        self._stopping = False
        self._input_seen = False
        self.input_desc = ""

        if mode["kind"] == "test":
            inp = ["-re", "-f", "lavfi", "-i", f"testsrc2=size={mode['w']}x{mode['h']}:rate={self.fps}"]
        elif mode["kind"] == "default" and not IS_WINDOWS:
            inp = ["-re", "-f", "lavfi", "-i", "testsrc2=size=720x480:rate=30000/1001"]
        else:
            inp = ft.dshow_input_args(device, mode)

        gop = 60 * SEGMENT_S
        cmd = [exe, "-hide_banner", "-loglevel", "info", "-stats", "-stats_period", "1", *inp,
               "-filter_complex",
               f"[0:v]split=2[rec][pv];[rec]format=nv12[recf];"
               f"[pv]scale={PREVIEW_W}:{PREVIEW_H}:flags=fast_bilinear:force_original_aspect_ratio=decrease,"
               f"pad={PREVIEW_W}:{PREVIEW_H}:(ow-iw)/2:(oh-ih)/2,format=bgr0[pvo]",
               "-map", "[recf]", "-c:v", encoder, *ft.encoder_opts(encoder),
               "-bf", "0", "-g", str(gop), "-force_key_frames", f"expr:gte(t,n_forced*{SEGMENT_S})",
               "-fps_mode", "passthrough",
               "-f", "segment", "-segment_time", str(SEGMENT_S), "-segment_format", "mpegts",
               "-segment_list", str(buffer_dir / "list.csv"), "-segment_list_type", "csv",
               str(buffer_dir / "seg_%06d.ts"),
               "-map", "[pvo]", "-f", "rawvideo", "-pix_fmt", "bgr0", "pipe:1"]
        try:
            self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                         stderr=subprocess.PIPE, bufsize=0,
                                         creationflags=ft.NO_WINDOW)
        except OSError as e:
            self.stopped.emit(f"无法启动 FFmpeg：{e}")
            return
        threading.Thread(target=self._read_preview, args=(self.proc,), daemon=True).start()
        threading.Thread(target=self._read_stderr, args=(self.proc,), daemon=True).start()

    def stop(self):
        proc, self.proc = self.proc, None
        if not proc:
            return
        self._stopping = True
        try:
            proc.stdin.write(b"q")
            proc.stdin.flush()
        except OSError:
            pass
        try:
            proc.wait(timeout=4)
        except subprocess.TimeoutExpired:
            proc.kill()

    @property
    def running(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    # ---- data access ---------------------------------------------------
    def latest_frame(self) -> QImage | None:
        with self._lock:
            return self._latest

    def poll_segments(self):
        """Read segments ffmpeg has finished since last call (list.csv is appended per segment)."""
        if not self.buffer_dir:
            return
        path = self.buffer_dir / "list.csv"
        try:
            with open(path, newline="", encoding="utf-8") as f:
                f.seek(self._list_pos)
                data = f.read()
        except OSError:
            return
        if not data.endswith("\n"):
            data = data[: data.rfind("\n") + 1]
        self._list_pos += len(data.encode("utf-8"))
        for row in csv.reader(data.splitlines()):
            if len(row) >= 3:
                self.segments.append((self.buffer_dir / row[0], float(row[1]), float(row[2])))

    def delete_segments_before(self, stream_t: float):
        keep = []
        for seg in self.segments:
            if seg[2] < stream_t:
                seg[0].unlink(missing_ok=True)
            else:
                keep.append(seg)
        self.segments = keep

    # ---- worker threads --------------------------------------------------
    def _read_preview(self, proc):
        # bgr0 bytes are exactly QImage.Format_RGB32 on little-endian PCs, which Qt paints several
        # times faster than RGB888, so the live picture keeps up with a 60 fps card.
        size = PREVIEW_W * PREVIEW_H * 4
        buf = bytearray(size)
        view = memoryview(buf)
        t_fps, n_fps = time.perf_counter(), 0
        while True:
            got = 0
            while got < size:
                n = proc.stdout.readinto(view[got:])
                if not n:
                    self._finished(proc)
                    return
                got += n
            now = time.perf_counter()
            img = QImage(buf, PREVIEW_W, PREVIEW_H, PREVIEW_W * 4, QImage.Format_RGB32).copy()
            # The smallest (arrival - frame time) seen is the best estimate of when stream time 0 was.
            est = now - self.frame_count / self.fps
            if self.anchor is None or est < self.anchor:
                self.anchor = est
            self.frame_count += 1
            n_fps += 1
            if now - t_fps >= 1.0:
                self.stats["fps"] = n_fps / (now - t_fps)
                t_fps, n_fps = now, 0
            with self._lock:
                self._latest = img
            self.frame_ready.emit()

    def _read_stderr(self, proc):
        pending = b""
        while True:
            chunk = proc.stderr.read(256)
            if not chunk:
                return
            pending += chunk
            parts = re.split(rb"[\r\n]", pending)
            pending = parts.pop()
            for raw in parts:
                line = raw.decode("utf-8", errors="replace").strip()
                if not line:
                    continue
                m = re.search(r"Stream #0:0.*Video:.*?(\d{3,5})x(\d{3,5}).*?([\d.]+) (?:fps|tbr)", line)
                if m and not self._input_seen:
                    self._input_seen = True
                    self.input_desc = f"{m.group(1)}x{m.group(2)} {float(m.group(3)):g}帧"
                    if float(m.group(3)) > 1:
                        self.fps = float(m.group(3))
                    continue
                m = re.search(r"drop=\s*(\d+)", line)
                if m:
                    self.stats["dropped"] = int(m.group(1)) + self._dshow_drops
                elif "real-time buffer" in line and "frame dropped" in line:
                    self._dshow_drops += 1
                    self.stats["dropped"] = max(self.stats["dropped"], self._dshow_drops)
                m = re.search(r"speed=\s*(\S+)", line)
                if m:
                    self.stats["speed"] = m.group(1)
                if not line.startswith("frame=") and not line.startswith(" "):
                    self._stderr_tail = (self._stderr_tail + [line])[-12:]

    def _finished(self, proc):
        proc.wait()
        if self._stopping:
            self.stopped.emit("")
        else:
            tail = "\n".join(self._stderr_tail[-5:])
            hint = ""
            if "I/O error" in tail or "Could not" in tail or "busy" in tail.lower():
                hint = "\n\n采集卡可能被 OBS 等其它软件占用，请先关掉它们再试。"
            self.stopped.emit(f"采集已停止。\n{tail}{hint}")
