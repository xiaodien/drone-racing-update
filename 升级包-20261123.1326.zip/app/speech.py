"""报圈语音：用 Windows 自带的语音（System.Speech），开一个后台 PowerShell 一直等着念字。

只在 Windows 上有声音；别的系统上 say() 什么也不做。
"""
import subprocess
import sys
import threading

_PS = r"""
[Console]::InputEncoding = [Text.Encoding]::UTF8
Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$zh = $s.GetInstalledVoices() | Where-Object { $_.Enabled -and $_.VoiceInfo.Culture.Name -like 'zh*' } | Select-Object -First 1
if ($zh) { $s.SelectVoice($zh.VoiceInfo.Name) }
$s.Rate = 2
while (($l = [Console]::In.ReadLine()) -ne $null) {
  if ($l -eq '!stop') { $s.SpeakAsyncCancelAll(); continue }
  $s.SpeakAsync($l) | Out-Null
}
"""


class Speaker:
    def __init__(self):
        self.proc = None
        self.lock = threading.Lock()

    def _start(self):
        if sys.platform != "win32":
            return False
        if self.proc and self.proc.poll() is None:
            return True
        try:
            self.proc = subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", _PS],
                                         stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                         creationflags=subprocess.CREATE_NO_WINDOW)
            return True
        except OSError:
            self.proc = None
            return False

    def warm_up(self):
        """提前把 PowerShell 开起来，第一次报圈就不会慢"""
        threading.Thread(target=lambda: self._send(None), daemon=True).start()

    def _send(self, text):
        with self.lock:
            if not self._start() or text is None:
                return
            try:
                self.proc.stdin.write((text.replace("\n", " ") + "\n").encode("utf-8"))
                self.proc.stdin.flush()
            except OSError:
                self.proc = None

    def say(self, text):
        threading.Thread(target=self._send, args=(text,), daemon=True).start()

    def stop(self):
        self.say("!stop")

    def close(self):
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.stdin.close()
                self.proc.terminate()
            except OSError:
                pass
        self.proc = None


def seconds_text(ms) -> str:
    """12430 毫秒 → "12.4秒"；超过一分钟 → "1分02.4秒" """
    s = ms / 1000
    if s >= 60:
        return f"{int(s // 60)}分{s % 60:04.1f}秒"
    return f"{s:.1f}秒"
