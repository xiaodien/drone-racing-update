"""成绩海报：比赛结束生成一张带选手照片的竖图，可以直接发微信群。"""
from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QBrush, QColor, QFont, QImage, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap

W = 1080
MEDAL = [QColor(255, 196, 40), QColor(200, 210, 220), QColor(215, 140, 80)]


def _font(size, bold=False):
    f = QFont("Microsoft YaHei")
    f.setPixelSize(size)
    f.setBold(bold)
    return f


def _photo(p: QPainter, pm: QPixmap, cx, cy, r, ring: QColor, name: str):
    path = QPainterPath()
    path.addEllipse(QRectF(cx - r, cy - r, 2 * r, 2 * r))
    if pm and not pm.isNull():
        s = pm.scaled(int(2 * r), int(2 * r), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        p.save()
        p.setClipPath(path)
        p.drawPixmap(int(cx - s.width() / 2), int(cy - s.height() / 2), s)
        p.restore()
    else:
        p.fillPath(path, QColor(60, 66, 80))
        p.setPen(QColor(230, 230, 230))
        p.setFont(_font(int(r * 0.8), True))
        p.drawText(QRectF(cx - r, cy - r, 2 * r, 2 * r), Qt.AlignCenter, name[:1])
    p.setPen(QPen(ring, max(4, r / 12)))
    p.setBrush(Qt.NoBrush)
    p.drawEllipse(QRectF(cx - r, cy - r, 2 * r, 2 * r))


def make_poster(title: str, subtitle: str, rows: list[dict], columns: list[str], footer: str = "") -> QImage:
    """rows: [{rank, name, label, photo(QPixmap), cells: [与 columns 对应的文字]}]，已经按名次排好"""
    podium = rows[:3]
    H = 420 + (460 if podium else 0) + 90 + 84 * max(len(rows), 1) + 120
    img = QImage(W, H, QImage.Format_RGB32)
    p = QPainter(img)
    p.setRenderHint(QPainter.Antialiasing)
    p.setRenderHint(QPainter.SmoothPixmapTransform)
    g = QLinearGradient(0, 0, 0, H)
    g.setColorAt(0, QColor(14, 20, 48))
    g.setColorAt(1, QColor(30, 12, 52))
    p.fillRect(0, 0, W, H, QBrush(g))
    # 标题
    p.setPen(QColor(120, 220, 255))
    p.setFont(_font(30, True))
    p.drawText(QRectF(0, 60, W, 44), Qt.AlignCenter, "无人机竞速 · 比赛成绩")
    p.setPen(QColor(255, 255, 255))
    p.setFont(_font(64, True))
    p.drawText(QRectF(40, 120, W - 80, 100), Qt.AlignCenter | Qt.TextWordWrap, title)
    p.setPen(QColor(190, 196, 220))
    p.setFont(_font(30))
    p.drawText(QRectF(40, 240, W - 80, 50), Qt.AlignCenter, subtitle)
    y = 330
    # 领奖台：第二名 左，第一名 中，第三名 右
    if podium:
        spots = {0: (W / 2, 150, 0), 1: (W / 2 - 330, 115, 60), 2: (W / 2 + 330, 115, 90)}
        for k, r in enumerate(podium):
            cx, rad, dy = spots[k]
            cy = y + 40 + rad + dy
            _photo(p, r.get("photo"), cx, cy, rad, MEDAL[k], r["name"])
            p.setBrush(MEDAL[k])
            p.setPen(Qt.NoPen)
            p.drawEllipse(QRectF(cx + rad * 0.55, cy - rad - 6, 56, 56))
            p.setPen(QColor(30, 30, 30))
            p.setFont(_font(30, True))
            p.drawText(QRectF(cx + rad * 0.55, cy - rad - 6, 56, 56), Qt.AlignCenter, str(k + 1))
            p.setPen(QColor(255, 255, 255))
            p.setFont(_font(36 if k == 0 else 30, True))
            p.drawText(QRectF(cx - 170, cy + rad + 14, 340, 46), Qt.AlignCenter, r["name"])
            p.setPen(MEDAL[k])
            p.setFont(_font(26))
            p.drawText(QRectF(cx - 170, cy + rad + 58, 340, 36), Qt.AlignCenter, r.get("podium", ""))
        y += 460
    # 完整名次表
    x0, x1 = 50, W - 50
    p.setPen(QColor(150, 160, 190))
    p.setFont(_font(24, True))
    widths = [90, 380] + [(x1 - x0 - 470) / max(len(columns), 1)] * len(columns)
    heads = ["名次", "选手"] + columns
    x = x0
    for wd, t in zip(widths, heads):
        p.drawText(QRectF(x, y + 30, wd, 40), Qt.AlignCenter, t)
        x += wd
    y += 80
    for k, r in enumerate(rows):
        if k % 2 == 0:
            p.fillRect(QRectF(x0, y, x1 - x0, 80), QColor(255, 255, 255, 14))
        _photo(p, r.get("photo"), x0 + 90 + 40, y + 40, 30, MEDAL[k] if k < 3 else QColor(120, 130, 160), r["name"])
        cells = [str(r["rank"]), ""] + list(r["cells"])
        x = x0
        for c, (wd, t) in enumerate(zip(widths, cells)):
            p.setPen(MEDAL[k] if (c == 0 and k < 3) else QColor(240, 240, 245))
            p.setFont(_font(28, c == 0))
            if c == 1:
                p.drawText(QRectF(x + 90, y, wd - 90, 80), Qt.AlignVCenter | Qt.AlignLeft, r.get("label") or r["name"])
            else:
                p.drawText(QRectF(x, y, wd, 80), Qt.AlignCenter, t)
            x += wd
        y += 84
    p.setPen(QColor(130, 136, 160))
    p.setFont(_font(22))
    p.drawText(QRectF(0, H - 80, W, 40), Qt.AlignCenter, footer)
    p.end()
    return img
