"""Stick overlay drawn on top of live and replayed video (Mode 2: left = throttle/yaw, right = pitch/roll)."""
from bisect import bisect_left

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPen, QPolygonF

TRAIL_S = 0.5
LEFT_COLOR = QColor(255, 196, 0)
RIGHT_COLOR = QColor(0, 200, 255)
CURVE_COLORS = {"thr": LEFT_COLOR, "yaw": QColor(255, 120, 60), "pitch": RIGHT_COLOR, "roll": QColor(120, 220, 120)}
CURVE_LABELS = {"thr": "油门", "yaw": "偏航", "pitch": "俯仰", "roll": "横滚"}


def _box_point(box: QRectF, x: float, y: float) -> QPointF:
    return QPointF(box.center().x() + x * box.width() / 2, box.center().y() - y * box.height() / 2)


def _draw_box(p: QPainter, box: QRectF, color: QColor, trail: list[tuple[float, float]], label: str):
    p.setPen(QPen(QColor(255, 255, 255, 90), 1))
    p.setBrush(QColor(0, 0, 0, 25))
    p.drawRoundedRect(box, 8, 8)
    p.setPen(QPen(QColor(255, 255, 255, 50), 1, Qt.DashLine))
    p.drawLine(QPointF(box.left(), box.center().y()), QPointF(box.right(), box.center().y()))
    p.drawLine(QPointF(box.center().x(), box.top()), QPointF(box.center().x(), box.bottom()))

    n = len(trail)
    for i in range(1, n):
        c = QColor(color)
        c.setAlpha(int(220 * i / n))
        p.setPen(QPen(c, max(1.5, box.width() / 60), Qt.SolidLine, Qt.RoundCap))
        p.drawLine(_box_point(box, *trail[i - 1]), _box_point(box, *trail[i]))

    if trail:
        pt = _box_point(box, *trail[-1])
        r = max(5.0, box.width() / 14)
        p.setPen(QPen(color, 3))
        p.setBrush(QColor(255, 255, 255))
        p.drawEllipse(pt, r, r)

    p.setPen(QColor(255, 255, 255, 230))
    f = QFont()
    f.setPixelSize(max(10, int(box.width() / 9)))
    p.setFont(f)
    p.drawText(QRectF(box.left() - 20, box.bottom() + 2, box.width() + 40, f.pixelSize() * 1.6),
               Qt.AlignHCenter | Qt.AlignTop, label)


def draw_overlay(p: QPainter, video: QRectF, now: dict | None, trail: list[dict], bottom_inset: float = 0.0):
    """bottom_inset: height at the bottom of the picture covered by something else (the replay graph)."""
    p.setRenderHint(QPainter.Antialiasing)
    if not now:
        p.setPen(QColor(255, 255, 255, 200))
        p.drawText(video.adjusted(10, 10, -10, -10), Qt.AlignLeft | Qt.AlignBottom, "遥控器未连接或未校准")
        return
    size = video.height() * 0.24
    margin = video.height() * 0.01
    label_h = size / 9 * 1.8
    # Both sticks side by side at the bottom centre of the picture
    gap = size * 0.25
    top = video.bottom() - bottom_inset - margin - label_h - size
    left = QRectF(video.center().x() - gap / 2 - size, top, size, size)
    right = QRectF(video.center().x() + gap / 2, top, size, size)
    pts = trail + [now]
    _draw_box(p, left, LEFT_COLOR, [(s["yaw"], s["thr"]) for s in pts],
              f'油门 {round((now["thr"] + 1) * 50):>3}%   偏航 {round(now["yaw"] * 100):+d}')
    _draw_box(p, right, RIGHT_COLOR, [(s["roll"], s["pitch"]) for s in pts],
              # Pilots read pulling the stick back (down) as positive pitch, so the number is flipped;
              # the dot still moves the way the stick does.
              f'俯仰 {round(-now["pitch"] * 100):+d}   横滚 {round(now["roll"] * 100):+d}')

    # "未解锁" centred just above the sticks while disarmed; nothing once armed
    if now["armed"]:
        return
    bw, bh = size * 0.8, size * 0.22
    badge = QRectF(video.center().x() - bw / 2, top - bh - size * 0.08, bw, bh)
    p.setPen(Qt.NoPen)
    p.setBrush(QColor(80, 80, 80, 180))
    p.drawRoundedRect(badge, 6, 6)
    p.setPen(QColor(255, 255, 255))
    f = QFont()
    f.setPixelSize(max(10, int(badge.height() * 0.55)))
    f.setBold(True)
    p.setFont(f)
    p.drawText(badge, Qt.AlignCenter, "未解锁")

def fit_rect(outer: QRectF, w: int, h: int) -> QRectF:
    if w <= 0 or h <= 0:
        return outer
    scale = min(outer.width() / w, outer.height() / h)
    rw, rh = w * scale, h * scale
    return QRectF(outer.center().x() - rw / 2, outer.center().y() - rh / 2, rw, rh)


def shadow_text(p: QPainter, at: QPointF, text: str):
    p.setPen(QColor(0, 0, 0, 110))
    p.drawText(at + QPointF(1, 1), text)
    p.setPen(QColor(240, 240, 240, 170))
    p.drawText(at, text)


def interp_sorted(xs: list[float], ts: list[float], vs: list[float]) -> list[float]:
    """Linear interpolation of vs(ts) at ascending xs, clamped at both ends (like numpy.interp)."""
    out, last = [], len(ts) - 1
    j = max(0, bisect_left(ts, xs[0]) - 1) if xs else 0
    for x in xs:
        while j < last and ts[j + 1] < x:
            j += 1
        if x <= ts[0]:
            out.append(vs[0])
        elif j >= last:
            out.append(vs[last])
        else:
            a, b = ts[j], ts[j + 1]
            out.append(vs[j] + (vs[j + 1] - vs[j]) * ((x - a) / (b - a) if b > a else 0.0))
    return out


def draw_curves(p: QPainter, rect: QRectF, log, chans: list[str], gain: dict, start_s: float, length_s: float,
                pos_s: float, label_x: float = 6.0) -> list[tuple[float, float, str]]:
    """Stick curves, one lane per channel, thin and see-through like Blackbox Explorer.
    log has .t (seconds) and .ch[name]; times are already shifted by any sync offset.
    Returns (label right edge x, lane top y, channel) so the caller can put buttons after each label."""
    out = []
    if not chans:
        return out
    w, h = rect.width(), rect.height()
    row_h = h / len(chans)
    n = max(2, int(w))
    xs = [start_s + length_s * i / (n - 1) for i in range(n)]
    # Only draw where there is data: before take-off and after the end the window is empty
    valid = [i for i, x in enumerate(xs) if log.t[0] <= x <= log.t[-1]]
    p.setRenderHint(QPainter.Antialiasing)
    fm = p.fontMetrics()
    for r, c in enumerate(chans):
        mid = rect.top() + row_h * r + row_h / 2
        g = gain.get(c, 1.0)
        ys = [min(max(v * g, -1.15), 1.15) for v in interp_sorted([xs[i] for i in valid], log.t, log.ch[c])]
        poly = QPolygonF([QPointF(rect.left() + i * w / (n - 1), mid - y * row_h * 0.42) for i, y in zip(valid, ys)])
        p.setPen(QPen(QColor(0, 0, 0, 50), 2.4))
        p.drawPolyline(poly)
        col = QColor(CURVE_COLORS[c])
        col.setAlpha(170)
        p.setPen(QPen(col, 1.1))
        p.drawPolyline(poly)
        y0 = rect.top() + row_h * r + 4
        label = f"{CURVE_LABELS[c]} ×{gain.get(c, 1.0):.1f}"
        shadow_text(p, QPointF(rect.left() + label_x, y0 + 12), label)
        out.append((rect.left() + label_x + fm.horizontalAdvance(label), y0, c))
    x = rect.left() + (pos_s - start_s) / length_s * w
    p.setPen(QPen(QColor(255, 255, 255, 150), 1))
    p.drawLine(QPointF(x, rect.top()), QPointF(x, rect.bottom()))
    return out
