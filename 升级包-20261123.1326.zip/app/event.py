"""比赛分组和多轮：人多于计时器路数时自动分组，飞几轮预赛按名次给积分，积分前几名进决赛。

一个赛事存成「比赛成绩/赛事/赛事名.json」，软件关了再开也能接着飞。
"""
import json
import random
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QAbstractItemView, QDialog, QFormLayout, QGroupBox, QHBoxLayout,
                               QHeaderView, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox,
                               QPushButton, QSpinBox, QTableWidget, QTableWidgetItem, QVBoxLayout)

DEFAULT_POINTS = [10, 8, 6, 4]
FINAL = "决赛"


def event_dir(root) -> Path:
    return Path(root) / "比赛成绩" / "赛事"


class Event:
    def __init__(self, path: Path, data: dict):
        self.path = path
        self.d = data

    # ---- 存取
    @classmethod
    def create(cls, root, name, pilots, rounds, heat_size, points, channels):
        d = dict(name=name, created=datetime.now().isoformat(timespec="seconds"), pilots=list(pilots),
                 rounds=rounds, heat_size=heat_size, points=list(points), heats=[])
        ev = cls(event_dir(root) / f"{name}.json", d)
        ev.make_heats(channels)
        ev.save()
        return ev

    @classmethod
    def load(cls, path):
        path = Path(path)
        return cls(path, json.loads(path.read_text(encoding="utf-8")))

    @staticmethod
    def list(root):
        folder = event_dir(root)
        return sorted(folder.glob("*.json"), key=lambda f: f.stat().st_mtime, reverse=True) if folder.is_dir() else []

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self.d, ensure_ascii=False, indent=1), encoding="utf-8")

    @property
    def name(self):
        return self.d["name"]

    @property
    def heats(self):
        return self.d["heats"]

    # ---- 分组：每一轮打乱一次，人数平均分；同一组尽量不撞频道
    def make_heats(self, channels: dict):
        pilots = self.d["pilots"]
        size = self.d["heat_size"]
        n_heats = max(1, -(-len(pilots) // size))
        heats = []
        for rnd in range(1, self.d["rounds"] + 1):
            order = pilots[:]
            random.Random(f"{self.name}-{rnd}").shuffle(order)
            groups = [[] for _ in range(n_heats)]
            for name in order:
                ch = channels.get(name)
                cap = -(-len(pilots) // n_heats)
                free = [g for g in groups if len(g) < cap and not (ch and ch in [channels.get(x) for x in g])]
                pool = free or [g for g in groups if len(g) < cap] or groups
                min(pool, key=len).append(name)
            for k, g in enumerate(groups, 1):
                heats.append(dict(round=rnd, heat=k, pilots=g, done=False, result=[]))
        self.d["heats"] = heats

    def make_final(self):
        top = [x["pilot"] for x in self.standings(include_final=False)[:self.d["heat_size"]]]
        self.d["heats"] = [h for h in self.heats if h["round"] != FINAL]
        self.d["heats"].append(dict(round=FINAL, heat=1, pilots=top, done=False, result=[]))
        self.save()
        return len(self.heats) - 1

    def has_final(self):
        return any(h["round"] == FINAL for h in self.heats)

    def next_heat(self):
        return next((i for i, h in enumerate(self.heats) if not h["done"]), None)

    def heat_title(self, i):
        h = self.heats[i]
        return "决赛" if h["round"] == FINAL else f"第 {h['round']} 轮 第 {h['heat']} 组"

    # ---- 记成绩：result 是按名次排好的 [{pilot, laps, best, total}]
    def record(self, i, result, file=""):
        h = self.heats[i]
        pts = self.d["points"]
        for k, r in enumerate(result):
            r["rank"] = k + 1
            r["points"] = (pts[k] if k < len(pts) else 0) if r["laps"] > 0 else 0
        h.update(done=True, result=result, file=file, at=datetime.now().isoformat(timespec="seconds"))
        self.save()

    def standings(self, include_final=True):
        tab = {p: dict(pilot=p, points=0, best=None, heats=0) for p in self.d["pilots"]}
        for h in self.heats:
            if not h["done"] or h["round"] == FINAL:
                continue
            for r in h["result"]:
                t = tab.setdefault(r["pilot"], dict(pilot=r["pilot"], points=0, best=None, heats=0))
                t["points"] += r["points"]
                t["heats"] += 1
                if r.get("best") and (t["best"] is None or r["best"] < t["best"]):
                    t["best"] = r["best"]
        rows = sorted(tab.values(), key=lambda t: (-t["points"], t["best"] if t["best"] else 1e9))
        final = next((h for h in self.heats if h["round"] == FINAL and h["done"]), None)
        if include_final and final:
            order = [r["pilot"] for r in final["result"]]
            for t in rows:
                t["final"] = order.index(t["pilot"]) + 1 if t["pilot"] in order else None
            rows.sort(key=lambda t: (t["final"] is None, t["final"] or 0))
        return rows


class NewEventDialog(QDialog):
    def __init__(self, names, max_heat, parent=None):
        super().__init__(parent)
        self.setWindowTitle("新建赛事")
        self.resize(460, 560)
        self.name = QLineEdit(datetime.now().strftime("%Y-%m-%d 比赛"))
        self.rounds = QSpinBox(minimum=1, maximum=10, value=3, suffix=" 轮")
        self.heat_size = QSpinBox(minimum=1, maximum=max_heat, value=max_heat, suffix=" 人")
        self.points = QLineEdit(",".join(str(v) for v in DEFAULT_POINTS))
        self.points.setToolTip("每组第 1、2、3、4 名各得几分，用逗号隔开。0 圈的不得分。")
        self.list = QListWidget()
        for n in names:
            it = QListWidgetItem(n)
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked)
            self.list.addItem(it)
        all_btn = QPushButton("全选")
        all_btn.clicked.connect(lambda: self._check_all(Qt.Checked))
        none_btn = QPushButton("全不选")
        none_btn.clicked.connect(lambda: self._check_all(Qt.Unchecked))
        form = QFormLayout()
        form.addRow("赛事名称", self.name)
        form.addRow("预赛轮数", self.rounds)
        form.addRow("每组几人", self.heat_size)
        form.addRow("每组名次积分", self.points)
        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(QLabel("参赛选手（勾选）："))
        lay.addWidget(self.list, 1)
        row = QHBoxLayout()
        row.addWidget(all_btn)
        row.addWidget(none_btn)
        row.addStretch()
        ok = QPushButton("生成分组")
        ok.setDefault(True)
        ok.clicked.connect(self._ok)
        cancel = QPushButton("取消")
        cancel.clicked.connect(self.reject)
        row.addWidget(ok)
        row.addWidget(cancel)
        lay.addLayout(row)
        lay.addWidget(QLabel("每轮重新随机分组；同一组尽量不让两个人用同一个频道。\n预赛积分前几名（每组人数）进决赛，决赛名次就是最终名次。"))

    def _check_all(self, st):
        for i in range(self.list.count()):
            self.list.item(i).setCheckState(st)

    def _ok(self):
        self.pilots = [self.list.item(i).text() for i in range(self.list.count())
                       if self.list.item(i).checkState() == Qt.Checked]
        try:
            self.pts = [int(v) for v in self.points.text().replace("，", ",").split(",") if v.strip()]
        except ValueError:
            QMessageBox.warning(self, "新建赛事", "积分要填数字，用逗号隔开，比如 10,8,6,4")
            return
        if len(self.pilots) < 2:
            QMessageBox.warning(self, "新建赛事", "至少选 2 个选手。")
            return
        if not self.name.text().strip():
            QMessageBox.warning(self, "新建赛事", "填一个赛事名称。")
            return
        self.accept()


class EventDialog(QDialog):
    """赛事总表：分组和每组成绩、积分榜；可以选一组拿去飞"""

    def __init__(self, ev: Event, label, parent=None):
        super().__init__(parent)
        self.ev = ev
        self.label = label
        self.chosen = None
        self.want_poster = False
        self.setWindowTitle(f"赛事：{ev.name}")
        self.resize(980, 640)
        self.heats = QTableWidget(0, 4)
        self.heats.setHorizontalHeaderLabels(["分组", "选手", "状态", "成绩（名次 · 积分）"])
        self.heats.verticalHeader().setVisible(False)
        self.heats.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.heats.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.heats.setSelectionMode(QAbstractItemView.SingleSelection)
        hh = self.heats.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(3, QHeaderView.Stretch)
        self.heats.doubleClicked.connect(self._fly)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["名次", "选手", "积分", "最快一圈", "决赛"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        fly = QPushButton("飞选中的这一组")
        fly.setStyleSheet("QPushButton { font-weight: bold; }")
        fly.clicked.connect(self._fly)
        self.final_btn = QPushButton("生成决赛")
        self.final_btn.clicked.connect(self._final)
        poster = QPushButton("生成积分榜海报")
        poster.clicked.connect(self._poster)
        close = QPushButton("关闭")
        close.clicked.connect(self.reject)
        g1 = QGroupBox("分组（双击一组就去飞这一组）")
        QVBoxLayout(g1).addWidget(self.heats)
        g2 = QGroupBox("积分榜")
        QVBoxLayout(g2).addWidget(self.table)
        mid = QHBoxLayout()
        mid.addWidget(g1, 3)
        mid.addWidget(g2, 2)
        row = QHBoxLayout()
        row.addWidget(fly)
        row.addWidget(self.final_btn)
        row.addWidget(poster)
        row.addStretch()
        row.addWidget(close)
        lay = QVBoxLayout(self)
        lay.addLayout(mid, 1)
        lay.addLayout(row)
        self._fill()

    def _fill(self):
        ev = self.ev
        self.heats.setRowCount(len(ev.heats))
        nxt = ev.next_heat()
        for i, h in enumerate(ev.heats):
            res = "   ".join(f"{r['rank']}.{r['pilot']} {r['points']}分" for r in h["result"]) if h["done"] else ""
            vals = [ev.heat_title(i), "、".join(h["pilots"]), "飞完" if h["done"] else ("下一组" if i == nxt else "没飞"), res]
            for c, v in enumerate(vals):
                it = QTableWidgetItem(v)
                if i == nxt:
                    it.setForeground(Qt.darkGreen)
                self.heats.setItem(i, c, it)
        if nxt is not None:
            self.heats.selectRow(nxt)
        rows = ev.standings()
        self.table.setRowCount(len(rows))
        for k, t in enumerate(rows):
            vals = [str(k + 1), self.label(t["pilot"]), str(t["points"]), f"{t['best']:.2f}" if t["best"] else "",
                    str(t.get("final") or "")]
            for c, v in enumerate(vals):
                it = QTableWidgetItem(v)
                it.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(k, c, it)
        prelim_done = all(h["done"] for h in ev.heats if h["round"] != FINAL)
        self.final_btn.setEnabled(prelim_done)
        self.final_btn.setText("重新生成决赛" if ev.has_final() else "生成决赛")

    def _fly(self, *_):
        rows = self.heats.selectionModel().selectedRows()
        if not rows:
            return
        i = rows[0].row()
        if self.ev.heats[i]["done"] and QMessageBox.question(
                self, "赛事", "这一组已经飞过了，重飞会覆盖原来的成绩。确定重飞？") != QMessageBox.Yes:
            return
        self.chosen = i
        self.accept()

    def _final(self):
        if self.ev.has_final() and QMessageBox.question(self, "赛事", "已经有决赛了，重新生成会清掉决赛成绩。确定？") != QMessageBox.Yes:
            return
        i = self.ev.make_final()
        self._fill()
        self.heats.selectRow(i)

    def _poster(self):
        self.want_poster = True
        self.accept()
