"""Radio test window: live bars for every channel, so the radio or ELRS receiver can be checked
without starting the capture card."""
import time

from PySide6.QtCore import QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import QDialog, QLabel, QVBoxLayout, QWidget

from app.sticks import is_wireless

# EdgeTX default channel order (AETR); CH5 is usually the arm switch.
CH_NAMES = {0: "横滚", 1: "俯仰", 2: "油门", 3: "偏航", 4: "解锁开关"}


class ChannelBars(QWidget):
    ROW_H = 24

    def __init__(self, parent=None):
        super().__init__(parent)
        self.values: tuple = ()
        self.setMinimumHeight(self.ROW_H * 16)

    def set_values(self, values):
        self.values = tuple(values)
        self.setMinimumHeight(self.ROW_H * max(1, len(self.values)))
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        label_w, num_w = 120, 64
        bar_l, bar_r = label_w, self.width() - num_w
        mid = (bar_l + bar_r) / 2
        if not self.values:
            p.setPen(QColor(130, 130, 130))
            p.drawText(self.rect(), Qt.AlignCenter, "还没有收到遥控器数据")
            return
        for i, v in enumerate(self.values):
            y = i * self.ROW_H
            name = f"CH{i + 1}" + (f" {CH_NAMES[i]}" if i in CH_NAMES else "")
            p.setPen(QColor(60, 60, 60))
            p.drawText(QRectF(4, y, label_w - 8, self.ROW_H), Qt.AlignVCenter | Qt.AlignLeft, name)
            track = QRectF(bar_l, y + 6, bar_r - bar_l, self.ROW_H - 12)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(230, 230, 230))
            p.drawRoundedRect(track, 3, 3)
            x = mid + v * (bar_r - bar_l) / 2
            p.setBrush(QColor(0, 160, 230) if i < 4 else QColor(255, 170, 0))
            p.drawRect(QRectF(min(mid, x), track.top(), abs(x - mid), track.height()))
            p.setPen(QPen(QColor(120, 120, 120), 1))
            p.drawLine(int(mid), int(track.top()) - 2, int(mid), int(track.bottom()) + 2)
            p.setPen(QColor(60, 60, 60))
            p.drawText(QRectF(bar_r + 4, y, num_w - 4, self.ROW_H), Qt.AlignVCenter | Qt.AlignRight,
                       f"{v * 100:+.0f}%")


class RadioTestDialog(QDialog):
    def __init__(self, source, parent=None):
        super().__init__(parent)
        self.source = source
        self.setWindowTitle("遥控器测试")
        self.resize(560, 620)
        self.status = QLabel()
        self.status.setStyleSheet("font-size: 15px; font-weight: bold;")
        self.detail = QLabel()
        self.detail.setStyleSheet("color: gray;")
        self.bars = ChannelBars()
        tip = QLabel("动一下摇杆和开关，对应的条应该跟着动。\n"
                     "一直不动：关掉这个窗口，点右上角「诊断」，把报告发给开发者。")
        tip.setStyleSheet("color: gray;")
        lay = QVBoxLayout(self)
        lay.addWidget(self.status)
        lay.addWidget(self.detail)
        lay.addWidget(self.bars, 1)
        lay.addWidget(tip)
        self._last_frames, self._last_t, self._rate = 0, time.perf_counter(), 0.0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(40)
        self._tick()

    def _tick(self):
        src = self.source
        name = src.connected_name
        latest = src.latest()
        fresh = latest is not None and time.perf_counter() - latest[0] < 2.0
        reader = getattr(src, "_crsf", None)
        if not name:
            self.status.setText("遥控器：未连接")
            self.status.setStyleSheet("font-size: 15px; font-weight: bold; color: #d22;")
            names = [n for n in getattr(src, "device_names", []) if n]
            self.detail.setText("能选的设备：" + ("、".join(names) if names else "无"))
            self.bars.set_values(())
            return
        linked = fresh and (not is_wireless(name) or bool(latest[2] & 1))
        self.status.setText(f"遥控器：{name}   " + ("● 有信号" if linked else "○ 没信号"))
        self.status.setStyleSheet("font-size: 15px; font-weight: bold; color: %s;" % ("#1a1" if linked else "#d22"))
        if reader:
            st = reader.stats
            now = time.perf_counter()
            if now - self._last_t >= 1.0:
                self._rate = (st["frames"] - self._last_frames) / (now - self._last_t)
                self._last_frames, self._last_t = st["frames"], now
            text = f"串口 {reader.port}  波特率 {st['baud']}  每秒 {self._rate:.0f} 帧  共收到 {st['bytes']} 字节"
            if st["bytes"] > 2000 and not st["frames"]:
                text += ("\n有数据但解不出遥控信号：串口速度对不上。"
                         "把接收机的串口波特率（UART baud）改成 115200 再试。")
            self.detail.setText(text)
        else:
            self.detail.setText("")
        self.bars.set_values(latest[1] if latest else ())

    def done(self, r):
        self.timer.stop()
        super().done(r)
