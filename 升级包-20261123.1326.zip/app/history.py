"""学员成长记录：把「比赛成绩」文件夹里每一场的成绩按学员、按赛道排出来，画成曲线看进步。"""
import json
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPen, QPolygonF
from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QDialog, QHBoxLayout, QHeaderView, QLabel,
                               QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

ALL_TRACKS = "全部赛道"


def load_results(root: Path) -> list[dict]:
    """每个学员每一场一条：{pilot, when, track, name, best, avg, laps, rank, total_pilots}"""
    out = []
    folder = Path(root) / "比赛成绩"
    if not folder.is_dir():
        return out
    for f in folder.rglob("*.json"):
        if "赛事" in f.parts:
            continue
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
            when = datetime.fromisoformat(d["began"])
        except (OSError, ValueError, KeyError, TypeError):
            continue
        res = d.get("results", [])
        for r in res:
            laps = [v for v in r.get("laps_s", []) if v]
            if not laps:
                continue
            out.append(dict(pilot=r.get("pilot", ""), when=when, track=d.get("track") or "没填赛道",
                            name=d.get("name") or " ".join(v for v in (d.get("event"), d.get("heat")) if v), best=min(laps), avg=sum(laps) / len(laps), laps=len(laps),
                            rank=r.get("rank"), total_pilots=len(res), file=f))
    out.sort(key=lambda x: x["when"])
    return out


class GrowthChart(QWidget):
    """横轴：第几场；纵轴：秒（越低越快）。紫线最快一圈，蓝线平均一圈。"""

    def __init__(self):
        super().__init__()
        self.items = []
        self.setMinimumHeight(260)

    def set_items(self, items):
        self.items = items
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor(24, 26, 32))
        L, R, T, B = 56, 16, 30, 34
        w, h = self.width() - L - R, self.height() - T - B
        p.setPen(QColor(200, 200, 200))
        if len(self.items) < 1:
            p.drawText(self.rect(), Qt.AlignCenter, "还没有成绩。\n在比赛模式飞完一场（训练赛也行），成绩会自动记到这里。")
            return
        vals = [x["best"] for x in self.items] + [x["avg"] for x in self.items]
        lo, hi = min(vals), max(vals)
        pad = max(0.5, (hi - lo) * 0.15)
        lo, hi = lo - pad, hi + pad
        n = len(self.items)

        def X(i):
            return L + (w * i / (n - 1) if n > 1 else w / 2)

        def Y(v):
            return T + h * (v - lo) / (hi - lo)       # 上面快、下面慢

        f = QFont()
        f.setPointSize(9)
        p.setFont(f)
        for k in range(5):
            v = lo + (hi - lo) * k / 4
            y = Y(v)
            p.setPen(QPen(QColor(70, 72, 80), 1, Qt.DotLine))
            p.drawLine(L, int(y), L + w, int(y))
            p.setPen(QColor(170, 170, 170))
            p.drawText(4, int(y) + 4, f"{v:.1f}秒")
        step = max(1, n // 8)
        for i in range(0, n, step):
            p.drawText(int(X(i)) - 24, T + h + 20, self.items[i]["when"].strftime("%m-%d"))
        for key, col, label in (("avg", QColor(80, 170, 255), "平均一圈"), ("best", QColor(200, 90, 255), "最快一圈")):
            pts = QPolygonF([QPointF(X(i), Y(x[key])) for i, x in enumerate(self.items)])
            p.setPen(QPen(col, 2.5))
            p.drawPolyline(pts)
            p.setBrush(col)
            for q in pts:
                p.drawEllipse(q, 3.5, 3.5)
        p.setPen(QColor(200, 90, 255))
        p.drawText(L, 18, "● 最快一圈")
        p.setPen(QColor(80, 170, 255))
        p.drawText(L + 100, 18, "● 平均一圈")
        p.setPen(QColor(170, 170, 170))
        p.drawText(L + 200, 18, "越往上越快")


class GrowthDialog(QDialog):
    def __init__(self, root, names, current="", parent=None):
        super().__init__(parent)
        self.setWindowTitle("学员成长记录")
        self.resize(900, 640)
        self.all = load_results(Path(root))
        names = list(dict.fromkeys(list(names) + [x["pilot"] for x in self.all]))
        self.pilot = QComboBox()
        self.pilot.addItems(names)
        if current in names:
            self.pilot.setCurrentText(current)
        self.track = QComboBox()
        self.summary = QLabel()
        self.summary.setWordWrap(True)
        f = QFont()
        f.setPointSize(12)
        self.summary.setFont(f)
        self.chart = GrowthChart()
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(["日期", "赛道", "比赛", "圈数", "最快一圈", "平均一圈", "名次"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        top = QHBoxLayout()
        top.addWidget(QLabel("学员"))
        top.addWidget(self.pilot)
        top.addWidget(QLabel("赛道"))
        top.addWidget(self.track)
        top.addStretch()
        lay = QVBoxLayout(self)
        lay.addLayout(top)
        lay.addWidget(self.summary)
        lay.addWidget(self.chart, 3)
        lay.addWidget(self.table, 2)
        lay.addWidget(QLabel("成绩来自比赛模式每一场的记录。不同赛道圈速不能比，选一条赛道看最准。"))
        self.pilot.currentTextChanged.connect(self._pilot_changed)
        self.track.currentTextChanged.connect(self._refresh)
        self._pilot_changed()

    def _pilot_changed(self):
        mine = [x for x in self.all if x["pilot"] == self.pilot.currentText()]
        tracks = list(dict.fromkeys(x["track"] for x in reversed(mine)))
        self.track.blockSignals(True)
        self.track.clear()
        self.track.addItems(tracks + [ALL_TRACKS] if tracks else [ALL_TRACKS])
        self.track.blockSignals(False)
        self._refresh()

    def _refresh(self):
        t = self.track.currentText()
        items = [x for x in self.all if x["pilot"] == self.pilot.currentText() and (t == ALL_TRACKS or x["track"] == t)]
        self.chart.set_items(items)
        self.table.setRowCount(len(items))
        for k, x in enumerate(reversed(items)):
            vals = [x["when"].strftime("%Y-%m-%d %H:%M"), x["track"], x["name"], str(x["laps"]), f"{x['best']:.2f}",
                    f"{x['avg']:.2f}", f"{x['rank']} / {x['total_pilots']}" if x["rank"] else ""]
            for c, v in enumerate(vals):
                it = QTableWidgetItem(v)
                it.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(k, c, it)
        if not items:
            self.summary.setText("这个学员还没有成绩。")
            return
        best = min(items, key=lambda x: x["best"])
        text = f"一共 {len(items)} 场，个人最快一圈 {best['best']:.2f} 秒（{best['when']:%m-%d}）。"
        if len(items) >= 2:
            k = max(1, len(items) // 3)
            first = sum(x["avg"] for x in items[:k]) / k
            last = sum(x["avg"] for x in items[-k:]) / k
            d = first - last
            text += (f" 平均一圈比刚开始快了 {d:.2f} 秒，进步了！" if d > 0.05 else
                     f" 平均一圈比刚开始慢了 {-d:.2f} 秒，要加油。" if d < -0.05 else " 平均一圈跟刚开始差不多。")
        self.summary.setText(text)
