from PySide6.QtCore import QRect, QRectF, Qt
from PySide6.QtGui import QColor, QFont, QImage, QPainter
from PySide6.QtWidgets import QSizePolicy, QWidget

from app.overlay import draw_overlay, fit_rect


class VideoCanvas(QWidget):
    """Draws a video frame with the stick overlay and an optional corner badge."""

    def __init__(self, placeholder: str):
        super().__init__()
        self.image: QImage | None = None
        self.values = None
        self.trail: list[dict] = []
        self.badge = ""
        self.channel = ""
        self.placeholder = placeholder
        self.bottom_widget: QWidget | None = None   # the replay stick graph, laid over the video
        self.left_widget: QWidget | None = None     # the replay curve switches, at the left edge of the video
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumSize(480, 270)
        self.painted = 0   # frames actually drawn, for the on-screen fps readout

    def paintEvent(self, _):
        p = QPainter(self)
        left_w = 0
        side = self.left_widget
        if side is not None:
            side.setVisible(self.image is not None)
            if self.image is not None:
                video = fit_rect(QRectF(self.rect()), self.image.width(), self.image.height())
                hint = side.sizeHint()
                geom = QRect(round(video.left()) + 8, round(video.center().y() - hint.height() / 2),
                             hint.width(), hint.height())
                if side.geometry() != geom:
                    side.setGeometry(geom)
                side.raise_()
                left_w = hint.width() + 16
        w = self.bottom_widget
        if w is not None and w.isVisible() and self.image is not None:
            video = fit_rect(QRectF(self.rect()), self.image.width(), self.image.height())
            # Replay graph across the whole width so its play line sits in the middle of the picture,
            # between the two stick boxes; its labels start right of the curve switches
            gh = round(video.height() * 0.44)
            geom = QRect(round(video.left()), round(video.center().y() - gh / 2), round(video.width()), gh)
            w.label_x = left_w + 4
            if w.geometry() != geom:
                w.setGeometry(geom)
        paint_frame(p, QRectF(self.rect()), self.image, self.values, self.trail, self.channel, self.badge,
                    self.placeholder)
        self.painted += 1


def paint_frame(p: QPainter, outer: QRectF, image: QImage | None, values, trail, channel="", badge="",
                placeholder="", bottom_inset=0.0):
    """Video + sticks + channel + badge. Shared by the on-screen canvas and video export."""
    p.fillRect(outer, QColor(16, 16, 16))
    if image is not None:
        video = fit_rect(outer, image.width(), image.height())
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.drawImage(video, image)
    else:
        video = fit_rect(outer, 16, 9)
        p.setPen(QColor(160, 160, 160))
        f = QFont()
        f.setPixelSize(18)
        p.setFont(f)
        p.drawText(video, Qt.AlignCenter, placeholder)
    draw_overlay(p, video, values, trail, bottom_inset)
    if channel:
        f = QFont()
        f.setPixelSize(max(12, int(video.height() * 0.036)))
        f.setBold(True)
        p.setFont(f)
        text = f"频道 {channel}"
        w = p.fontMetrics().horizontalAdvance(text) + 20
        # Top-left corner, on the black side bar of a 4:3 picture, so it covers nothing
        r = QRectF(video.left() + 10, video.top() + 10, w, f.pixelSize() * 1.7)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(0, 0, 0, 170))
        p.drawRoundedRect(r, 6, 6)
        p.setPen(QColor(255, 220, 0))
        p.drawText(r, Qt.AlignCenter, text)
    if badge:
        f = QFont()
        f.setPixelSize(max(12, int(video.height() * 0.04)))
        f.setBold(True)
        p.setFont(f)
        w = p.fontMetrics().horizontalAdvance(badge) + 24
        h = f.pixelSize() * 1.8
        r = QRectF(video.right() - w - 12, video.top() + 12, w, h)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(200, 0, 0, 220))
        p.drawRoundedRect(r, 6, 6)
        p.setPen(QColor(255, 255, 255))
        p.drawText(r, Qt.AlignCenter, badge)
