import os
import sys
import traceback

# Software video decoding for replay: hardware-decoded frames can't be converted to images for drawing on some PCs.
os.environ.setdefault("QT_FFMPEG_DECODING_HW_DEVICE_TYPES", "none")

from app.config import USER_DIR

if sys.stderr is None:  # started with pythonw: keep errors in a log file
    sys.stdout = sys.stderr = open(USER_DIR / "app.log", "a", encoding="utf-8", buffering=1)


def _excepthook(kind, value, tb):
    text = "".join(traceback.format_exception(kind, value, tb))
    print(text, file=sys.stderr)
    try:
        from PySide6.QtWidgets import QApplication, QMessageBox
        if QApplication.instance():
            QMessageBox.critical(None, "出错了", f"软件出错，请把下面的内容发给开发者：\n\n{text[-1500:]}")
    except Exception:
        pass


sys.excepthook = _excepthook

from app.main import run  # noqa: E402

run()
