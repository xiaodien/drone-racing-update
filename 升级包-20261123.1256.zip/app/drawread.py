"""看图纸：自动适配不同主办方的赛道图纸，认出场地框、门框符号和指引线（只用 Qt，不用别的库）。

支持两类主流图纸风格（自动判断）：
1. 国赛深蓝粉线风格（navy_pink）：蓝色尺寸线、深蓝门框、粉色指引线。
2. FAI / 多色分层风格（color_multi）：规则 10m 灰网格、按门型分色（绿/蓝/紫/黑）、橙色一层 + 灰带蓝色二层路线。
"""
import colorsys
import math

from PySide6.QtCore import Qt
from PySide6.QtGui import QImage

WORK_W = 1600          # 认图时把图缩到这么宽
JUMP = 45              # 线断了（被门框挡住）最多往前接多少像素
LOOK = 10              # 岔口往每条路看多远比方向


LINE_PPM = 9.0         # 认线时每米几像素（线宽 2~3 像素，太细太粗都不好追）


def pink_pixels(img: QImage, px_per_m=None):
    """返回 (粉色像素集合, 缩放比例 原图像素/工作像素)"""
    ww = int(img.width() * LINE_PPM / px_per_m) if px_per_m else WORK_W
    work = img.scaledToWidth(ww) if img.width() > ww else img   # 不平滑：线的颜色不被冲淡
    work = work.convertToFormat(QImage.Format_RGB888)
    w, h, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())
    px = set()
    for y in range(h):
        row = data[y*bpl:y*bpl + w*3]
        for x in range(0, w*3, 3):
            r = row[x]
            if r > 150:
                g, b = row[x+1], row[x+2]
                if g < 100 and 60 < b < 210 and r - g > 90:
                    px.add((x // 3, y))
    return px, img.width() / w


N8 = ((0, -1), (1, -1), (1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0), (-1, -1))


def thin(px):
    """把粗线削成一个像素宽（Zhang-Suen）"""
    px = set(px)
    changed = True
    while changed:
        changed = False
        for step in (0, 1):
            kill = []
            for (x, y) in px:
                nb = [(x+dx, y+dy) in px for dx, dy in N8]
                b = sum(nb)
                if b < 2 or b > 6:
                    continue
                a = sum(1 for k in range(8) if not nb[k] and nb[(k+1) % 8])
                if a != 1:
                    continue
                P2, P4, P6, P8 = nb[0], nb[2], nb[4], nb[6]
                if step == 0 and (P2 and P4 and P6 or P4 and P6 and P8):
                    continue
                if step == 1 and (P2 and P4 and P8 or P2 and P6 and P8):
                    continue
                kill.append((x, y))
            if kill:
                changed = True
                px.difference_update(kill)
    return px


def _groups(px, link=3):
    left = set(px)
    out = []
    while left:
        seed = left.pop()
        grp, todo = [seed], [seed]
        while todo:
            cx, cy = todo.pop()
            for dx in range(-link, link+1):
                for dy in range(-link, link+1):
                    c = (cx+dx, cy+dy)
                    if c in left:
                        left.remove(c)
                        grp.append(c)
                        todo.append(c)
        out.append(grp)
    return sorted(out, key=len, reverse=True)


def _nbrs(sk, p):
    return [(p[0]+dx, p[1]+dy) for dx, dy in N8 if (p[0]+dx, p[1]+dy) in sk]


def _unit(dx, dy):
    n = math.hypot(dx, dy) or 1.0
    return dx/n, dy/n


def _ang(h, d):
    return abs(math.atan2(h[0]*d[1] - h[1]*d[0], h[0]*d[0] + h[1]*d[1]))


def _walk(sk, prev, cur, n, avoid=()):
    """从 prev->cur 顺着骨架往前走 n 步（岔口挑最直的），返回走到的点"""
    path = [prev, cur]
    for _ in range(n):
        h = _unit(path[-1][0]-path[max(0, len(path)-4)][0], path[-1][1]-path[max(0, len(path)-4)][1])
        c = [q for q in _nbrs(sk, path[-1]) if q not in path[-4:] and q not in avoid]
        if not c:
            break
        path.append(min(c, key=lambda q: _ang(h, (q[0]-path[-1][0], q[1]-path[-1][1]))))
    return path


def _loops_back(sk, cur, q, used):
    """从岔口 cur 往 q 那条路走下去（断了也接上），走一小圈又回到 cur 附近 = 图纸上的小圈"""
    w = trace(sk, [cur, q], used=set(used) | {cur}, limit=260, probe=True)
    return any(math.dist(z, cur) < 30 for z in w[60:])


def trace(sk, start, used=None, limit=200000, probe=False):
    """从线头顺着骨架追到底。start 可以是一个点，也可以是已经走的几个点"""
    path = list(start) if isinstance(start, list) else [start]
    used = set(path) if used is None else used | set(path)
    while len(path) < limit:
        cur = path[-1]
        back = path[max(0, len(path)-8)]
        h = _unit(cur[0]-back[0], cur[1]-back[1]) if len(path) > 1 else None
        cand = [q for q in _nbrs(sk, cur) if q not in path[-6:]]
        nxt = None
        if cand:
            if len(cand) == 1 or h is None:
                fresh = [q for q in cand if q not in used]
                nxt = (fresh or cand)[0]
            else:                                # 岔口：每条路往前看一段，挑最直、没走过的；没走过的小圈先绕
                best = None
                for q in cand:
                    w = _walk(sk, cur, q, LOOK, avoid=set(path[-6:]))
                    d = _unit(w[-1][0]-cur[0], w[-1][1]-cur[1])
                    old = sum(1 for z in w[1:] if z in used) / len(w)
                    score = _ang(h, d) + 1.5*old + (0.6 if len(w) < LOOK//2 else 0)   # 短叉（箭头）扣分
                    if not probe and old == 0 and len(w) >= LOOK//2 and _loops_back(sk, cur, q, used):
                        score -= 3
                    if best is None or score < best[0]:
                        best = (score, q)
                nxt = best[1]
            if nxt in used and h is not None and _ang(h, _unit(nxt[0]-cur[0], nxt[1]-cur[1])) > math.radians(100):
                nxt = None                       # 掉头了：不走
        if nxt is None:                          # 线断了：往前找最近、方向对得上的线
            if h is None:
                break
            best = None
            for q in sk:
                dx, dy = q[0]-cur[0], q[1]-cur[1]
                if abs(dx) > JUMP or abs(dy) > JUMP or q in used:
                    continue
                d = math.hypot(dx, dy)
                if d < 2 or d > JUMP:
                    continue
                a = _ang(h, (dx, dy))
                if a > math.radians(35) and not (d < 22 and a < math.radians(65)):
                    continue
                score = d * (1 + 2*a)
                if best is None or score < best[0]:
                    best = (score, q)
            if best is None:
                break
            nxt = best[1]
        path.append(nxt)
        used.add(nxt)
    return path


def detect_style(img: QImage) -> str:
    """自动识别图纸风格：'navy_pink'（深蓝门+粉线）或 'color_multi'（多色门+橙/蓝分层线）"""
    work = img.scaledToWidth(600) if img.width() > 600 else img
    work = work.convertToFormat(QImage.Format_RGB888)
    w, h, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())
    pink = navy = orange = green = purple = 0
    for y in range(h):
        row = data[y*bpl:y*bpl + w*3]
        for x in range(0, w*3, 3):
            r, g, b = row[x], row[x+1], row[x+2]
            if r > 150 and g < 100 and 60 < b < 210 and r - g > 90:
                pink += 1
            elif r < 120 and g < 120 and b < 160 and b - r >= 15 and b - g >= 10:
                navy += 1
            else:
                mx, mn = max(r, g, b), min(r, g, b)
                if mx - mn < 26 or (mx > 225 and mx - mn < 36):
                    continue
                if r > g > b and r > 130 and r - b > 35 and (g - b) * 2 >= (r - g):
                    orange += 1
                elif g > r + 12 and g > b + 12 and g < 210:
                    green += 1
                elif r > g + 22 and b > g + 18 and abs(r - b) < 70:
                    purple += 1
    if pink >= 60 and navy >= (green + purple):
        return "navy_pink"
    if (green + purple) >= 120 and (orange >= 100 or (green + purple) > navy * 0.6):
        return "color_multi"
    return "navy_pink"


def _multi_route_pixels(img: QImage, px_per_m=None):
    """提取多色分层图纸的路线像素：橙色（一层）+ 灰带上的深蓝（二层）"""
    ww = int(img.width() * LINE_PPM / px_per_m) if px_per_m else WORK_W
    work = img.scaledToWidth(ww) if img.width() > ww else img
    work = work.convertToFormat(QImage.Format_RGB888)
    w, h, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())
    px = set()
    blue_cand = []
    grey = set()
    for y in range(h):
        row = data[y*bpl:y*bpl + w*3]
        for x in range(w):
            r, g, b = row[3*x], row[3*x+1], row[3*x+2]
            mx, mn = max(r, g, b), min(r, g, b)
            diff = mx - mn
            if 130 <= r <= 198 and 130 <= g <= 198 and 130 <= b <= 198 and diff < 18:
                grey.add((x, y))
                continue
            if diff < 28:
                continue
            hh, ss, vv = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
            deg = hh * 360.0
            if 10.0 <= deg <= 45.0 and ss > 0.30 and vv > 0.32:
                px.add((x, y))
            elif 195.0 <= deg <= 255.0 and ss > 0.30 and vv < 0.85:
                blue_cand.append((x, y))
    # 落在灰带（二层）旁边的蓝色像素才算二层路线（避免把外面的蓝门当成路线）
    for x, y in blue_cand:
        if any((x + dx, y + dy) in grey for dx in (-2, 0, 2) for dy in (-2, 0, 2)):
            px.add((x, y))
    return px, img.width() / w


def read_line(img: QImage, start_hint=None, px_per_m=None):
    """认指引线（自动支持粉色线与橙/蓝分层线）。start_hint = 原图像素坐标，返回 [(x, y) 原图像素]"""
    style = detect_style(img)
    px, k = _multi_route_pixels(img, px_per_m) if style == "color_multi" else pink_pixels(img, px_per_m)
    if len(px) < 100:
        return []
    sk = thin(px)
    groups = _groups(sk)
    keep = set(groups[0])                        # 从最大那截开始，离得近（门框挡断的）一截截接上；指北针、图例离得远不要
    near = {(x//25, y//25) for x, y in keep}
    rest = [g for g in groups[1:] if len(g) >= 4]
    grown = True
    while grown:
        grown = False
        for g in list(rest):
            if any((x//25+dx, y//25+dy) in near for x, y in g for dx in (-1, 0, 1) for dy in (-1, 0, 1)):
                keep.update(g)
                near.update((x//25, y//25) for x, y in g)
                rest.remove(g)
                grown = True
    def is_end(p):
        nb = _nbrs(keep, p)
        return len(nb) == 1 or (len(nb) == 2 and max(abs(nb[0][0]-nb[1][0]), abs(nb[0][1]-nb[1][1])) == 1)
    def long_enough(p, n=30):                    # 虚线（去降落点那段）的小短截不算线头
        seen, todo = {p}, [p]
        while todo and len(seen) < n:
            for q in _nbrs(keep, todo.pop()):
                if q not in seen:
                    seen.add(q)
                    todo.append(q)
        return len(seen) >= n
    ends = [p for p in keep if is_end(p) and long_enough(p)] or list(keep)
    if start_hint is not None:
        sx, sy = start_hint[0]/k, start_hint[1]/k
        start = min(ends, key=lambda c: math.hypot(c[0]-sx, c[1]-sy))
    else:
        start = max(ends, key=lambda c: c[1])    # 没有提示就从最下面那个线头开始
    path = trace(keep, start)
    return [((x+0.5)*k, (y+0.5)*k) for x, y in path[::3]]


def _find_grid_field(work: QImage, k: float):
    """找图纸内部的规则正方形 10m 灰色网格框（适用于绿色/灰色/无蓝色尺寸线的各类主办方图纸）"""
    w, h, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())
    mx, my = max(4, int(w * 0.04)), max(4, int(h * 0.04))
    grey_r, grey_c = [0] * h, [0] * w
    for y in range(my, h - my):
        row = data[y*bpl:y*bpl + w*3]
        for x in range(mx, w - mx):
            r, g, b = row[3*x], row[3*x+1], row[3*x+2]
            if 150 < r < 236 and abs(r - g) < 16 and abs(g - b) < 16:
                grey_r[y] += 1
                grey_c[x] += 1

    def peaks(prof, min_v, sep=12):
        cand = [(prof[i], i) for i in range(1, len(prof) - 1)
                if prof[i] >= min_v and prof[i] >= prof[i - 1] and prof[i] >= prof[i + 1]]
        out = []
        for _v, i in sorted(cand, reverse=True):
            if all(abs(i - j) >= sep for j in out):
                out.append(i)
        return sorted(out)

    pr = peaks(grey_r, int(w * 0.22))
    pc = peaks(grey_c, int(h * 0.22))
    diffs = []
    for arr in (pr, pc):
        for i in range(len(arr)):
            for j in range(i + 1, min(len(arr), i + 3)):
                d = arr[j] - arr[i]
                if min(w, h) * 0.04 <= d <= min(w, h) * 0.22:
                    diffs.append(d)
    best = None
    for d in sorted(set(diffs)):
        tol = max(3, d * 0.08)

        def chain(arr):
            best_c = []
            for s in arr:
                c, cur = [s], s
                while True:
                    nxt = [p for p in arr if p > cur and abs((p - cur) - d) <= tol]
                    if nxt:
                        cur = min(nxt, key=lambda p: abs((p - cur) - d))
                        c.append(cur)
                        continue
                    nxt2 = [p for p in arr if p > cur and abs((p - cur) - 2 * d) <= tol * 1.5]
                    if nxt2:
                        cur = min(nxt2, key=lambda p: abs((p - cur) - 2 * d))
                        c.append(cur)
                        continue
                    nxt_h = [p for p in arr if p > cur and abs((p - cur) - 0.5 * d) <= tol]
                    if nxt_h and len(c) >= 4:
                        cur = min(nxt_h, key=lambda p: abs((p - cur) - 0.5 * d))
                        c.append(cur)
                    break
                if len(c) > len(best_c):
                    best_c = c
            return best_c

        rc, cc = chain(pr), chain(pc)
        if len(rc) >= 4 and len(cc) >= 4:
            score = (len(rc) + len(cc)) * 1000 + (cc[-1] - cc[0]) + (rc[-1] - rc[0])
            if best is None or score > best[0]:
                best = (score, cc[0], rc[0], cc[-1], rc[-1])
    if not best:
        return None
    _, x0, y0, x1, y1 = best
    if x1 - x0 < w * 0.2 or y1 - y0 < h * 0.2:
        return None
    return int(x0 * k), int(y0 * k), int((x1 + 1) * k), int((y1 + 1) * k)


def find_field(img: QImage):
    """找图纸上的场地框：
    1. 优先找蓝色尺寸箭头线并贴到灰色场地边线（国赛标准图纸）；
    2. 找不到蓝色尺寸线时，找内部规则正方形网格（FAI / 绿色尺寸线等各类图纸）；
    3. 都没有时退回最长的灰色外框线。
    返回原图像素 (左, 上, 右, 下)，找不到返回 None"""
    W0 = 2000
    work = img.scaledToWidth(W0) if img.width() > W0 else img
    k = img.width() / work.width()
    work = work.convertToFormat(QImage.Format_RGB888)
    w, h, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())
    blue_r, blue_c = [[] for _ in range(h)], [[] for _ in range(w)]
    grey_r, grey_c = [0]*h, [0]*w
    for y in range(h):
        row = data[y*bpl:y*bpl + w*3]
        for x in range(w):
            r, g, b = row[3*x], row[3*x+1], row[3*x+2]
            if b > 130 and r < 100 and 60 < g < 160 and b - r > 60:
                blue_r[y].append(x)
                blue_c[x].append(y)
            elif 150 < r < 232 and abs(r-g) < 14 and abs(g-b) < 14:
                grey_r[y] += 1
                grey_c[x] += 1

    def run(vals, gap=6):
        """一串坐标里最长的一段（中间断开不超过 gap）"""
        best, cur = (0, 0, 0), None
        for v in sorted(vals):
            if cur and v - cur[1] <= gap:
                cur = (cur[0], v)
            else:
                cur = (v, v)
            if cur[1] - cur[0] > best[2]:
                best = (cur[0], cur[1], cur[1]-cur[0])
        return best

    gx, gy = max(6, w//14), max(6, h//14)        # 线中间写着「85m」断开一截，也算一根
    hy = max(range(h), key=lambda y: run(blue_r[y], gx)[2])
    vx = max(range(w), key=lambda x: run(blue_c[x], gy)[2])
    x0, x1, lx = run(blue_r[hy], gx)
    y0, y1, ly = run(blue_c[vx], gy)
    if lx < w*0.25 or ly < h*0.25:               # 没有蓝色尺寸线：先找内部规则正方形网格
        grid = _find_grid_field(work, k)
        if grid:
            return grid
        top = max(grey_r)
        rows = [y for y in range(h) if grey_r[y] > top*0.45]
        topc = max(grey_c)
        cols = [x for x in range(w) if grey_c[x] > topc*0.45]
        if len(rows) < 2 or len(cols) < 2:
            return None
        x0, x1, y0, y1 = cols[0], cols[-1], rows[0], rows[-1]
    else:
        def snap(v, prof, lim):                  # 贴到附近最明显的灰色边线
            cand = [(prof[i], i) for i in range(max(0, v-6), min(lim, v+7))]
            best = max(cand)
            return best[1] if best[0] > max(prof)*0.3 else v
        x0, x1 = snap(x0, grey_c, w), snap(x1, grey_c, w)
        y0, y1 = snap(y0, grey_r, h), snap(y1, grey_r, h)
    if x1 - x0 < w*0.2 or y1 - y0 < h*0.2:
        return None
    return int(x0*k), int(y0*k), int((x1+1)*k), int((y1+1)*k)


def _mask(img: QImage, test):
    img = img.convertToFormat(QImage.Format_RGB888)
    w, h, bpl = img.width(), img.height(), img.bytesPerLine()
    data = bytes(img.constBits())
    px = set()
    for y in range(h):
        row = data[y*bpl:y*bpl + w*3]
        for x in range(w):
            if test(row[3*x], row[3*x+1], row[3*x+2]):
                px.add((x, y))
    return px


def _blobs(px):
    """8 邻接连成块"""
    left = set(px)
    out = []
    while left:
        s = left.pop()
        grp, todo = [s], [s]
        while todo:
            x, y = todo.pop()
            for dx, dy in N8:
                q = (x+dx, y+dy)
                if q in left:
                    left.remove(q)
                    grp.append(q)
                    todo.append(q)
        out.append(grp)
    return out


def is_navy(r, g, b):
    # 深蓝色门符号（组委会图纸多为 #202050 左右）：必须明显偏蓝，不能把场地黑框、深灰辅助线吸进来
    return r < 120 and g < 120 and b < 160 and b - r >= 15 and b - g >= 10


def _corners(x0, y0, x1, y1, pts):
    """外框四个角（各占 22%）里深蓝像素的占比：[左上, 右上, 左下, 右下]"""
    bw, bh = x1 - x0 + 1, y1 - y0 + 1
    cw, ch = max(2, int(bw * 0.22)), max(2, int(bh * 0.22))
    area = cw * ch
    tl = tr = bl = br = 0
    for x, y in pts:
        if x < x0 + cw:
            if y < y0 + ch:
                tl += 1
            elif y > y1 - ch:
                bl += 1
        elif x > x1 - cw:
            if y < y0 + ch:
                tr += 1
            elif y > y1 - ch:
                br += 1
    return (tl / area, tr / area, bl / area, br / area)


def glyphs(img: QImage, px_per_m, memory=()):
    """图纸上的门符号（自动适配深蓝单色图纸与多色分层图纸）：
    返回 [dict(kind, x, y 原图像素中心, w, h 米, fill, n 几块, lift=bool)]"""
    if detect_style(img) == "color_multi":
        return _glyphs_color(img, px_per_m, memory)
    return _glyphs_navy(img, px_per_m, memory)


def _merge_boxes(blobs, gap_px, ppm, max_m=16.0):
    boxes = []
    for b in blobs:
        xs = [p[0] for p in b]
        ys = [p[1] for p in b]
        x0, y0, x1, y1 = min(xs), min(ys), max(xs), max(ys)
        if max((x1 - x0 + 1) / ppm, (y1 - y0 + 1) / ppm) > max_m:
            continue
        boxes.append([x0, y0, x1, y1, len(b), 1, [len(b)], set(b)])
    merged = True
    while merged:
        merged = False
        for i in range(len(boxes)):
            for j in range(i + 1, len(boxes)):
                a, c = boxes[i], boxes[j]
                if a[0] - gap_px <= c[2] and c[0] - gap_px <= a[2] and a[1] - gap_px <= c[3] and c[1] - gap_px <= a[3]:
                    nx0, ny0, nx1, ny1 = min(a[0], c[0]), min(a[1], c[1]), max(a[2], c[2]), max(a[3], c[3])
                    if max((nx1 - nx0 + 1) / ppm, (ny1 - ny0 + 1) / ppm) > max_m:
                        continue
                    boxes[i] = [nx0, ny0, nx1, ny1, a[4] + c[4], a[5] + c[5], a[6] + c[6], a[7] | c[7]]
                    boxes.pop(j)
                    merged = True
                    break
            if merged:
                break
    return boxes


def _glyphs_color(img: QImage, px_per_m, memory=()):
    """多色分层图纸（如 FAI 锦标赛）：按绿/蓝/紫/黑分通道提取门框，按灰带判断二层叠高"""
    if px_per_m > 20.0:
        work = img.scaledToWidth(max(50, int(img.width() * 20.0 / px_per_m)), Qt.SmoothTransformation)
        ppm = 20.0
    else:
        work = img
        ppm = float(px_per_m)
    k = img.width() / work.width()
    work = work.convertToFormat(QImage.Format_RGB888)
    ww, wh, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())

    chans = {c: set() for c in ("green", "blue", "purple", "black", "greyband")}
    for y in range(wh):
        row = data[y*bpl:y*bpl + ww*3]
        for x in range(ww):
            r, g, b = row[3*x], row[3*x+1], row[3*x+2]
            mx, mn = max(r, g, b), min(r, g, b)
            diff = mx - mn
            if 130 <= r <= 198 and 130 <= g <= 198 and 130 <= b <= 198 and diff < 18:
                chans["greyband"].add((x, y))
            if mx < 110 and diff < 28:
                chans["black"].add((x, y))
                continue
            if diff < 24 or (mx > 225 and diff < 35):
                continue
            hh, ss, vv = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
            deg = hh * 360.0
            if 65.0 <= deg <= 165.0 and ss > 0.20 and vv < 0.82:
                chans["green"].add((x, y))
            elif 195.0 <= deg <= 255.0 and ss > 0.28 and vv < 0.85:
                chans["blue"].add((x, y))
            elif 270.0 <= deg <= 335.0 and ss > 0.24 and vv < 0.88:
                chans["purple"].add((x, y))

    min_px = max(8, int(20 * (ppm / 20.0) ** 2))
    gap_px = max(2, int(round(0.45 * ppm)))
    pad = max(2, int(round(0.5 * ppm)))

    def grey_ratio(x0, y0, x1, y1):
        xa, xb = max(0, x0 - pad), min(ww, x1 + pad + 1)
        ya, yb = max(0, y0 - pad), min(wh, y1 + pad + 1)
        area = max(1, (xb - xa) * (yb - ya))
        cnt = sum(1 for x in range(xa, xb) for y in range(ya, yb) if (x, y) in chans["greyband"])
        return cnt / area

    raw = []  # (priority, dict)

    # 1. 绿色：方形单门 / F形门（三连门） / 刀旗
    for x0, y0, x1, y1, n, parts, _sz, pts in _merge_boxes([b for b in _blobs(chans["green"]) if len(b) >= min_px], gap_px, ppm):
        w, h = (x1 - x0 + 1) / ppm, (y1 - y0 + 1) / ppm
        fill = n / ((x1 - x0 + 1) * (y1 - y0 + 1))
        if max(w, h) < 1.8:
            continue
        if w <= 1.3 and h >= 1.8 and h / max(w, 0.1) >= 1.8:
            kind = '刀旗'
        elif max(w, h) >= 5.5 and w >= 5.0:
            kind = '三连门' if w >= 6.5 else '双连门'
        elif max(w, h) >= 2.2 and min(w, h) >= 1.0:
            kind = '单门'
        else:
            continue
        lift = kind not in ('刀旗',) and grey_ratio(x0, y0, x1, y1) >= 0.14
        raw.append((2, dict(kind=kind, x=(x0 + x1 + 1) / 2 * k, y=(y0 + y1 + 1) / 2 * k,
                            w=round(w, 2), h=round(h, 2), fill=round(fill, 2), n=parts, lift=lift)))

    # 2. 紫色：双联门 2×2 / 蛇形门（宽幅连成一片时按 4.5m 间距拆成多个单门）
    p_gap = max(3, int(round(0.65 * ppm)))
    for x0, y0, x1, y1, n, parts, _sz, pts in _merge_boxes([b for b in _blobs(chans["purple"]) if len(b) >= min_px], p_gap, ppm, max_m=24.0):
        w, h = (x1 - x0 + 1) / ppm, (y1 - y0 + 1) / ppm
        fill = n / ((x1 - x0 + 1) * (y1 - y0 + 1))
        if max(w, h) < 2.2 or min(w, h) < 1.2:
            continue
        if w >= 9.0:
            # 蛇形门连成一大段：按段宽拆成若干单门
            cnt = max(2, min(6, int(round(w / 4.8))))
            for m_i in range(cnt):
                cx = x0 + (x1 - x0 + 1) * (m_i + 0.5) / cnt
                cy = (y0 + y1 + 1) / 2
                raw.append((3, dict(kind='单门', x=cx * k, y=cy * k, w=round(w / cnt, 2), h=round(h, 2),
                                    fill=round(fill, 2), n=1, lift=False)))
            continue
        kind = '双连门' if w >= 4.2 else '单门'
        lift = grey_ratio(x0, y0, x1, y1) >= 0.14
        raw.append((3, dict(kind=kind, x=(x0 + x1 + 1) / 2 * k, y=(y0 + y1 + 1) / 2 * k,
                            w=round(w, 2), h=round(h, 2), fill=round(fill, 2), n=parts, lift=lift)))

    # 3. 蓝色：六边形单门 / 双联门 1×1 / 田字门（过滤圆形 P 降落区与灰带里的蓝色路线箭头）
    for x0, y0, x1, y1, n, parts, _sz, pts in _merge_boxes([b for b in _blobs(chans["blue"]) if len(b) >= min_px], gap_px, ppm):
        w, h = (x1 - x0 + 1) / ppm, (y1 - y0 + 1) / ppm
        fill = n / ((x1 - x0 + 1) * (y1 - y0 + 1))
        lo, hi = min(w, h), max(w, h)
        R = hi / max(lo, 0.1)
        cr = _corners(x0, y0, x1, y1, pts)
        if R < 1.25 and fill >= 0.52 and max(cr) < 0.30:   # 圆形 P 降落区
            continue
        gr = grey_ratio(x0, y0, x1, y1)
        if hi < 2.6 and gr >= 0.10:                        # 二层灰带里的蓝色小箭头
            continue
        if hi < 2.5 or lo < 0.8:
            continue
        if lo >= 4.0 and R < 1.35:
            kind = '田字门'
        elif h > w * 1.6 and h >= 5.0:
            kind = '日字门'
        elif w > h * 1.5 and w >= 4.0:
            kind = '双连门'
        else:
            kind = '单门'
        raw.append((2, dict(kind=kind, x=(x0 + x1 + 1) / 2 * k, y=(y0 + y1 + 1) / 2 * k,
                            w=round(w, 2), h=round(h, 2), fill=round(fill, 2), n=parts, lift=gr >= 0.14)))

    # 4. 深黑色：计时门 / 起飞台 / 土形魔方门（双重）
    for x0, y0, x1, y1, n, parts, _sz, pts in _merge_boxes([b for b in _blobs(chans["black"]) if len(b) >= min_px], gap_px, ppm):
        w, h = (x1 - x0 + 1) / ppm, (y1 - y0 + 1) / ppm
        fill = n / ((x1 - x0 + 1) * (y1 - y0 + 1))
        if max(w, h) < 2.4 or min(w, h) < 0.8:
            continue
        cy_rel = (y0 + y1) / 2 / max(1, wh)
        if h > w * 1.7 and w >= 1.2 and (cy_rel > 0.78 or cy_rel < 0.22):
            kind = '起飞台'
        elif max(w, h) >= 4.5 and min(w, h) >= 2.8:
            kind = '双重'
        else:
            kind = '计时门'
        raw.append((4, dict(kind=kind, x=(x0 + x1 + 1) / 2 * k, y=(y0 + y1 + 1) / 2 * k,
                            w=round(w, 2), h=round(h, 2), fill=round(fill, 2), n=parts, lift=False)))

    # 跨颜色通道去重（如多色组合门重合位置，保留高优先级那一个）
    out = []
    min_dist = 2.0 * px_per_m
    for _prio, g in sorted(raw, key=lambda t: (-t[0], -(t[1]['w'] * t[1]['h']))):
        if any(math.hypot(g['x'] - o['x'], g['y'] - o['y']) < min_dist for o in out):
            continue
        for m in memory:
            if abs(m['w'] - g['w']) < 0.5 and abs(m['h'] - g['h']) < 0.5 and abs(m['fill'] - g['fill']) < 0.06:
                g['kind'] = m['kind']
                break
        out.append(g)
    return out


def _glyphs_navy(img: QImage, px_per_m, memory=()):
    """国赛深蓝图纸上的门符号：[dict(kind, x, y 原图像素中心, w, h 米, fill, n 几块)]
    kind：单门 / 日字门 / 田字门 / 双连门 / 三连门 / 单重 / 双重 / 双层单门 / 计时门 / 起飞台 / ?"""
    ppm = 20.0
    k = px_per_m / ppm                           # 原图像素 / 工作像素
    work = img.scaledToWidth(max(50, int(img.width() / k)), Qt.SmoothTransformation)
    k = img.width() / work.width()
    navy = _mask(work, is_navy)
    blobs = [b for b in _blobs(navy) if len(b) >= 25]
    # 粉色线压断的几块并回一个：外框挨着（6 像素内）的算一个符号；超大块（如顶部标题栏/底色）直接跳过
    boxes = _merge_boxes(blobs, 6, ppm, max_m=16.0)
    out = []
    small = []
    for x0, y0, x1, y1, n, parts, sizes, pts in boxes:
        w, h = (x1-x0+1)/ppm, (y1-y0+1)/ppm
        fill = n / ((x1-x0+1)*(y1-y0+1))
        if max(w, h) < 1.2 or min(w, h) < 0.6:  # 太小、细线（尺寸标注的短竖线）不是门
            continue
        if max(w, h) < 2.5:                      # 小符号（起飞台前面的 ^ 箭头）先记下
            small.append(((x0+x1+1)/2, y1, (x1-x0+1)/2))
            continue
        lo, hi = min(w, h), max(w, h)
        R = hi / lo
        cr = _corners(x0, y0, x1, y1, pts)
        # 圆形「P 降落点」图标：实心圆填充高但四角几乎为空，不是门框
        if R < 1.25 and fill >= 0.55 and max(cr) < 0.30:
            continue
        if parts >= 4 and sum(1 for s in sizes if s < 150) >= 2:
            kind = '起飞台'
        elif R < 1.25 and lo > 5.0 and min(cr) < 0.15 and max(cr) < 0.25:
            kind = '起飞台'                        # 斜着画的起飞箭头带（对角为空，区别于四角满的田字门）
        elif fill >= 0.58 and h > w*1.5 and w >= 2.0:
            kind = '双层单门'
        elif fill >= 0.43 and R < 1.3 and lo > 3.6:
            kind = '单重'
        elif fill >= 0.45 and h > w*1.5 and lo > 3.6:
            kind = '双重'
        elif w > h and 1.25 <= R < 1.6 and fill >= 0.4:
            kind = '计时门'
        elif R < 1.25 and lo > 5.2:
            kind = '田字门'
        elif w <= 2.4 and h < 6.4 and R >= 1.9:
            kind = '单门'                         # 又瘦又高的平行四边形：斜着放的单门
        elif w <= 2.4 and h >= 6.4:
            kind = '日字门'                        # 斜着放的两层日字门
        elif R < 1.45:
            kind = '单门'
        elif h > w:
            kind = '日字门'
        elif R < 2.4:
            kind = '双连门'
        else:
            kind = '三连门'
        for m in memory:                         # 学过的：这种符号操作者改成过别的，照改过的来
            if abs(m['w']-w) < 0.5 and abs(m['h']-h) < 0.5 and abs(m['fill']-fill) < 0.06:
                kind = m['kind']
                break
        out.append(dict(kind=kind, x=(x0+x1+1)/2*k, y=(y0+y1+1)/2*k, w=round(w, 2), h=round(h, 2),
                        fill=round(fill, 2), n=parts))
    if len(small) >= 2 and not any(g['kind'] == '起飞台' for g in out):   # 一串 ^ 箭头 = 起飞方向，起飞台在最下面那个后面
        best = []
        for a in small:                          # 竖着排成一串的小符号（左右差不到 1 米、上下挨着）
            col = sorted([q for q in small if abs(q[0]-a[0]) < ppm], key=lambda q: q[1])
            if len(col) > len(best) and all(col[i+1][1]-col[i][1] < 3*ppm for i in range(len(col)-1)):
                best = col
        if len(best) >= 2:
            xs = [q[0] for q in best]
            out.append(dict(kind='起飞台', x=sum(xs)/len(xs)*k, y=(best[-1][1] + 1.5*ppm)*k, w=2.0, h=2.0, fill=0, n=len(best)))
    return out
