"""最小的 AES-128 加密（只做加密，给黑羊 .trk 用），不依赖第三方库。"""
def _xt(a): return ((a << 1) ^ 0x1B) & 0xFF if a & 0x80 else a << 1
def _sbox():
    s = [0]*256; p = q = 1
    while True:
        p = p ^ ((p << 1) & 0xFF) ^ (0x1B if p & 0x80 else 0)
        q ^= q << 1; q ^= q << 2; q ^= q << 4; q &= 0xFF
        if q & 0x80: q ^= 0x09
        x = q ^ (q << 1 | q >> 7) ^ (q << 2 | q >> 6) ^ (q << 3 | q >> 5) ^ (q << 4 | q >> 4)
        s[p] = (x ^ 0x63) & 0xFF
        if p == 1: break
    s[0] = 0x63
    return s
SBOX = _sbox()
def _expand(key):
    w = [list(key[i:i+4]) for i in range(0, 16, 4)]; rc = 1
    for i in range(4, 44):
        t = list(w[i-1])
        if i % 4 == 0:
            t = [SBOX[b] for b in t[1:] + t[:1]]; t[0] ^= rc; rc = _xt(rc)
        w.append([a ^ b for a, b in zip(w[i-4], t)])
    return [sum(w[r*4:r*4+4], []) for r in range(11)]
def _block(s, rk):
    s = [a ^ b for a, b in zip(s, rk[0])]
    for r in range(1, 11):
        s = [SBOX[b] for b in s]
        s = [s[(i + 4*(i % 4)) % 16] for i in range(16)]          # ShiftRows (列优先)
        if r != 10:
            n = []
            for c in range(4):
                a = s[c*4:c*4+4]; t = a[0] ^ a[1] ^ a[2] ^ a[3]
                n += [a[i] ^ t ^ _xt(a[i] ^ a[(i+1) % 4]) for i in range(4)]
            s = n
        s = [a ^ b for a, b in zip(s, rk[r])]
    return s
def ecb_encrypt(data, key):
    rk = _expand(key); out = bytearray()
    for i in range(0, len(data), 16): out += bytes(_block(list(data[i:i+16]), rk))
    return bytes(out)


# ---- 解密（读黑羊存的 .trk 用）
INV_SBOX = [0]*256
for _i, _v in enumerate(SBOX): INV_SBOX[_v] = _i
def _mul(a, b):
    r = 0
    for _ in range(8):
        if b & 1: r ^= a
        a = _xt(a); b >>= 1
    return r & 0xFF
def _inv_block(s, rk):
    s = [a ^ b for a, b in zip(s, rk[10])]
    for r in range(9, -1, -1):
        t = [0]*16                                                # InvShiftRows（和加密那步互逆）
        for i in range(16): t[(i + 4*(i % 4)) % 16] = s[i]
        s = [INV_SBOX[b] for b in t]
        s = [a ^ b for a, b in zip(s, rk[r])]
        if r != 0:
            n = []
            for c in range(4):
                a = s[c*4:c*4+4]
                n += [_mul(a[0], m[0]) ^ _mul(a[1], m[1]) ^ _mul(a[2], m[2]) ^ _mul(a[3], m[3])
                      for m in ((14, 11, 13, 9), (9, 14, 11, 13), (13, 9, 14, 11), (11, 13, 9, 14))]
            s = n
    return s
def ecb_decrypt(data, key):
    rk = _expand(key); out = bytearray()
    for i in range(0, len(data), 16): out += bytes(_inv_block(list(data[i:i+16]), rk))
    return bytes(out)
