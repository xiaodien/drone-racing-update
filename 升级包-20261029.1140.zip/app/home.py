"""总页面（首页）：蓝色大标题写项目名和版本，下面六个大卡片进各个功能。"""
import math

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontMetrics, QLinearGradient, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QLabel, QSizePolicy, QVBoxLayout, QWidget

CARDS = [  # (key, 标题, 说明, 图标)
    ("train", "训练模式", "采集图传画面，解锁自动录像，打杆数据同步回看", "camera"),
    ("race", "比赛模式", "多路画面，连计时器自动记圈、排名次、出成绩海报", "flag"),
    ("build", "赛道搭建", "3D 摆门、点门洞定顺序，画笔画路线，电脑也能自动摆", "gate"),
    ("track", "黑羊导出 / 模拟飞行", "打开搭好的或组委会的赛道，模拟飞一遍，导出黑羊地图", "drone"),
    ("ai", "AI 教学和比对", "和教练、高手的打杆对比，找出差在哪", "ai"),
    ("timer", "计时模式", "单独用计时器练圈速", "watch"),
    ("guide", "使用向导", "第一次用看这里：设录像位置、采集卡、遥控器、学员", "guide"),
    ("settings", "设置", "录像保存位置、录像时间、诊断报告", "gear"),
]
COLS = 4


def _icon(p, kind, r):
    """卡片左上角的图标：蓝色圆角方块里画白色线条图"""
    g = QLinearGradient(r.topLeft(), r.bottomRight())
    g.setColorAt(0, QColor("#3aa0ff"))
    g.setColorAt(1, QColor("#0057d9"))
    p.setPen(Qt.NoPen)
    p.setBrush(g)
    p.drawRoundedRect(r, r.width()*0.26, r.width()*0.26)
    p.setPen(QPen(QColor("white"), r.width()*0.06, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
    p.setBrush(Qt.NoBrush)
    c, s = r.center(), r.width()

    def P(x, y):
        return QPointF(c.x() + x*s, c.y() + y*s)
    if kind == "camera":
        p.drawRoundedRect(QRectF(P(-0.28, -0.15), P(0.1, 0.17)), s*0.05, s*0.05)
        p.drawPolygon([P(0.1, -0.02), P(0.28, -0.13), P(0.28, 0.15), P(0.1, 0.04)])
    elif kind == "flag":
        p.drawLine(P(-0.22, -0.27), P(-0.22, 0.28))
        path = QPainterPath(P(-0.22, -0.25))
        path.cubicTo(P(-0.05, -0.33), P(0.05, -0.15), P(0.25, -0.22))
        path.lineTo(P(0.25, 0.04))
        path.cubicTo(P(0.05, 0.11), P(-0.05, -0.07), P(-0.22, 0.01))
        p.drawPath(path)
    elif kind == "gate":
        p.drawRect(QRectF(P(-0.2, -0.24), P(0.2, 0.14)))
        p.drawLine(P(-0.2, 0.14), P(-0.2, 0.27))
        p.drawLine(P(0.2, 0.14), P(0.2, 0.27))
        p.drawLine(P(-0.3, 0.27), P(-0.1, 0.27))
        p.drawLine(P(0.1, 0.27), P(0.3, 0.27))
    elif kind == "drone":
        p.drawLine(P(-0.17, -0.17), P(0.17, 0.17))
        p.drawLine(P(-0.17, 0.17), P(0.17, -0.17))
        for x, y in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
            p.drawEllipse(P(0.2*x, 0.2*y), s*0.1, s*0.1)
        p.setBrush(QColor("white"))
        p.drawRoundedRect(QRectF(P(-0.06, -0.06), P(0.06, 0.06)), 2, 2)
    elif kind == "ai":
        f = QFont()
        f.setBold(True)
        f.setPixelSize(int(s*0.36))
        p.setFont(f)
        p.setPen(QColor("white"))
        p.drawText(r, Qt.AlignCenter, "AI")
    elif kind == "guide":
        path = QPainterPath(P(0, -0.2))
        path.cubicTo(P(-0.1, -0.27), P(-0.22, -0.26), P(-0.28, -0.22))
        path.lineTo(P(-0.28, 0.22))
        path.cubicTo(P(-0.2, 0.18), P(-0.08, 0.18), P(0, 0.25))
        path.cubicTo(P(0.08, 0.18), P(0.2, 0.18), P(0.28, 0.22))
        path.lineTo(P(0.28, -0.22))
        path.cubicTo(P(0.22, -0.26), P(0.1, -0.27), P(0, -0.2))
        path.lineTo(P(0, 0.25))
        p.drawPath(path)
    elif kind == "gear":
        p.drawEllipse(P(0, 0), s*0.09, s*0.09)
        for k in range(8):
            a = k*math.pi/4
            p.drawLine(P(0.17*math.cos(a), 0.17*math.sin(a)), P(0.27*math.cos(a), 0.27*math.sin(a)))
        p.drawEllipse(P(0, 0), s*0.18, s*0.18)
    elif kind == "watch":
        p.drawEllipse(P(0, 0.04), s*0.24, s*0.24)
        p.drawLine(P(0, 0.04), P(0, -0.1))
        p.drawLine(P(0, 0.04), P(0.1, 0.1))
        p.drawLine(P(-0.07, -0.29), P(0.07, -0.29))
        p.drawLine(P(0, -0.29), P(0, -0.2))


class Card(QWidget):
    clicked = Signal()

    def __init__(self, title, sub, icon):
        super().__init__()
        self.title, self.sub, self.icon = title, sub, icon
        self.hover = False
        self.badge = ""
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumSize(240, 160)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMouseTracking(True)

    def enterEvent(self, e):
        self.hover = True
        self.update()

    def leaveEvent(self, e):
        self.hover = False
        self.update()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self.rect().contains(e.position().toPoint()):
            self.clicked.emit()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(6, 6, -6, -6)
        if self.hover:                          # 鼠标指着：浮起来一点，带蓝色描边
            r.translate(0, -2)
        for k in range(6):                      # 软阴影
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(0, 60, 160, 6 if not self.hover else 10))
            p.drawRoundedRect(r.adjusted(-k, -k+3, k, k+3), 20+k, 20+k)
        p.setBrush(QColor("white"))
        p.setPen(QPen(QColor("#0a84ff") if self.hover else QColor("#e3e8f0"), 2 if self.hover else 1))
        p.drawRoundedRect(r, 20, 20)
        ic = min(64.0, r.height()*0.42)
        _icon(p, self.icon, QRectF(r.left()+24, r.top()+24, ic, ic))
        f = QFont()
        f.setBold(True)
        tx = r.left()+24+ic+18
        tw = r.right()-tx-16
        title = self.title
        px = 24
        while True:                             # 卡片窄的时候标题字缩小，还放不下就在「/」那里折成两行
            f.setPixelSize(px)
            if max(QFontMetrics(f).horizontalAdvance(t) for t in title.split("\n")) <= tw or px <= 16:
                break
            if px <= 20 and " / " in title and "\n" not in title:
                title, px = title.replace(" / ", " /\n"), 24
                continue
            px -= 1
        p.setFont(f)
        p.setPen(QColor("#0b1f3a"))
        p.drawText(QRectF(tx, r.top()+24, tw, ic), Qt.AlignVCenter | Qt.AlignLeft, title)
        f.setBold(False)
        f.setPixelSize(15)
        p.setFont(f)
        p.setPen(QColor("#5b6b80"))
        p.drawText(QRectF(r.left()+24, r.top()+24+ic+12, r.width()-48, r.bottom()-(r.top()+24+ic+12)-36),
                   Qt.AlignLeft | Qt.AlignTop | Qt.TextWordWrap, self.sub)
        if self.badge:
            f.setPixelSize(12)
            f.setBold(True)
            p.setFont(f)
            w = p.fontMetrics().horizontalAdvance(self.badge) + 18
            br = QRectF(r.right()-w-18, r.top()+20, w, 22)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor("#fff4e5"))
            p.drawRoundedRect(br, 11, 11)
            p.setPen(QColor("#c26a00"))
            p.drawText(br, Qt.AlignCenter, self.badge)
        f.setPixelSize(14)
        f.setBold(True)
        p.setFont(f)
        p.setPen(QColor("#0a84ff"))
        p.drawText(QRectF(r.left()+24, r.bottom()-34, r.width()-48, 22), Qt.AlignLeft | Qt.AlignVCenter, "进入  →")


class HomePage(QWidget):
    """首页。open_card(key) 由主窗口接上"""
    chosen = Signal(str)

    def __init__(self, name, version, clock=None, guide=None):
        super().__init__()
        self.name, self.version = name, version
        self.cards = {}
        lay = QVBoxLayout(self)
        lay.setContentsMargins(48, 0, 48, 28)
        lay.setSpacing(0)
        head = QWidget()
        head.setFixedHeight(210)
        hl = QHBoxLayout(head)
        hl.setContentsMargins(0, 0, 0, 0)
        hl.addStretch()
        if clock is not None:                   # 首页右上角也放时钟
            col = QVBoxLayout()
            col.addSpacing(40)
            col.addWidget(clock)
            col.addStretch()
            hl.addLayout(col)
        lay.addWidget(head)
        grid = QGridLayout()
        grid.setSpacing(18)
        for k, (key, title, sub, ic) in enumerate(CARDS):
            c = Card(title, sub, ic)
            c.setFixedHeight(200)
            c.clicked.connect(lambda kk=key: self.chosen.emit(kk))
            grid.addWidget(c, k // COLS, k % COLS)
            self.cards[key] = c
        for k in ("ai", "timer"):               # 还没做好的先标出来
            self.cards[k].badge = "未实装"
        lay.addStretch(1)
        lay.addLayout(grid)
        lay.addStretch(2)
        foot = QLabel("点卡片进入；进去以后点左上角「⌂ 首页」回到这里")
        foot.setAlignment(Qt.AlignCenter)
        foot.setStyleSheet("color: #8a98ab; padding-top: 14px;")
        lay.addWidget(foot)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor("#f2f6fc"))
        h = 230
        g = QLinearGradient(0, 0, self.width(), h)
        g.setColorAt(0, QColor("#0a84ff"))
        g.setColorAt(0.55, QColor("#0062e6"))
        g.setColorAt(1, QColor("#003fb3"))
        path = QPainterPath()
        path.moveTo(0, 0)
        path.lineTo(self.width(), 0)
        path.lineTo(self.width(), h-40)
        path.cubicTo(self.width()*0.7, h+10, self.width()*0.3, h-60, 0, h-10)
        path.closeSubpath()
        p.fillPath(path, g)
        p.setPen(QPen(QColor(255, 255, 255, 28), 2))   # 背景里淡淡的赛道线
        for k in range(3):
            q = QPainterPath()
            q.moveTo(self.width()*0.45, 40+k*36)
            for x in range(0, 60):
                t = x/59
                q.lineTo(self.width()*(0.45+0.55*t), 40+k*36 + 26*math.sin(t*math.pi*2 + k))
            p.drawPath(q)
        f = QFont()
        f.setBold(True)
        f.setPixelSize(40)
        p.setFont(f)
        p.setPen(QColor("white"))
        p.drawText(QRectF(52, 46, self.width()-104, 60), Qt.AlignLeft | Qt.AlignVCenter, self.name)
        f.setBold(False)
        f.setPixelSize(17)
        p.setFont(f)
        p.setPen(QColor(255, 255, 255, 215))
        p.drawText(QRectF(54, 108, self.width()-104, 30), Qt.AlignLeft | Qt.AlignVCenter, "FPV 穿越机 · 打杆教学 · 比赛计时 · 赛道搭建")
        f.setPixelSize(13)
        f.setBold(True)
        p.setFont(f)
        w = p.fontMetrics().horizontalAdvance(self.version) + 24
        br = QRectF(54, 148, w, 26)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(255, 255, 255, 46))
        p.drawRoundedRect(br, 13, 13)
        p.setPen(QColor("white"))
        p.drawText(br, Qt.AlignCenter, self.version)
