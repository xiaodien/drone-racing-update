"""计时调线：按距离设进门线/出门线，比赛后看信号回放、拖线重算圈速（思路参考开源计时器的做法，代码是自己写的）"""
from PySide6.QtCore import QPointF, Qt, Signal
from PySide6.QtGui import QColor, QPainter, QPen, QPolygonF
from PySide6.QtWidgets import (QDialog, QDialogButtonBox, QGridLayout, QHBoxLayout, QLabel, QListWidget,
                               QPushButton, QSpinBox, QVBoxLayout, QWidget)


def detect(hist, enter, exit_):
    """信号历史 [(毫秒, 毫伏)] → 过门 [(毫秒, 最高信号)]。和计时器里一样：过进门线开始找最高点，掉到出门线下算一次"""
    out, crossing, peak, first, last = [], False, 0, 0, 0
    for t, v in hist:
        if not crossing:
            if v >= enter:
                crossing, peak, first, last = True, v, t, t
        else:
            if v > peak:
                peak, first, last = v, t, t
            elif v == peak:
                last = t
            if v < exit_:
                crossing = False
                out.append((first + (last - first) / 2, peak))
    return out


def apply_rules(passes, start, min_lap, max_passes):
    """比赛规则：开始前的不算；离上一次太近的，只留信号更强的那次。返回（留下的, 去掉的）"""
    kept, dropped = [], []
    for t, peak in passes:
        if t < start - 300:
            continue
        if kept and t - kept[-1][0] < min_lap:
            if peak > kept[-1][1]:
                dropped.append(kept.pop()[0])
                kept.append((t, peak))
            else:
                dropped.append(t)
            continue
        if len(kept) < max_passes:
            kept.append((t, peak))
    return kept, dropped


# ============================================================ 按距离设线
class LineCaptureDialog(QDialog):
    """飞机放在离计时器 2 米 → 设进门线；拿到 7 米外 → 设出门线"""

    def __init__(self, view, lanes):
        super().__init__(view)
        self.view, self.lanes = view, lanes
        self.setWindowTitle("按距离设线")
        lay = QVBoxLayout(self)
        tip = QLabel("飞机通电、图传开着：\n"
                     "1. 拿到离计时器 2 米左右 → 点「设为进门线」\n"
                     "2. 拿到 7 米左右（或隔一个房间）→ 点「设为出门线」\n"
                     "进门线要比出门线高出一截，差得越多越不容易一次过门记成两圈。")
        lay.addWidget(tip)
        grid = QGridLayout()
        for c, h in enumerate(["", "现在信号", "进门线", "", "出门线", ""]):
            grid.addWidget(QLabel(h), 0, c)
        self.now_labels = {}
        for k, i in enumerate(lanes, 1):
            r = view.rows[i]
            name = QLabel(f"{i + 1} 路  {r['pilot'].currentText()}")
            now = QLabel("-")
            now.setMinimumWidth(60)
            enter = QSpinBox(minimum=100, maximum=3000, singleStep=10, value=r["enter"].value())
            exit_ = QSpinBox(minimum=100, maximum=3000, singleStep=10, value=r["exit"].value())
            b_in = QPushButton("设为进门线")
            b_out = QPushButton("设为出门线")
            b_in.clicked.connect(lambda _c=False, n=now, s=enter: s.setValue(int(n.text()) if n.text().isdigit() else s.value()))
            b_out.clicked.connect(lambda _c=False, n=now, s=exit_: s.setValue(int(n.text()) if n.text().isdigit() else s.value()))
            enter.valueChanged.connect(lambda _v, j=i, a=enter, b=exit_: self._set(j, a, b))
            exit_.valueChanged.connect(lambda _v, j=i, a=enter, b=exit_: self._set(j, a, b))
            for c, w in enumerate([name, now, enter, b_in, exit_, b_out]):
                grid.addWidget(w, k, c)
            self.now_labels[i] = now
        lay.addLayout(grid)
        self.warn = QLabel("")
        self.warn.setStyleSheet("color: #c62828;")
        lay.addWidget(self.warn)
        bb = QDialogButtonBox()
        bb.addButton("关闭", QDialogButtonBox.RejectRole)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        if view.link:
            view.link.rssi.connect(self._rssi)

    def _rssi(self, v, _lo, _hi):
        for i, lab in self.now_labels.items():
            if i < len(v):
                lab.setText(str(int(v[i])))

    def _set(self, i, enter, exit_):
        if exit_.value() >= enter.value() - 30:
            self.warn.setText(f"{i + 1} 路：出门线要比进门线低，现在离得太近或者反了")
            return
        self.warn.setText("")
        r = self.view.rows[i]
        r["enter"].setValue(enter.value())
        r["exit"].setValue(exit_.value())
        self.view._thr_changed(i)

    def done(self, code):
        if self.view.link:
            try:
                self.view.link.rssi.disconnect(self._rssi)
            except (RuntimeError, TypeError):
                pass
        super().done(code)


# ============================================================ 比赛回放调线
class LaneGraph(QWidget):
    """一路的整场信号曲线，两条线可以用鼠标拖：上面虚线=进门线，下面点线=出门线"""
    moved = Signal()

    def __init__(self, color, hist, enter, exit_, start):
        super().__init__()
        self.color, self.hist, self.start = color, hist, start
        self.enter, self.exit = enter, exit_
        self.passes, self.dropped = [], []
        self.drag = None
        self.setMinimumSize(640, 170)
        vals = [v for _t, v in hist] or [0, 1000]
        self.lo, self.hi = min(vals + [exit_]) - 40, max(vals + [enter]) + 40

    def _y(self, v):
        return self.height() - 16 - (v - self.lo) / max(1, self.hi - self.lo) * (self.height() - 26)

    def _v(self, y):
        return self.lo + (self.height() - 16 - y) / max(1, self.height() - 26) * (self.hi - self.lo)

    def _x(self, t):
        t0, t1 = self.hist[0][0], self.hist[-1][0]
        return (t - t0) / max(1, t1 - t0) * (self.width() - 1)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor(32, 30, 44))
        if len(self.hist) < 2:
            p.setPen(QColor(170, 170, 180))
            p.drawText(self.rect(), Qt.AlignCenter, "这一路没有记到信号")
            return
        if self.start is not None:
            p.setPen(QPen(QColor(120, 120, 130), 1, Qt.DashDotLine))
            p.drawLine(self._x(self.start), 0, self._x(self.start), self.height())
        p.setPen(QPen(self.color, 2))
        p.drawPolyline(QPolygonF([QPointF(self._x(t), self._y(v)) for t, v in self.hist]))
        for k, v in enumerate((self.enter, self.exit)):
            p.setPen(QPen(QColor(255, 255, 255), 1.5, Qt.DashLine if k == 0 else Qt.DotLine))
            p.drawLine(0, self._y(v), self.width(), self._y(v))
            p.drawText(6, self._y(v) - 3, ("进门线 " if k == 0 else "出门线 ") + str(int(v)))
        for t in self.dropped:
            p.setPen(QPen(QColor(255, 180, 60), 2))
            p.drawLine(self._x(t), 4, self._x(t), self.height() - 16)
        for t in self.passes:
            p.setPen(QPen(QColor(120, 255, 120), 2))
            p.drawLine(self._x(t), 4, self._x(t), self.height() - 16)
        p.setPen(QColor(170, 170, 180))
        p.drawText(6, self.height() - 3, "绿线=记一圈  橙线=太快没算  拖白线调整")

    def mousePressEvent(self, e):
        y = e.position().y()
        d_in, d_out = abs(y - self._y(self.enter)), abs(y - self._y(self.exit))
        self.drag = "enter" if d_in <= d_out else "exit"
        self.mouseMoveEvent(e)

    def mouseMoveEvent(self, e):
        if not self.drag:
            return
        v = int(round(self._v(e.position().y()) / 5) * 5)
        if self.drag == "enter":
            self.enter = max(v, self.exit + 20)
        else:
            self.exit = min(v, self.enter - 20)
        self.moved.emit()
        self.update()

    def mouseReleaseEvent(self, _):
        self.drag = None


class MarshalDialog(QDialog):
    """比赛后：看每一路整场的信号，拖进门线/出门线，圈速马上重算。满意了可以更新成绩、把线存下来以后用"""

    def __init__(self, view, race, hist, colors):
        super().__init__(view)
        self.view, self.race = view, race
        self.setWindowTitle("比赛回放调线")
        self.resize(900, 640)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("圈数不对时：拖动白线，下面的圈速马上重算。\n"
                             "多记了圈 → 把进门线往上拖，或者把出门线往下拖；少记了圈 → 把进门线往下拖。"))
        self.graphs, self.lists = {}, {}
        for p in race["pilots"]:
            r = view.rows[p.node]
            g = LaneGraph(colors[p.node], hist.get(p.node, []), r["enter"].value(), r["exit"].value(), race["start"])
            g.moved.connect(self._recalc)
            box = QHBoxLayout()
            col = QVBoxLayout()
            col.addWidget(QLabel(f"{p.node + 1} 路  {p.name}"))
            col.addWidget(g, 1)
            box.addLayout(col, 3)
            lst = QListWidget()
            lst.setMaximumWidth(200)
            box.addWidget(lst, 1)
            lay.addLayout(box)
            self.graphs[p.node], self.lists[p.node] = g, lst
        self.result = {}
        btns = QHBoxLayout()
        keep = QPushButton("把这两条线存下来，以后比赛用")
        keep.clicked.connect(self._keep_lines)
        apply = QPushButton("按新的圈速更新成绩")
        apply.clicked.connect(self._apply)
        close = QPushButton("关闭")
        close.clicked.connect(self.reject)
        for b in (keep, apply):
            btns.addWidget(b)
        btns.addStretch(1)
        btns.addWidget(close)
        lay.addLayout(btns)
        self._recalc()

    def _recalc(self):
        r = self.race
        for p in r["pilots"]:
            g = self.graphs[p.node]
            raw = detect(g.hist, g.enter, g.exit)
            kept, dropped = apply_rules(raw, r["start"], r["min_lap"], r["laps"] + 1)
            g.passes, g.dropped = [t for t, _ in kept], dropped
            self.result[p.node] = g.passes
            lst = self.lists[p.node]
            lst.clear()
            times = g.passes
            for n, (a, b) in enumerate(zip(times, times[1:]), 1):
                lst.addItem(f"第 {n} 圈  {(b - a) / 1000:.2f}")
            if not times:
                lst.addItem("没有过门")
            g.update()

    def _keep_lines(self):
        for node, g in self.graphs.items():
            row = self.view.rows[node]
            row["enter"].setValue(int(g.enter))
            row["exit"].setValue(int(g.exit))
            self.view._thr_changed(node)
        self.view.cal_label.setText("已用回放里调好的进门线/出门线")

    def _apply(self):
        self.view.rescore(self.result)
        self.accept()
