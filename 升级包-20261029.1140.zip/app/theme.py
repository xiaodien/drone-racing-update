"""整体外观：苹果式的浅色主题（浅灰底、白卡片、圆角按钮、蓝色主色）。在 run() 里对整个软件调用一次 apply()。"""
import sys
import tempfile
from pathlib import Path

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPalette, QPen, QPixmap

BLUE = "#007aff"
GREEN = "#34c759"
RED = "#ff3b30"
ORANGE = "#ff9500"
PURPLE = "#af52de"
TEXT = "#1d1d1f"
SUB = "#6e6e73"
LINE = "#d2d2d7"
BG = "#f5f5f7"

QSS = f"""
QMainWindow, QDialog {{ background: {BG}; }}
QWidget {{ color: {TEXT}; }}
QToolTip {{ background: #2c2c2e; color: white; border: none; border-radius: 6px; padding: 6px 8px; }}

QPushButton, QToolButton {{
    background: #ffffff; border: 1px solid {LINE}; border-radius: 8px; padding: 5px 14px; min-height: 20px;
}}
QToolButton {{ padding: 1px; min-height: 0px; }}
QPushButton:hover, QToolButton:hover {{ background: #f2f2f5; border-color: #c4c4ca; }}
QPushButton:pressed, QToolButton:pressed {{ background: #e5e5ea; }}
QPushButton:checked, QToolButton:checked {{ background: {BLUE}; color: white; border-color: {BLUE}; }}
QPushButton:default {{ background: {BLUE}; color: white; border-color: {BLUE}; }}
QPushButton:default:hover {{ background: #1a86ff; }}
QPushButton:disabled, QToolButton:disabled {{ color: #a1a1a6; background: #f2f2f4; border-color: #e3e3e8; }}
QPushButton::menu-indicator {{ subcontrol-origin: padding; subcontrol-position: right center; right: 6px; }}

QComboBox, QLineEdit, QSpinBox, QDoubleSpinBox, QTimeEdit, QDateEdit, QPlainTextEdit, QTextEdit {{
    background: #ffffff; border: 1px solid {LINE}; border-radius: 7px; padding: 4px 8px;
    selection-background-color: {BLUE}; selection-color: white;
}}
QComboBox, QLineEdit, QSpinBox, QDoubleSpinBox, QTimeEdit, QDateEdit {{ min-height: 20px; }}
QComboBox:hover, QLineEdit:hover, QSpinBox:hover, QDoubleSpinBox:hover, QTimeEdit:hover {{ border-color: #b8b8be; }}
QComboBox:focus, QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QTimeEdit:focus,
QPlainTextEdit:focus, QTextEdit:focus {{ border: 1px solid {BLUE}; }}
QComboBox:disabled, QLineEdit:disabled, QSpinBox:disabled, QDoubleSpinBox:disabled {{ color: #a1a1a6; background: #f2f2f4; }}
QComboBox::drop-down {{ border: none; width: 24px; subcontrol-origin: padding; subcontrol-position: center right; }}
QComboBox::down-arrow {{ image: url(@ARROW_DOWN@); width: 10px; height: 10px; }}
QComboBox::down-arrow:disabled {{ image: url(@ARROW_DOWN_OFF@); }}
QAbstractSpinBox {{ padding: 4px 22px 4px 8px; }}
QSpinBox::up-button, QDoubleSpinBox::up-button, QTimeEdit::up-button, QDateEdit::up-button {{
    subcontrol-origin: border; subcontrol-position: top right; width: 18px; border: none; margin: 2px 2px 0 0; }}
QSpinBox::down-button, QDoubleSpinBox::down-button, QTimeEdit::down-button, QDateEdit::down-button {{
    subcontrol-origin: border; subcontrol-position: bottom right; width: 18px; border: none; margin: 0 2px 2px 0; }}
QSpinBox::up-arrow, QDoubleSpinBox::up-arrow, QTimeEdit::up-arrow, QDateEdit::up-arrow {{ image: url(@ARROW_UP@); width: 8px; height: 8px; }}
QSpinBox::down-arrow, QDoubleSpinBox::down-arrow, QTimeEdit::down-arrow, QDateEdit::down-arrow {{ image: url(@ARROW_DOWN@); width: 8px; height: 8px; }}
QComboBox QAbstractItemView {{
    background: white; border: 1px solid {LINE}; border-radius: 8px; padding: 4px; outline: none;
    selection-background-color: {BLUE}; selection-color: white;
}}

QTabWidget::pane {{ border: 1px solid #e0e0e5; border-radius: 10px; background: white; top: -1px; }}
QTabBar::tab {{
    background: #e8e8ed; color: {SUB}; padding: 5px 18px; margin: 0 2px 4px 0; border-radius: 7px; min-width: 40px;
}}
QTabBar::tab:selected {{ background: white; color: {TEXT}; font-weight: bold; border: 1px solid {LINE}; }}
QTabBar::tab:hover:!selected {{ background: #dedee3; }}

QTreeView, QTreeWidget, QListView, QListWidget, QTableView, QTableWidget {{
    background: white; border: 1px solid #e0e0e5; border-radius: 10px; padding: 4px; outline: none;
    alternate-background-color: #fafafc; selection-background-color: {BLUE}; selection-color: white;
}}
QTreeView::item, QListView::item {{ padding: 3px 2px; border-radius: 5px; }}
QTreeView::item:hover:!selected, QListView::item:hover:!selected {{ background: #f0f0f5; }}
QHeaderView::section {{ background: #f5f5f7; color: {SUB}; border: none; border-bottom: 1px solid #e0e0e5; padding: 5px 6px; }}
QTableCornerButton::section {{ background: #f5f5f7; border: none; }}

QGroupBox {{
    background: white; border: 1px solid #e3e3e8; border-radius: 12px; margin-top: 16px; padding: 10px 8px 8px 8px;
}}
QGroupBox::title {{ subcontrol-origin: margin; left: 12px; padding: 0 4px; color: {SUB}; font-weight: bold; }}

QScrollArea {{ border: none; background: transparent; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 2px; }}
QScrollBar::handle:vertical, QScrollBar::handle:horizontal {{ background: #c7c7cc; border-radius: 4px; }}
QScrollBar::handle:vertical {{ min-height: 30px; }}
QScrollBar::handle:horizontal {{ min-width: 30px; }}
QScrollBar::handle:hover {{ background: #a1a1a6; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}

QSlider::groove:horizontal {{ height: 4px; background: #e0e0e5; border-radius: 2px; }}
QSlider::sub-page:horizontal {{ background: {BLUE}; border-radius: 2px; }}
QSlider::handle:horizontal {{ background: white; border: 1px solid #c7c7cc; width: 18px; height: 18px; margin: -8px 0; border-radius: 9px; }}

QMenu {{ background: white; border: 1px solid {LINE}; border-radius: 10px; padding: 5px; }}
QMenu::item {{ padding: 6px 22px 6px 14px; border-radius: 6px; }}
QMenu::item:selected {{ background: {BLUE}; color: white; }}
QMenu::separator {{ height: 1px; background: #e5e5ea; margin: 4px 8px; }}

QStatusBar {{ background: {BG}; color: {SUB}; border-top: 1px solid #e5e5ea; }}
QStatusBar::item {{ border: none; }}
QSplitter::handle {{ background: transparent; }}
QProgressBar {{ background: #e5e5ea; border: none; border-radius: 4px; text-align: center; height: 8px; }}
QProgressBar::chunk {{ background: {BLUE}; border-radius: 4px; }}
"""


def _arrows():
    """下拉框、数字框的小箭头（QSS 只能用图片文件，这里画好存到临时目录）"""
    d = Path(tempfile.gettempdir()) / "drone_teach_ui"
    d.mkdir(exist_ok=True)
    out = {}
    for name, up, col in (("ARROW_DOWN", False, SUB), ("ARROW_DOWN_OFF", False, "#c7c7cc"), ("ARROW_UP", True, SUB)):
        pm = QPixmap(20, 20)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(QPen(QColor(col), 2.4, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        pts = [QPointF(4, 13), QPointF(10, 7), QPointF(16, 13)] if up else [QPointF(4, 7), QPointF(10, 13), QPointF(16, 7)]
        p.drawPolyline(pts)
        p.end()
        f = d / f"{name.lower()}.png"
        pm.save(str(f))
        out[name] = f.as_posix()
    return out


def apply(app):
    app.setStyle("Fusion")
    pal = QPalette()
    for role, col in ((QPalette.Window, BG), (QPalette.WindowText, TEXT), (QPalette.Base, "#ffffff"),
                      (QPalette.AlternateBase, "#fafafc"), (QPalette.Text, TEXT), (QPalette.Button, "#ffffff"),
                      (QPalette.ButtonText, TEXT), (QPalette.Highlight, BLUE), (QPalette.HighlightedText, "#ffffff"),
                      (QPalette.ToolTipBase, "#2c2c2e"), (QPalette.ToolTipText, "#ffffff"),
                      (QPalette.PlaceholderText, "#a1a1a6"), (QPalette.Link, BLUE)):
        pal.setColor(role, QColor(col))
    pal.setColor(QPalette.Disabled, QPalette.Text, QColor("#a1a1a6"))
    pal.setColor(QPalette.Disabled, QPalette.ButtonText, QColor("#a1a1a6"))
    pal.setColor(QPalette.Disabled, QPalette.WindowText, QColor("#a1a1a6"))
    app.setPalette(pal)
    f = QFont("Microsoft YaHei UI" if sys.platform == "win32" else app.font().family())
    f.setPointSizeF(9.5 if sys.platform == "win32" else app.font().pointSizeF())
    f.setHintingPreference(QFont.PreferNoHinting)
    app.setFont(f)
    qss = QSS
    try:
        for k, v in _arrows().items():
            qss = qss.replace(f"@{k}@", v)
    except OSError:
        pass
    app.setStyleSheet(qss)
