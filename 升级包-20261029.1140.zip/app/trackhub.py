"""「黑羊导出 / 模拟飞行」合成一个窗口：两页，打开一张赛道两页都换成它。"""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog, QTabWidget, QVBoxLayout


class TrackHub(QDialog):
    def __init__(self, folder=None, parent=None, preset=None, start="fly"):
        super().__init__(parent)
        from app.track_tool import TrackDialog
        from app.vdexport import ExportDialog
        self.setWindowTitle("黑羊导出 / 模拟飞行")
        self.setWindowFlags(self.windowFlags() | Qt.WindowMaximizeButtonHint | Qt.WindowMinimizeButtonHint)
        self.resize(1400, 860)
        self.fly = TrackDialog(folder, self)
        self.vd = ExportDialog(folder, self, preset=preset)
        for d in (self.fly, self.vd):             # 两个原来的窗口嵌进来当页面
            d.setWindowFlags(Qt.Widget)
            d.reject = lambda: None               # 按 Esc 不要把里面那页关掉
        self.tabs = QTabWidget()
        self.tabs.addTab(self.fly, "▶ 模拟飞行")
        self.tabs.addTab(self.vd, "⬆ 导出黑羊地图")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.addWidget(self.tabs)
        self._syncing = False
        self._wrap(self.fly, self.vd)
        self._wrap(self.vd, self.fly)
        self.fly.export_btn.setText("去导出黑羊地图 →")
        self.fly.export_btn.setToolTip("换到「导出黑羊地图」页：选门框颜色、杆子、起飞台、门间距比例再导出")
        try:
            self.fly.export_btn.clicked.disconnect()
        except (RuntimeError, TypeError):
            pass
        self.fly.export_btn.clicked.connect(lambda: self.tabs.setCurrentWidget(self.vd))
        self.tabs.currentChanged.connect(lambda _i: self.fly.view.pause_sim() if hasattr(self.fly.view, "pause_sim") else None)
        self.tabs.setCurrentWidget(self.vd if start == "vd" else self.fly)

    def _wrap(self, a, b):
        """a 打开了赛道，b 也打开同一张"""
        orig = a.open_file

        def opened(path, _orig=orig):
            _orig(path)
            if not self._syncing:
                self._syncing = True
                try:
                    b.open_file(path)
                finally:
                    self._syncing = False
        a.open_file = opened

    def open_file(self, path):
        self.fly.open_file(path)

    def closeEvent(self, e):
        for d in (self.fly, self.vd):
            d.close()
        super().closeEvent(e)
