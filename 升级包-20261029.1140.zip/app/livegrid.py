"""比赛模式右边的 4 路实时画面：每个选手一个框，框里叠着他自己的计时。

每一框可以选一个采集卡（每个选手的眼镜 HDMI 输出或者接收机接一个采集卡），
只取小预览，不录像，占电脑资源少。双击一个框放大成单个画面，再双击回到 4 格。
"""
import subprocess
import threading

from PySide6.QtCore import QObject, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPen
from PySide6.QtWidgets import QComboBox, QGridLayout, QHBoxLayout, QLabel, QSizePolicy, QVBoxLayout, QWidget

from app import ffmpeg_tools as ft
from app.config import IS_WINDOWS
from app.overlay import fit_rect

PW, PH = 640, 360
NONE = "不显示画面"


class PreviewCapture(QObject):
    """一个采集卡的小预览（ffmpeg → 原始画面 → 管道）"""
    failed = Signal(str)

    def __init__(self, device):
        super().__init__()
        self.device = device
        self.proc = None
        self.frame = None
        self.lock = threading.Lock()

    def start(self):
        exe = ft.ffmpeg_path()
        if not exe:
            self.failed.emit("找不到 FFmpeg")
            return
        if self.device == ft.TEST_DEVICE or not IS_WINDOWS:
            inp = ["-re", "-f", "lavfi", "-i", f"testsrc2=size={PW}x{PH}:rate=30"]
        else:
            inp = ft.dshow_input_args(self.device, ft.DEFAULT_MODE)
        cmd = [exe, "-hide_banner", "-loglevel", "error", *inp, "-an",
               "-vf", f"fps=30,scale={PW}:{PH}:flags=fast_bilinear:force_original_aspect_ratio=decrease,"
                      f"pad={PW}:{PH}:(ow-iw)/2:(oh-ih)/2,format=bgr0",
               "-f", "rawvideo", "-pix_fmt", "bgr0", "pipe:1"]
        try:
            self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                         bufsize=0, creationflags=ft.NO_WINDOW)
        except OSError as e:
            self.failed.emit(f"打不开：{e}")
            return
        threading.Thread(target=self._read, args=(self.proc,), daemon=True).start()

    def _read(self, proc):
        size = PW * PH * 4
        while True:
            buf = bytearray()
            while len(buf) < size:
                chunk = proc.stdout.read(size - len(buf))
                if not chunk:
                    break
                buf += chunk
            if len(buf) < size:
                break
            img = QImage(bytes(buf), PW, PH, PW * 4, QImage.Format_RGB32).copy()
            with self.lock:
                self.frame = img
        if self.proc is proc:
            err = proc.stderr.read().decode("utf-8", "replace").strip().splitlines()
            self.failed.emit("画面断了" + (f"：{err[-1][:80]}" if err else "（采集卡被别的程序占用或者拔掉了）"))

    def latest(self):
        with self.lock:
            return self.frame

    def stop(self):
        proc, self.proc = self.proc, None
        if not proc:
            return
        try:
            proc.stdin.write(b"q")
            proc.stdin.flush()
            proc.wait(timeout=2)
        except (OSError, subprocess.TimeoutExpired):
            proc.kill()


class PilotView(QWidget):
    """一个选手的画面 + 他自己的计时"""
    double_clicked = Signal()

    def __init__(self, idx, color: QColor):
        super().__init__()
        self.idx = idx
        self.color = color
        self.image = None
        self.info = dict(name="", on=False)
        self.message = ""
        self.flash_until = 0.0
        self.now = 0.0
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumSize(240, 135)

    def mouseDoubleClickEvent(self, _):
        self.double_clicked.emit()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect())
        p.fillRect(r, QColor(12, 12, 14))
        inf = self.info
        if self.image is not None:
            p.drawImage(fit_rect(r, self.image.width(), self.image.height()), self.image)
        else:
            p.setPen(QColor(110, 110, 120))
            f = QFont()
            f.setPointSize(11)
            p.setFont(f)
            p.drawText(r.adjusted(10, 40, -10, -10), Qt.AlignCenter | Qt.TextWordWrap,
                       self.message or "上面选这个选手的采集卡，显示他的图传画面")
        s = max(0.6, min(1.4, r.width() / 640, r.height() / 360))
        # 上面一条：路数、名字、名次
        bar = QRectF(0, 0, r.width(), 34 * s)
        p.fillRect(bar, QColor(0, 0, 0, 150))
        p.fillRect(QRectF(0, 0, 8 * s, bar.height()), self.color)
        f = QFont()
        f.setBold(True)
        f.setPixelSize(int(20 * s))
        p.setFont(f)
        p.setPen(self.color if inf.get("on") else QColor(120, 120, 120))
        p.drawText(bar.adjusted(16 * s, 0, 0, 0), Qt.AlignVCenter | Qt.AlignLeft,
                   f"{self.idx + 1} 路  {inf.get('label') or inf.get('name') or ''}"
                   + (f"  ·  {inf['ch']}" if inf.get("ch") else "") + ("" if inf.get("on") else "（没用）"))
        if inf.get("rank"):
            p.setPen(QColor(255, 210, 60))
            p.drawText(bar.adjusted(0, 0, -12 * s, 0), Qt.AlignVCenter | Qt.AlignRight, f"第 {inf['rank']} 名")
        # 下面：本圈计时（大字）+ 圈数、上一圈、最快
        if inf.get("on") and inf.get("state"):
            h = 78 * s
            box = QRectF(0, r.height() - h, r.width(), h)
            p.fillRect(box, QColor(0, 0, 0, 160))
            big = QFont()
            big.setBold(True)
            big.setPixelSize(int(46 * s))
            p.setFont(big)
            p.setPen(QColor(255, 255, 255))
            p.drawText(box.adjusted(14 * s, 0, 0, 0), Qt.AlignVCenter | Qt.AlignLeft, inf.get("big", ""))
            sm = QFont()
            sm.setPixelSize(int(17 * s))
            sm.setBold(True)
            p.setFont(sm)
            lines = [inf.get("laps", ""), inf.get("last", ""), inf.get("best", "")]
            lh = h / 3
            for k, t in enumerate(lines):
                p.setPen(QColor(200, 110, 255) if k == 2 else QColor(230, 230, 235))
                p.drawText(QRectF(r.width() * 0.45, box.top() + k * lh, r.width() * 0.55 - 14 * s, lh),
                           Qt.AlignVCenter | Qt.AlignRight, t)
            if inf.get("state_text"):
                p.setPen(QColor(120, 230, 140))
                p.setFont(sm)
                p.drawText(QRectF(14 * s, box.top() - 28 * s, r.width(), 26 * s), Qt.AlignLeft | Qt.AlignVCenter,
                           inf["state_text"])
        # 刚过门：边框闪一下
        if self.now < self.flash_until:
            p.setPen(QPen(QColor(120, 255, 120) if not inf.get("best_flash") else QColor(210, 110, 255), 8 * s))
            p.setBrush(Qt.NoBrush)
            p.drawRect(r.adjusted(4 * s, 4 * s, -4 * s, -4 * s))
        p.setPen(QPen(QColor(60, 60, 66), 1))
        p.setBrush(Qt.NoBrush)
        p.drawRect(r.adjusted(0, 0, -1, -1))


class LiveGrid(QWidget):
    """4 个选手画面，2×2；双击放大单个"""
    device_changed = Signal(int, str)

    def __init__(self, colors, devices: list[str], chosen: list[str]):
        super().__init__()
        self.views, self.boxes, self.caps, self.cells = [], [], [None] * len(colors), []
        self.single = None
        self.grid = QGridLayout(self)
        self.grid.setContentsMargins(0, 0, 0, 0)
        self.grid.setSpacing(4)
        for i, col in enumerate(colors):
            v = PilotView(i, col)
            v.double_clicked.connect(lambda k=i: self.toggle_single(k))
            box = QComboBox()
            box.setToolTip("这个选手的画面从哪个采集卡来")
            cell = QWidget()
            cl = QVBoxLayout(cell)
            cl.setContentsMargins(0, 0, 0, 0)
            cl.setSpacing(2)
            row = QHBoxLayout()
            dot = QLabel(f"{i + 1} 路画面")
            dot.setStyleSheet(f"color: {col.name()}; font-weight: bold;")
            row.addWidget(dot)
            row.addWidget(box, 1)
            cl.addLayout(row)
            cl.addWidget(v, 1)
            self.views.append(v)
            self.boxes.append(box)
            self.cells.append(cell)
            box.currentTextChanged.connect(lambda t, k=i: self._chosen(k, t))
        self.set_devices(devices, chosen)
        self._place()

    def set_devices(self, devices, chosen):
        for i, box in enumerate(self.boxes):
            want = chosen[i] if i < len(chosen) else NONE
            box.blockSignals(True)
            box.clear()
            box.addItems([NONE] + devices)
            box.setCurrentText(want if box.findText(want) >= 0 else NONE)
            box.blockSignals(False)

    def start_all(self):
        for i, box in enumerate(self.boxes):
            if not self.caps[i] and box.currentText() != NONE:
                self._open(i, box.currentText())

    def _chosen(self, i, name):
        self._open(i, name)
        self.device_changed.emit(i, name)

    def _open(self, i, name):
        if self.caps[i]:
            self.caps[i].stop()
            self.caps[i] = None
        v = self.views[i]
        v.image = None
        v.message = ""
        if name == NONE:
            return
        users = [k for k, b in enumerate(self.boxes) if k != i and b.currentText() == name and name != ft.TEST_DEVICE]
        if users:
            v.message = f"这个采集卡已经给 {users[0] + 1} 路用了，一个采集卡只能接一个选手"
            return
        cap = PreviewCapture(name)
        cap.failed.connect(lambda msg, k=i: self._failed(k, msg))
        self.caps[i] = cap
        v.message = "正在打开采集卡…"
        cap.start()

    def _failed(self, i, msg):
        self.views[i].message = msg
        self.views[i].image = None

    def refresh_frames(self):
        for v, cap in zip(self.views, self.caps):
            if cap:
                img = cap.latest()
                if img is not None:
                    v.image = img

    def toggle_single(self, i):
        self.single = None if self.single == i else i
        self._place()

    def _place(self):
        for c in self.cells:
            self.grid.removeWidget(c)
            c.hide()
        if self.single is None:
            for i, c in enumerate(self.cells):
                self.grid.addWidget(c, i // 2, i % 2)
                c.show()
        else:
            self.grid.addWidget(self.cells[self.single], 0, 0, 2, 2)
            self.cells[self.single].show()

    def stop_all(self):
        for i, cap in enumerate(self.caps):
            if cap:
                cap.stop()
                self.caps[i] = None
