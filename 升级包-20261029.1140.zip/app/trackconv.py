"""组委会 eDrawings 赛道 exe  ->  VelociDrone（黑羊）.trk

只读 exe 里附带的 eDrawings 数据（不运行 exe）：
  exe 中间夹着一个 zip，里面的 eModel 是 HSF 模型（zlib 压缩）。
  - 每个零件 assempartN 有名字和 4x3 变换矩阵（米，y 朝上）
  - 名字带「赛道布局图」的零件里是一根根管子，就是飞行路线
路线和每个门洞求交点，得到过门顺序和方向；门框按设定的方管粗细和门洞尺寸重建。
"""
import base64, io, json, math, re, struct, zipfile, zlib
from collections import defaultdict

try:
    from . import aes
except ImportError:
    import aes

# ----------------------------------------------------------------------- 门型
# CAD 里这些门的尺寸：门洞 2.0 m，方管 0.2 m（用来识别路线穿过的是哪个门洞）
CAD_S, CAD_T = 2.0, 0.2
TYPES = {
    '单门': '单门（一个门洞）',
    '日子门': '日字门（上下两个门洞）',
    '三联': '三联门（并排三个门洞）',
    '单重': '方框（一个立方体）',
    '双重': '双层方框（两个立方体叠起来）',
    '起飞台': '起飞台',
    '杆子': '杆子（绕杆用）',
    '刀旗': '刀旗（从左边或右边过）',
    '降落区': '降落区',
    '路线': '飞行路线',
    '忽略': '不导出',
}
KEYWORDS = [('赛道布局', '路线'), ('双重', '双重'), ('单重', '单重'), ('三联', '三联'),
            ('日子', '日子门'), ('单门', '单门'), ('起飞', '起飞台'), ('降落', '降落区')]


def guess_type(name, remembered=None):
    if remembered and name_key(name) in remembered:
        return remembered[name_key(name)]
    for kw, t in KEYWORDS:
        if kw in name:
            return t
    return '忽略'


def name_key(name):
    """同一种零件的不同实例：「单门 (2)-11」->「单门 (2)」"""
    return re.sub(r'-\d+$', '', name).strip()


# ----------------------------------------------------------------- 读 exe
def read_exe(path):
    b = open(path, 'rb').read()
    e = b.rfind(b'PK\x05\x06')
    if e < 0:
        raise ValueError('这个文件里没有找到 eDrawings 赛道数据')
    clen = struct.unpack('<H', b[e+20:e+22])[0]
    z = zipfile.ZipFile(io.BytesIO(b[:e+22+clen]))
    names = z.namelist()
    if 'eModel' not in names:
        raise ValueError('这个文件里没有 eModel（不是 eDrawings 导出的赛道？）')
    em = z.read('eModel')
    preview = z.read('preview.jpg') if 'preview.jpg' in names else None
    i = em.find(b'\x78\xda')
    if i < 0:
        i = em.find(b'\x78\x9c')
    return zlib.decompressobj().decompress(em[i:]), preview


def parse_hsf(d):
    start = d.find(b'?Include Library/references')
    if start < 0:
        start = len(d)
    pre = d[:start]
    # 零件
    heads = list(re.finditer(rb'\(.assempart(\d+)', pre, re.S))
    parts = []
    for k, m in enumerate(heads):
        n = int(m.group(1)); s = m.end()
        end = heads[k+1].start() if k+1 < len(heads) else len(pre)
        seg = pre[s:end]
        nm = None
        for off in (0, 1):                      # 名字是 UTF-16，可能从奇数位置开始
            nm = re.search(r'name=`([^`]*)`', seg[off:off+1200].decode('utf-16le', 'ignore'))
            if nm:
                break
        if not nm:
            continue
        j = seg.find(b'part%')
        if j < 0:
            continue
        v = struct.unpack('<12f', seg[j+5:j+53])
        bodies = sorted(set(int(x) for x in re.findall(rb'shared/body(\d+)', seg)))
        parts.append(dict(id=n, name=nm.group(1), m=list(v[:9]), o=list(v[9:12]), bodies=bodies))
    # 实体：占位顺序 + 真正的点
    ph = [(int(m.group(1)), m.group(2).count(b'S\x90'))
          for m in re.finditer(rb'body(\d+)sub0((?:S\x90\x02\x00\x00q)+)', pre)]
    seq = [b for b, n in ph for _ in range(n)]
    shells = []; i = start
    while True:
        j = d.find(b'S\x0e', i)
        if j < 0:
            break
        key = struct.unpack('<I', d[j+2:j+6])[0]; n = struct.unpack('<I', d[j+7:j+11])[0]
        if 0 < n < 200000 and j+11+12*n <= len(d):
            pts = struct.unpack('<%df' % (3*n), d[j+11:j+11+12*n])
            if all(abs(x) < 1e4 for x in pts):
                e = j+11+12*n
                shells.append((key, pts, _strips(d, e, n))); i = e; continue
        i = j+2
    rank = {k: r for r, k in enumerate(sorted(k for k, _, _ in shells))}
    bodies = defaultdict(list); edges = defaultdict(list); pieces = defaultdict(list)
    for key, pts, ed in shells:
        r = rank[key]
        if r < len(seq):
            b = seq[r]; off = len(bodies[b])//3
            bodies[b].extend(pts)
            pieces[b].append(pts)
            edges[b].extend((a+off, c+off) for a, c in ed)
    return parts, dict(bodies), dict(edges), dict(pieces)


def _strips(d, e, n):
    """点后面跟着三角带：[长度, 序号...]...，取出相邻点的连线（用来顺着管子走）"""
    try:
        if d[e] != 1:
            return []
        L = struct.unpack('<I', d[e+1:e+5])[0]; size = d[e+5]
        if size == 0x10:
            arr = struct.unpack('<%dH' % ((L-1)//2), d[e+6:e+6+(L-1)//2*2])
        elif size == 0x08:
            arr = d[e+6:e+6+L-1]
        else:
            return []
    except struct.error:
        return []
    out = []; k = 0
    while k < len(arr):
        m = arr[k]; st = arr[k+1:k+1+m]
        if m == 0 or len(st) < m or max(st) >= n:
            break
        for t in range(m-1):
            out.append((st[t], st[t+1]))
            if t+2 < m:
                out.append((st[t], st[t+2]))
        k += 1+m
    return out


def load(path):
    d, preview = read_exe(path)
    parts, bodies, edges, pieces = parse_hsf(d)
    for p in parts:                       # 零件自身的外框（局部坐标）：按形状认门、找中心
        pts = [v for b in p['bodies'] for v in bodies.get(b, [])]
        if pts:
            lo = [min(pts[k::3]) for k in range(3)]; hi = [max(pts[k::3]) for k in range(3)]
            p['ext'] = [hi[k]-lo[k] for k in range(3)]
            p['lc'] = [(hi[k]+lo[k])/2 for k in range(3)]
            p['npts'] = len(pts)//3
    return dict(parts=parts, bodies=bodies, edges=edges, pieces=pieces, preview=preview)


# ------------------------------------------------------------- 小数学
def add(a, b): return [i+j for i, j in zip(a, b)]
def sub(a, b): return [i-j for i, j in zip(a, b)]
def mul(a, s): return [i*s for i in a]
def dot(a, b): return sum(i*j for i, j in zip(a, b))
def cross(u, v): return [u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]]
def norm(v):
    l = math.sqrt(dot(v, v)) or 1
    return [i/l for i in v]


def xform(p, v, point=True):
    m = p['m']; x, y, z = v
    r = [x*m[0]+y*m[3]+z*m[6], x*m[1]+y*m[4]+z*m[7], x*m[2]+y*m[5]+z*m[8]]
    return add(r, p['o']) if point else r


def quat(rx, ry, rz):
    m00, m10, m20 = rx; m01, m11, m21 = ry; m02, m12, m22 = rz
    tr = m00+m11+m22
    if tr > 0:
        s = math.sqrt(tr+1)*2; w = s/4; x = (m21-m12)/s; y = (m02-m20)/s; z = (m10-m01)/s
    elif m00 > m11 and m00 > m22:
        s = math.sqrt(1+m00-m11-m22)*2; w = (m21-m12)/s; x = s/4; y = (m01+m10)/s; z = (m02+m20)/s
    elif m11 > m22:
        s = math.sqrt(1+m11-m00-m22)*2; w = (m02-m20)/s; x = (m01+m10)/s; y = s/4; z = (m12+m21)/s
    else:
        s = math.sqrt(1+m22-m00-m11)*2; w = (m10-m01)/s; x = (m02+m20)/s; y = (m12+m21)/s; z = s/4
    if w < 0:
        w, x, y, z = -w, -x, -y, -z
    return [round(1000*v) for v in (w, x, y, z)]


def qrot(q, v):
    w, x, y, z = [c/1000 for c in q]; n = math.sqrt(w*w+x*x+y*y+z*z); w, x, y, z = w/n, x/n, y/n, z/n
    vx, vy, vz = v; tx = 2*(y*vz-z*vy); ty = 2*(z*vx-x*vz); tz = 2*(x*vy-y*vx)
    return (vx+w*tx+(y*tz-z*ty), vy+w*ty+(z*tx-x*tz), vz+w*tz+(x*ty-y*tx))


# ------------------------------------------------------------- 飞行路线
def _ring_centres(pts):
    """管子是一圈圈的点：聚成圈心"""
    H = defaultdict(list)
    for i, q in enumerate(pts):
        H[tuple(int(math.floor(v/0.5)) for v in q)].append(i)
    used = [False]*len(pts); cent = []; lab = [0]*len(pts)
    for i, q in enumerate(pts):
        if used[i]:
            continue
        c = tuple(int(math.floor(v/0.5)) for v in q); grp = []; idx = []
        for a in (-1, 0, 1):
            for b in (-1, 0, 1):
                for e in (-1, 0, 1):
                    for j in H.get((c[0]+a, c[1]+b, c[2]+e), []):
                        if not used[j] and math.dist(pts[j], q) < 0.42:
                            used[j] = True; grp.append(pts[j]); idx.append(j)
        for j in idx:
            lab[j] = len(cent)
        cent.append([sum(g[t] for g in grp)/len(grp) for t in range(3)])
    return cent, lab


def route_arrows(model, types):
    """组委会路线上的箭头（小圆锥）：返回 [(位置, 指向)]，用来确定路线方向"""
    out = []
    for p in model['parts']:
        if types.get(p['id']) != '路线':
            continue
        for b in p['bodies']:
            for pc in model.get('pieces', {}).get(b, []):
                n = len(pc)//3
                if n > 300:
                    continue
                P = [xform(p, pc[i:i+3]) for i in range(0, len(pc), 3)]
                ext = sorted(max(q[k] for q in P)-min(q[k] for q in P) for k in range(3))
                if ext[0] < 0.2 or ext[2] > 0.8:        # 平的圆片（端盖、锥底）或太大：不是圆锥
                    continue
                def spread(q):                      # 锥尖到底圈每个点一样远
                    ds = [math.dist(q, r) for r in P if math.dist(q, r) > 0.05]
                    if len(ds) < 3:
                        return 9
                    mu = sum(ds)/len(ds)
                    return sum((x-mu)**2 for x in ds)/len(ds)
                apex = min(P, key=spread)
                ring = [q for q in P if math.dist(q, apex) > 0.2]
                if len(ring) < 3:
                    continue
                base = [sum(q[k] for q in ring)/len(ring) for k in range(3)]
                out.append((apex, norm(sub(apex, base))))
    return out


def route_path(model, types):
    """飞行路线：把路线管的点聚成一圈圈的圈心，再顺着管子的网格连线从起飞台一路走下去
    （只走网格上真正相连的圈，路线绕回来贴得很近也不会串错）"""
    pts, edges = [], []
    for p in model['parts']:
        if types.get(p['id']) != '路线':
            continue
        for b in p['bodies']:
            raw = model['bodies'].get(b, [])
            if len(raw)//3 <= 24:                 # 一个长方体（场地板之类），不是路线管
                continue
            off = len(pts)
            pts += [xform(p, raw[i:i+3]) for i in range(0, len(raw), 3)]
            edges += [(a+off, c+off) for a, c in model.get('edges', {}).get(b, [])]
    if not pts:
        return []
    cent, lab = _ring_centres(pts)
    adj = defaultdict(set)
    for a, c in edges:
        x, y = lab[a], lab[c]
        if x != y:
            adj[x].add(y); adj[y].add(x)
    take = next((p for p in model['parts'] if types.get(p['id']) == '起飞台'), None)
    s0 = take['o'] if take else cent[0]
    start = min(range(len(cent)), key=lambda i: math.dist((cent[i][0], cent[i][2]), (s0[0], s0[2])))
    order = [start]; seen = {start}; left = set(range(len(cent))) - {start}
    while left:
        cur = order[-1]
        d0 = norm(sub(cent[cur], cent[order[-2]])) if len(order) > 1 else None

        def straight(i):
            v = sub(cent[i], cent[cur])
            return -dot(d0, norm(v)) if d0 else math.dist(cent[i], cent[cur])
        nb = [i for i in adj[cur] if i not in seen]
        if nb:
            j = min(nb, key=straight)
        else:                                     # 管子断开（端盖、箭头）：跳到最近的没走过的圈
            j = min(left, key=lambda i: math.dist(cent[i], cent[cur]) * (1 + 0.8*(1 + straight(i)) if d0 else 1))
        order.append(j); seen.add(j); left.discard(j)
    path = [cent[i] for i in order]
    # 走到降落区就结束：后面剩下的零碎点（箭头、端盖）不要
    land = next((p for p in model['parts'] if types.get(p['id']) == '降落区'), None)
    if land and len(path) > 10:
        lo = len(path)*3//4
        k = min(range(lo, len(path)), key=lambda i: math.dist((path[i][0], path[i][2]), (land['o'][0], land['o'][2])))
        path = path[:k+1]
    # 用组委会画的箭头核对方向：大多数箭头和路线反着，就整条反过来
    agree, against = arrow_check(path, route_arrows(model, types))
    if against > agree:
        path = path[::-1]
    return path


def arrow_check(path, arrows):
    """每个箭头找附近的路线点，看方向一致还是相反"""
    agree = against = 0
    for a, dv in arrows:
        best = 0.0
        for i in range(len(path)):
            if math.dist(path[i], a) < 0.5:
                pd = norm(sub(path[min(len(path)-1, i+2)], path[max(0, i-2)]))
                v = dot(pd, dv)
                if abs(v) > abs(best):
                    best = v
        if best > 0.7:
            agree += 1
        elif best < -0.7:
            against += 1
    return agree, against


# ---------------------------------------------------- 门型几何（零件坐标 a, y, b）
def frame_of(p, t):
    m = p['m']; X = m[0:3]; Y = m[3:6]; Z = m[6:9]
    # 中心用零件自己的外框中心（原点不一定在中间：三联在一端，双重在一个侧面）
    O = xform(p, p['lc']) if 'lc' in p else p['o']
    if 'lc' not in p and t == '三联':
        O = add(O, mul(Z, -(3*CAD_S+4*CAD_T)/2))
    rows = [X, Y, Z]
    up = max(range(3), key=lambda i: abs(rows[i][1]))   # 哪根局部轴是竖着的（双重是躺着画的：X 朝下）
    a, b = [r for i, r in enumerate(rows) if i != up]
    return [O[0], p.get('lift', 0.0), O[2]], a, b       # lift：叠在别的门上面（手工拼的组合门）


def to_world(fr, v):
    C, a, b = fr
    return [C[0]+v[0]*a[0]+v[2]*b[0], v[1]+C[1], C[2]+v[0]*a[2]+v[2]*b[2]]


def vec_world(fr, v):
    C, a, b = fr
    return [v[0]*a[0]+v[2]*b[0], v[1], v[0]*a[2]+v[2]*b[2]]


A_, Y_, B_ = (1, 0, 0), (0, 1, 0), (0, 0, 1)


def openings(t, S, T):
    """门洞：(标签, 中心, 法向, 宽度方向)，零件坐标"""
    H = S+2*T; c = S/2+T/2; mid = T+S/2
    if t == '单门':
        return [('门', (0, mid, 0), B_, A_)]
    if t == '日子门':
        return [('下', (0, mid, 0), B_, A_), ('上', (0, H+S/2, 0), B_, A_)]
    if t == '三联':
        return [(str(i+1), (0, mid, (1-i)*(S+T)), A_, B_) for i in range(3)]
    if t in ('单重', '双重'):
        n = 1 if t == '单重' else 2; out = []
        for k in range(n):
            y = k*(H-T)+mid; pre = '' if n == 1 else ('下层' if k == 0 else '上层')
            out += [(pre+'右', (c, y, 0), A_, B_), (pre+'左', (-c, y, 0), A_, B_),
                    (pre+'前', (0, y, c), B_, A_), (pre+'后', (0, y, -c), B_, A_)]
        out.append(('顶', (0, n*H-(n-1)*T-T/2, 0), Y_, A_))
        return out
    if t == '刀旗':                 # 刀旗两边各一个看不见的进门框：从旗的左边 / 右边过（组委会的线离旗 1.4～2 米）
        off = 0.6 + S/2
        return [('左', (off, mid, 0), B_, A_), ('右', (-off, mid, 0), B_, A_)]
    return []


def boxes(t, S, T, lifted=False):
    """方管：(中心, 尺寸)，零件坐标；lifted = 叠在别的门上面，不要底座脚"""
    H = S+2*T; c = S/2+T/2; B = []
    if t in ('单门', '日子门'):
        n = 1 if t == '单门' else 2; ph = n*H-(n-1)*T
        for s in (-1, 1):
            B.append(((s*c, ph/2, 0), (T, ph, T)))
            if not lifted:
                B.append(((s*c, T/2, 0), (T, T, 2.6)))      # 底座脚
        for i in range(n+1):
            B.append(((0, i*(H-T)+T/2, 0), (S, T, T)))
    elif t == '三联':
        for k in range(4):
            b = -1.5*(S+T)+k*(S+T)
            B.append(((0, H/2, b), (T, H, T)))
            if not lifted:
                B.append(((0, T/2, b), (3.2, T, T)))
        for y in (T/2, H-T/2):
            B.append(((0, y, 0), (T, T, 3*S+2*T)))
    elif t in ('单重', '双重'):
        n = 1 if t == '单重' else 2; ph = n*H-(n-1)*T
        for sa in (-1, 1):
            for sb in (-1, 1):
                B.append(((sa*c, ph/2, sb*c), (T, ph, T)))
        for i in range(n+1):
            y = i*(H-T)+T/2
            for s in (-1, 1):
                B.append(((s*c, y, 0), (T, T, S)))
                B.append(((0, y, s*c), (S, T, T)))
    elif t == '杆子':                                      # 绕杆用的杆子：3 米高
        B.append(((0, 1.5, 0), (T, 3.0, T)))
    elif t == '刀旗':                                      # 旗杆 3.2 米 + 一面竖着的刀形旗
        B.append(((0, 1.6, 0), (0.08, 3.2, 0.08)))
        B.append(((0, 2.3, 0.32), (0.04, 1.6, 0.6)))
    elif t == '起飞台':
        for x in (-1.65, -0.55, 0.55, 1.65):
            B.append(((x, 0.6, 0), (0.5, 1.2, 0.5)))
    elif t == '降落区':
        B.append(((0, 0.01, 0), (5, 0.02, 5)))
    return B


# ------------------------------------------------------------ 过门顺序
def crossings(model, types, path):
    """路线和 CAD 门洞（2.0 m）求交：[(路线位置, 零件id, 门洞标签, 方向±1)]"""
    out = []
    P = [p for p in model['parts'] if types.get(p['id']) in ('单门', '日子门', '三联', '单重', '双重', '刀旗')]
    ops = []
    for p in P:
        t = types[p['id']]; fr = frame_of(p, t)
        for lab, c, n, w in openings(t, CAD_S, CAD_T):
            nw = vec_world(fr, n); ww = vec_world(fr, w)
            ops.append((p['id'], lab, to_world(fr, c), nw, ww, norm(cross(nw, ww))))
    G = 4.0                                     # 门洞按 4 米格子分好，每段路线只查附近格子里的
    grid = {}
    for o in ops:
        grid.setdefault((math.floor(o[2][0]/G), math.floor(o[2][2]/G)), []).append(o)
    pad = CAD_S
    for i in range(len(path)-1):
        a, b = path[i], path[i+1]
        if math.dist(a, b) > 6:
            continue
        x0, x1 = math.floor((min(a[0], b[0])-pad)/G), math.floor((max(a[0], b[0])+pad)/G)
        z0, z1 = math.floor((min(a[2], b[2])-pad)/G), math.floor((max(a[2], b[2])+pad)/G)
        near = [o for gx in range(x0, x1+1) for gz in range(z0, z1+1) for o in grid.get((gx, gz), ())]
        for pid, lab, c, n, w, up in near:
            da = (a[0]-c[0])*n[0] + (a[1]-c[1])*n[1] + (a[2]-c[2])*n[2]
            db = (b[0]-c[0])*n[0] + (b[1]-c[1])*n[1] + (b[2]-c[2])*n[2]
            if (da > 0) == (db > 0) or da == db:
                continue
            t = da/(da-db); h = [a[k]+t*(b[k]-a[k]) for k in range(3)]; r = sub(h, c)
            lim = CAD_S/2 - 0.05
            if abs(dot(r, w)) <= lim and abs(dot(r, up)) <= lim:
                out.append([i+t, pid, lab, 1 if db > da else -1])
    out.sort()
    # 同一个门洞来回各穿一次（路线贴着面画的）：不算
    keep = []
    for c in out:
        if keep and keep[-1][1:3] == c[1:3] and keep[-1][3] == -c[3] and c[0]-keep[-1][0] < 2:
            keep.pop(); continue
        keep.append(c)
    return keep


# --------------------------------------------------------------- 生成
SCENES = {42: ('Empty Polyworld（空旷场地，电脑和手机都能飞）', -1),
          21: ('Sports Hall（体育馆，只有电脑版）', 7)}


def build(model, types, S=2.5, T=0.2, scene=42, name='Track', path=None):
    floor = SCENES[scene][1]
    parts = {p['id']: p for p in model['parts']}
    if path is None:
        path = route_path(model, types)
    notes = []

    shifts = spread_shifts(model, types, S, T)

    def frame_out(p, t):
        C, a, b = frame_of(p, t)
        sh = shifts.get(p['id'])
        return (add(C, sh) if sh else C), a, b

    barriers = []
    for p in model['parts']:
        t = types.get(p['id'])
        barriers += emit_barriers(t, frame_out(p, t), S, T, floor)

    def gate(centre, fly, wdir, w, h, prefab=88):
        return emit_gate(centre, fly, wdir, w, h, floor, prefab)

    gates, labels = [], []

    def push(g, lab):
        g.update(gate=len(gates), start=False, finish=False, lap1only=False)
        gates.append(g); labels.append(lab)

    arrows = route_arrows(model, types)
    if arrows:
        ok, bad = arrow_check(path, arrows)
        notes.append(f"按组委会路线上的箭头核对方向：{ok} 个和路线一致，" + (f"{bad} 个相反，请检查" if bad else "没有反的"))
    cr = crossings(model, types, path)
    passed = {c[1] for c in cr}
    # 塔：组委会的线贴着塔面画，算不出穿过哪个面 -> 看路线（箭头方向）从哪进、从哪出
    for p in model['parts']:
        if types.get(p['id']) != '双重' or p['id'] in passed:
            continue
        runs = tower_runs(p, path)
        if not runs:
            notes.append(f"{p['name']}：路线没有经过，没放检查点")
        for r in runs:
            cr.append([r['i0'], p['id'], r['in'][0], r['in'][1]])
            cr.append([r['i1'], p['id'], r['out'][0], r['out'][1]])
            notes.append(f"{p['name']}：按路线方向，从「{r['in'][0]}」进，从「{r['out'][0]}」出")
    cr.sort(key=lambda c: c[0])
    while len(cr) > 1 and types.get(cr[0][1]) == '刀旗':
        cr.pop(0)                                 # 起飞的时候从刀旗旁边擦过：不算，计时门得是真门
    for pid in sorted({c[1] for c in cr if types[c[1]] in ('单重', '双重')}):
        seq = [c[2] for c in cr if c[1] == pid]
        if not any('按路线方向' in n and parts[pid]['name'] in n for n in notes):
            notes.append(f"{parts[pid]['name']}：按路线依次穿过「" + '」→「'.join(seq) + '」')
    extra = []
    seq = [(c[0], 'x', c) for c in cr] + [(e[0], 'e', e) for e in extra]
    seq.sort(key=lambda s: s[0])
    for _, kind, c in seq:
        if kind == 'e':
            _, pid, lab, fly, out, cen = c
            push(gate(cen, fly, [-out[2], 0, out[0]], S, S), f"{parts[pid]['name']} {lab}")
            continue
        _, pid, lab, d = c
        p = parts[pid]; t = types[pid]; fr = frame_out(p, t)
        o = {l: (cc, n, w) for l, cc, n, w in openings(t, S, T)}[lab]
        nw = vec_world(fr, o[1])
        push(gate(to_world(fr, o[0]), mul(nw, d), vec_world(fr, o[2]), S, S), f"{p['name']} {lab}")
    mark_timing(gates, labels, notes)
    unused = [parts[i]['name'] for i, t in types.items()
              if t in ('单门', '日子门', '三联', '单重') and i not in passed]
    for n in unused:
        notes.append(f'{n}：路线没有穿过，只摆了门框，不算检查点')
    path = center_tower_dives(model, types, path)
    others = [parts[i]['name'] for i, t in types.items() if t == '忽略' and max(parts[i].get('ext', [0])) < 20]
    if others:
        notes.append('原图里还有：' + '、'.join(sorted({name_key(n) for n in others})) + '（预览里画成灰色，不导出）')
    return dict(gates=gates, barriers=barriers, labels=labels, path=path, notes=notes, scene=scene, name=name,
                arrows=arrows, scenery=scenery(model, types))


def scenery(model, types):
    """原图里认不出来的东西（刀旗、标志牌…）：网格线段，世界坐标，只给预览用"""
    segs = []
    for p in model['parts']:
        if types.get(p['id']) != '忽略' or max(p.get('ext', [99])) >= 20:
            continue
        for b in p['bodies']:
            pts = model['bodies'].get(b, [])
            W = [xform(p, pts[i:i+3]) for i in range(0, len(pts), 3)]
            seen = set()
            for i, j in model['edges'].get(b, []):
                if i >= len(W) or j >= len(W):
                    continue
                k = (min(i, j), max(i, j))
                if k in seen or math.dist(W[i], W[j]) < 0.05:
                    continue
                seen.add(k)
                segs.append((W[i], W[j]))
    return segs[:30000]


def unity(p, floor):
    return [p[0]*100, p[1]*100+floor, -p[2]*100]


def emit_barriers(t, fr, S, T, floor):
    """一个零件的方管 -> 黑羊方块（54 号，按 2 米的百分比缩放，轴心在底面中间）"""
    bx = boxes(t, S, T, lifted=fr[0][1] > 0.01)
    if not bx:
        return []
    au = norm([fr[1][0], fr[1][1], -fr[1][2]]); bu = cross(au, [0, 1, 0]); rot = quat(au, [0, 1, 0], bu)
    out = []
    for (cx, cy, cz), (sx, sy, sz) in bx:
        base = unity(to_world(fr, (cx, cy-sy/2, cz)), floor)
        out.append({"prefab": 54, "trans": {"pos": [round(v) for v in base], "rot": rot,
                    "scale": [max(1, round(sx*50)), max(1, round(sy*50)), max(1, round(sz*50))]}})
    return out


def emit_gate(centre, fly, wdir, w, h, floor, prefab=88):
    """检查点：centre 门洞中心（米），fly 飞过去的方向，wdir 门洞宽度方向"""
    Ud = lambda d: [d[0], d[1], -d[2]]
    rx = mul(norm(Ud(fly)), -1)
    ry = norm(Ud(wdir)); ry = norm(sub(ry, mul(rx, dot(ry, rx))))
    rz = cross(rx, ry)
    c = unity(centre, floor); pos = [c[i]-0.5*h*100*rz[i] for i in range(3)]
    return {"prefab": prefab, "trans": {"pos": [round(v) for v in pos], "rot": quat(rx, ry, rz),
            "scale": [3 if prefab == 88 else 14, round(w*50), round(h*50)]}}


def mark_timing(gates, labels, notes):
    """计时：起飞后过的第一个门就是计时门（起点/终点），飞完一圈再过它算一圈"""
    if not gates:
        return
    if len(gates) > 1 and labels[-1] == labels[0]:
        gates.pop(); labels.pop()                 # 最后一次过计时门 = 一圈结束，不重复放
    g0 = gates[0]
    g0['start'] = g0['finish'] = True
    g0['prefab'] = 209                            # 绿色霓虹框，看得出是计时门
    g0['trans']['scale'][0] = 14
    labels[0] = labels[0] + '（计时门：起点/终点）'
    notes.insert(0, f"计时门：{labels[0].split('（')[0]}，起飞过它开始计时，飞完一圈再过它算一圈")


def tower_runs(p, path):
    """路线在塔里的每一段：从哪个面进、哪个面出（按路线前进方向判断）"""
    fr = frame_of(p, '双重'); cx, cz = fr[0][0], fr[0][2]
    H = CAD_S+2*CAD_T; top = 2*H-CAD_T; near = CAD_S/2+CAD_T+0.6
    inside = [math.dist((q[0], q[2]), (cx, cz)) < near and q[1] < top+0.6 for q in path]
    runs, i = [], 0
    while i < len(path):
        if not inside[i]:
            i += 1; continue
        j = i
        while j+1 < len(path) and inside[j+1]:
            j += 1
        if j > i:
            runs.append((i, j))
        i = j+1

    def face(i, entering):
        a, b = path[max(0, i-2)], path[min(len(path)-1, i+2)]
        v = sub(b, a); q = path[i]
        if entering and q[1] >= top-0.4 and v[1] < 0:
            return ('顶', -1)
        if not entering and q[1] >= top-0.4 and v[1] > 0:
            return ('顶', 1)
        layer = '下层' if q[1] < H-CAD_T else '上层'
        da, db = dot(v, fr[1]), dot(v, fr[2])
        if abs(da) > abs(db):          # 沿左右方向飞
            side = ('左' if da > 0 else '右') if entering else ('右' if da > 0 else '左')
            return (layer+side, 1 if da > 0 else -1)
        side = ('后' if db > 0 else '前') if entering else ('前' if db > 0 else '后')
        return (layer+side, 1 if db > 0 else -1)
    out = []
    for i0, i1 in runs:
        out.append(dict(i0=i0, i1=i1, **{'in': face(i0, True), 'out': face(i1, False)}))
    return out


def spread_shifts(model, types, S, T):
    """并排紧挨着的门（比如两个日字门挨在一起）：门放大以后会互相插进去，按比例往两边推开"""
    f = (S+2*T) / (CAD_S+2*CAD_T)
    gs = [p for p in model['parts'] if types.get(p['id']) in ('单门', '日子门')]
    info = {p['id']: frame_of(p, types[p['id']]) for p in gs}
    parent = {p['id']: p['id'] for p in gs}
    def root(i):
        while parent[i] != i:
            i = parent[i]
        return i
    for i, p in enumerate(gs):
        for q in gs[i+1:]:
            (c1, a1, b1), (c2, a2, _) = info[p['id']], info[q['id']]
            if abs(dot(a1, a2)) < 0.99:
                continue
            d = sub(c2, c1)
            if abs(dot(d, b1)) < 0.3 and abs(dot(d, a1)) < CAD_S+2*CAD_T+0.1:
                parent[root(q['id'])] = root(p['id'])
    groups = defaultdict(list)
    for p in gs:
        groups[root(p['id'])].append(p['id'])
    shifts = {}
    for ids in groups.values():
        if len(ids) < 2:
            continue
        a = info[ids[0]][1]
        cen = [sum(info[i][0][k] for i in ids)/len(ids) for k in range(3)]
        for i in ids:
            along = dot(sub(info[i][0], cen), a)
            shifts[i] = mul(a, along*(f-1))
    return shifts


def center_tower_dives(model, types, path):
    """固定规则：从塔顶钻进去的，一律走塔的正中间往下（组委会的线常常贴着塔面画）"""
    path = [list(q) for q in path]
    for p in model['parts']:
        if types.get(p['id']) != '双重':
            continue
        fr = frame_of(p, '双重'); cx, cz = fr[0][0], fr[0][2]
        for r in tower_runs(p, path):
            if r['in'][0] != '顶':
                continue
            for j in range(max(0, r['i0']-3), r['i1']+1):
                q = path[j]
                w = 1.0 if j >= r['i0'] else 0.5
                if q[1] < CAD_S/2+CAD_T and j > r['i0']:   # 低到出口高度：只收一半，保持出去的方向
                    w = 0.5
                q[0] += (cx-q[0])*w
                q[2] += (cz-q[2])*w
    return path


def trk_text(track):
    js = {"gates": track['gates'], "barriers": track['barriers']}
    plain = f"{track['scene']}\n{track['name']}\n{json.dumps(js, separators=(',', ':'))}".encode('utf-8')
    k8 = 'Velocidrone'[:8]; key = (k8+k8[::-1]).encode()
    pad = 16-len(plain) % 16
    return base64.b64encode(aes.ecb_encrypt(plain+bytes([pad])*pad, key)).decode()


# 按形状认零件：局部外框尺寸（米），CAD 门洞 2.0、方管 0.2
SHAPES = [('单门', (2.4, 2.4, 2.6)), ('日子门', (2.4, 4.6, 2.6)), ('单重', (2.4, 2.4, 2.4)),
          ('双重', (4.6, 2.4, 2.4)), ('双重', (2.4, 4.6, 2.4)), ('三联', (3.2, 2.4, 6.8)),
          ('起飞台', (3.8, 1.2, 0.5)), ('降落区', (5.0, 0.02, 5.0))]


def shape_type(p):
    e = p.get('ext')
    if not e:
        return None
    for t, ref in SHAPES:
        if all(abs(e[k]-ref[k]) < 0.08 for k in range(3)):
            return t
    return None


def default_types(model, remembered=None):
    types = {}
    for p in model['parts']:
        t = guess_type(p['name'], remembered)
        if not (remembered and name_key(p['name']) in remembered):
            t = shape_type(p) or t        # 名字可能乱起，形状不会骗人
        types[p['id']] = t
    if '路线' not in types.values():
        # 路线零件名字不一定带「赛道布局」（平湖站叫「零件6」）：没认出来的零件里点最多的那个就是路线管子
        def npts(p):
            return p.get('npts', 0)
        cand = [p for p in model['parts'] if types[p['id']] == '忽略' and npts(p) > 3000]
        if cand:
            types[max(cand, key=npts)['id']] = '路线'
    return types


if __name__ == '__main__':
    import sys
    m = load(sys.argv[1]); ty = default_types(m)
    tr = build(m, ty, name=sys.argv[3] if len(sys.argv) > 3 else 'Track')
    for i, l in enumerate(tr['labels']):
        print(i, l)
    print('\n'.join(tr['notes']))
    open(sys.argv[2], 'w').write(trk_text(tr))
    print(len(tr['gates']), 'gates', len(tr['barriers']), 'bars')


# ------------------------------------------------------------------ 读黑羊 .trk
TRK_PAD = 422          # 标准地图的起飞台


def read_trk(path):
    """黑羊 .trk -> (场景编号, 赛道名, {"gates": [...], "barriers": [...]})"""
    from pathlib import Path
    text = Path(path).read_text(encoding="utf-8", errors="replace").strip()
    raw = base64.b64decode("".join(text.split()))
    k8 = "Velocidrone"[:8]
    plain = aes.ecb_decrypt(raw, (k8 + k8[::-1]).encode())
    pad = plain[-1]
    if 1 <= pad <= 16 and plain.endswith(bytes([pad]) * pad):
        plain = plain[:-pad]
    s = plain.decode("utf-8", errors="replace")
    head, name, rest = s.split("\n", 2)
    js, _ = json.JSONDecoder().raw_decode(rest)
    return int(head), name, js


def gate_centre(g, floor):
    """黑羊检查点 -> (门洞中心, 飞过去的方向)，米，本程序的坐标"""
    q = g['trans']['rot']
    f, ext = qrot(q, (-1, 0, 0)), qrot(q, (0, 0, 1))
    f, ext = [f[0], f[1], -f[2]], [ext[0], ext[1], -ext[2]]
    pos = g['trans']['pos']
    base = [pos[0]/100, (pos[1]-floor)/100, -pos[2]/100]
    h = g['trans']['scale'][2]/50
    return [base[i] + ext[i]*h/2 for i in range(3)], f


def from_trk(path):
    """黑羊地图 -> 和 build() 一样的赛道（预览、模拟飞行、导出都能用）。
    .trk 里没有路线：按检查点顺序，每个门前后各拉 2.5 米顺着门的方向，再连成平滑的一圈。"""
    scene, name, js = read_trk(path)
    if scene not in SCENES:                      # 软件自带样板里认识的地图（标准草地 8 号等）
        try:
            from pathlib import Path
            kit = json.loads((Path(__file__).parent / "黑羊样板-默认.json").read_text(encoding="utf-8"))
            for sid, sc in kit.get("scenes", {}).items():
                SCENES.setdefault(int(sid), (sc["name"], sc["floor"]))
        except (OSError, ValueError, KeyError):
            pass
    gates = sorted((g for g in js.get('gates', []) if 'trans' in g), key=lambda g: g.get('gate', 0))
    barriers = [b for b in js.get('barriers', []) if 'trans' in b and 'curve' not in b]
    notes = []
    if scene not in SCENES:                      # 没见过的地图：地面高度按最低的东西估
        ys = [o['trans']['pos'][1] for o in gates + barriers] or [0]
        SCENES[scene] = (f"黑羊地图 {scene}", min(ys))
        notes.append(f"黑羊地图编号 {scene} 这里没见过，地面高度是按最低的东西估的")
    floor = SCENES[scene][1]
    for i, g in enumerate(gates):
        g['gate'] = i
        g.setdefault('start', False)
        g.setdefault('finish', False)
    if gates and not any(g['start'] for g in gates):
        gates[0]['start'] = gates[0]['finish'] = True
    labels = [f"检查点 {i}" + ('（计时门：起点/终点）' if g['start'] else '') for i, g in enumerate(gates)]
    pts = []
    for g in gates:
        c, f = gate_centre(g, floor)
        f = norm(f)
        pts += [[c[i] - 2.5*f[i] for i in range(3)], c, [c[i] + 2.5*f[i] for i in range(3)]]
    path = []
    if len(gates) >= 2:
        loop = pts + pts[:3]                     # 飞完一圈回到计时门
        pad = next((b for b in barriers if b['prefab'] == TRK_PAD), None)
        if pad:                                  # 有起飞台：从起飞台飞起来
            p = pad['trans']['pos']
            loop = [[p[0]/100, 0.3, -p[2]/100], [p[0]/100, 1.5, -p[2]/100]] + loop
        try:
            from . import trackgen as tg
        except ImportError:
            import trackgen as tg
        path = tg._catmull(loop)
        path = [[q[0], max(0.3, q[1]), q[2]] for q in path]
    notes.insert(0, f"黑羊地图「{name}」：{len(gates)} 个检查点，{len(barriers)} 个摆件。"
                    "黑羊地图里没有路线，红线是按检查点顺序自动连的，只是参考")
    return dict(gates=gates, barriers=barriers, labels=labels, path=path, notes=notes, scene=scene, name=name,
                arrows=[], scenery=[])
