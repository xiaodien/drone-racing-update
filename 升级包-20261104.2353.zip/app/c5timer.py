"""C5 计时器：XIAO ESP32-C5 刷 widscan58 固件，用 USB 线插电脑。

板子上电默认是「计时器模式」，说的是开源计时器 RotorHazard 的节点协议（一问一答的二进制小包），
过门判断在板子里做（每秒几百次测信号），电脑每 0.1 秒问一次每一路的信号和过门次数。
软件这边把它包装成和原来 ESP32 + RX5808 计时器一样的接口（TimerLink），比赛模式其它地方不用改。

信号单位：板子报 0.25 dB 一格（1~254），乘 SCALE 变成和原来计时器差不多大小的数，
信号条、校准、灵敏度、按距离设线都照旧能用。
"""
import queue
import threading
import time

from PySide6.QtCore import QTimer, Signal

from app.race import TimerLink, now_ms

SEATS = 8                   # 板子有 8 路
SCALE = 6                   # 板子 1 格 = 0.25 dB，乘 6 → 0~1524，和原来 RX5808 的毫伏差不多大
OFF_MHZ = 1111              # 计时器协议里「这一路不用」

READ_LAP_STATS = 0x05
READ_FREQUENCY = 0x03
READ_ENTER_AT = 0x31
READ_EXIT_AT = 0x32
READ_NODE_COUNT = 0x39
READ_FW_VERSION = 0x3D
WRITE_FREQUENCY = 0x51
WRITE_ENTER_AT = 0x71
WRITE_EXIT_AT = 0x72
WRITE_NODE_INDEX = 0x7A


class SockSer:
    """WiFi 版：B 板把 TCP 原样转给 A 板。包成和 pyserial 一样的几个方法"""

    def __init__(self, host, port=5810):
        import socket
        self.s = socket.create_connection((host, port), timeout=4)
        self.s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.s.settimeout(0.05)

    def write(self, b):
        self.s.sendall(bytes(b))

    def read(self, n):
        try:
            d = self.s.recv(n)
        except TimeoutError:
            return b""
        except OSError as ex:
            if "timed out" in str(ex):
                return b""
            raise
        if not d:
            raise OSError("WiFi 连接断了")
        return d

    def reset_input_buffer(self):
        self.s.setblocking(False)
        try:
            while self.s.recv(4096):
                pass
        except (BlockingIOError, OSError):
            pass
        self.s.settimeout(0.05)

    def close(self):
        self.s.close()


def to_code(v):
    return max(1, min(254, int(round(v / SCALE))))


class C5Link(TimerLink):
    """USB 串口连 C5。读写都在后台线程里排队做，界面只收信号。"""
    _poll = Signal(object)          # 后台线程 → 界面线程

    def __init__(self, port, nodes=4, ser=None):
        super().__init__()
        self.port = port
        self.nodes = nodes
        self.ser = ser
        self.mhz = [0] * nodes
        self.enter = [0] * nodes
        self.exit = [0] * nodes
        self.lo = [9999] * nodes
        self.hi = [0] * nodes
        self.laps = [None] * nodes
        self.jobs = queue.Queue()
        self._stop = False
        self._poll.connect(self._on_poll)
        threading.Thread(target=self._run, daemon=True).start()

    # ---- 串口小包
    def _write(self, cmd, data=b""):
        pkt = bytes([cmd]) + bytes(data)
        if data:
            pkt += bytes([sum(data) & 0xFF])
        self.ser.write(pkt)

    def _read(self, cmd, n):
        """发一个读命令，收 n 个字节 + 1 个校验。不对就返回 None"""
        self.ser.write(bytes([cmd]))
        got = b""
        end = time.monotonic() + (0.4 if self.port.startswith("tcp:") else 0.15)
        while len(got) < n + 1 and time.monotonic() < end:
            got += self.ser.read(n + 1 - len(got))
        if len(got) < n + 1 or sum(got[:n]) & 0xFF != got[n]:
            self.ser.reset_input_buffer()
            return None
        return got[:n]

    def _seat(self, i):
        self._write(WRITE_NODE_INDEX, [i])

    def _open(self):
        if self.ser is None and self.port.startswith("tcp:"):
            self.ser = SockSer(self.port[4:])
        if self.ser is None:
            import serial
            for k in range(6):                  # 刚被别的程序放开时要等一下（遥控器那边 3 秒内会放开）
                try:
                    self.ser = serial.Serial(self.port, 921600, timeout=0.05)
                    break
                except serial.SerialException:
                    if k == 5 or self._stop:
                        raise
                    time.sleep(1.0)
        # 网页上用过的话板子停在「监视模式」：这一行把它切回计时器模式（已经是计时器模式也没关系）
        self.ser.write(b"\nPROTOCOL RH\n")
        time.sleep(0.4)
        self.ser.reset_input_buffer()
        for _ in range(3):
            n = self._read(READ_NODE_COUNT, 1)
            if n:
                return n[0]
            time.sleep(0.2)
        return 0

    def _run(self):
        try:
            count = self._open()
        except Exception as ex:  # noqa: BLE001 - 打不开串口的各种原因
            self._release()
            if "PermissionError" in repr(ex) or "拒绝访问" in str(ex) or "Access is denied" in str(ex):
                msg = (f"{self.port} 被别的程序占着：把 Chrome（widscan58 网页）、Betaflight、ELRS 配置器、Arduino 这类软件"
                       "全关掉，拔插一下 C5 的 USB 线，再点「断开」→「连接计时器」")
            else:
                msg = f"打不开 {self.port}：{ex}"
            self._poll.emit(("status", False, msg))
            return
        if count < self.nodes:
            self._release()
            self._poll.emit(("status", False, f"{self.port} 没有回应。确认插的是 C5 计时器、已经用网页刷好 widscan58，"
                                              "网页那边点了 Disconnect（同一时间只能一个程序用 USB 口）"))
            return
        try:
            ver = self._read(READ_FW_VERSION, 16)
            ver = ver.split(b"\0")[0].decode("ascii", "replace") if ver else "?"
            for i in range(SEATS):              # 先读每一路的设置；用不到的几路关掉，剩下的测得更快
                self._seat(i)
                if i >= self.nodes:
                    self._write(WRITE_FREQUENCY, [OFF_MHZ >> 8, OFF_MHZ & 0xFF])
                    continue
                f = self._read(READ_FREQUENCY, 2)
                e = self._read(READ_ENTER_AT, 1)
                x = self._read(READ_EXIT_AT, 1)
                self.mhz[i] = (f[0] << 8 | f[1]) if f else 0
                self.enter[i] = e[0] * SCALE if e else 750
                self.exit[i] = x[0] * SCALE if x else 630
            self._poll.emit(("status", True, f"已连接 C5 计时器 {self.port}（固件 {ver}）"))
            self._poll.emit(("cfg",))
            fails = 0
            while not self._stop:
                t0 = time.monotonic()
                while not self.jobs.empty():
                    self.jobs.get()()
                rows, now = [], now_ms()
                for i in range(self.nodes):
                    self._seat(i)
                    d = self._read(READ_LAP_STATS, 16)        # 过门统计 8 字节 + 高低点 8 字节
                    rows.append((d, now_ms()))                # 每一路按自己收到的时刻算（WiFi 有延迟）
                fails = fails + 1 if not any(d for d, _ in rows) else 0
                if fails > 20:
                    raise OSError("板子 2 秒没回应")
                if self._stop:
                    break
                self._poll.emit(("stats", now, rows))
                time.sleep(max(0.0, 0.1 - (time.monotonic() - t0)))
        except Exception as ex:  # noqa: BLE001 - 拔线等
            self._release()
            if not self._stop:
                self.connected = False
                self._poll.emit(("status", False, f"C5 计时器断开了（USB 线松了？）：{ex}"))

    # ---- 界面线程
    def _on_poll(self, m):
        kind = m[0]
        if kind == "status":
            self.connected = m[1]
            self.status.emit(m[1], m[2])
        elif kind == "cfg":
            self._cfg()
        elif kind == "stats":
            now, rows = m[1], m[2]
            self._clock(now)                    # 时间就用电脑的，过门时间 = 收到时刻 - 板子说的「过门到现在几毫秒」
            self.last_rssi_ms = now
            v = []
            for i, (d, t_i) in enumerate(rows):
                if not d:
                    v.append(0)
                    continue
                lap, since, level, pass_peak = d[0], d[1] << 8 | d[2], d[3], d[5]
                val = level * SCALE
                v.append(val)
                self.lo[i] = min(self.lo[i], val)
                self.hi[i] = max(self.hi[i], val)
                flags, peak_level = d[8], d[11]
                if flags & 0x02:                # 板子记下的信号高点（0.1 秒之间的最高）
                    self.hi[i] = max(self.hi[i], peak_level * SCALE)
                if self.laps[i] is not None and lap != self.laps[i]:
                    self.hi[i] = max(self.hi[i], pass_peak * SCALE)
                    self.passed.emit(i, float(t_i - since), pass_peak * SCALE)
                self.laps[i] = lap
            self.rssi.emit(v, [0 if x == 9999 else x for x in self.lo], list(self.hi))

    def _cfg(self):
        self.cfg.emit({"t": "cfg", "ms": now_ms(), "nodes": [
            {"mhz": self.mhz[i], "enter": self.enter[i], "exit": self.exit[i]} for i in range(self.nodes)]})

    def send(self, obj):
        c, i = obj.get("c"), obj.get("node", -1)
        if c == "freq" and 0 <= i < self.nodes:
            mhz = int(obj["mhz"])
            self.mhz[i] = mhz
            self.laps[i] = None                 # 换频道板子会清零这一路，别当成过门
            self.jobs.put(lambda: (self._seat(i), self._write(WRITE_FREQUENCY, [mhz >> 8, mhz & 0xFF])))
            self._cfg()
        elif c == "thr" and 0 <= i < self.nodes:
            en, ex = to_code(obj["enter"]), to_code(obj["exit"])
            ex = min(ex, en - 1)
            self.enter[i], self.exit[i] = en * SCALE, ex * SCALE
            self.jobs.put(lambda: (self._seat(i), self._write(WRITE_ENTER_AT, [en]), self._write(WRITE_EXIT_AT, [ex])))
        elif c == "range":
            self.lo, self.hi = [9999] * self.nodes, [0] * self.nodes
        elif c == "get":
            self._cfg()
        elif c == "wifi":
            self.status.emit(self.connected, "C5 计时器是 USB 连接，不用设 WiFi")

    def _release(self):
        """串口一定要关掉，不然下次连会「拒绝访问」"""
        try:
            if self.ser:
                self.ser.close()
        except Exception:  # noqa: BLE001
            pass

    def close(self):
        self._stop = True
        self.connected = False
        self._release()
