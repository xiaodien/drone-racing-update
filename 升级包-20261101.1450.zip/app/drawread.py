"""看图纸：把组委会图纸上的粉色指引线认出来，排成一条有先后的线（只用 Qt，不用别的库）。

做法：
1. 挑出"粉色"的点（红多、绿少、蓝居中），按 3 像素一格记下来；
2. 只留最大的那一片附近的（去掉指北针、图例里那根小箭头）；
3. 从起点（离计时门最近的线头）开始往前"追"：每一步看前方一圈，挑最顺着走的那个格子
   —— 线自己交叉的地方就直着穿过去；线被门的黑框挡住断了一小截，就往前多看一点接上。
"""
import math

from PySide6.QtGui import QImage

WORK_W = 1600          # 认图时把图缩到这么宽
JUMP = 45              # 线断了（被门框挡住）最多往前接多少像素
LOOK = 10              # 岔口往每条路看多远比方向


def pink_pixels(img: QImage):
    """返回 (粉色像素集合, 缩放比例 原图像素/工作像素)"""
    work = img.scaledToWidth(WORK_W) if img.width() > WORK_W else img   # 不平滑：线的颜色不被冲淡
    work = work.convertToFormat(QImage.Format_RGB888)
    w, h, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())
    px = set()
    for y in range(h):
        row = data[y*bpl:y*bpl + w*3]
        for x in range(0, w*3, 3):
            r = row[x]
            if r > 150:
                g, b = row[x+1], row[x+2]
                if g < 100 and 60 < b < 210 and r - g > 90:
                    px.add((x // 3, y))
    return px, img.width() / w


N8 = ((0, -1), (1, -1), (1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0), (-1, -1))


def thin(px):
    """把粗线削成一个像素宽（Zhang-Suen）"""
    px = set(px)
    changed = True
    while changed:
        changed = False
        for step in (0, 1):
            kill = []
            for (x, y) in px:
                nb = [(x+dx, y+dy) in px for dx, dy in N8]
                b = sum(nb)
                if b < 2 or b > 6:
                    continue
                a = sum(1 for k in range(8) if not nb[k] and nb[(k+1) % 8])
                if a != 1:
                    continue
                P2, P4, P6, P8 = nb[0], nb[2], nb[4], nb[6]
                if step == 0 and (P2 and P4 and P6 or P4 and P6 and P8):
                    continue
                if step == 1 and (P2 and P4 and P8 or P2 and P6 and P8):
                    continue
                kill.append((x, y))
            if kill:
                changed = True
                px.difference_update(kill)
    return px


def _groups(px, link=3):
    left = set(px)
    out = []
    while left:
        seed = left.pop()
        grp, todo = [seed], [seed]
        while todo:
            cx, cy = todo.pop()
            for dx in range(-link, link+1):
                for dy in range(-link, link+1):
                    c = (cx+dx, cy+dy)
                    if c in left:
                        left.remove(c)
                        grp.append(c)
                        todo.append(c)
        out.append(grp)
    return sorted(out, key=len, reverse=True)


def _nbrs(sk, p):
    return [(p[0]+dx, p[1]+dy) for dx, dy in N8 if (p[0]+dx, p[1]+dy) in sk]


def _unit(dx, dy):
    n = math.hypot(dx, dy) or 1.0
    return dx/n, dy/n


def _ang(h, d):
    return abs(math.atan2(h[0]*d[1] - h[1]*d[0], h[0]*d[0] + h[1]*d[1]))


def _walk(sk, prev, cur, n, avoid=()):
    """从 prev->cur 顺着骨架往前走 n 步（岔口挑最直的），返回走到的点"""
    path = [prev, cur]
    for _ in range(n):
        h = _unit(path[-1][0]-path[max(0, len(path)-4)][0], path[-1][1]-path[max(0, len(path)-4)][1])
        c = [q for q in _nbrs(sk, path[-1]) if q not in path[-4:] and q not in avoid]
        if not c:
            break
        path.append(min(c, key=lambda q: _ang(h, (q[0]-path[-1][0], q[1]-path[-1][1]))))
    return path


def _loops_back(sk, cur, q, used):
    """从岔口 cur 往 q 那条路走下去（断了也接上），走一小圈又回到 cur 附近 = 图纸上的小圈"""
    w = trace(sk, [cur, q], used=set(used) | {cur}, limit=260, probe=True)
    return any(math.dist(z, cur) < 30 for z in w[60:])


def trace(sk, start, used=None, limit=200000, probe=False):
    """从线头顺着骨架追到底。start 可以是一个点，也可以是已经走的几个点"""
    path = list(start) if isinstance(start, list) else [start]
    used = set(path) if used is None else used | set(path)
    while len(path) < limit:
        cur = path[-1]
        back = path[max(0, len(path)-8)]
        h = _unit(cur[0]-back[0], cur[1]-back[1]) if len(path) > 1 else None
        cand = [q for q in _nbrs(sk, cur) if q not in path[-6:]]
        nxt = None
        if cand:
            if len(cand) == 1 or h is None:
                fresh = [q for q in cand if q not in used]
                nxt = (fresh or cand)[0]
            else:                                # 岔口：每条路往前看一段，挑最直、没走过的；没走过的小圈先绕
                best = None
                for q in cand:
                    w = _walk(sk, cur, q, LOOK, avoid=set(path[-6:]))
                    d = _unit(w[-1][0]-cur[0], w[-1][1]-cur[1])
                    old = sum(1 for z in w[1:] if z in used) / len(w)
                    score = _ang(h, d) + 1.5*old + (0.6 if len(w) < LOOK//2 else 0)   # 短叉（箭头）扣分
                    if not probe and old == 0 and len(w) >= LOOK//2 and _loops_back(sk, cur, q, used):
                        score -= 3
                    if best is None or score < best[0]:
                        best = (score, q)
                nxt = best[1]
            if nxt in used and h is not None and _ang(h, _unit(nxt[0]-cur[0], nxt[1]-cur[1])) > math.radians(100):
                nxt = None                       # 掉头了：不走
        if nxt is None:                          # 线断了：往前找最近、方向对得上的线
            if h is None:
                break
            best = None
            for q in sk:
                dx, dy = q[0]-cur[0], q[1]-cur[1]
                if abs(dx) > JUMP or abs(dy) > JUMP or q in used:
                    continue
                d = math.hypot(dx, dy)
                if d < 2 or d > JUMP:
                    continue
                a = _ang(h, (dx, dy))
                if a > math.radians(35) and not (d < 22 and a < math.radians(65)):
                    continue
                score = d * (1 + 2*a)
                if best is None or score < best[0]:
                    best = (score, q)
            if best is None:
                break
            nxt = best[1]
        path.append(nxt)
        used.add(nxt)
    return path


def read_line(img: QImage, start_hint=None):
    """认粉色指引线。start_hint = 原图像素坐标（计时门在图上的位置），从离它最近的线头开始。
    返回 [(x, y) 原图像素]，没认出来返回 []"""
    px, k = pink_pixels(img)
    if len(px) < 100:
        return []
    sk = thin(px)
    groups = _groups(sk)
    keep = set(groups[0])                        # 从最大那截开始，离得近（门框挡断的）一截截接上；指北针、图例离得远不要
    near = {(x//25, y//25) for x, y in keep}
    rest = [g for g in groups[1:] if len(g) >= 4]
    grown = True
    while grown:
        grown = False
        for g in list(rest):
            if any((x//25+dx, y//25+dy) in near for x, y in g for dx in (-1, 0, 1) for dy in (-1, 0, 1)):
                keep.update(g)
                near.update((x//25, y//25) for x, y in g)
                rest.remove(g)
                grown = True
    def is_end(p):
        nb = _nbrs(keep, p)
        return len(nb) == 1 or (len(nb) == 2 and max(abs(nb[0][0]-nb[1][0]), abs(nb[0][1]-nb[1][1])) == 1)
    def long_enough(p, n=30):                    # 虚线（去降落点那段）的小短截不算线头
        seen, todo = {p}, [p]
        while todo and len(seen) < n:
            for q in _nbrs(keep, todo.pop()):
                if q not in seen:
                    seen.add(q)
                    todo.append(q)
        return len(seen) >= n
    ends = [p for p in keep if is_end(p) and long_enough(p)] or list(keep)
    if start_hint is not None:
        sx, sy = start_hint[0]/k, start_hint[1]/k
        start = min(ends, key=lambda c: math.hypot(c[0]-sx, c[1]-sy))
    else:
        start = max(ends, key=lambda c: c[1])    # 没有提示就从最下面那个线头开始
    path = trace(keep, start)
    return [((x+0.5)*k, (y+0.5)*k) for x, y in path[::3]]
