"""赛道搭建（照黑羊编辑器的用法）：左边一排门，点一下再点地上放；单门靠近别的门会磁吸，并排或叠上去拼成组合门，
组合门可以起名存进库；也可以让电脑自动摆一圈再改。
进门顺序照黑羊：在 3D 里点门洞（面）加进顺序，箭头是穿的方向，系统按顺序自动连线。

搭好的赛道存成「xxx.赛道.json」（一张地图），上面「地图」下拉里能选回来接着改；还带几张预载的单项练习图。
「▶ 模拟飞行」看飞一遍，「转成黑羊」导出 .trk。
"""
import json
import math
import random
import re
from pathlib import Path

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QCursor, QImage, QKeySequence, QShortcut
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QFileDialog, QGridLayout, QGroupBox,
                               QHBoxLayout, QInputDialog, QLabel, QLineEdit, QListWidget, QMenu, QMessageBox,
                               QPushButton, QScrollArea, QSlider, QSpinBox, QTabWidget, QToolButton, QVBoxLayout, QWidget)

from app import trackconv as tc
from app import trackgen as tg
from app.config import APP_DIR, USER_DIR
from app.track_tool import TopView
from app.trackmanual import FieldEditor, group_of, height, icon, label, step_text

CODES = {'综合': 'Mix', '直线加速': 'Straight', 'S 弯': 'Slalom', '急转掉头': 'Hairpin', '高低穿越': 'HighLow',
         '下翻塔': 'Dive'}
PREFS = USER_DIR / "赛道搭建.json"          # 自己填过的场地大小、练习重点
LIBRARY = USER_DIR / "组合门库.json"        # 自己拼的组合门
PRESETS = APP_DIR / "app" / "预载地图"
NEW_MAP = "（新的空白地图）"
UL_DIR = "图纸"                              # 地图文件夹里放底图的子文件夹
UL_MAX = 4096                                # 底图太大缩到这么宽，画起来不卡
READ_RULES = """<h3>怎么看组委会的赛道图纸</h3>
<p>（从嘉善站图纸和实际做出来的黑羊地图对出来的，有不对的告诉 Claude 改）</p>
<table border="1" cellspacing="0" cellpadding="5">
<tr><th>图纸上画的</th><th>实际怎么飞</th></tr>
<tr><td>门的符号</td><td>是<b>正面画法</b>，不代表门朝哪；门朝哪看<b>粉色指引线从哪边穿过去</b></td></tr>
<tr><td>单门画成平行四边形</td><td>门<b>斜着摆</b>，角度顺着指引线</td></tr>
<tr><td>日字门 + 旁边一个<b>小圈</b></td><td>上下两个洞<b>都穿，同一个方向</b>，中间绕小圈换洞；<br>低处飞来先穿下洞，高处飞来先穿上洞</td></tr>
<tr><td>田字门 + 小圈</td><td><b>4 个洞都穿</b></td></tr>
<tr><td>指引线在门上面<b>拱起来（∩）</b></td><td>从<b>门顶翻过去</b>，再穿下一个洞（三连门常见）</td></tr>
<tr><td>双连门</td><td><b>U 形掉头</b>：一个洞进，另一个洞反方向出</td></tr>
<tr><td>双层单门，<b>下半涂黑</b></td><td>下面堵死，<b>只穿上洞</b></td></tr>
<tr><td>单层重力门（立方体）</td><td><b>从顶上钻下去</b>，再从侧面出来（出口看指引线）</td></tr>
<tr><td>双层重力门</td><td>同上，更高（顶约 5.5 米）</td></tr>
<tr><td>起飞台 / 降落点</td><td>起飞台 → 计时门出发；降落点不算门</td></tr>
</table>
<h3>照图纸做赛道</h3>
<ol>
<li>「导入图纸」→ 对齐：「图纸 ▾」里铺满场地 / 两点定比例 / 挪图片</li>
<li><b>先只放门</b>：左边点门型，照图纸上的符号点地上放（Ctrl+滚轮 1 度、方向键 0.1 米微调，右边能直接填位置和角度）</li>
<li>再画路线：切到<b>俯视</b>，点右上角「✏ 手绘路线」，<b>顺着粉色指引线描一遍</b>。<br>
软件按上面的规则自己定穿哪个洞：叠着的洞按飞来的高度挑，同一个门再描一圈就换另一个洞；
描到方框里面算从顶上钻；同一个洞来回描两次算先翻过门顶再穿</li>
<li>描回 1 号计时门收圈，保存地图（图纸跟地图一起存）</li>
<li>点「🔍 核对」：软件自己看图纸猜一遍，跟你画的逐个门洞对比，不一样的列出来；你画的存成学习样本</li>
</ol>"""
PALETTE = ['单门', '日子门', '三联', '单重', '双重', tg.FLAG, tg.TAKEOFF]


def _read_json(f, default):
    try:
        return json.loads(Path(f).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _write_json(f, d):
    try:
        Path(f).write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError:
        pass


def parse_field(text):
    """「50×35」「50x35 米」「中（45×30 米）」都认：返回 (长, 宽) 米，认不出返回 None"""
    if text in tg.FIELDS:
        return tg.FIELDS[text]
    m = re.search(r"(\d+(?:\.\d+)?)\s*[×xX*＊]\s*(\d+(?:\.\d+)?)", text)
    if not m:
        return None
    a, b = float(m.group(1)), float(m.group(2))
    if not (5 <= a <= 1000 and 5 <= b <= 1000):
        return None
    return a, b


def items_from_auto(model, types, elems):
    """电脑摆的图 -> (items, route)"""
    items = tg.to_items(model, types)
    for it, e in zip(items, elems or []):
        it['how'] = e[1]
    return tg.legacy_route(items)


class TrackBuildDialog(QDialog):
    def __init__(self, folder: Path, parent=None):
        super().__init__(parent)
        self.setWindowTitle("赛道搭建")
        self.setWindowFlags(self.windowFlags() | Qt.WindowMinMaxButtonsHint)   # 右上角有最大化，想全屏自己点
        scr = (parent.screen() if parent else QApplication.primaryScreen()).availableGeometry()
        self.resize(min(1280, int(scr.width()*0.75)), min(800, int(scr.height()*0.75)))
        self.setWindowState(Qt.WindowMaximized)        # 打开就铺满桌面（还原按钮能变回小窗口）
        self.folder = Path(folder)
        self.prefs = _read_json(PREFS, {})
        self.prefs.setdefault("fields", [])
        self.prefs.setdefault("focuses", [])
        self.library = _read_json(LIBRARY, [])
        self.items = []
        self.route = []                     # 进门顺序：[{id, f 门洞, d ±1}]
        self.result = None                  # (model, types, path, info)
        self.closed = False                 # 路线收圈了没有：最后点一下起始门才收
        self.track = None
        self.saved_file = None
        self.seed = random.randint(1, 99999)
        self._hist, self._redo = [], []     # 撤销 / 重做：每次改完存一份 [items, route, closed]

        # ---- 上面一排：地图、场地、尺寸、电脑自动摆
        self.maps = QComboBox()
        self.maps.setMinimumWidth(220)
        self.maps.activated.connect(self._map_chosen)
        self.field = QComboBox()
        self.field.setEditable(True)
        self.field.addItems(list(tg.FIELDS) + [f for f in self.prefs["fields"] if f not in tg.FIELDS])
        self.field.setCurrentIndex(1)
        self.field.setToolTip("可以直接打字，比如「50×35」（长×宽，米）")
        self.field.lineEdit().editingFinished.connect(self._field_typed)
        self.field.activated.connect(lambda _i: self._field_typed())
        self.focus = QComboBox()
        self.focus.setEditable(True)
        self.focus.addItems(tg.FOCUS + [f for f in self.prefs["focuses"] if f not in tg.FOCUS])
        self.focus.setToolTip("可以直接打字写自己的练习重点；不是列出来的，电脑按「综合」来摆")
        self.focus.lineEdit().editingFinished.connect(self._focus_typed)
        self.gap = QDoubleSpinBox(minimum=1.5, maximum=3.0, singleStep=0.1, value=2.5, suffix=" 米")
        self.bar = QSpinBox(minimum=20, maximum=500, singleStep=10, value=200, suffix=" 毫米")
        self.count = QSpinBox(minimum=3, maximum=100, value=10, suffix=" 个门")
        self.del_btn = QPushButton("删除地图")
        self.del_btn.setToolTip("删掉下拉里选中的这张自己存的地图（预载的不能删）")
        self.del_btn.setStyleSheet("QPushButton:enabled { color: #ff3b30; }")
        self.del_btn.clicked.connect(self.delete_map)
        trk_btn = QPushButton("打开黑羊赛道…")
        trk_btn.setToolTip("读一张黑羊（VelociDrone）存的 .trk：每个检查点变成一个门，接着在这里改，改好存成地图或再转成黑羊")
        trk_btn.clicked.connect(self.open_trk)
        clear = QPushButton("全部清空")
        clear.setToolTip("把地上的门、刀旗全部清掉，从空地重新摆（存好的地图文件不动）")
        clear.clicked.connect(self.clear_all)
        self.undo_btn = QPushButton("↶ 撤销")
        self.undo_btn.setToolTip("撤销上一步（Ctrl+Z）")
        self.undo_btn.clicked.connect(self.undo)
        self.redo_btn = QPushButton("↷ 重做")
        self.redo_btn.setToolTip("把撤销的再做回来（Ctrl+Y）")
        self.redo_btn.clicked.connect(self.redo)
        QShortcut(QKeySequence.Undo, self, self.undo)
        QShortcut(QKeySequence.Redo, self, self.redo)
        QShortcut(QKeySequence("Ctrl+Y"), self, self.redo)
        auto = QPushButton("电脑自动摆")
        auto.setToolTip("按场地、练习重点和门数，电脑摆一圈；摆好以后还能拖、改")
        auto.clicked.connect(self.auto_place)
        top = QVBoxLayout()                 # 两排，小屏幕也放得下
        top.setSpacing(4)
        row1, row2 = QHBoxLayout(), QHBoxLayout()
        self.maps.setMinimumWidth(180)
        for w in (QLabel("地图"), self.maps, trk_btn, self.del_btn, clear, self.undo_btn, self.redo_btn):
            row1.addWidget(w)
        row1.addStretch()
        for w in (QLabel("场地"), self.field, QLabel("练习重点"), self.focus,
                  QLabel("门洞"), self.gap, QLabel("方管"), self.bar, self.count, auto):
            row2.addWidget(w)
        row2.addStretch()
        top.addLayout(row1)
        top.addLayout(row2)

        # ---- 左边一排：门（像黑羊编辑器），存过的组合门接在下面
        pal = QVBoxLayout()
        pal.setSpacing(4)
        pal.addWidget(QLabel("点一下再放"))
        self.pal_btns = {}
        for t in PALETTE:
            b = self._tool(label(t), icon(t))
            b.clicked.connect(lambda _c=False, tt=t: self.start_place(tt))
            pal.addWidget(b)
            self.pal_btns[t] = b
        self.lib_box = QVBoxLayout()
        self.lib_box.setSpacing(4)
        pal.addLayout(self.lib_box)
        pal.addStretch()
        palw = QWidget()
        palw.setLayout(pal)
        scroll = QScrollArea()
        scroll.setWidget(palw)
        scroll.setWidgetResizable(True)
        scroll.setFixedWidth(100)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._fill_library()

        # ---- 中间：平面布置 / 3D
        self.editor = FieldEditor()
        self.editor.changed.connect(self._editor_changed)
        self.editor.selected.connect(self._editor_selected)
        self.editor.pen_clicked.connect(self._pen)
        self.editor.calibrated.connect(self._ul_calibrated)
        self.editor.underlay_changed.connect(self._sync_ul)
        self.ul_src = None                  # 底图原文件（保存地图时拷进 图纸/ 文件夹）
        self.helpers = QCheckBox("显示进门框和箭头")
        self.helpers.setChecked(True)
        self.helpers.setToolTip("门洞上的进门框和方向箭头；不勾就藏起来")
        self.helpers.toggled.connect(self.editor.set_helpers)
        self.show_path = QCheckBox("显示路线")
        self.show_path.setToolTip("勾上 = 显示系统自动连的红色路线；不勾 = 只看门和进门箭头（默认不显示，会记住）")
        self.show_path.setChecked(bool(self.prefs.get("show_path", False)))
        self.editor.set_show_path(self.show_path.isChecked())
        self.show_path.toggled.connect(self.editor.set_show_path)
        self.show_path.toggled.connect(self._remember_show_path)
        self.editor.helpers_changed.connect(self.helpers.setChecked)
        self.view = TopView()
        views = QHBoxLayout()
        for name in TopView.VIEWS:
            vb = QPushButton(name)
            vb.clicked.connect(lambda _c=False, n=name: self.view.set_view(n))
            views.addWidget(vb)
        views.addSpacing(16)
        self.play_btn = QPushButton("▶ 播放")
        self.play_btn.setMinimumWidth(100)
        self.play_btn.clicked.connect(self.toggle_play)
        views.addWidget(self.play_btn)
        views.addStretch()
        self.sim_label = QLabel("")
        self.view.progress.connect(self.sim_label.setText)
        self.view.timer.timeout.connect(self._sync_play)
        d3 = QWidget()
        dl = QVBoxLayout(d3)
        dl.setContentsMargins(0, 0, 0, 0)
        dl.addWidget(self.view, 1)
        dl.addLayout(views)
        dl.addWidget(self.sim_label)
        evs = QHBoxLayout()
        for name in FieldEditor.VIEWS:
            vb = QPushButton(name)
            vb.clicked.connect(lambda _c=False, n=name: self.editor.set_view(n))
            evs.addWidget(vb)
        evs.addWidget(self.helpers)
        evs.addWidget(self.show_path)
        evs.addSpacing(12)
        ul_btn = QPushButton("🖼 导入图纸…")
        ul_btn.setToolTip("把组委会的赛道图纸（图片）铺在地上，照着摆门；跟地图一起保存")
        ul_btn.clicked.connect(self.import_underlay)
        self.ul_menu_btn = QToolButton()
        self.ul_menu_btn.setText("图纸 ▾")
        self.ul_menu_btn.setPopupMode(QToolButton.InstantPopup)
        m = QMenu(self)
        self.ul_acts = {
            "fit": m.addAction("铺满场地（图纸边框 = 场地边）", self.ul_fit),
            "calib": m.addAction("两点定比例…（点已知长度的两头）", self.ul_calib),
            "move": m.addAction("挪图片（左键拖）", self.ul_toggle_move),
            "rot": m.addAction("图片转 90°", self.ul_rotate),
            "show": m.addAction("显示图纸", self.ul_toggle_show),
            "del": m.addAction("去掉图纸", self.ul_remove),
        }
        self.ul_acts["move"].setCheckable(True)
        self.ul_acts["show"].setCheckable(True)
        self.ul_menu_btn.setMenu(m)
        self.ul_op = QSlider(Qt.Horizontal)
        self.ul_op.setRange(10, 100)
        self.ul_op.setValue(60)
        self.ul_op.setFixedWidth(90)
        self.ul_op.setToolTip("图纸透明度")
        self.ul_op.valueChanged.connect(self._ul_opacity)
        rules_btn = QPushButton("📖 看图规则")
        rules_btn.setToolTip("组委会图纸上的符号、小圈、拱起来的线是什么意思，照图纸做赛道的步骤")
        rules_btn.clicked.connect(self.show_rules)
        check_btn = QPushButton("🔍 核对")
        check_btn.setToolTip("手工画好路线以后点：软件自己看图纸猜一遍穿门顺序，跟你画的一个门一个门对比；你画的存成学习样本")
        check_btn.clicked.connect(self.check_route)
        uls = QHBoxLayout()                 # 图纸一排单独放，窗口窄也不挤
        for w in (ul_btn, rules_btn, self.ul_menu_btn, QLabel("透明"), self.ul_op, check_btn):
            uls.addWidget(w)
        uls.addStretch()
        evs.addStretch()
        edw = QWidget()
        el = QVBoxLayout(edw)
        el.setContentsMargins(0, 0, 0, 0)
        el.addWidget(self.editor, 1)
        el.addLayout(evs)
        el.addLayout(uls)
        self.tabs = QTabWidget()
        self.tabs.addTab(edw, "摆门（3D）")
        self.tabs.addTab(d3, "飞行预览 / 播放")
        self.tabs.currentChanged.connect(lambda _i: self.view.pause_sim() or self._sync_play())
        self.info = QLabel("")
        self.info.setWordWrap(True)
        self.info.setStyleSheet("color: #c77800;")
        self.info.setMinimumHeight(30)
        mid = QWidget()
        ml = QVBoxLayout(mid)
        ml.setContentsMargins(0, 0, 0, 0)
        ml.addWidget(self.tabs, 1)
        ml.addWidget(self.info)

        # ---- 右边：选中的门 + 过门顺序 + 保存
        self.sel_label = QLabel("没选中门")
        self.sel_label.setStyleSheet("font-weight: bold; color: #ff3b30;")
        g = QGridLayout()
        self.act = {}
        acts = [("⟲ 左转 15°", lambda i: self._rotate(i, -15)), ("⟳ 右转 15°", lambda i: self._rotate(i, 15)),
                ("↻ 掉头", lambda i: self._rotate(i, 180)), ("转 90°", lambda i: self._rotate(i, 90)),
                ("升高一层", lambda i: self._lift(i, 1)), ("降低一层", lambda i: self._lift(i, -1)),
                ("拆开组合", self._ungroup), ("存成组合门…", self._save_combo),
                ("🔒 锁定", self._toggle_lock), ("删掉", self._delete)]
        for k, (text, fn) in enumerate(acts):
            b = QPushButton(text)
            b.clicked.connect(lambda _c=False, f=fn: self._act(f))
            g.addWidget(b, k // 2, k % 2)
            self.act[text] = b
        self.act["删掉"].setStyleSheet("color: #ff3b30;")
        selbox = QGroupBox("选中的门")
        sl = QVBoxLayout(selbox)
        sl.addWidget(self.sel_label)
        sl.addLayout(g)
        self.pos_x = QDoubleSpinBox(minimum=-50, maximum=1050, decimals=1, singleStep=0.1)
        self.pos_z = QDoubleSpinBox(minimum=-50, maximum=1050, decimals=1, singleStep=0.1)
        self.pos_a = QDoubleSpinBox(minimum=-360, maximum=720, decimals=0, singleStep=1, suffix="°", wrapping=True)
        self.pos_x.setToolTip("横（长边）：从场地左上角量，和上边标尺一样")
        self.pos_z.setToolTip("竖（宽边）：从场地左上角量，和左边标尺一样")
        self.pos_a.setToolTip("门朝哪：0° = 朝右（顺着长边），每格 1 度；组合门整组一起转")
        pg = QGridLayout()
        for k, (lab, w) in enumerate((("横(米)", self.pos_x), ("竖(米)", self.pos_z), ("角", self.pos_a))):
            w.setKeyboardTracking(False)
            w.setMinimumWidth(70)
            w.valueChanged.connect(self._pos_typed)
            pg.addWidget(QLabel(lab), k // 2, (k % 2)*2)
            pg.addWidget(w, k // 2, (k % 2)*2 + 1)
        sl.addLayout(pg)
        tipm = QLabel("微调：Ctrl+滚轮 / Shift+Q、E 转 1 度；方向键挪 0.1 米（Shift 1 米）")
        tipm.setWordWrap(True)
        tipm.setStyleSheet("color: gray;")
        sl.addWidget(tipm)
        self.order = QListWidget()
        self.order.setStyleSheet("QListWidget::item:selected { background: #ff3b30; color: white; }")
        self.order.itemClicked.connect(self._order_clicked)
        ordbox = QGroupBox("进门顺序")
        ol = QVBoxLayout(ordbox)
        tip = QLabel("在 3D 里一个门洞一个门洞点进来，箭头是穿的方向；最后再点一下 1 号起始门收圈。刀旗点左边再点右边就是掉头")
        tip.setWordWrap(True)
        tip.setStyleSheet("color: gray;")
        ol.addWidget(tip)
        ol.addWidget(self.order)
        og = QGridLayout()
        self.step_act = {}
        for k, (text, fn) in enumerate([("往前", lambda k: self._move_step(k, -1)), ("往后", lambda k: self._move_step(k, 1)),
                                         ("反方向", self._flip_step), ("去掉这一步", self._drop_step),
                                         ("清掉手绘", self._clear_draw), ("翻门", self._cycle_over),
                                         ("螺旋", self._cycle_spiral)]):
            b = QPushButton(text)
            b.clicked.connect(lambda _c=False, f=fn: self._step(f))
            if text == "翻门":
                og.addWidget(b, 3, 0, 1, 2)
            elif text == "螺旋":
                b.setToolTip("日字门、田字门下洞穿过去再从上洞穿（或反过来）：从右手边绕上去还是左手边")
                og.addWidget(b, 4, 0, 1, 2)
            else:
                og.addWidget(b, k // 2, k % 2)
            self.step_act[text] = b
        clr = QPushButton("清空进门顺序（门不动）")
        clr.setToolTip("把进门顺序、路线和手绘全部清掉，门留在原地，再自己一个门洞一个门洞重新点")
        clr.setStyleSheet("QPushButton { color: #ff3b30; }")
        clr.clicked.connect(self.clear_route)
        og.addWidget(clr, 5, 0, 1, 2)
        ol.addLayout(og)
        self.name = QLineEdit()
        self.name.setPlaceholderText("赛道名（建议英文，黑羊里能显示）")
        save = QPushButton("保存地图")
        save.setMinimumHeight(36)
        save.clicked.connect(self.save)
        fly = QPushButton("▶ 模拟飞行")
        fly.setMinimumHeight(44)
        fly.setStyleSheet("QPushButton { background: #007aff; border: none; color: white; font-weight: bold; font-size: 15px;"
                          " border-radius: 10px; }")
        fly.clicked.connect(self.to_fly)
        vd = QPushButton("转成黑羊 →")
        vd.setMinimumHeight(44)
        vd.setStyleSheet("QPushButton { background: #34c759; border: none; color: white; font-weight: bold; font-size: 15px;"
                         " border-radius: 10px; }")
        vd.clicked.connect(self.to_vd)
        savebox = QGroupBox("保存")
        sv = QVBoxLayout(savebox)
        sv.addWidget(self.name)
        sv.addWidget(save)
        sv.addWidget(fly)
        sv.addWidget(vd)
        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.addWidget(selbox)
        rl.addWidget(ordbox, 1)
        rl.addWidget(savebox)
        self.order.setMinimumHeight(120)
        rscroll = QScrollArea()             # 屏幕矮的时候右边能上下滚，窗口不会比屏幕高
        rscroll.setWidget(right)
        rscroll.setWidgetResizable(True)
        rscroll.setFixedWidth(280)
        rscroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        rscroll.setFrameShape(QScrollArea.NoFrame)

        body = QHBoxLayout()
        body.addWidget(scroll)
        body.addWidget(mid, 1)
        body.addWidget(rscroll)
        lay = QVBoxLayout(self)
        lay.addLayout(top)
        lay.addLayout(body, 1)
        for w in (self.gap, self.bar):
            w.valueChanged.connect(lambda _v: self.refresh())
        self._fill_maps()
        self._sync_sel()
        self._sync_ul()
        presets = self._preset_files()
        if presets:
            self.load_map(presets[0])
            self.maps.setCurrentIndex(self.maps.findData(str(presets[0])))
        else:
            self.refresh()

    def _tool(self, text, ic):
        b = QToolButton()
        b.setText(text)
        b.setIcon(ic)
        b.setIconSize(QSize(38, 38))
        b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        b.setFixedSize(80, 58)
        return b

    # ---- 场地、练习重点（可以自己填）
    def _field_typed(self):
        text = self.field.currentText().strip()
        wl = parse_field(text)
        if wl is None:
            QMessageBox.information(self, "赛道搭建", "场地大小这样写：长×宽，比如「50×35」（单位米）。")
            self.field.setCurrentIndex(1)
            return
        if text not in tg.FIELDS:
            lab = f"{wl[0]:g}×{wl[1]:g} 米"
            tg.FIELDS[lab] = wl
            if self.field.findText(lab) < 0:
                self.field.addItem(lab)
            self.field.setCurrentText(lab)
            if lab not in self.prefs["fields"]:
                self.prefs["fields"].append(lab)
                _write_json(PREFS, self.prefs)
        self.refresh()

    def _focus_typed(self):
        text = self.focus.currentText().strip()
        if text and text not in tg.FOCUS and text not in self.prefs["focuses"]:
            self.prefs["focuses"].append(text)
            _write_json(PREFS, self.prefs)
            if self.focus.findText(text) < 0:
                self.focus.addItem(text)
            self.focus.setCurrentText(text)

    def _field_wl(self):
        lab = self.field.currentText().strip()
        wl = parse_field(lab) or (45, 30)
        if lab not in tg.FIELDS:
            tg.FIELDS[lab] = wl
        return lab, max(wl), min(wl)

    # ---- 地图下拉：预载的单项练习图 + 自己存的
    def _preset_files(self):
        return sorted(PRESETS.glob(f"*{tg.SUFFIX}")) if PRESETS.is_dir() else []

    def _fill_maps(self, select=None):
        self.maps.blockSignals(True)
        self.maps.clear()
        self.maps.addItem(NEW_MAP, None)
        for p in self._preset_files():
            self.maps.addItem("预载 · " + p.name[:-len(tg.SUFFIX)], str(p))
        files = sorted(self.folder.glob(f"*{tg.SUFFIX}"), key=lambda p: p.stat().st_mtime, reverse=True) \
            if self.folder.is_dir() else []
        for p in files:
            self.maps.addItem(p.name[:-len(tg.SUFFIX)], str(p))
        if select:
            self.maps.setCurrentIndex(max(0, self.maps.findData(str(select))))
        self.maps.blockSignals(False)
        self._sync_del()

    def _sync_del(self):
        f = self.maps.currentData()
        self.del_btn.setEnabled(bool(f) and Path(f).parent == self.folder)

    def delete_map(self):
        f = self.maps.currentData()
        if not f or Path(f).parent != self.folder:
            return
        name = Path(f).name[:-len(tg.SUFFIX)]
        if QMessageBox.question(self, "删除地图", f"把地图「{name}」删掉？删了就找不回来了。") != QMessageBox.Yes:
            return
        try:
            Path(f).unlink()
        except OSError as ex:
            QMessageBox.warning(self, "删除地图", f"删不掉：{ex}")
            return
        if self.saved_file == Path(f):
            self.saved_file = None
        self._fill_maps()
        self.maps.setCurrentIndex(0)
        self._sync_del()

    def _map_chosen(self, _i):
        f = self.maps.currentData()
        self._sync_del()
        if not f:
            self.items = []
            self.route = []
            self.closed = False                 # 新的空图：一开始不收圈
            self._hist, self._redo = [], []
            self.saved_file = None
            self.name.setText(f"My Track {random.randint(1, 999)}")
            self.ul_remove()
            self.editor.select(None)
            self.refresh(refit=True)
            return
        self.load_map(f)

    def load_map(self, f):
        try:
            model, types, path, d = tg.load(f)
        except (OSError, ValueError, KeyError) as ex:
            QMessageBox.warning(self, "赛道搭建", f"这张地图读不出来：\n{ex}")
            return
        meta = d.get("meta", {})
        for w, v in ((self.gap, meta.get("S")), (self.bar, round(meta.get("T", 0) * 1000) or None)):
            if v:
                w.blockSignals(True)
                w.setValue(v)
                w.blockSignals(False)
        if meta.get("field"):
            if meta["field"] not in tg.FIELDS and parse_field(meta["field"]):
                tg.FIELDS[meta["field"]] = parse_field(meta["field"])
            if self.field.findText(meta["field"]) < 0:
                self.field.addItem(meta["field"])
            self.field.setCurrentText(meta["field"])
        if meta.get("focus"):
            self.focus.setCurrentText(meta["focus"])
        self.name.setText(d.get("name") or "Track")
        self.saved_file = Path(f) if Path(f).parent == self.folder else None
        if meta.get("items") and "route" in meta:
            self.items = [dict(it) for it in meta["items"]]
            self.route = [dict(s) for s in meta["route"]]
            self.closed = bool(meta.get("closed", True))
        elif meta.get("items"):                     # 老格式：每个门自己记怎么穿 -> 门洞顺序
            self.items, self.route = tg.legacy_route(meta["items"])
            self.closed = True
        else:                                       # 老版本电脑摆的图：门的位置从零件里读出来
            self.items, self.route = items_from_auto(model, types, meta.get("elems"))
            self.closed = True
        self.ul_remove()
        ul = meta.get("underlay")
        if ul and ul.get("file"):
            self._ul_load(Path(f).parent / ul["file"], ul)
        self.editor.sel_step = None
        self.editor.select(None)
        self._hist, self._redo = [], []
        self.refresh(refit=True)

    def _remember_show_path(self, on):
        self.prefs["show_path"] = bool(on)
        _write_json(PREFS, self.prefs)

    def open_trk(self):
        """黑羊地图 -> 这里能改的门和进门顺序"""
        docs = Path.home() / "Documents"
        f, _ = QFileDialog.getOpenFileName(self, "打开黑羊赛道", str(docs if docs.is_dir() else Path.home()),
                                           "黑羊地图 (*.trk);;所有文件 (*)")
        if not f:
            return
        S, T = self.gap.value(), self.bar.value()/1000
        try:
            items, route, (L, W), name, notes = tg.items_from_trk(f, S, T)
        except Exception as ex:  # noqa: BLE001 - 不是黑羊存的文件也统一提示
            QMessageBox.warning(self, "赛道搭建", f"这个文件读不出来，是黑羊保存的 .trk 吗？\n{ex}")
            return
        lab = f"{L:g}×{W:g} 米"
        tg.FIELDS.setdefault(lab, (L, W))
        if self.field.findText(lab) < 0:
            self.field.addItem(lab)
        self.field.setCurrentText(lab)
        self.editor.stop_place()
        self.items, self.route, self.closed = items, route, True
        self.name.setText(name or "Track")
        self.saved_file = None
        self.maps.setCurrentIndex(0)
        self._sync_del()
        self.editor.sel_step = None
        self.editor.set_helpers(self.helpers.isChecked())
        self.editor.select(None)
        self._hist, self._redo = [], []
        self.refresh(refit=True)
        QMessageBox.information(self, "赛道搭建", "\n".join(notes) + "\n\n改好以后点「保存地图」，或者直接「转成黑羊」。")

    def clear_all(self):
        if self.items and QMessageBox.question(self, "全部清空", "把地上的东西全部清掉？") != QMessageBox.Yes:
            return
        self.editor.stop_place()
        self.items.clear()
        self.route.clear()
        self.closed = False
        self.editor.select(None)
        self.refresh()

    # ---- 放门
    def start_place(self, t):
        self.tabs.setCurrentIndex(0)
        self.editor.start_place([dict(t=t, x=0, z=0, yaw=0)])

    def _fill_library(self):
        while self.lib_box.count():
            w = self.lib_box.takeAt(0).widget()
            if w:
                w.hide()
                w.setParent(None)
                w.deleteLater()
        for k, c in enumerate(self.library):
            b = self._tool(c['name'], icon('组合', items=c['items']))
            b.setToolTip(f"{c['name']}：{len(c['items'])} 个门。右键可以改名、删掉")
            b.clicked.connect(lambda _c=False, kk=k: self._place_combo(kk))
            b.setContextMenuPolicy(Qt.CustomContextMenu)
            b.customContextMenuRequested.connect(lambda _p, kk=k, bb=b: self._combo_menu(kk, bb))
            self.lib_box.addWidget(b)

    def _place_combo(self, k):
        self.tabs.setCurrentIndex(0)
        self.editor.start_place([dict(it, combo=self.library[k]['name']) for it in self.library[k]['items']])

    def _combo_menu(self, k, b):
        m = QMenu(self)
        ren = m.addAction("改名")
        dele = m.addAction("删掉")
        a = m.exec(QCursor.pos())
        if a == ren:
            name, ok = QInputDialog.getText(self, "组合门", "新名字", text=self.library[k]['name'])
            if ok and name.strip():
                self.library[k]['name'] = name.strip()
        elif a == dele:
            if QMessageBox.question(self, "组合门", f"从库里删掉「{self.library[k]['name']}」？") != QMessageBox.Yes:
                return
            self.library.pop(k)
        else:
            return
        _write_json(LIBRARY, self.library)
        self._fill_library()

    # ---- 电脑自动摆
    def auto_place(self):
        if self.items and QMessageBox.question(self, "赛道搭建", "电脑重新摆会换掉现在地上的门，继续？") != QMessageBox.Yes:
            return
        lab, _L, _W = self._field_wl()
        focus = self.focus.currentText().strip()
        self.seed = random.randint(1, 99999)
        QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))
        try:
            model, types, _path, info = tg.generate(n_gates=self.count.value(), allowed=list(tg.GATE_TYPES),
                                                    focus=focus if focus in tg.FOCUS else '综合', field=lab,
                                                    seed=self.seed, S=self.gap.value(), T=self.bar.value()/1000)
        except ValueError as ex:
            QApplication.restoreOverrideCursor()
            QMessageBox.information(self, "赛道搭建", str(ex))
            return
        QApplication.restoreOverrideCursor()
        self.items, self.route = items_from_auto(model, types, info['elems'])
        self.closed = True
        self.name.setText(f"Random {CODES.get(focus, 'Mix')} {self.seed}")
        self.saved_file = None
        self.maps.setCurrentIndex(0)
        if info.get('grown'):
            QMessageBox.information(self, "赛道搭建", f"门太多，场地放大到了 {info['field'][0]}×{info['field'][1]} 米。")
        self.editor.select(None)
        self.refresh(refit=True)

    # ---- 重新连路线、显示
    def refresh(self, refit=False):
        S, T = self.gap.value(), self.bar.value()/1000
        if sum(1 for st in self.route if st.get('f')) < 2:
            self.closed = False                     # 门洞不到 2 个谈不上收圈
        snap = json.dumps([self.items, self.route, self.closed], ensure_ascii=False, sort_keys=True)
        if not self._hist or self._hist[-1] != snap:
            self._hist = self._hist[-99:] + [snap]
            self._redo = []
        self.undo_btn.setEnabled(len(self._hist) > 1)
        self.redo_btn.setEnabled(bool(self._redo))
        try:
            self.result = tg.build_manual(self.items, self.route, S=S, T=T, closed=self.closed)
        except ValueError:
            self.result = None
        _lab, L, W = self._field_wl()
        self.view.stop_sim()
        self._sync_play()
        if not self.result:
            self.track = None
            self.view.set_track(None)
            self.editor.set_data(self.items, self.route, W, L, S, T, [], refit=refit, closed=self.closed)
            self.info.setText("左边点一个门，再点地上放（第 1 个门会问要不要当起始计时门）；"
                              "然后在 3D 里一个门洞一个门洞点，系统按顺序自动连线。")
        else:
            model, types, path, info = self.result
            self.track = tc.build(model, types, S=S, T=T, name=self.name.text() or "Track", path=path)
            self.view.set_track(self.track)
            self.editor.set_data(self.items, self.route, W, L, S, T, path, refit=refit, closed=self.closed)
            if self.closed:
                text = (f"{info['n']} 个门洞，{len(self.track['gates'])} 个检查点，一圈约 {info['length']:.0f} 米。"
                        "红线=系统自动连的路线，青色框+箭头=进门方向，淡虚框=还没加进顺序的门洞。")
            else:
                text = (f"已经连了 {info['n']} 个门洞。最后一个门放好后，点一下 1 号起始门（计时门）的门洞，"
                        "路线才连回去收成一圈。")
            if info.get('warn'):
                text += "\n⚠ " + "\n⚠ ".join(info['warn'])
            self.info.setText(text)
        self._fill_order()
        self._sync_sel()

    def _restore(self, snap):
        self.items, self.route, self.closed = json.loads(snap)
        self.editor.stop_place()
        self.editor.drawing = None
        self.editor.sel_step = None
        self.editor.select(None)
        self.refresh()

    def undo(self):
        if len(self._hist) > 1 and not self.editor._drag:
            self._redo.append(self._hist.pop())
            self._restore(self._hist[-1])

    def redo(self):
        if self._redo and not self.editor._drag:
            self._hist.append(self._redo.pop())
            self._restore(self._hist[-1])

    def _editor_changed(self):
        self.closed = self.editor.closed
        self.refresh()

    def _editor_selected(self, i):
        self._sync_sel()

    def _fill_order(self):
        self.order.blockSignals(True)
        self.order.clear()
        n = 0
        byid = {it.get('id'): it for it in self.items}
        for st in self.route:
            it = byid.get(st.get('id'))
            if it is None:
                txt = "   ·（已删掉）"
            elif st.get('f'):
                n += 1
                txt = f"{n:2d}  {step_text(it, st)}" + ("  计时门" if n == 1 else "")
            else:
                txt = "   · " + step_text(it, st)
            if st.get('via'):
                txt += "（手绘）"
            elif st.get('over') is not None:
                txt += "（翻过去）" if st['over'] else "（不翻）"
            if st.get('spiral') == 'L':
                txt += "（左螺旋）"
            elif st.get('spiral') == 'R':
                txt += "（右螺旋）"
            self.order.addItem(txt)
        if self.closed and self.route:
            fin = self.route[-1]
            self.order.addItem("  ↺ 回到 1 号起始门（收圈）" + ("（手绘）" if fin.get('via') else ""))
        self.order.blockSignals(False)

    def _order_clicked(self, item):
        k = self.order.row(item)
        self.editor.sel_step = k
        self.editor.set_helpers(self.helpers.isChecked())
        st = self.route[k] if k < len(self.route) else self.route[0]      # 「收圈」那行 -> 起始门
        self.editor.select(self.editor.index_of(st.get('id')))
        self.tabs.setCurrentIndex(0)
        self._sync_sel()

    def _sync_sel(self):
        k = self.editor.sel_step
        for b in self.step_act.values():
            b.setEnabled(k is not None)
        if k is not None:
            fin = k >= len(self.route)               # 最后那行「收圈」
            for t in ("往前", "往后", "反方向"):
                self.step_act[t].setEnabled(not fin)
            if not fin:
                self.step_act["反方向"].setEnabled(bool(self.route[k].get('f')))
            seg = self._seg(k)
            self.step_act["清掉手绘"].setEnabled(seg is not None and bool(self.route[seg].get('via')))
            ov = self.route[seg].get('over') if seg is not None else None
            self.step_act["翻门"].setEnabled(seg is not None)
            self.step_act["翻门"].setText({None: "到下一个：自动翻", True: "到下一个：从上面翻",
                                          False: "到下一个：不翻（中间切）"}[ov])
            sp = self.route[seg].get('spiral') if seg is not None else None
            self.step_act["螺旋"].setEnabled(seg is not None)
            self.step_act["螺旋"].setText("到下一个：左螺旋（左边绕上去）" if sp == 'L' else "到下一个：右螺旋（右边绕上去）")
            self.order.setCurrentRow(k)
        else:
            self.order.clearSelection()
        i = self.editor.sel
        has = i is not None and i < len(self.items)
        for b in self.act.values():
            b.setEnabled(has)
        _lab, L, W = self._field_wl()
        for w in (self.pos_x, self.pos_z, self.pos_a):
            w.blockSignals(True)
            w.setEnabled(has and not self.editor.locked(i))
        if has:
            it = self.items[i]
            self.pos_x.setValue(it['x'] + L/2)
            self.pos_z.setValue(it['z'] + W/2)
            self.pos_a.setValue(round(it.get('yaw', 0)) % 360)
            self.pos_a.setEnabled(self.pos_a.isEnabled() and it['t'] != tg.WP)
        for w in (self.pos_x, self.pos_z, self.pos_a):
            w.blockSignals(False)
        if not has:
            self.sel_label.setText("没选中门（在图上点一个门框）")
            return
        it = self.items[i]
        grp = group_of(self.items, i)
        txt = label(it['t'])
        if len(grp) > 1:
            txt += f"（组合门里的一个，共 {len(grp)} 个）"
        if it.get('lift'):
            txt += f"，叠高 {it['lift']:.1f} 米"
        if it['t'] == tg.WP:
            txt += f"，离地 {it.get('h') or (self.gap.value()/2 + self.bar.value()/1000):.1f} 米"
        self.sel_label.setText(txt)
        gate = it['t'] not in (tg.WP, tg.FLAG, tg.TAKEOFF)
        wp = it['t'] == tg.WP
        lk = self.editor.locked(i)
        if lk:
            txt += "（🔒 锁住了）"
            self.sel_label.setText(txt)
        self.act["升高一层"].setText("升高 1 米" if wp else "升高一层")
        self.act["降低一层"].setText("降低 1 米" if wp else "降低一层")
        self.act["升高一层"].setEnabled(wp or it['t'] in ('单门', '日子门'))
        self.act["降低一层"].setEnabled(wp or bool(it.get('lift')))
        self.act["拆开组合"].setEnabled(len(grp) > 1)
        self.act["存成组合门…"].setEnabled(gate)
        for b in (self.act["⟲ 左转 15°"], self.act["⟳ 右转 15°"], self.act["↻ 掉头"], self.act["转 90°"]):
            b.setEnabled(it['t'] != tg.WP)
        self.act["🔒 锁定"].setText("🔓 解锁" if lk else "🔒 锁定")
        if lk:                                       # 锁住了：不能挪、转、升降、拆、删
            for t, b in self.act.items():
                if t not in ("🔒 锁定", "存成组合门…"):
                    b.setEnabled(False)

    # ---- 进门顺序：右边列表下面的按钮
    def _step(self, fn):
        k = self.editor.sel_step
        if k is None or k > len(self.route) or (k == len(self.route) and not self.closed):
            return
        if fn(k) is False:
            return
        self.refresh()
        self.editor.update()

    def _move_step(self, k, d):
        j = k + d
        if 0 <= j < len(self.route):
            self.route[k], self.route[j] = self.route[j], self.route[k]
            self.editor.sel_step = j

    def _flip_step(self, k):
        if self.route[k].get('f'):
            self.route[k]['d'] = -(self.route[k].get('d') or 1)

    def clear_route(self):
        if not self.route:
            return
        if QMessageBox.question(self, "清空进门顺序", "把进门顺序和路线全部清掉，门留在原地，重新自己点？") != QMessageBox.Yes:
            return
        self.editor.stop_place()
        self.editor.sel_step = None
        self.items[:] = [it for it in self.items if it['t'] != tg.WP]     # 路线点只在顺序里有用
        self.route.clear()
        self.closed = False
        self.editor.select(None)
        self.refresh()

    def _drop_step(self, k):
        self.editor.sel_step = None
        if k >= len(self.route):                     # 去掉「收圈」：路线又不回起始门了
            self.closed = False
            self.route[-1].pop('via', None)
            return
        st = self.route.pop(k)
        if not self.closed and self.route:
            self.route[-1].pop('via', None)
        j = self.editor.index_of(st.get('id'))
        if j is not None and self.items[j]['t'] == tg.WP:     # 路线点不在顺序里就没用了
            self.editor.remove_item(j)

    def _seg(self, k):
        """顺序里第 k 行对应的那一段（从第几步飞到下一步）；没有下一步就是 None"""
        n = len(self.route)
        if k < n - 1:
            return k
        if self.closed and n >= 2 and k >= n - 1:
            return n - 1
        return None

    def _pen(self):
        """3D 画面右上角的画笔：
        选中了中间的一步 -> 重画这一步到下一步；没选（或选的是最后一步）-> 从最后一个门洞往后直接画，
        画过的门洞按先后加进顺序；正在画再点 = 取消"""
        if self.editor.drawing is not None:
            self.editor.drawing = None
            self.editor.stroke = []
            self.editor.update()
            self.refresh()
            return
        k = self.editor.sel_step
        n = len(self.route)
        if k is not None and (k < n - 1 or (self.closed and k >= n - 1)) and self._seg(k) is not None:
            self._draw_step(k)
            return
        if self.closed:
            self.info.setText("路线已经收圈了：在右边顺序里选一步，再点画笔重画那一段。")
            return
        self.tabs.setCurrentIndex(0)
        self.editor.start_free()
        self.info.setText("画笔：按住左键从最后一个门洞往后画，画过哪个门洞就按先后加进顺序，路线照你画的走；"
                          "画回 1 号起始门就收圈。再点一下画笔取消。")

    def _draw_step(self, k):
        seg = self._seg(k)
        if seg is None:
            return False
        self.editor.sel_step = seg
        self.tabs.setCurrentIndex(0)
        self.editor.start_draw(seg)
        self.info.setText("手绘：在 3D 里按住左键从这一步画到下一步，松开就好（Esc 取消）。"
                          "要从门上面翻过去，先把视角转到侧面再画。再点一下右上角画笔取消。")
        return False

    def _cycle_over(self, k):
        """这一步到下一步：自动 -> 从上面翻 -> 不翻（从中间空当切 / 旁边绕）-> 自动"""
        seg = self._seg(k)
        if seg is None:
            return False
        st = self.route[seg]
        nxt = {None: True, True: False, False: None}[st.get('over')]
        if nxt is None:
            st.pop('over', None)
        else:
            st['over'] = nxt

    def _cycle_spiral(self, k):
        """日字门 / 田字门上下两个洞连着穿：右螺旋 <-> 左螺旋"""
        seg = self._seg(k)
        if seg is None:
            return False
        st = self.route[seg]
        st['spiral'] = 'R' if st.get('spiral') == 'L' else 'L'
        st.pop('via', None)                      # 换了绕的方向，手绘的那段作废

    def _clear_draw(self, k):
        seg = self._seg(k)
        if seg is not None:
            self.route[seg].pop('via', None)

    # ---- 选中的门：右边那些按钮
    def _pos_typed(self, _v=None):
        i = self.editor.sel
        if i is None or i >= len(self.items) or self.editor.locked(i):
            return
        _lab, L, W = self._field_wl()
        it = self.items[i]
        dx, dz = round(self.pos_x.value() - L/2 - it['x'], 2), round(self.pos_z.value() - W/2 - it['z'], 2)
        if dx or dz:
            self.editor.nudge(i, dx, dz)
        if it['t'] != tg.WP:
            da = (self.pos_a.value() - it.get('yaw', 0) + 180) % 360 - 180
            if abs(da) > 0.05:
                self.editor.rotate(i, da)
        self.refresh()
        self.editor.select(i)

    # ---- 底图（组委会图纸）
    def import_underlay(self):
        f, _ = QFileDialog.getOpenFileName(self, "导入赛道图纸", str(Path.home()),
                                           "图片 (*.png *.jpg *.jpeg *.bmp *.webp);;所有文件 (*)")
        if not f:
            return
        if not self._ul_load(f):
            QMessageBox.warning(self, "导入图纸", "这张图片打不开。")
            return
        self.ul_fit()
        self.editor.set_view("俯视")
        self.show_rules(first=True)

    def show_rules(self, first=False):
        box = QMessageBox(self)
        box.setWindowTitle("看图规则")
        box.setTextFormat(Qt.RichText)
        head = ("<p style='color:#007aff'><b>图纸先按「铺满场地」放好了。</b>场地边框对不上的话："
                "「图纸 ▾ → 两点定比例」点一段标了长度的线（比如 85m 那条）两头，输入实际米数，"
                "再「挪图片」拖到场地角对齐。</p>") if first else ""
        box.setText(head + READ_RULES)
        box.setStyleSheet("QLabel { min-width: 680px; }")
        box.exec()

    def _ul_load(self, f, params=None):
        img = QImage(str(f))
        if img.isNull():
            return False
        if img.width() > UL_MAX:
            img = img.scaledToWidth(UL_MAX, Qt.SmoothTransformation)
        self.ul_src = str(f)
        u = dict(img=img, cx=0.0, cz=0.0, w=10.0, rot=0, op=self.ul_op.value()/100, show=True)
        if params:
            u.update({k: params[k] for k in ('cx', 'cz', 'w', 'rot', 'op', 'show') if k in params})
            self.ul_op.blockSignals(True)
            self.ul_op.setValue(int(u['op']*100))
            self.ul_op.blockSignals(False)
        self.editor.underlay = u
        self._sync_ul()
        return True

    def _sync_ul(self):
        u = self.editor.underlay
        for k in ("fit", "calib", "move", "rot", "show", "del"):
            self.ul_acts[k].setEnabled(u is not None)
        self.ul_acts["move"].setChecked(self.editor.ul_move)
        self.ul_acts["show"].setChecked(bool(u and u.get('show', True)))
        self.ul_menu_btn.setEnabled(u is not None)
        self.ul_op.setEnabled(u is not None)
        self.editor.update()

    def ul_fit(self):
        u = self.editor.underlay
        if not u:
            return
        _lab, L, W = self._field_wl()
        iw, ih = u['img'].width(), u['img'].height()
        if u.get('rot', 0) % 180:
            iw, ih = ih, iw
        u.update(cx=0.0, cz=0.0, w=min(L, W*iw/ih) if not u.get('rot', 0) % 180 else min(W, L*ih/iw))
        self.editor.update()

    def ul_calib(self):
        if self.editor.underlay:
            self.editor.underlay['show'] = True
            self.editor.start_calib()
            self._sync_ul()

    def _ul_calibrated(self, a, b):
        u = self.editor.underlay
        d = math.dist(a, b)
        if not u or d < 0.05:
            return
        real, ok = QInputDialog.getDouble(self, "两点定比例", f"这两点在图上量着是 {d:.1f} 米，实际是多少米？",
                                          round(d, 1), 0.1, 2000, 1)
        if not ok or real <= 0:
            return
        r = real / d                                # 以第一个点为中心放大缩小，第一个点不动
        u['w'] *= r
        u['cx'] = round(a[0] + (u['cx']-a[0])*r, 2)
        u['cz'] = round(a[1] + (u['cz']-a[1])*r, 2)
        self.editor.update()

    def ul_toggle_move(self):
        self.editor.ul_move = not self.editor.ul_move and self.editor.underlay is not None
        if self.editor.ul_move:
            self.editor.stop_place()
        self._sync_ul()

    def ul_rotate(self):
        u = self.editor.underlay
        if u:
            u['rot'] = (u.get('rot', 0) + 90) % 360
            self.editor.update()

    def ul_toggle_show(self):
        u = self.editor.underlay
        if u:
            u['show'] = not u.get('show', True)
            self._sync_ul()

    def ul_remove(self):
        self.editor.underlay = None
        self.editor.ul_move = False
        self.ul_src = None
        self._sync_ul()

    def _ul_opacity(self, v):
        if self.editor.underlay:
            self.editor.underlay['op'] = v/100
            self.editor.update()

    def check_route(self):
        """核对：软件自己认图纸上的粉色指引线、按看图规则排穿门顺序（之前不显示），跟手画的逐个门洞对比；存学习样本"""
        import difflib
        from datetime import datetime
        from app import drawread
        e = self.editor
        u = e.underlay
        if not u or u['img'].isNull():
            QMessageBox.information(self, "核对", "先「🖼 导入图纸…」，照着图纸摆好门、手工画好路线，再点核对。")
            return
        mine = [st for st in self.route if st.get('f')]
        if not mine:
            QMessageBox.information(self, "核对", "还没有路线：先在俯视里点「✏ 手绘路线」顺着图纸的粉色线描一遍，再点核对。")
            return
        src = next((it for it in self.items if it['t'] == tg.TAKEOFF), None)      # 线从起飞台那头开始
        if src is None:
            src = self.items[e.index_of(mine[0]['id'])]
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            line = drawread.read_line(u['img'], start_hint=e.ground_to_img(src['x'], src['z']))
            guess, _closed = e.guess_route([e.img_to_ground(x, y) for x, y in line]) if len(line) > 20 else ([], False)
        finally:
            QApplication.restoreOverrideCursor()
        if not guess:
            QMessageBox.information(self, "核对", "没在图纸上认出粉色指引线（或者线没穿过摆好的门）。"
                                    "看看图纸是不是放对了位置、门是不是摆在图纸的门上。")
            return
        key = lambda st: (st['id'], st.get('f'), st.get('d', 1))
        a = [key(st) for st in mine]
        b = [key(st) for st in guess if st.get('f')]
        sm = difflib.SequenceMatcher(a=a, b=b, autojunk=False)
        same = sum(m.size for m in sm.get_matching_blocks())

        def txt(steps, k0, k1):
            out = []
            for k in range(k0, k1):
                st = steps[k]
                j = e.index_of(st['id'])
                out.append(f"{k+1}. " + (step_text(self.items[j], st) if j is not None else str(st['id'])))
            return "<br>".join(out) or "（没有）"
        guess_f = [st for st in guess if st.get('f')]
        rows = ""
        for op, a0, a1, b0, b1 in sm.get_opcodes():
            if op != 'equal':
                rows += (f"<tr><td style='padding:4px 10px;border-bottom:1px solid #ddd'>{txt(mine, a0, a1)}</td>"
                         f"<td style='padding:4px 10px;border-bottom:1px solid #ddd;color:#c0392b'>{txt(guess_f, b0, b1)}</td></tr>")
        sample = self._save_sample(mine, guess, line, same)
        html = (f"<p><b>你画的 {len(a)} 个门洞，软件自己看图猜的 {len(b)} 个，对上了 {same} 个。</b></p>")
        if rows:
            html += ("<p>不一样的地方（左边是你画的，右边红字是软件猜的）：</p>"
                     "<table cellspacing=0><tr><th align=left style='padding:4px 10px'>你画的</th>"
                     f"<th align=left style='padding:4px 10px'>软件猜的</th></tr>{rows}</table>")
        else:
            html += "<p style='color:#2e7d32'>全部一样！</p>"
        html += ("<p style='color:#666'>以你画的为准，软件猜的不会改你的路线。"
                 + ("这份图纸和你的路线已经存成学习样本（在地图文件夹的「学习样本」里），以后用来把软件教准。" if sample else "") + "</p>")
        box = QMessageBox(self)
        box.setWindowTitle("核对")
        box.setTextFormat(Qt.RichText)
        box.setText(html)
        box.setStyleSheet("QLabel { min-width: 600px; }")
        box.exec()

    def _save_sample(self, mine, guess, line, same):
        """学习样本：地图文件夹/学习样本/<地图名>-<时间>/ 里放 图纸 + sample.json（门、你画的、软件猜的、认出来的线）"""
        from datetime import datetime
        try:
            u = self.editor.underlay
            name = re.sub(r'[\\/:*?"<>|]', '_', self.name.text().strip() or "赛道")
            d = self.folder / "学习样本" / f"{name}-{datetime.now():%Y%m%d-%H%M%S}"
            d.mkdir(parents=True, exist_ok=True)
            img = None
            if self.ul_src and Path(self.ul_src).is_file():
                img = "图纸" + Path(self.ul_src).suffix.lower()
                (d / img).write_bytes(Path(self.ul_src).read_bytes())
            data = dict(image=img, image_size=[u['img'].width(), u['img'].height()],
                        underlay=dict(cx=u['cx'], cz=u['cz'], w=u['w'], rot=u.get('rot', 0)),
                        S=self.gap.value(), T=self.bar.value()/1000,
                        items=[{k: (float(v) if isinstance(v, float) else v) for k, v in it.items() if v is not None} for it in self.items],
                        mine=[dict(st) for st in mine], guess=[dict(st) for st in guess],
                        same=same, line=[[round(x, 1), round(y, 1)] for x, y in line[::2]])
            _write_json(d / "sample.json", data)
            return f"{d.parent.name}/{d.name}"
        except OSError:
            return None

    def _ul_meta(self, map_file):
        """保存地图时：底图拷进 地图文件夹/图纸/，meta 里只记文件名和摆法"""
        u = self.editor.underlay
        if not u or not self.ul_src:
            return None
        src = Path(self.ul_src)
        dst = map_file.parent / UL_DIR / (map_file.name[:-len(tg.SUFFIX)] + src.suffix.lower())
        if src.resolve() != dst.resolve():
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(src.read_bytes())
            self.ul_src = str(dst)
        return dict(file=f"{UL_DIR}/{dst.name}", cx=u['cx'], cz=u['cz'], w=round(u['w'], 3), rot=u.get('rot', 0),
                    op=round(u.get('op', 0.6), 2), show=u.get('show', True))

    def _act(self, fn):
        i = self.editor.sel
        if i is None or i >= len(self.items):
            return
        if fn(i) is not False:
            self.refresh()
            if self.editor.sel is not None:
                self.editor.select(self.editor.sel)

    def _rotate(self, i, deg):
        self.editor.rotate(i, deg)

    def _toggle_lock(self, i):
        self.editor.toggle_lock(i)

    def _lift(self, i, d):
        it = self.items[i]
        S, T = self.gap.value(), self.bar.value()/1000
        if it['t'] == tg.WP:                        # 路线点：每次升降 1 米，路线跟着高低走
            it['h'] = round(max(0.5, min(15.0, (it.get('h') or T+S/2) + d)), 2)
            return
        step = height(it['t'], S, T) - T
        it['lift'] = round(max(0.0, (it.get('lift', 0) or 0) + d*step), 3)
        if not it['lift']:
            it.pop('lift')

    def _ungroup(self, i):
        for j in group_of(self.items, i):
            self.items[j].pop('grp', None)
            self.items[j].pop('combo', None)

    def _delete(self, i):
        self.editor.remove_item(i)

    def _save_combo(self, i):
        members = group_of(self.items, i)
        name, ok = QInputDialog.getText(self, "存成组合门", f"给这个组合门起个名字（{len(members)} 个门）：",
                                        text=f"组合门 {len(self.library)+1}")
        if not ok or not name.strip():
            return False
        a = self.items[i]
        r = math.radians(-a.get('yaw', 0))
        rel = []
        for j in members:
            it = self.items[j]
            dx, dz = it['x']-a['x'], it['z']-a['z']
            q = {k: v for k, v in it.items() if k in ('t', 'how', 'lift', 'h', 'name')}
            q.update(x=round(dx*math.cos(r) - dz*math.sin(r), 3), z=round(dx*math.sin(r) + dz*math.cos(r), 3),
                     yaw=(it.get('yaw', 0) - a.get('yaw', 0)) % 360)
            rel.append(q)
        self.library.append(dict(name=name.strip(), items=rel))
        for j in members:
            self.items[j]['combo'] = name.strip()
        _write_json(LIBRARY, self.library)
        self._fill_library()
        QMessageBox.information(self, "组合门", f"「{name.strip()}」存进库了，左边那列门最下面点一下就能再放。")
        self.editor.update()
        return False

    # ---- 3D 里播放
    def toggle_play(self):
        if self.view.timer.isActive():
            self.view.pause_sim()
        elif self.track and len(self.track['path']) > 1:
            self.view.start_sim()
        self._sync_play()

    def _sync_play(self):
        self.play_btn.setText("⏸ 暂停" if self.view.timer.isActive() else "▶ 播放")

    # ---- 保存 / 模拟飞行 / 转黑羊
    def _file_for(self, name):
        safe = re.sub(r'[\\/:*?"<>|]', "_", name) or "Track"
        return self.folder / f"{safe}{tg.SUFFIX}"

    def _write(self, file):
        model, types, path, info = self.result
        meta = dict(focus=self.focus.currentText().strip(), field=self.field.currentText().strip(), seed=self.seed,
                    S=self.gap.value(), T=self.bar.value()/1000, length=info['length'], mode="manual",
                    items=[{k: v for k, v in it.items() if v is not None} for it in self.items],
                    route=[dict(st) for st in self.route], closed=self.closed, elems=info['elems'])
        ul = self._ul_meta(file)
        if ul:
            meta['underlay'] = ul
        file.parent.mkdir(parents=True, exist_ok=True)
        tg.save(file, self.name.text().strip() or "Track", model, types, path, meta)
        self.saved_file = file
        self._fill_maps(select=file)

    def _ready(self, need_closed=False):
        if not self.result:
            QMessageBox.information(self, "赛道搭建", "还没有赛道：至少要放 2 个要穿的门。")
            return False
        if need_closed and not self.closed:
            QMessageBox.information(self, "赛道搭建", "路线还没收圈：最后在 3D 里点一下 1 号起始门的门洞，再来飞。")
            return False
        return True

    def save(self):
        if not self._ready():
            return
        f = self._file_for(self.name.text().strip())
        if f.exists() and f != self.saved_file and QMessageBox.question(
                self, "赛道搭建", f"已经有一张叫「{f.name[:-len(tg.SUFFIX)]}」的地图，覆盖它？") != QMessageBox.Yes:
            return
        try:
            self._write(f)
        except OSError as ex:
            QMessageBox.warning(self, "赛道搭建", f"保存不了：{ex}")
            return
        QMessageBox.information(self, "赛道搭建", f"已保存：{f}\n\n以后在上面「地图」下拉里就能选回来。")

    def _autosave(self):
        if not self._ready(need_closed=True):
            return False
        try:
            self._write(self._file_for(self.name.text().strip()))
        except OSError as ex:
            QMessageBox.warning(self, "赛道搭建", f"保存不了：{ex}")
            return False
        return True

    def to_fly(self):
        if not self._autosave():
            return
        from app.trackhub import TrackHub
        self.view.pause_sim()
        dlg = TrackHub(self.folder, self)
        dlg.open_file(str(self.saved_file))
        dlg.fly.view.start_sim()
        dlg.fly._sync_buttons()
        dlg.exec()

    def to_vd(self):
        if not self._autosave():
            return
        from app.trackhub import TrackHub
        self.view.pause_sim()
        dlg = TrackHub(self.folder, self, start="vd")
        dlg.open_file(str(self.saved_file))
        dlg.exec()
