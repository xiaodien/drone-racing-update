"""内置黑羊（VelociDrone）3D 地图预览器：纯 PySide6 真实透视 3D 渲染（球场草坪分格条纹、渐变天空地平线、
带厚度的二层白色高架桥与立柱投影、VelociDrone 橙/霓虹绿发光检查门、起飞垫、路线试飞与 FPV 跟飞视角）。
支持直接打开 `.trk` 文件，也支持从「赛道搭建」实时同步查看三维效果。
"""
import bisect
import math
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen, QPolygonF
from PySide6.QtWidgets import (QCheckBox, QComboBox, QFileDialog, QHBoxLayout, QLabel, QMessageBox,
                               QPushButton, QVBoxLayout, QWidget)

from app import trackconv as tc
from app import trackgen as tg
from app.config import APP_DIR, USER_DIR


def _qrot_w(q, v):
    a = tc.qrot(q, v)
    return [a[0], a[1], -a[2]]


def _quad_depth(cam_pts):
    return sum(c[2] for c in cam_pts) / len(cam_pts)


class VelociCanvas(QWidget):
    """纯 QPainter 真透视黑羊 3D 视口：左键旋转、右键/中键平移、滚轮缩放"""
    VIEWS = {
        "斜视 3D": (-32.0, 21.0),
        "俯视":    (0.0, 86.0),
        "低空视角": (-24.0, 10.0),
        "正面":    (0.0, 15.0),
    }
    NEAR = 0.6

    progress = Signal(str)
    sim_state = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.yaw, self.pitch = self.VIEWS["斜视 3D"]
        self.fov = 62.0
        self.dist_base = 64.0
        self.dist = 64.0
        self.target = [0.0, 1.0, 0.0]

        self.show_path = True
        self.show_nums = True
        self.show_bridges = True
        self.follow = False
        self.yaw_off = 0.0
        self.cam = None

        self.scene_data = None
        self.arc = [0.0]
        self.gate_s = []
        self.sim_s = None
        self.speed = 12.0

        self._drag = None
        self.timer = QTimer(self)
        self.timer.setInterval(33)
        self.timer.timeout.connect(self._step)
        self.setMinimumSize(480, 360)
        self.setMouseTracking(True)

    # ---- 数据加载 ----------------------------------------------------------
    def set_track(self, tr):
        self.stop_sim()
        if not tr:
            self.scene_data = None
            self.arc = [0.0]
            self.gate_s = []
            self.update()
            return

        sid = tr.get("scene", 42)
        scene_name, floor = tc.SCENES.get(sid, (f"黑羊场景 {sid}", 0))
        C = lambda u: [u[0] / 100.0, (u[1] - floor) / 100.0, -u[2] / 100.0]

        pads, tubes, blocks, gates = [], [], [], []
        xs, zs = [], []

        def track_xz(pt):
            xs.append(pt[0])
            zs.append(pt[2])

        bridges = list(tr.get("bridges") or [])
        has_br = bool(bridges)
        for br in bridges:
            for q in br.get("pts") or []:
                xs.append(q[0])
                zs.append(q[1])

        for b in tr.get("barriers") or []:
            tr_b = b.get("trans") or {}
            pos = tr_b.get("pos")
            if not pos:
                continue
            q = tr_b.get("rot", [0.0, 0.0, 0.0, 1.0])
            prefab = b.get("prefab", 0)
            base = C(pos)
            ax = [_qrot_w(q, (1, 0, 0)), _qrot_w(q, (0, 1, 0)), _qrot_w(q, (0, 0, 1))]

            if prefab == tc.TRK_PAD:
                hw = 1.25
                cs = [
                    [base[k] + sa * ax[0][k] * hw + sb * ax[2][k] * hw for k in range(3)]
                    for sa, sb in ((-1, -1), (1, -1), (1, 1), (-1, 1))
                ]
                for c in cs:
                    c[1] = 0.03
                    track_xz(c)
                pads.append(dict(corners=cs, mid=[base[0], 0.03, base[2]], ax=ax[0], az=ax[2]))
                continue

            per_m = 50.0 if prefab == 54 else 100.0
            s = [max(0.02, abs(v) / per_m) for v in tr_b.get("scale", [20, 20, 20])]
            cen = [base[k] + ax[1][k] * s[1] * 0.5 for k in range(3)]

            # 铺路产生的宽扁方块在预览里让位于平滑路面/高架桥
            if tr.get("road") and prefab == 54 and s[1] < 0.25 and s[0] >= 1.8:
                if has_br or cen[1] < 0.35:
                    continue

            ss = sorted(s)
            if prefab == 54 and ss[1] >= 0.45 and s[1] >= 0.25:
                # 体积方块（墙体/跳台/集装箱）
                hx, hy, hz = s[0] * 0.5, s[1] * 0.5, s[2] * 0.5
                top = [[cen[k] + sx * ax[0][k] * hx + ax[1][k] * hy + sz * ax[2][k] * hz for k in range(3)]
                       for sx, sz in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
                bot = [[cen[k] + sx * ax[0][k] * hx - ax[1][k] * hy + sz * ax[2][k] * hz for k in range(3)]
                       for sx, sz in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
                for pt in top:
                    track_xz(pt)
                blocks.append(dict(top=top, bot=bot, mid=cen, col=QColor(210, 218, 228)))
            else:
                # 细长方管/旗杆/门框杆
                i = max(range(3), key=lambda j: s[j])
                thick = max(0.06, ss[1])
                half_l = s[i] * 0.5
                e1 = [cen[k] - ax[i][k] * half_l for k in range(3)]
                e2 = [cen[k] + ax[i][k] * half_l for k in range(3)]
                track_xz(e1)
                track_xz(e2)
                col = QColor(245, 158, 11) if (i == 1 and s[1] >= 2.2 and max(s[0], s[2]) < 0.35) else QColor(238, 242, 246)
                tubes.append(dict(a=e1, b=e2, thick=thick, mid=cen, col=col))

        for idx, g in enumerate(tr.get("gates") or []):
            tr_g = g.get("trans") or {}
            pos = tr_g.get("pos")
            if not pos:
                continue
            q = tr_g.get("rot", [0.0, 0.0, 0.0, 1.0])
            lat = _qrot_w(q, (0, 1, 0))
            ext = _qrot_w(q, (0, 0, 1))
            sc = tr_g.get("scale", [3, 125, 125])
            w, h = abs(sc[1]) / 50.0, abs(sc[2]) / 50.0
            base = C(pos)
            cen = [base[k] + ext[k] * h * 0.5 for k in range(3)]
            cs = [
                [cen[k] + sa * lat[k] * w * 0.5 + sb * ext[k] * h * 0.5 for k in range(3)]
                for sa, sb in ((-1, -1), (1, -1), (1, 1), (-1, 1))
            ]
            for c in cs:
                track_xz(c)
            gates.append(dict(
                no=int(g.get("gate", idx)) + 1,
                idx=idx,
                corners=cs,
                mid=cen,
                start=bool(g.get("start")),
                finish=bool(g.get("finish")),
                w=w,
                h=h,
            ))

        path = [list(pt) for pt in (tr.get("path") or [])]
        for pt in path:
            track_xz(pt)

        self._commit_scene(
            name=tr.get("name") or "VelociDrone Track",
            scene_name=scene_name,
            pads=pads,
            tubes=tubes,
            blocks=blocks,
            gates=gates,
            bridges=bridges,
            path=path,
            xs=xs,
            zs=zs,
        )

    def set_scene_items(self, items, bridges=None, field=(80, 60), S=2.5, T=0.2, name="", path=None, route=None):
        """即使还没有点击过门顺序，也能直接用编辑器的摆件和高架桥生成完整 3D 黑羊预览"""
        from app.trackmanual import frames

        self.stop_sim()
        pads, tubes, gates = [], [], []
        xs = [-field[0] * 0.5, field[0] * 0.5]
        zs = [-field[1] * 0.5, field[1] * 0.5]
        br_list = list(bridges or [])
        for br in br_list:
            for q in br.get("pts") or []:
                xs.append(q[0])
                zs.append(q[1])

        route_idx = {}
        if route:
            no = 0
            for st in route:
                if st.get("f"):
                    no += 1
                    route_idx[(st.get("id"), st.get("f"))] = no

        for it in items or []:
            xs.append(it["x"])
            zs.append(it["z"])
            if it["t"] == tg.WP:
                continue
            if it["t"] == tg.TAKEOFF:
                a = math.radians(it.get("yaw", 0))
                ax = [math.cos(a), 0.0, math.sin(a)]
                az = [-ax[2], 0.0, ax[0]]
                hw = 1.25
                cs = [[it["x"] + sx * ax[0] * hw + sz * az[0] * hw, 0.03,
                       it["z"] + sx * ax[2] * hw + sz * az[2] * hw]
                      for sx, sz in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
                pads.append(dict(corners=cs, mid=[it["x"], 0.03, it["z"]], ax=ax, az=az))
                continue

            col = QColor(245, 158, 11) if it["t"] in (tg.FLAG, tg.POLE) else QColor(238, 242, 246)
            for a_pt, b_pt, thick in frames(it, S, T):
                mid = [(a_pt[k] + b_pt[k]) * 0.5 for k in range(3)]
                tubes.append(dict(a=a_pt, b=b_pt, thick=thick, mid=mid, col=col))

            for lab, C, _N, Wd, U in tg.faces(it, S, T):
                no = route_idx.get((it.get("id"), lab), 0)
                h = S * 0.5
                cs = [tc.add(tc.add(C, tc.mul(Wd, sw * h)), tc.mul(U, su * h))
                      for sw, su in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
                gates.append(dict(
                    no=no,
                    idx=len(gates),
                    corners=cs,
                    mid=C,
                    start=(no == 1),
                    finish=False,
                    w=S,
                    h=S,
                ))

        self._commit_scene(
            name=name or "赛道三维预览",
            scene_name="体育场草地（编辑预览）",
            pads=pads,
            tubes=tubes,
            blocks=[],
            gates=gates,
            bridges=br_list,
            path=[list(pt) for pt in (path or [])],
            xs=xs,
            zs=zs,
        )

    def _commit_scene(self, name, scene_name, pads, tubes, blocks, gates, bridges, path, xs, zs):
        if xs and zs:
            x0, x1 = min(xs), max(xs)
            z0, z1 = min(zs), max(zs)
        else:
            x0, x1, z0, z1 = -40.0, 40.0, -30.0, 30.0

        span = max(18.0, x1 - x0, z1 - z0)
        self.dist_base = span * 0.92 + 12.0
        self.dist = self.dist_base
        self.target = [(x0 + x1) * 0.5, 1.0, (z0 + z1) * 0.5]

        margin = max(12.0, span * 0.20)
        br_segs = tc.bridge_ribbon(bridges) if bridges else []
        self.scene_data = dict(
            name=name,
            scene_name=scene_name,
            bounds=(x0 - margin, x1 + margin, z0 - margin, z1 + margin),
            pads=pads,
            tubes=tubes,
            blocks=blocks,
            gates=gates,
            br_segs=br_segs,
            path=path,
        )

        # 路径弧长与检查点对应位置
        self.arc = [0.0]
        for i in range(1, len(path)):
            self.arc.append(self.arc[-1] + math.dist(path[i - 1], path[i]))
        self.gate_s = []
        if len(path) >= 2:
            j0 = 0
            for g in sorted(gates, key=lambda it: it["no"] or 9999):
                if g["no"] <= 0:
                    continue
                c = g["mid"]
                best = None
                for j in range(j0, len(path)):
                    d = math.dist(path[j], c)
                    if best is None or d < best[1]:
                        best = (j, d)
                    elif best[1] < 2.5 and d > best[1] + 1.0:
                        break
                j0 = best[0] if best else j0
                self.gate_s.append((g["idx"], self.arc[j0]))
        self.update()
        self._emit_idle_status()

    def _emit_idle_status(self):
        sd = self.scene_data
        if not sd:
            self.progress.emit("拖入 .trk 或点击左上角「打开黑羊 .trk…」查看 3D 效果")
            return
        lap = f"{self.arc[-1]:.0f}m" if len(self.arc) >= 2 else "未连线"
        self.progress.emit(f"{sd['name']} · {len(sd['gates'])} 个检查门 · {len(sd['br_segs']) and '含二层高架桥 · ' or ''}一圈 {lap}")

    # ---- 视角 & 试飞控制 ---------------------------------------------------
    def set_view(self, name):
        if name in self.VIEWS:
            self.yaw, self.pitch = self.VIEWS[name]
            if self.scene_data:
                x0, x1, z0, z1 = self.scene_data["bounds"]
                self.target = [(x0 + x1) * 0.5, 1.0, (z0 + z1) * 0.5]
                self.dist = self.dist_base
            self.update()

    def set_follow(self, on):
        self.follow = bool(on)
        self.cam = None
        self.yaw_off = 0.0
        self.update()

    def start_sim(self):
        if not self.scene_data or len(self.scene_data["path"]) < 2:
            return
        if self.sim_s is None or self.sim_s >= self.arc[-1]:
            self.sim_s = 0.0
            self.cam = None
        self.timer.start()
        self.sim_state.emit(True)

    def pause_sim(self):
        if self.timer.isActive():
            self.timer.stop()
            self.sim_state.emit(False)

    def stop_sim(self):
        was = self.timer.isActive()
        self.timer.stop()
        self.sim_s = None
        self.cam = None
        if was:
            self.sim_state.emit(False)
        self._emit_idle_status()
        self.update()

    def _at(self, s):
        pts = self.scene_data["path"]
        s = max(0.0, min(self.arc[-1], s))
        j = max(1, min(len(pts) - 1, bisect.bisect_left(self.arc, s)))
        seg = (self.arc[j] - self.arc[j - 1]) or 1.0
        t = (s - self.arc[j - 1]) / seg
        return [pts[j - 1][k] + t * (pts[j][k] - pts[j - 1][k]) for k in range(3)]

    def _drone(self):
        pos = self._at(self.sim_s)
        a = self._at(self.sim_s - 1.2)
        b = self._at(self.sim_s + 2.8)
        return pos, [b[k] - a[k] for k in range(3)]

    def _step(self):
        self.sim_s += self.speed * 0.033
        if self.sim_s >= self.arc[-1]:
            self.sim_s = self.arc[-1]
            self.timer.stop()
            self.sim_state.emit(False)
        pos, head = self._drone()
        yaw_d = math.degrees(math.atan2(-head[0], -head[2])) if (head[0] or head[2]) else (self.cam[3] if self.cam else self.yaw)
        if self.cam is None:
            self.cam = [pos[0], pos[1], pos[2], yaw_d]
        else:
            for k in range(3):
                self.cam[k] += (pos[k] - self.cam[k]) * 0.16
            d = (yaw_d - self.cam[3] + 180.0) % 360.0 - 180.0
            self.cam[3] += max(-4.0, min(4.0, d * 0.09))
        done = sum(1 for _i, gs in self.gate_s if gs <= self.sim_s + 0.35)
        self.progress.emit(f"试飞中：已过 {done}/{len(self.gate_s)} 个检查门 · 用时 {self.sim_s / self.speed:.1f} / {self.arc[-1] / self.speed:.1f} 秒")
        self.update()

    # ---- 鼠标交互 ----------------------------------------------------------
    def mousePressEvent(self, e):
        pan_mode = e.button() in (Qt.RightButton, Qt.MiddleButton)
        self._drag = (e.position(), self.yaw_off if self.follow else self.yaw, self.pitch, list(self.target), pan_mode)
        self.setCursor(Qt.ClosedHandCursor if pan_mode else Qt.SizeAllCursor)

    def mouseMoveEvent(self, e):
        if not self._drag:
            return
        d = e.position() - self._drag[0]
        if self._drag[4]:
            # 平移目标点
            yr = math.radians(self.yaw)
            rx, rz = math.cos(yr), -math.sin(yr)
            fx, fz = -math.sin(yr), -math.cos(yr)
            sens = self.dist * 0.0022
            t0 = self._drag[3]
            self.target = [
                t0[0] - d.x() * rx * sens + d.y() * fx * sens,
                t0[1],
                t0[2] - d.x() * rz * sens + d.y() * fz * sens,
            ]
        else:
            if self.follow:
                self.yaw_off = self._drag[1] - d.x() * 0.45
            else:
                self.yaw = self._drag[1] - d.x() * 0.42
            self.pitch = max(5.0, min(88.0, self._drag[2] + d.y() * 0.35))
        self.update()

    def mouseReleaseEvent(self, _):
        self._drag = None
        self.setCursor(Qt.ArrowCursor)

    def wheelEvent(self, e):
        factor = 0.87 if e.angleDelta().y() > 0 else 1.15
        lo = max(5.0, self.dist_base * 0.25)
        hi = max(80.0, self.dist_base * 5.0)
        self.dist = max(lo, min(hi, self.dist * factor))
        self.update()

    # ---- 真透视投影与裁剪 --------------------------------------------------
    def _camera_vectors(self):
        if self.follow and self.sim_s is not None and self.cam is not None:
            tx, ty, tz, cyaw = self.cam
            eff_yaw = cyaw + self.yaw_off
            yr = math.radians(eff_yaw)
            eff_pitch = max(6.0, min(40.0, self.pitch))
            pr = math.radians(eff_pitch)
            chase_d = max(5.5, min(14.0, self.dist * 0.16))
            ex = tx + chase_d * math.cos(pr) * math.sin(yr)
            ey = ty + chase_d * math.sin(pr) + 1.1
            ez = tz + chase_d * math.cos(pr) * math.cos(yr)
            look = [tx, ty + 0.6, tz]
        else:
            tx, ty, tz = self.target
            yr = math.radians(self.yaw)
            pr = math.radians(self.pitch)
            cp, sp = math.cos(pr), math.sin(pr)
            sy, cy = math.sin(yr), math.cos(yr)
            ex = tx + self.dist * cp * sy
            ey = ty + self.dist * sp
            ez = tz + self.dist * cp * cy
            look = [tx, ty, tz]
            eff_pitch = self.pitch

        fwd = tc.norm([look[0] - ex, look[1] - ey, look[2] - ez])
        right = tc.norm([ -fwd[2], 0.0, fwd[0] ])
        if math.hypot(*right) < 1e-4:
            right = [1.0, 0.0, 0.0]
        up = tc.cross(right, fwd)
        f_px = (max(100, self.height()) * 0.5) / math.tan(math.radians(self.fov * 0.5))
        return (ex, ey, ez), right, up, fwd, f_px, eff_pitch

    @staticmethod
    def _clip_poly_near(cam_pts, near):
        if len(cam_pts) < 3:
            return []
        out = []
        n = len(cam_pts)
        for i in range(n):
            a = cam_pts[i]
            b = cam_pts[(i + 1) % n]
            ia, ib = a[2] >= near, b[2] >= near
            if ia and ib:
                out.append(b)
            elif ia and not ib:
                t = (near - a[2]) / ((b[2] - a[2]) or -1e-6)
                out.append((a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1]), near))
            elif not ia and ib:
                t = (near - a[2]) / ((b[2] - a[2]) or 1e-6)
                out.append((a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1]), near))
                out.append(b)
        return out

    @staticmethod
    def _clip_seg_near(ca, cb, near):
        za, zb = ca[2], cb[2]
        if za < near and zb < near:
            return None
        if za < near:
            t = (near - za) / ((zb - za) or 1e-6)
            ca = (ca[0] + t * (cb[0] - ca[0]), ca[1] + t * (cb[1] - ca[1]), near)
        elif zb < near:
            t = (near - zb) / ((za - zb) or 1e-6)
            cb = (cb[0] + t * (ca[0] - cb[0]), cb[1] + t * (ca[1] - cb[1]), near)
        return ca, cb

    # ---- 绘制 --------------------------------------------------------------
    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        W, H = self.width(), self.height()

        eye, right, up, fwd, f_px, eff_pitch = self._camera_vectors()
        ex, ey, ez = eye
        W2, H2 = W * 0.5, H * 0.5
        near = self.NEAR

        def cam(pt):
            dx, dy, dz = pt[0] - ex, pt[1] - ey, pt[2] - ez
            return (
                dx * right[0] + dy * right[1] + dz * right[2],
                dx * up[0] + dy * up[1] + dz * up[2],
                dx * fwd[0] + dy * fwd[1] + dz * fwd[2],
            )

        def scr(c):
            return QPointF(W2 + c[0] * f_px / c[2], H2 - c[1] * f_px / c[2])

        def poly_scr(pts):
            cl = self._clip_poly_near([cam(q) for q in pts], near)
            if len(cl) < 3:
                return None, 0.0
            return QPolygonF([scr(c) for c in cl]), _quad_depth(cl)

        # 1. 天空与远山渐变背景
        horizon_y = max(-40.0, min(H + 40.0, H2 - f_px * math.tan(math.radians(eff_pitch))))
        sky_rect = QRectF(0, 0, W, max(0.0, horizon_y + 2))
        if sky_rect.height() > 1:
            sg = QLinearGradient(0, 0, 0, max(120.0, horizon_y))
            sg.setColorAt(0.0, QColor("#0f294a"))
            sg.setColorAt(0.55, QColor("#2563eb"))
            sg.setColorAt(1.0, QColor("#bfdbfe"))
            p.fillRect(sky_rect, sg)
        gnd_rect = QRectF(0, max(0.0, horizon_y), W, max(0.0, H - max(0.0, horizon_y)))
        if gnd_rect.height() > 1:
            gg = QLinearGradient(0, max(0.0, horizon_y), 0, H)
            gg.setColorAt(0.0, QColor("#1e462d"))
            gg.setColorAt(1.0, QColor("#14301f"))
            p.fillRect(gnd_rect, gg)

        sd = self.scene_data
        if not sd:
            p.setPen(QColor(226, 232, 240))
            p.drawText(self.rect(), Qt.AlignCenter, "打开或拖入黑羊赛道 .trk 文件，\n或在「赛道搭建」摆门后切换至此查看黑羊 3D 效果")
            return

        # 2. 体育场修剪草坪分格条纹 + 边界白线 + 10m 参考网格
        x0, x1, z0, z1 = sd["bounds"]
        pg, _ = poly_scr([[x0, 0.0, z0], [x1, 0.0, z0], [x1, 0.0, z1], [x0, 0.0, z1]])
        if pg:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor("#2a6a3f"))
            p.drawPolygon(pg)

        stripe = 10.0
        gx_start = math.floor(x0 / stripe) * stripe
        gx = gx_start
        idx_st = 0
        while gx < x1 - 0.1:
            nx = min(x1, gx + stripe)
            sx0 = max(x0, gx)
            if idx_st % 2 == 0 and nx - sx0 > 0.2:
                stp, _ = poly_scr([[sx0, 0.0, z0], [nx, 0.0, z0], [nx, 0.0, z1], [sx0, 0.0, z1]])
                if stp:
                    p.setBrush(QColor("#327748"))
                    p.drawPolygon(stp)
            gx += stripe
            idx_st += 1

        # 10m 细网格线
        p.setPen(QPen(QColor(255, 255, 255, 28), 1.0))
        gx = math.ceil(x0 / 10.0) * 10.0
        while gx <= x1:
            seg = self._clip_seg_near(cam([gx, 0.01, z0]), cam([gx, 0.01, z1]), near)
            if seg:
                p.drawLine(scr(seg[0]), scr(seg[1]))
            gx += 10.0
        gz = math.ceil(z0 / 10.0) * 10.0
        while gz <= z1:
            seg = self._clip_seg_near(cam([x0, 0.01, gz]), cam([x1, 0.01, gz]), near)
            if seg:
                p.drawLine(scr(seg[0]), scr(seg[1]))
            gz += 10.0
        # 白色体育场边界线
        if pg:
            p.setPen(QPen(QColor(255, 255, 255, 165), 2.0))
            p.setBrush(Qt.NoBrush)
            p.drawPolygon(pg)

        # 3. 棋盘格起飞垫
        for pad in sd["pads"]:
            pg_pad, _ = poly_scr(pad["corners"])
            if pg_pad:
                p.setPen(QPen(QColor("#f8fafc"), 1.6))
                p.setBrush(QColor("#1e293b"))
                p.drawPolygon(pg_pad)
                ax, az = pad["ax"], pad["az"]
                mx, mz = pad["mid"][0], pad["mid"][2]
                p.setPen(Qt.NoPen)
                p.setBrush(QColor("#e2e8f0"))
                step = 0.625
                for ix in (-2, -1, 0, 1):
                    for iz in (-2, -1, 0, 1):
                        if (ix + iz) % 2 == 0:
                            cell = [
                                [mx + (ix + dx) * step * ax[0] + (iz + dz) * step * az[0], 0.04,
                                 mz + (ix + dx) * step * ax[2] + (iz + dz) * step * az[2]]
                                for dx, dz in ((0, 0), (1, 0), (1, 1), (0, 1))
                            ]
                            cp_cell, _ = poly_scr(cell)
                            if cp_cell:
                                p.drawPolygon(cp_cell)

        # 4. 地面投影（高架桥阴影 + 门框阴影）
        if self.show_bridges:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(8, 22, 14, 72))
            for s in sd["br_segs"]:
                sp, _ = poly_scr([[v[0], 0.02, v[2]] for v in s["quad"]])
                if sp:
                    p.drawPolygon(sp)

        # 5. 收集所有 3D 图元按深度从远到近排序绘制
        draw_list = []

        # 5a) 二层白色高架桥段 + 支撑柱
        if self.show_bridges:
            for s in sd["br_segs"]:
                cm = cam(s["mid"])
                if cm[2] < near:
                    continue
                draw_list.append((cm[2], "bridge", s))

        # 5b) 立体障碍块（如墙体、平台）
        for blk in sd["blocks"]:
            cm = cam(blk["mid"])
            if cm[2] >= near:
                draw_list.append((cm[2], "block", blk))

        # 5c) PVC 管/杆
        for tb in sd["tubes"]:
            cm = cam(tb["mid"])
            if cm[2] >= near * 0.4:
                draw_list.append((cm[2], "tube", tb))

        # 5d) VelociDrone 检查门
        next_gate_idx = None
        passed_idx = set()
        if self.sim_s is not None and self.gate_s:
            for gidx, gs in self.gate_s:
                if gs <= self.sim_s + 0.35:
                    passed_idx.add(gidx)
                elif next_gate_idx is None:
                    next_gate_idx = gidx

        for gt in sd["gates"]:
            cm = cam(gt["mid"])
            if cm[2] >= near * 0.5:
                draw_list.append((cm[2], "gate", gt))

        # 按深度降序画（远 -> 近）
        draw_list.sort(key=lambda item: -item[0])

        badge_items = []
        for depth, kind, obj in draw_list:
            if kind == "bridge":
                # 桥墩
                p.setPen(QPen(QColor("#cbd5e1"), max(1.6, 0.24 * f_px / max(1.0, depth)), Qt.SolidLine, Qt.RoundCap))
                for bot, top in obj["pillars"]:
                    seg = self._clip_seg_near(cam(bot), cam(top), near)
                    if seg:
                        p.drawLine(scr(seg[0]), scr(seg[1]))
                q_pts = obj["quad"]
                qb_pts = [[v[0], max(0.0, v[1] - 0.30), v[2]] for v in q_pts]
                # 左右侧裙
                for i0, i1 in ((0, 3), (1, 2)):
                    side_p, _ = poly_scr([q_pts[i0], q_pts[i1], qb_pts[i1], qb_pts[i0]])
                    if side_p:
                        p.setPen(Qt.NoPen)
                        p.setBrush(QColor("#94a3b8"))
                        p.drawPolygon(side_p)
                # 桥顶白面 + 路缘边线
                deck_p, _ = poly_scr(q_pts)
                if deck_p:
                    p.setPen(Qt.NoPen)
                    p.setBrush(QColor("#f8fafc"))
                    p.drawPolygon(deck_p)
                    p.setPen(QPen(QColor("#64748b"), 1.6))
                    for a_i, b_i in ((0, 3), (1, 2)):
                        seg = self._clip_seg_near(cam(q_pts[a_i]), cam(q_pts[b_i]), near)
                        if seg:
                            p.drawLine(scr(seg[0]), scr(seg[1]))

            elif kind == "block":
                top_p, _ = poly_scr(obj["top"])
                for k in range(4):
                    kn = (k + 1) % 4
                    sp, _ = poly_scr([obj["top"][k], obj["top"][kn], obj["bot"][kn], obj["bot"][k]])
                    if sp:
                        p.setPen(QPen(QColor("#64748b"), 1.0))
                        p.setBrush(QColor("#cbd5e1"))
                        p.drawPolygon(sp)
                if top_p:
                    p.setPen(QPen(QColor("#94a3b8"), 1.2))
                    p.setBrush(obj["col"])
                    p.drawPolygon(top_p)

            elif kind == "tube":
                seg = self._clip_seg_near(cam(obj["a"]), cam(obj["b"]), near)
                if seg:
                    pa, pb = scr(seg[0]), scr(seg[1])
                    px_w = max(1.8, min(14.0, obj["thick"] * f_px / max(1.5, depth)))
                    p.setPen(QPen(QColor(15, 23, 42, 160), px_w + 1.6, Qt.SolidLine, Qt.RoundCap))
                    p.drawLine(pa, pb)
                    p.setPen(QPen(obj["col"], px_w, Qt.SolidLine, Qt.RoundCap))
                    p.drawLine(pa, pb)

            elif kind == "gate":
                gp, _ = poly_scr(obj["corners"])
                if not gp:
                    continue
                if obj["idx"] in passed_idx:
                    edge_col = QColor("#22c55e")
                    fill_col = QColor(34, 197, 94, 52)
                elif obj["idx"] == next_gate_idx:
                    edge_col = QColor("#06b6d4")
                    fill_col = QColor(6, 182, 212, 80)
                elif obj["start"]:
                    edge_col = QColor("#22c55e")
                    fill_col = QColor(34, 197, 94, 64)
                else:
                    edge_col = QColor("#f97316")
                    fill_col = QColor(249, 115, 22, 42)
                bw = max(2.2, min(8.0, 0.22 * f_px / max(2.0, depth)))
                p.setBrush(fill_col)
                p.setPen(QPen(edge_col, bw, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                p.drawPolygon(gp)
                if self.show_nums and obj["no"] > 0 and depth > 1.5:
                    top_pt = [
                        (obj["corners"][2][k] + obj["corners"][3][k]) * 0.5 + (0.45 if k == 1 else 0.0)
                        for k in range(3)
                    ]
                    ct = cam(top_pt)
                    if ct[2] >= near:
                        badge_items.append((scr(ct), obj["no"], edge_col))

        # 6. 飞行路线 + 方向箭头
        pts = sd["path"]
        if self.show_path and len(pts) >= 2:
            step = max(1, len(pts) // 260)
            for j in range(step, len(pts), step):
                a = pts[j - step]
                b = pts[j]
                if math.dist(a, b) < 8.0:
                    seg = self._clip_seg_near(cam(a), cam(b), near)
                    if seg:
                        p.setPen(QPen(QColor(244, 63, 94, 215), 2.4, Qt.SolidLine, Qt.RoundCap))
                        p.drawLine(scr(seg[0]), scr(seg[1]))
            # 沿线每隔 ~22m 画一个小箭头指示飞行方向
            nxt_s = 8.0
            for j in range(1, len(pts)):
                if self.arc[j] >= nxt_s:
                    nxt_s += 22.0
                    seg = self._clip_seg_near(cam(pts[j - 1]), cam(pts[j]), near)
                    if seg:
                        p0, p1 = scr(seg[0]), scr(seg[1])
                        vx, vy = p1.x() - p0.x(), p1.y() - p0.y()
                        vn = math.hypot(vx, vy)
                        if vn > 1.0:
                            vx, vy = vx / vn, vy / vn
                            tip = p1
                            al = QPointF(tip.x() - vx * 8 - vy * 5, tip.y() - vy * 8 + vx * 5)
                            ar = QPointF(tip.x() - vx * 8 + vy * 5, tip.y() - vy * 8 - vx * 5)
                            p.setPen(QPen(QColor("#fef08a"), 2.2, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                            p.drawPolyline(QPolygonF([al, tip, ar]))

        # 7. 试飞 3D 四旋翼飞机
        if self.sim_s is not None and len(pts) >= 2:
            pos, head = self._drone()
            cd = cam(pos)
            if cd[2] >= near:
                p_drone = scr(cd)
                sz = max(7.0, min(26.0, 1.3 * f_px / max(1.5, cd[2])))
                # 地面影子
                cs_sh = cam([pos[0], 0.03, pos[2]])
                if cs_sh[2] >= near:
                    p.setPen(Qt.NoPen)
                    p.setBrush(QColor(0, 0, 0, 110))
                    p.drawEllipse(scr(cs_sh), sz * 0.75, sz * 0.45)
                # 四轴机臂与桨盘
                p.setPen(QPen(QColor("#0f172a"), max(2.5, sz * 0.22), Qt.SolidLine, Qt.RoundCap))
                for dx, dy in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
                    arm = QPointF(p_drone.x() + dx * sz * 0.72, p_drone.y() + dy * sz * 0.45)
                    p.drawLine(p_drone, arm)
                    p.setBrush(QColor(56, 189, 248, 120))
                    p.setPen(QPen(QColor("#e0f2fe"), 1.3))
                    p.drawEllipse(arm, sz * 0.42, sz * 0.28)
                p.setBrush(QColor("#ef4444"))
                p.setPen(QPen(QColor("white"), 1.5))
                p.drawEllipse(p_drone, sz * 0.28, sz * 0.28)

        # 8. 浮空检查门编号徽章
        if badge_items:
            bf = QFont()
            bf.setPixelSize(11)
            bf.setBold(True)
            p.setFont(bf)
            for pt_s, no, col in badge_items:
                pill = QRectF(pt_s.x() - 12, pt_s.y() - 18, 24, 17)
                p.setPen(QPen(col, 1.3))
                p.setBrush(QColor(15, 23, 42, 210))
                p.drawRoundedRect(pill, 8, 8)
                p.setPen(QColor("white"))
                p.drawText(pill, Qt.AlignCenter, str(no))

        # 9. 左上角半透明信息角标 & 底部操作提示
        p.setFont(QFont())
        lap_str = f"一圈 {self.arc[-1]:.0f} m" if len(self.arc) >= 2 else "未连线"
        hud_text = f"  {sd['name']}  |  {sd['scene_name']}  |  {len(sd['gates'])} 检查门  |  {lap_str}  "
        fm = p.fontMetrics()
        hw = min(W - 24, fm.horizontalAdvance(hud_text) + 18)
        hud = QRectF(12, 12, hw, 28)
        p.setPen(QPen(QColor(255, 255, 255, 48), 1))
        p.setBrush(QColor(15, 23, 42, 185))
        p.drawRoundedRect(hud, 14, 14)
        p.setPen(QColor("#f8fafc"))
        p.drawText(hud, Qt.AlignCenter, hud_text)

        bar = QRectF(0, H - 22, W, 22)
        p.fillRect(bar, QColor(15, 23, 42, 185))
        p.setPen(QColor("#cbd5e1"))
        p.drawText(10, H - 6, "左键拖=旋转 3D 视角   右键/中键拖=平移场地   滚轮=缩放   支持直接拖入 .trk 文件预览")


class VelociPreviewWidget(QWidget):
    """带文件栏、预设目录快速切换、相机角度、试飞与 FPV 跟飞控制的黑羊 3D 地图预览组件"""
    DEFAULT_DIRECTORIES = [
        USER_DIR / "赛道",
        APP_DIR.parent.parent / "黑羊赛道",
        Path.home() / "Documents" / "Velocidrone" / "tracks",
    ]

    def __init__(self, folder=None, parent=None, embedded=False):
        super().__init__(parent)
        self.folder = Path(folder) if folder else None
        self.embedded = embedded
        self._live_track = None
        self._updating_box = False
        self.setAcceptDrops(True)

        open_btn = QPushButton("📂 打开 .trk…" if embedded else "📂 打开黑羊 .trk…")
        open_btn.setToolTip("打开任意黑羊 VelociDrone .trk 文件，或「赛道搭建」的 .赛道.json 地图")
        open_btn.clicked.connect(self.choose_file)

        self.trk_box = QComboBox()
        self.trk_box.setMinimumWidth(90 if embedded else 160)
        self.trk_box.setMaximumWidth(260)
        self.trk_box.currentIndexChanged.connect(self._trk_chosen)

        row1 = QHBoxLayout()
        row1.setSpacing(5)
        row1.addWidget(open_btn)
        row1.addWidget(self.trk_box, 1)

        self.canvas = VelociCanvas(self)
        for vname in VelociCanvas.VIEWS:
            vb = QPushButton(vname)
            vb.clicked.connect(lambda _c=False, n=vname: self.canvas.set_view(n))
            row1.addWidget(vb)
        row1.addStretch()

        self.chk_path = QCheckBox("路线")
        self.chk_path.setChecked(True)
        self.chk_path.toggled.connect(self._toggle_path)
        self.chk_nums = QCheckBox("门号")
        self.chk_nums.setChecked(True)
        self.chk_nums.toggled.connect(self._toggle_nums)
        self.chk_bridges = QCheckBox("高架桥")
        self.chk_bridges.setChecked(True)
        self.chk_bridges.toggled.connect(self._toggle_bridges)

        row2 = QHBoxLayout()
        row2.setSpacing(5)
        self.play_btn = QPushButton("▶ 试飞" if embedded else "▶ 试飞一圈")
        self.play_btn.clicked.connect(self.toggle_sim)
        again_btn = QPushButton("从头")
        again_btn.clicked.connect(self.restart_sim)
        self.speed_box = QComboBox()
        for v in (8, 12, 18, 25):
            self.speed_box.addItem(f"{v} m/s" if embedded else f"{v} 米/秒", v)
        self.speed_box.setCurrentIndex(1)
        self.speed_box.currentIndexChanged.connect(self._speed_changed)
        self.follow_chk = QCheckBox("🎥 跟飞" if embedded else "🎥 跟飞视角 (FPV)")
        self.follow_chk.toggled.connect(self.canvas.set_follow)
        self.prog_label = QLabel("")
        self.prog_label.setStyleSheet("color: #475569; font-weight: 500;")
        self.canvas.progress.connect(self.prog_label.setText)
        self.canvas.sim_state.connect(self._sync_play_btn)

        for w in (self.play_btn, again_btn, self.speed_box, self.follow_chk,
                  self.chk_path, self.chk_nums, self.chk_bridges):
            row2.addWidget(w)
        if not embedded:
            row2.addWidget(self.prog_label)
        row2.addStretch()

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0 if embedded else 6, 4 if embedded else 6, 0 if embedded else 6, 0)
        lay.setSpacing(6)
        lay.addWidget(self.canvas, 1)
        lay.addLayout(row1)
        lay.addLayout(row2)

        self.refresh_trk_list()

    def refresh_trk_list(self, select_path=None):
        self._updating_box = True
        self.trk_box.blockSignals(True)
        self.trk_box.clear()
        if self._live_track is not None:
            self.trk_box.addItem("（当前搭建的赛道）", "__live__")

        dirs = []
        if self.folder:
            dirs.append(self.folder)
        dirs.extend(self.DEFAULT_DIRECTORIES)
        seen = set()
        found = []
        for d in dirs:
            if not d or not d.is_dir():
                continue
            for p in sorted(d.glob("*.trk")):
                rp = str(p.resolve()).lower()
                if rp not in seen:
                    seen.add(rp)
                    found.append(p)
        for p in found:
            self.trk_box.addItem(p.name, str(p))
        if not self.trk_box.count():
            self.trk_box.addItem("（选择 .trk 地图…）", None)
        if select_path:
            idx = self.trk_box.findData(str(select_path))
            if idx >= 0:
                self.trk_box.setCurrentIndex(idx)
        self.trk_box.blockSignals(False)
        self._updating_box = False

    def _trk_chosen(self, _i):
        if self._updating_box:
            return
        data = self.trk_box.currentData()
        if data == "__live__" and self._live_track is not None:
            self.canvas.set_track(self._live_track)
        elif data and Path(data).is_file():
            self.open_file(data)

    def choose_file(self):
        start_dir = next((str(d) for d in [self.folder, *self.DEFAULT_DIRECTORIES] if d and d.is_dir()), "")
        f, _ = QFileDialog.getOpenFileName(
            self,
            "打开黑羊赛道 / 搭建地图",
            start_dir,
            f"所有支持赛道 (*.trk *{tg.SUFFIX} *.exe *.eprt *.easm);;黑羊地图 (*.trk);;搭建地图 (*{tg.SUFFIX});;所有文件 (*)",
        )
        if f:
            self.open_file(f)

    def open_file(self, path):
        p = Path(path)
        if not p.is_file():
            return
        try:
            low = p.name.lower()
            if low.endswith(".trk"):
                tr = tc.from_trk(p)
            elif low.endswith(tg.SUFFIX) or low.endswith(".json"):
                model, types, line, d = tg.load(p)
                meta = d.get("meta", {})
                tr = tc.build(
                    model,
                    types,
                    S=meta.get("S", 2.5),
                    T=meta.get("T", 0.2),
                    name=d.get("name") or p.stem,
                    path=line,
                )
                if meta.get("bridges"):
                    tr["bridges"] = meta["bridges"]
            else:
                model = tc.load(p)
                types = tc.default_types(model)
                tr = tc.build(model, types, name=p.stem)
        except Exception as ex:  # noqa: BLE001 - 文件格式各种各样，统一提示
            QMessageBox.warning(self, "打不开地图", f"这个地图文件读不出来：\n{ex}")
            return
        self._live_track = None
        self.canvas.set_track(tr)
        self._sync_play_btn(False)
        self.refresh_trk_list(select_path=str(p))

    def set_track(self, tr, live=True):
        if live:
            self._live_track = tr
            self.refresh_trk_list()
            self._updating_box = True
            self.trk_box.blockSignals(True)
            self.trk_box.setCurrentIndex(0)
            self.trk_box.blockSignals(False)
            self._updating_box = False
        self.canvas.set_track(tr)
        self._sync_play_btn(False)

    def set_editor_preview(self, items, bridges=None, field=(80, 60), S=2.5, T=0.2, name=""):
        self._live_track = None
        self.canvas.set_scene_items(items, bridges=bridges, field=field, S=S, T=T, name=name)
        self._sync_play_btn(False)

    def toggle_sim(self):
        if self.canvas.timer.isActive():
            self.canvas.pause_sim()
        else:
            self.canvas.start_sim()

    def restart_sim(self):
        self.canvas.stop_sim()
        self.canvas.start_sim()

    def pause_sim(self):
        self.canvas.pause_sim()

    def _speed_changed(self, _i):
        self.canvas.speed = float(self.speed_box.currentData() or 12)

    def _sync_play_btn(self, running):
        if running:
            self.play_btn.setText("⏸ 暂停")
        elif self.canvas.sim_s and len(self.canvas.arc) >= 2 and self.canvas.sim_s < self.canvas.arc[-1]:
            self.play_btn.setText("▶ 继续")
        else:
            self.play_btn.setText("▶ 试飞" if self.embedded else "▶ 试飞一圈")

    def _toggle_path(self, on):
        self.canvas.show_path = bool(on)
        self.canvas.update()

    def _toggle_nums(self, on):
        self.canvas.show_nums = bool(on)
        self.canvas.update()

    def _toggle_bridges(self, on):
        self.canvas.show_bridges = bool(on)
        self.canvas.update()

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        urls = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
        if urls:
            self.open_file(urls[0])
