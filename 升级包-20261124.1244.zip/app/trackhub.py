"""「黑羊导出 / 模拟飞行 / 黑羊地图预览」合成一个窗口：三页，打开一张赛道三页都换成它。"""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog, QTabWidget, QVBoxLayout


class TrackHub(QDialog):
    def __init__(self, folder=None, parent=None, preset=None, start="fly"):
        super().__init__(parent)
        from app.track_tool import TrackDialog
        from app.vdexport import ExportDialog
        from app.vdpreview import VelociPreviewWidget

        self.setWindowTitle("黑羊预览 / 模拟飞行 / 导出")
        self.setWindowFlags(self.windowFlags() | Qt.WindowMaximizeButtonHint | Qt.WindowMinimizeButtonHint)
        self.resize(1400, 860)
        self.fly = TrackDialog(folder, self)
        self.vd = ExportDialog(folder, self, preset=preset)
        self.preview = VelociPreviewWidget(folder, self)
        for d in (self.fly, self.vd):             # 两个原来的窗口嵌进来当页面
            d.setWindowFlags(Qt.Widget)
            d.reject = lambda: None               # 按 Esc 不要把里面那页关掉
        self.tabs = QTabWidget()
        self.tabs.addTab(self.fly, "▶ 模拟飞行")
        self.tabs.addTab(self.vd, "⬆ 导出黑羊地图")
        self.tabs.addTab(self.preview, "🐑 黑羊地图预览")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.addWidget(self.tabs)
        self._syncing = False
        widgets = (self.fly, self.vd, self.preview)
        for w in widgets:
            orig = w.open_file

            def opened(path, _orig=orig, _src=w):
                _orig(path)
                if not self._syncing:
                    self._syncing = True
                    try:
                        for other in widgets:
                            if other is not _src:
                                other.open_file(path)
                    finally:
                        self._syncing = False

            w.open_file = opened

        self.fly.export_btn.setText("去导出黑羊地图 →")
        self.fly.export_btn.setToolTip("换到「导出黑羊地图」页：选门框颜色、杆子、起飞台、门间距比例再导出")
        try:
            self.fly.export_btn.clicked.disconnect()
        except (RuntimeError, TypeError):
            pass
        self.fly.export_btn.clicked.connect(lambda: self.tabs.setCurrentWidget(self.vd))
        self.tabs.currentChanged.connect(self._tab_changed)
        self.tabs.setCurrentWidget(self.vd if start == "vd" else (self.preview if start == "preview" else self.fly))

    def _tab_changed(self, _i):
        if hasattr(self.fly.view, "pause_sim"):
            self.fly.view.pause_sim()
        self.preview.pause_sim()

    def open_file(self, path):
        self.fly.open_file(path)

    def closeEvent(self, e):
        for d in (self.fly, self.vd):
            d.close()
        self.preview.pause_sim()
        super().closeEvent(e)
