"""整体外观：现代科技感浅色专业主题（清爽冷灰底、纯白浮层卡片、电光钴蓝主色、精致圆角与自定义勾选框）。"""
import sys
import tempfile
from pathlib import Path

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPalette, QPen, QPixmap

BLUE = "#2563eb"
BLUE_HOVER = "#1d4ed8"
GREEN = "#10b981"
RED = "#ef4444"
ORANGE = "#f59e0b"
PURPLE = "#7c3aed"
TEXT = "#0f172a"
SUB = "#64748b"
LINE = "#dbe2ea"
BG = "#eef2f7"
SURFACE = "#ffffff"

QSS = f"""
QMainWindow, QDialog {{ background: {BG}; }}
QWidget {{ color: {TEXT}; }}
QToolTip {{
    background: #0f172a; color: #f8fafc; border: 1px solid #334155;
    border-radius: 8px; padding: 6px 10px;
}}

QPushButton, QToolButton {{
    background: {SURFACE}; color: {TEXT}; border: 1px solid {LINE};
    border-radius: 8px; padding: 4px 10px; min-height: 22px; font-weight: 500;
}}
QToolButton {{ padding: 4px 8px; min-height: 20px; }}
QPushButton:hover, QToolButton:hover {{
    background: #f8fafc; border-color: #94a3b8;
}}
QPushButton:pressed, QToolButton:pressed {{
    background: #e2e8f0; border-color: #94a3b8;
}}
QPushButton:checked, QToolButton:checked {{
    background: {BLUE}; color: white; border-color: {BLUE}; font-weight: 600;
}}
QPushButton:checked:hover, QToolButton:checked:hover {{
    background: {BLUE_HOVER}; border-color: {BLUE_HOVER};
}}
QPushButton:default {{
    background: {BLUE}; color: white; border-color: {BLUE}; font-weight: 600;
}}
QPushButton:default:hover {{ background: {BLUE_HOVER}; border-color: {BLUE_HOVER}; }}
QPushButton:disabled, QToolButton:disabled {{
    color: #94a3b8; background: #f1f5f9; border-color: #e2e8f0;
}}
QPushButton::menu-indicator {{ subcontrol-origin: padding; subcontrol-position: right center; right: 6px; }}

QCheckBox {{ spacing: 6px; color: {TEXT}; }}
QCheckBox::indicator {{
    width: 16px; height: 16px; border-radius: 5px;
    border: 1.5px solid #cbd5e1; background: white;
}}
QCheckBox::indicator:hover {{ border-color: {BLUE}; }}
QCheckBox::indicator:checked {{
    border: 1.5px solid {BLUE}; background: {BLUE}; image: url(@CHECK_ON@);
}}
QCheckBox::indicator:disabled {{ border-color: #e2e8f0; background: #f1f5f9; }}

QComboBox, QLineEdit, QSpinBox, QDoubleSpinBox, QTimeEdit, QDateEdit, QPlainTextEdit, QTextEdit {{
    background: {SURFACE}; border: 1px solid {LINE}; border-radius: 8px; padding: 4px 9px;
    selection-background-color: {BLUE}; selection-color: white;
}}
QComboBox, QLineEdit, QSpinBox, QDoubleSpinBox, QTimeEdit, QDateEdit {{ min-height: 22px; }}
QComboBox:hover, QLineEdit:hover, QSpinBox:hover, QDoubleSpinBox:hover, QTimeEdit:hover {{
    border-color: #94a3b8;
}}
QComboBox:focus, QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QTimeEdit:focus,
QPlainTextEdit:focus, QTextEdit:focus {{
    border: 1.5px solid {BLUE}; background: #ffffff;
}}
QComboBox:disabled, QLineEdit:disabled, QSpinBox:disabled, QDoubleSpinBox:disabled {{
    color: #94a3b8; background: #f1f5f9; border-color: #e2e8f0;
}}
QComboBox::drop-down {{ border: none; width: 24px; subcontrol-origin: padding; subcontrol-position: center right; }}
QComboBox::down-arrow {{ image: url(@ARROW_DOWN@); width: 10px; height: 10px; }}
QComboBox::down-arrow:disabled {{ image: url(@ARROW_DOWN_OFF@); }}
QAbstractSpinBox {{ padding: 4px 22px 4px 9px; }}
QSpinBox::up-button, QDoubleSpinBox::up-button, QTimeEdit::up-button, QDateEdit::up-button {{
    subcontrol-origin: border; subcontrol-position: top right; width: 18px; border: none; margin: 2px 2px 0 0; }}
QSpinBox::down-button, QDoubleSpinBox::down-button, QTimeEdit::down-button, QDateEdit::down-button {{
    subcontrol-origin: border; subcontrol-position: bottom right; width: 18px; border: none; margin: 0 2px 2px 0; }}
QSpinBox::up-arrow, QDoubleSpinBox::up-arrow, QTimeEdit::up-arrow, QDateEdit::up-arrow {{ image: url(@ARROW_UP@); width: 8px; height: 8px; }}
QSpinBox::down-arrow, QDoubleSpinBox::down-arrow, QTimeEdit::down-arrow, QDateEdit::down-arrow {{ image: url(@ARROW_DOWN@); width: 8px; height: 8px; }}
QComboBox QAbstractItemView {{
    background: white; border: 1px solid #cbd5e1; border-radius: 10px; padding: 4px; outline: none;
    selection-background-color: #eff6ff; selection-color: {BLUE};
}}

QTabWidget::pane {{
    border: 1px solid #e2e8f0; border-radius: 12px; background: white; top: -1px;
}}
QTabBar::tab {{
    background: #e2e8f0; color: {SUB}; padding: 6px 12px; margin: 0 4px 5px 0;
    border-radius: 8px; min-width: 40px; font-weight: 500;
}}
QTabBar::tab:selected {{
    background: white; color: {BLUE}; font-weight: 700; border: 1px solid #cbd5e1;
}}
QTabBar::tab:hover:!selected {{ background: #d5dde7; color: {TEXT}; }}

QTreeView, QTreeWidget, QListView, QListWidget, QTableView, QTableWidget {{
    background: white; border: 1px solid #e2e8f0; border-radius: 12px; padding: 4px; outline: none;
    alternate-background-color: #f8fafc; selection-background-color: #eff6ff; selection-color: {BLUE};
}}
QTreeView::item, QListView::item {{ padding: 4px 6px; border-radius: 6px; }}
QTreeView::item:hover:!selected, QListView::item:hover:!selected {{ background: #f1f5f9; }}
QHeaderView::section {{
    background: #f8fafc; color: {SUB}; font-weight: 600;
    border: none; border-bottom: 1px solid #e2e8f0; padding: 6px 8px;
}}
QTableCornerButton::section {{ background: #f8fafc; border: none; }}

QGroupBox {{
    background: {SURFACE}; border: 1px solid #e2e8f0; border-radius: 14px;
    margin-top: 14px; padding: 14px 10px 10px 10px;
}}
QGroupBox::title {{
    subcontrol-origin: margin; left: 14px; padding: 0 6px;
    color: #334155; font-weight: 700; background: transparent;
}}

QScrollArea {{ border: none; background: transparent; }}
QScrollBar:vertical {{ background: transparent; width: 8px; margin: 2px; }}
QScrollBar:horizontal {{ background: transparent; height: 8px; margin: 2px; }}
QScrollBar::handle:vertical, QScrollBar::handle:horizontal {{ background: #cbd5e1; border-radius: 4px; }}
QScrollBar::handle:vertical {{ min-height: 30px; }}
QScrollBar::handle:horizontal {{ min-width: 30px; }}
QScrollBar::handle:hover {{ background: #94a3b8; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}

QSlider::groove:horizontal {{ height: 5px; background: #cbd5e1; border-radius: 3px; }}
QSlider::sub-page:horizontal {{ background: {BLUE}; border-radius: 3px; }}
QSlider::handle:horizontal {{
    background: white; border: 2px solid {BLUE}; width: 16px; height: 16px; margin: -7px 0; border-radius: 9px;
}}
QSlider::handle:horizontal:hover {{ background: #eff6ff; }}

QMenu {{ background: white; border: 1px solid #cbd5e1; border-radius: 12px; padding: 6px; }}
QMenu::item {{ padding: 7px 24px 7px 14px; border-radius: 7px; color: {TEXT}; }}
QMenu::item:selected {{ background: #eff6ff; color: {BLUE}; font-weight: 600; }}
QMenu::separator {{ height: 1px; background: #e2e8f0; margin: 5px 8px; }}

QStatusBar {{ background: {SURFACE}; color: {SUB}; border-top: 1px solid #e2e8f0; padding: 2px 8px; }}
QStatusBar::item {{ border: none; }}
QSplitter::handle {{ background: transparent; width: 6px; height: 6px; }}
QProgressBar {{ background: #e2e8f0; border: none; border-radius: 5px; text-align: center; height: 8px; }}
QProgressBar::chunk {{ background: {BLUE}; border-radius: 5px; }}
"""


def _icons():
    """下拉箭头 + 勾选框对勾（存到临时目录给 QSS 引用）"""
    d = Path(tempfile.gettempdir()) / "drone_teach_ui_v2"
    d.mkdir(exist_ok=True)
    out = {}
    for name, up, col in (("ARROW_DOWN", False, SUB), ("ARROW_DOWN_OFF", False, "#cbd5e1"), ("ARROW_UP", True, SUB)):
        pm = QPixmap(20, 20)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(QPen(QColor(col), 2.4, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        pts = [QPointF(4, 13), QPointF(10, 7), QPointF(16, 13)] if up else [QPointF(4, 7), QPointF(10, 13), QPointF(16, 7)]
        p.drawPolyline(pts)
        p.end()
        f = d / f"{name.lower()}.png"
        pm.save(str(f))
        out[name] = f.as_posix()
    # 白色勾选对勾
    pm = QPixmap(16, 16)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    p.setPen(QPen(QColor("white"), 2.2, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
    p.drawPolyline([QPointF(3.5, 8.2), QPointF(6.8, 11.5), QPointF(12.6, 4.6)])
    p.end()
    fc = d / "check_on.png"
    pm.save(str(fc))
    out["CHECK_ON"] = fc.as_posix()
    return out


def apply(app):
    app.setStyle("Fusion")
    pal = QPalette()
    for role, col in ((QPalette.Window, BG), (QPalette.WindowText, TEXT), (QPalette.Base, SURFACE),
                      (QPalette.AlternateBase, "#f8fafc"), (QPalette.Text, TEXT), (QPalette.Button, SURFACE),
                      (QPalette.ButtonText, TEXT), (QPalette.Highlight, BLUE), (QPalette.HighlightedText, "#ffffff"),
                      (QPalette.ToolTipBase, "#0f172a"), (QPalette.ToolTipText, "#f8fafc"),
                      (QPalette.PlaceholderText, "#94a3b8"), (QPalette.Link, BLUE)):
        pal.setColor(role, QColor(col))
    pal.setColor(QPalette.Disabled, QPalette.Text, QColor("#94a3b8"))
    pal.setColor(QPalette.Disabled, QPalette.ButtonText, QColor("#94a3b8"))
    pal.setColor(QPalette.Disabled, QPalette.WindowText, QColor("#94a3b8"))
    app.setPalette(pal)
    f = QFont("Microsoft YaHei UI" if sys.platform == "win32" else app.font().family())
    f.setPointSizeF(9.5 if sys.platform == "win32" else app.font().pointSizeF())
    f.setHintingPreference(QFont.PreferNoHinting)
    app.setFont(f)
    qss = QSS
    try:
        for k, v in _icons().items():
            qss = qss.replace(f"@{k}@", v)
    except OSError:
        pass
    app.setStyleSheet(qss)
