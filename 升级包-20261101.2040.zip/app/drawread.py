"""看图纸：把组委会图纸上的粉色指引线认出来，排成一条有先后的线（只用 Qt，不用别的库）。

做法：
1. 挑出"粉色"的点（红多、绿少、蓝居中），按 3 像素一格记下来；
2. 只留最大的那一片附近的（去掉指北针、图例里那根小箭头）；
3. 从起点（离计时门最近的线头）开始往前"追"：每一步看前方一圈，挑最顺着走的那个格子
   —— 线自己交叉的地方就直着穿过去；线被门的黑框挡住断了一小截，就往前多看一点接上。
"""
import math

from PySide6.QtCore import Qt
from PySide6.QtGui import QImage

WORK_W = 1600          # 认图时把图缩到这么宽
JUMP = 45              # 线断了（被门框挡住）最多往前接多少像素
LOOK = 10              # 岔口往每条路看多远比方向


LINE_PPM = 9.0         # 认线时每米几像素（线宽 2~3 像素，太细太粗都不好追）


def pink_pixels(img: QImage, px_per_m=None):
    """返回 (粉色像素集合, 缩放比例 原图像素/工作像素)"""
    ww = int(img.width() * LINE_PPM / px_per_m) if px_per_m else WORK_W
    work = img.scaledToWidth(ww) if img.width() > ww else img   # 不平滑：线的颜色不被冲淡
    work = work.convertToFormat(QImage.Format_RGB888)
    w, h, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())
    px = set()
    for y in range(h):
        row = data[y*bpl:y*bpl + w*3]
        for x in range(0, w*3, 3):
            r = row[x]
            if r > 150:
                g, b = row[x+1], row[x+2]
                if g < 100 and 60 < b < 210 and r - g > 90:
                    px.add((x // 3, y))
    return px, img.width() / w


N8 = ((0, -1), (1, -1), (1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0), (-1, -1))


def thin(px):
    """把粗线削成一个像素宽（Zhang-Suen）"""
    px = set(px)
    changed = True
    while changed:
        changed = False
        for step in (0, 1):
            kill = []
            for (x, y) in px:
                nb = [(x+dx, y+dy) in px for dx, dy in N8]
                b = sum(nb)
                if b < 2 or b > 6:
                    continue
                a = sum(1 for k in range(8) if not nb[k] and nb[(k+1) % 8])
                if a != 1:
                    continue
                P2, P4, P6, P8 = nb[0], nb[2], nb[4], nb[6]
                if step == 0 and (P2 and P4 and P6 or P4 and P6 and P8):
                    continue
                if step == 1 and (P2 and P4 and P8 or P2 and P6 and P8):
                    continue
                kill.append((x, y))
            if kill:
                changed = True
                px.difference_update(kill)
    return px


def _groups(px, link=3):
    left = set(px)
    out = []
    while left:
        seed = left.pop()
        grp, todo = [seed], [seed]
        while todo:
            cx, cy = todo.pop()
            for dx in range(-link, link+1):
                for dy in range(-link, link+1):
                    c = (cx+dx, cy+dy)
                    if c in left:
                        left.remove(c)
                        grp.append(c)
                        todo.append(c)
        out.append(grp)
    return sorted(out, key=len, reverse=True)


def _nbrs(sk, p):
    return [(p[0]+dx, p[1]+dy) for dx, dy in N8 if (p[0]+dx, p[1]+dy) in sk]


def _unit(dx, dy):
    n = math.hypot(dx, dy) or 1.0
    return dx/n, dy/n


def _ang(h, d):
    return abs(math.atan2(h[0]*d[1] - h[1]*d[0], h[0]*d[0] + h[1]*d[1]))


def _walk(sk, prev, cur, n, avoid=()):
    """从 prev->cur 顺着骨架往前走 n 步（岔口挑最直的），返回走到的点"""
    path = [prev, cur]
    for _ in range(n):
        h = _unit(path[-1][0]-path[max(0, len(path)-4)][0], path[-1][1]-path[max(0, len(path)-4)][1])
        c = [q for q in _nbrs(sk, path[-1]) if q not in path[-4:] and q not in avoid]
        if not c:
            break
        path.append(min(c, key=lambda q: _ang(h, (q[0]-path[-1][0], q[1]-path[-1][1]))))
    return path


def _loops_back(sk, cur, q, used):
    """从岔口 cur 往 q 那条路走下去（断了也接上），走一小圈又回到 cur 附近 = 图纸上的小圈"""
    w = trace(sk, [cur, q], used=set(used) | {cur}, limit=260, probe=True)
    return any(math.dist(z, cur) < 30 for z in w[60:])


def trace(sk, start, used=None, limit=200000, probe=False):
    """从线头顺着骨架追到底。start 可以是一个点，也可以是已经走的几个点"""
    path = list(start) if isinstance(start, list) else [start]
    used = set(path) if used is None else used | set(path)
    while len(path) < limit:
        cur = path[-1]
        back = path[max(0, len(path)-8)]
        h = _unit(cur[0]-back[0], cur[1]-back[1]) if len(path) > 1 else None
        cand = [q for q in _nbrs(sk, cur) if q not in path[-6:]]
        nxt = None
        if cand:
            if len(cand) == 1 or h is None:
                fresh = [q for q in cand if q not in used]
                nxt = (fresh or cand)[0]
            else:                                # 岔口：每条路往前看一段，挑最直、没走过的；没走过的小圈先绕
                best = None
                for q in cand:
                    w = _walk(sk, cur, q, LOOK, avoid=set(path[-6:]))
                    d = _unit(w[-1][0]-cur[0], w[-1][1]-cur[1])
                    old = sum(1 for z in w[1:] if z in used) / len(w)
                    score = _ang(h, d) + 1.5*old + (0.6 if len(w) < LOOK//2 else 0)   # 短叉（箭头）扣分
                    if not probe and old == 0 and len(w) >= LOOK//2 and _loops_back(sk, cur, q, used):
                        score -= 3
                    if best is None or score < best[0]:
                        best = (score, q)
                nxt = best[1]
            if nxt in used and h is not None and _ang(h, _unit(nxt[0]-cur[0], nxt[1]-cur[1])) > math.radians(100):
                nxt = None                       # 掉头了：不走
        if nxt is None:                          # 线断了：往前找最近、方向对得上的线
            if h is None:
                break
            best = None
            for q in sk:
                dx, dy = q[0]-cur[0], q[1]-cur[1]
                if abs(dx) > JUMP or abs(dy) > JUMP or q in used:
                    continue
                d = math.hypot(dx, dy)
                if d < 2 or d > JUMP:
                    continue
                a = _ang(h, (dx, dy))
                if a > math.radians(35) and not (d < 22 and a < math.radians(65)):
                    continue
                score = d * (1 + 2*a)
                if best is None or score < best[0]:
                    best = (score, q)
            if best is None:
                break
            nxt = best[1]
        path.append(nxt)
        used.add(nxt)
    return path


def read_line(img: QImage, start_hint=None, px_per_m=None):
    """认粉色指引线。start_hint = 原图像素坐标（计时门在图上的位置），从离它最近的线头开始。
    返回 [(x, y) 原图像素]，没认出来返回 []"""
    px, k = pink_pixels(img, px_per_m)
    if len(px) < 100:
        return []
    sk = thin(px)
    groups = _groups(sk)
    keep = set(groups[0])                        # 从最大那截开始，离得近（门框挡断的）一截截接上；指北针、图例离得远不要
    near = {(x//25, y//25) for x, y in keep}
    rest = [g for g in groups[1:] if len(g) >= 4]
    grown = True
    while grown:
        grown = False
        for g in list(rest):
            if any((x//25+dx, y//25+dy) in near for x, y in g for dx in (-1, 0, 1) for dy in (-1, 0, 1)):
                keep.update(g)
                near.update((x//25, y//25) for x, y in g)
                rest.remove(g)
                grown = True
    def is_end(p):
        nb = _nbrs(keep, p)
        return len(nb) == 1 or (len(nb) == 2 and max(abs(nb[0][0]-nb[1][0]), abs(nb[0][1]-nb[1][1])) == 1)
    def long_enough(p, n=30):                    # 虚线（去降落点那段）的小短截不算线头
        seen, todo = {p}, [p]
        while todo and len(seen) < n:
            for q in _nbrs(keep, todo.pop()):
                if q not in seen:
                    seen.add(q)
                    todo.append(q)
        return len(seen) >= n
    ends = [p for p in keep if is_end(p) and long_enough(p)] or list(keep)
    if start_hint is not None:
        sx, sy = start_hint[0]/k, start_hint[1]/k
        start = min(ends, key=lambda c: math.hypot(c[0]-sx, c[1]-sy))
    else:
        start = max(ends, key=lambda c: c[1])    # 没有提示就从最下面那个线头开始
    path = trace(keep, start)
    return [((x+0.5)*k, (y+0.5)*k) for x, y in path[::3]]


def find_field(img: QImage):
    """找图纸上的场地框：先找标尺寸的蓝色长箭头线（横的一根、竖的一根），两头就是场地边；
    再贴到旁边灰色的场地边线上。返回原图像素 (左, 上, 右, 下)，找不到返回 None"""
    W0 = 2000
    work = img.scaledToWidth(W0) if img.width() > W0 else img
    k = img.width() / work.width()
    work = work.convertToFormat(QImage.Format_RGB888)
    w, h, bpl = work.width(), work.height(), work.bytesPerLine()
    data = bytes(work.constBits())
    blue_r, blue_c = [[] for _ in range(h)], [[] for _ in range(w)]
    grey_r, grey_c = [0]*h, [0]*w
    for y in range(h):
        row = data[y*bpl:y*bpl + w*3]
        for x in range(w):
            r, g, b = row[3*x], row[3*x+1], row[3*x+2]
            if b > 130 and r < 100 and 60 < g < 160 and b - r > 60:
                blue_r[y].append(x)
                blue_c[x].append(y)
            elif 150 < r < 232 and abs(r-g) < 14 and abs(g-b) < 14:
                grey_r[y] += 1
                grey_c[x] += 1

    def run(vals, gap=6):
        """一串坐标里最长的一段（中间断开不超过 gap）"""
        best, cur = (0, 0, 0), None
        for v in sorted(vals):
            if cur and v - cur[1] <= gap:
                cur = (cur[0], v)
            else:
                cur = (v, v)
            if cur[1] - cur[0] > best[2]:
                best = (cur[0], cur[1], cur[1]-cur[0])
        return best

    gx, gy = max(6, w//14), max(6, h//14)        # 线中间写着「85m」断开一截，也算一根
    hy = max(range(h), key=lambda y: run(blue_r[y], gx)[2])
    vx = max(range(w), key=lambda x: run(blue_c[x], gy)[2])
    x0, x1, lx = run(blue_r[hy], gx)
    y0, y1, ly = run(blue_c[vx], gy)
    if lx < w*0.25 or ly < h*0.25:               # 没有蓝色尺寸线：用最长的几根灰色线
        top = max(grey_r)
        rows = [y for y in range(h) if grey_r[y] > top*0.45]
        topc = max(grey_c)
        cols = [x for x in range(w) if grey_c[x] > topc*0.45]
        if len(rows) < 2 or len(cols) < 2:
            return None
        x0, x1, y0, y1 = cols[0], cols[-1], rows[0], rows[-1]
    else:
        def snap(v, prof, lim):                  # 贴到附近最明显的灰色边线
            cand = [(prof[i], i) for i in range(max(0, v-6), min(lim, v+7))]
            best = max(cand)
            return best[1] if best[0] > max(prof)*0.3 else v
        x0, x1 = snap(x0, grey_c, w), snap(x1, grey_c, w)
        y0, y1 = snap(y0, grey_r, h), snap(y1, grey_r, h)
    if x1 - x0 < w*0.2 or y1 - y0 < h*0.2:
        return None
    return int(x0*k), int(y0*k), int((x1+1)*k), int((y1+1)*k)


def _mask(img: QImage, test):
    img = img.convertToFormat(QImage.Format_RGB888)
    w, h, bpl = img.width(), img.height(), img.bytesPerLine()
    data = bytes(img.constBits())
    px = set()
    for y in range(h):
        row = data[y*bpl:y*bpl + w*3]
        for x in range(w):
            if test(row[3*x], row[3*x+1], row[3*x+2]):
                px.add((x, y))
    return px


def _blobs(px):
    """8 邻接连成块"""
    left = set(px)
    out = []
    while left:
        s = left.pop()
        grp, todo = [s], [s]
        while todo:
            x, y = todo.pop()
            for dx, dy in N8:
                q = (x+dx, y+dy)
                if q in left:
                    left.remove(q)
                    grp.append(q)
                    todo.append(q)
        out.append(grp)
    return out


def _holes(blob):
    """块里面围起来的空洞：[(面积, 中心x, 中心y)]"""
    xs = [p[0] for p in blob]
    ys = [p[1] for p in blob]
    x0, x1, y0, y1 = min(xs)-1, max(xs)+1, min(ys)-1, max(ys)+1
    solid = set(blob)
    seen = set()
    out = []
    for sy in range(y0, y1+1):
        for sx in range(x0, x1+1):
            if (sx, sy) in solid or (sx, sy) in seen:
                continue
            comp, todo, edge = [], [(sx, sy)], False
            seen.add((sx, sy))
            while todo:
                x, y = todo.pop()
                comp.append((x, y))
                if x in (x0, x1) or y in (y0, y1):
                    edge = True
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    q = (x+dx, y+dy)
                    if x0 <= q[0] <= x1 and y0 <= q[1] <= y1 and q not in solid and q not in seen:
                        seen.add(q)
                        todo.append(q)
            if not edge:
                out.append((len(comp), sum(c[0] for c in comp)/len(comp), sum(c[1] for c in comp)/len(comp)))
    return out


def is_navy(r, g, b):
    return r < 120 and g < 120 and b < 160 and b >= r - 5


def glyphs(img: QImage, px_per_m, memory=()):
    """图纸上的门符号（深蓝色）：[dict(kind, x, y 原图像素中心, w, h 米, fill, n 几块)]
    kind：单门 / 日字门 / 田字门 / 双连门 / 三连门 / 单重 / 双重 / 双层单门 / 计时门 / 起飞台 / ?"""
    ppm = 20.0
    k = px_per_m / ppm                           # 原图像素 / 工作像素
    work = img.scaledToWidth(max(50, int(img.width() / k)), Qt.SmoothTransformation)
    k = img.width() / work.width()
    navy = _mask(work, is_navy)
    blobs = [b for b in _blobs(navy) if len(b) >= 25]
    # 粉色线压断的几块并回一个：外框挨着（6 像素内）的算一个符号
    boxes = []
    for b in blobs:
        xs = [p[0] for p in b]
        ys = [p[1] for p in b]
        boxes.append([min(xs), min(ys), max(xs), max(ys), len(b), 1, [len(b)]])
    merged = True
    while merged:
        merged = False
        for i in range(len(boxes)):
            for j in range(i+1, len(boxes)):
                a, c = boxes[i], boxes[j]
                if a[0]-6 <= c[2] and c[0]-6 <= a[2] and a[1]-6 <= c[3] and c[1]-6 <= a[3]:
                    boxes[i] = [min(a[0], c[0]), min(a[1], c[1]), max(a[2], c[2]), max(a[3], c[3]),
                                a[4]+c[4], a[5]+c[5], a[6]+c[6]]
                    boxes.pop(j)
                    merged = True
                    break
            if merged:
                break
    out = []
    small = []
    for x0, y0, x1, y1, n, parts, sizes in boxes:
        w, h = (x1-x0+1)/ppm, (y1-y0+1)/ppm
        fill = n / ((x1-x0+1)*(y1-y0+1))
        if max(w, h) < 1.2 or min(w, h) < 0.6:  # 太小、细线（尺寸标注的短竖线）不是门
            continue
        if max(w, h) < 2.5:                      # 小符号（起飞台前面的 ^ 箭头）先记下
            small.append(((x0+x1+1)/2, y1, (x1-x0+1)/2))
            continue
        lo, hi = min(w, h), max(w, h)
        R = hi / lo
        if parts >= 4 and sum(1 for s in sizes if s < 150) >= 2:
            kind = '起飞台'
        elif fill >= 0.58 and h > w*1.5:
            kind = '双层单门'
        elif fill >= 0.45 and R < 1.3 and lo > 3.6:
            kind = '单重'
        elif fill >= 0.45 and h > w*1.5 and lo > 3.6:
            kind = '双重'
        elif w > h and 1.25 <= R < 1.6 and fill >= 0.4:
            kind = '计时门'
        elif R < 1.25 and lo > 5.2:
            kind = '田字门'
        elif w < h and R >= 2.4:
            kind = '单门'                         # 又瘦又高的平行四边形：斜着放的单门
        elif R < 1.45:
            kind = '单门'
        elif h > w:
            kind = '日字门'
        elif R < 2.4:
            kind = '双连门'
        else:
            kind = '三连门'
        for m in memory:                         # 学过的：这种符号操作者改成过别的，照改过的来
            if abs(m['w']-w) < 0.5 and abs(m['h']-h) < 0.5 and abs(m['fill']-fill) < 0.06:
                kind = m['kind']
                break
        out.append(dict(kind=kind, x=(x0+x1+1)/2*k, y=(y0+y1+1)/2*k, w=round(w, 2), h=round(h, 2),
                        fill=round(fill, 2), n=parts))
    if len(small) >= 2 and not any(g['kind'] == '起飞台' for g in out):   # 一串 ^ 箭头 = 起飞方向，起飞台在最下面那个后面
        best = []
        for a in small:                          # 竖着排成一串的小符号（左右差不到 1 米、上下挨着）
            col = sorted([q for q in small if abs(q[0]-a[0]) < ppm], key=lambda q: q[1])
            if len(col) > len(best) and all(col[i+1][1]-col[i][1] < 3*ppm for i in range(len(col)-1)):
                best = col
        if len(best) >= 2:
            xs = [q[0] for q in best]
            out.append(dict(kind='起飞台', x=sum(xs)/len(xs)*k, y=(best[-1][1] + 1.5*ppm)*k, w=2.0, h=2.0, fill=0, n=len(best)))
    return out
