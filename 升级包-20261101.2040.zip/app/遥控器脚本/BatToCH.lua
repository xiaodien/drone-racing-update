-- BatToCH: put the drone battery voltage (telemetry) on a free channel, so the
-- DroneRacing teaching software can tell when a new battery is plugged in.
-- Run once per model: SYS -> TOOLS -> BatToCH, with the drone battery plugged in.
-- It only adds one mix on an empty channel (CH8 first); nothing else is changed.
local toolName = "TNS|BatToCH|TNE"

local SENSORS = { "RxBt", "VBAT", "Bat", "A1" }
local state, lines = "start", {}
local src, sname, ch, weight, t0, volts

local function say(...)
  lines = { ... }
end

local function chOut()
  return getValue("ch" .. (ch + 1)) or 0
end

local function mixWith(w, off)
  -- remove our previous try, then add the mix again with the new numbers
  local n = model.getMixesCount(ch)
  for i = n - 1, 0, -1 do
    local m = model.getMix(ch, i)
    if m and m.name == "BAT" then model.deleteMix(ch, i) end
  end
  model.insertMix(ch, 0, { name = "BAT", source = src, weight = w, offset = off })
  weight, t0 = w, getTime()
end

local function findSensor()
  for _, n in ipairs(SENSORS) do
    local fi = getFieldInfo(n)
    if fi then return fi.id, n end
  end
end

local function alreadyDone()
  for c = 0, 15 do
    for i = 0, model.getMixesCount(c) - 1 do
      local m = model.getMix(c, i)
      if m and m.source == src then return c end
    end
  end
end

local function freeChannel()
  if model.getMixesCount(7) == 0 then return 7 end
  for c = 5, 15 do
    if model.getMixesCount(c) == 0 then return c end
  end
end

local function start()
  src, sname = findSensor()
  if not src then
    say("No battery sensor yet.", "Plug in the drone battery,", "wait for telemetry, then", "run BatToCH again.")
    return "done"
  end
  volts = getValue(src) or 0
  if volts < 2 then
    say("Battery sensor " .. sname .. " = " .. volts, "Plug in the drone battery", "and run BatToCH again.")
    return "done"
  end
  local c = alreadyDone()
  if c then
    say("Already set up:", "CH" .. (c + 1) .. " = " .. sname, "Nothing changed.")
    return "done"
  end
  ch = freeChannel()
  if not ch then
    say("No empty channel CH6-CH16.", "Nothing changed.")
    return "done"
  end
  say("Measuring " .. sname .. " ...")
  mixWith(100, 0)
  return "measure"
end

-- Output of the mix is k * volts * weight / 100 (in -1024..1024). Find k, then pick
-- weight/offset so 3.3 .. 4.35 V per cell spans most of the channel without hitting the end.
local function measure()
  if getTime() - t0 < 50 then return "measure" end
  local out = chOut()
  if math.abs(out) >= 1000 and weight > 1 then
    mixWith(math.max(1, math.floor(weight / 10)), 0)
    return "measure"
  end
  if out == 0 then
    say("Mix output stays 0.", "Remove mix 'BAT' on CH" .. (ch + 1), "and set it by hand.")
    return "done"
  end
  local k = out / (volts * weight / 100)
  local cells = math.max(1, math.floor(volts / 4.4) + 1)
  local vlo, vhi = 3.3 * cells, 4.35 * cells
  local mid = (vlo + vhi) / 2
  local w = math.floor(1800 / (vhi - vlo) / k * 100)
  w = math.max(-500, math.min(500, w))
  local off
  while true do
    local kw = k * w / 100
    off = math.floor(-kw * mid / 1024 * 100 + 0.5)
    off = math.max(-100, math.min(100, off))
    local lo = kw * vlo + off * 1024 / 100
    local hi = kw * vhi + off * 1024 / 100
    if math.max(math.abs(lo), math.abs(hi)) <= 1000 or math.abs(w) <= 1 then break end
    w = (w > 0) and math.max(1, math.floor(w * 0.8)) or math.min(-1, math.ceil(w * 0.8))
  end
  mixWith(w, off)
  say("Checking ...")
  return "check"
end

local function check()
  if getTime() - t0 < 50 then return "check" end
  local out = chOut()
  local aux = ch + 1 - 4
  say("Done! CH" .. (ch + 1) .. " = " .. sname,
      "weight " .. weight .. "  now " .. math.floor(out / 10.24) .. "%",
      "Check Betaflight Modes:",
      "AUX" .. aux .. " must not be used.",
      "ELRS PC receiver: Wide mode.")
  return "done"
end

local function run(event)
  if event == EVT_VIRTUAL_EXIT then return 1 end
  if state == "start" then state = start()
  elseif state == "measure" then state = measure()
  elseif state == "check" then state = check() end
  lcd.clear()
  lcd.drawText(2, 2, "BatToCH", 0)
  for i, s in ipairs(lines) do
    lcd.drawText(2, 4 + i * 11, s, SMLSIZE)
  end
  if state == "done" then lcd.drawText(2, 4 + (#lines + 1) * 11, "RTN to exit", SMLSIZE) end
  return 0
end

return { run = run }
