"""上课时间和铃声：顶上显示日期、时间、星期几；预设上午上课、中午下课、下午上课、下午下课，到点响铃；
另外一行「老师接管时间」随便填（10:30、10:30-10:45 都行，用逗号或空格隔开），到点也响。"""
import re
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import Qt, QTime, QTimer, QUrl, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout,
                               QHBoxLayout, QLabel, QLineEdit, QPushButton, QSlider, QTimeEdit, QVBoxLayout, QWidget)

BELL_DIR = Path(__file__).resolve().parent / "铃声"
WEEK = "一二三四五六日"
SLOTS = [("am_in", "上午上课", "08:30"), ("am_out", "中午下课", "11:30"),
         ("pm_in", "下午上课", "13:30"), ("pm_out", "下午下课", "17:00")]
DEFAULT = dict(on=True, days=[0, 1, 2, 3, 4, 5, 6], bell="上课铃.wav", out_bell="下课铃.wav", volume=80,
               takeover="", takeover_bell="叮咚.wav",
               **{k: dict(on=True, t=t) for k, _n, t in SLOTS})


def builtin_bells():
    return sorted(p.name for p in BELL_DIR.glob("*.wav")) if BELL_DIR.is_dir() else []


def bell_path(name):
    if not name:
        return None
    p = Path(name)
    if not p.is_absolute():
        p = BELL_DIR / name
    return p if p.exists() else None


def parse_takeover(text):
    """「10:30, 15:00-15:20」-> [(开始, 结束或 None)]，时间都是 'HH:MM'；看不懂的跳过"""
    out = []
    for tok in re.split(r"[,，;；、\s]+", text or ""):
        m = re.fullmatch(r"(\d{1,2})[:：点](\d{2})?(?:\s*[-~～到至]\s*(\d{1,2})[:：点](\d{2})?)?", tok.strip())
        if not m:
            continue
        a = f"{int(m.group(1)):02d}:{int(m.group(2) or 0):02d}"
        b = f"{int(m.group(3)):02d}:{int(m.group(4) or 0):02d}" if m.group(3) else None
        if a <= "23:59" and (b is None or b <= "23:59"):
            out.append((a, b))
    return out


def events(cfg):
    """今天要响铃的点：[(HH:MM, 名字, 铃声)]，按时间排好"""
    cfg = {**DEFAULT, **(cfg or {})}
    ev = []
    for k, name, _t in SLOTS:
        s = cfg.get(k) or {}
        if s.get("on"):
            ev.append((s.get("t", "00:00"), name, cfg["bell"] if k.endswith("_in") else cfg["out_bell"]))
    for a, b in parse_takeover(cfg.get("takeover")):
        ev.append((a, "老师接管", cfg["takeover_bell"]))
        if b:
            ev.append((b, "老师接管结束", cfg["takeover_bell"]))
    return sorted(ev)


class Bell:
    """放铃声（Qt 多媒体，wav/mp3 都行）"""

    def __init__(self):
        self.player = None

    def play(self, name, volume=80):
        p = bell_path(name)
        if p is None:
            return False
        try:
            from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
        except ImportError:
            return False
        if self.player is None:
            self.player = QMediaPlayer()
            self.out = QAudioOutput()
            self.player.setAudioOutput(self.out)
        self.player.stop()
        self.out.setVolume(max(0, min(100, volume)) / 100)
        self.player.setSource(QUrl.fromLocalFile(str(p)))
        self.player.play()
        return True


class ClassClock(QPushButton):
    """顶上的时钟：日期 时间 星期几 + 下一次铃；点一下设上课时间和铃声"""
    rang = Signal(str)

    def __init__(self, settings, parent=None, ring=True):
        super().__init__(parent)
        self.s = settings
        self.ring = ring                        # 同时开着两个时钟（首页、训练页）只让一个响铃
        self.bell = Bell()
        self._fired = None
        self.setFlat(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("点一下设上课时间、下课时间、老师接管时间和铃声")
        self.setStyleSheet("QPushButton { font-size: 15px; font-weight: bold; color: #007aff; padding: 4px 14px;"
                           " text-align: left; border: 1px solid #d6e6fb; border-radius: 10px; background: #eef5ff; }"
                           "QPushButton:hover { background: #e2eeff; }")
        self.clicked.connect(self.edit)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(1000)
        self.tick()

    @property
    def cfg(self):
        return {**DEFAULT, **(self.s.data.get("schedule") or {})}

    def tick(self):
        now = datetime.now()
        hm = now.strftime("%H:%M")
        cfg = self.cfg
        today = cfg["on"] and now.weekday() in cfg["days"]
        ev = events(cfg) if today else []
        nxt = next((e for e in ev if e[0] > hm), None)
        tail = ""
        for a, b in parse_takeover(cfg.get("takeover")) if today else []:
            if b and a <= hm < b:
                tail = f"   老师接管中（到 {b}）"
                break
        if not tail and nxt:
            tail = f"   下一个：{nxt[1]} {nxt[0]}"
        if not tail:
            tail = "   ✎ 上课时间" if cfg["on"] else "   ✎ 未上课"   # 让人一眼看出这里能点
        self.setText(now.strftime("%Y-%m-%d  ") + f"星期{WEEK[now.weekday()]}  " + now.strftime("%H:%M:%S") + tail)
        key = now.strftime("%Y-%m-%d ") + hm
        if self._fired != key:
            hit = [e for e in ev if e[0] == hm]
            if hit and now.second < 5 and self.ring:          # 到点那一分钟开头响一次（程序这一分钟中间才打开就不补响）
                self._fired = key
                self.bell.play(hit[0][2], cfg["volume"])
                self.rang.emit(f"{hit[0][1]}（{hm}）")

    def edit(self, _=None, dialog=None):
        dlg = (dialog or ScheduleDialog)(self.cfg, self.bell, self.window())
        if dlg.exec():
            self.s.data["schedule"] = dlg.result()
            self.s.save()
            self.tick()

    def edit_takeover(self):
        self.edit(dialog=TakeoverDialog)


class ScheduleDialog(QDialog):
    def __init__(self, cfg, bell, parent=None):
        super().__init__(parent)
        self.setWindowTitle("上课时间和铃声")
        self.bell = bell
        self.on = QCheckBox("到点响铃")
        self.on.setChecked(cfg["on"])
        days = QHBoxLayout()
        self.days = []
        for k, d in enumerate(WEEK):
            c = QCheckBox("周" + d)
            c.setChecked(k in cfg["days"])
            days.addWidget(c)
            self.days.append(c)
        form = QFormLayout()
        form.addRow(self.on)
        form.addRow("哪几天", days)
        self.slots = {}
        for k, name, _t in SLOTS:
            s = cfg.get(k) or {}
            c = QCheckBox(name)
            c.setChecked(bool(s.get("on")))
            te = QTimeEdit(QTime.fromString(s.get("t", "08:00"), "HH:mm"))
            te.setDisplayFormat("HH:mm")
            self.slots[k] = (c, te)
            form.addRow(c, te)
        self.cfg = cfg
        self.bell_in = self._bell_box(cfg["bell"])
        self.bell_out = self._bell_box(cfg["out_bell"])
        form.addRow("上课铃声", self._bell_row(self.bell_in))
        form.addRow("下课铃声", self._bell_row(self.bell_out))
        self.vol = QSlider(Qt.Horizontal)
        self.vol.setRange(0, 100)
        self.vol.setValue(int(cfg["volume"]))
        form.addRow("音量", self.vol)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(bb)

    def _bell_box(self, cur):
        box = QComboBox()
        for n in builtin_bells():
            box.addItem(Path(n).stem, n)
        if cur and box.findData(cur) < 0:
            box.addItem(Path(cur).name, cur)
        box.addItem("自己选文件…", "")
        box.setCurrentIndex(max(0, box.findData(cur)))
        box.activated.connect(lambda _i, b=box: self._maybe_pick(b))
        return box

    def _maybe_pick(self, box):
        if box.currentData():
            return
        f, _ = QFileDialog.getOpenFileName(self, "选铃声", "", "声音 (*.wav *.mp3 *.m4a *.wma)")
        if f:
            box.insertItem(box.count()-1, Path(f).name, f)
            box.setCurrentIndex(box.count()-2)
        else:
            box.setCurrentIndex(0)

    def _bell_row(self, box):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.addWidget(box, 1)
        t = QPushButton("试听")
        t.clicked.connect(lambda: self.bell.play(box.currentData(), self.vol.value()))
        h.addWidget(t)
        return w

    def result(self):
        r = dict(self.cfg, on=self.on.isChecked(), days=[k for k, c in enumerate(self.days) if c.isChecked()],
                 bell=self.bell_in.currentData() or "", out_bell=self.bell_out.currentData() or "",
                 volume=self.vol.value())
        for k, (c, te) in self.slots.items():
            r[k] = dict(on=c.isChecked(), t=te.time().toString("HH:mm"))
        return r


class TakeoverDialog(QDialog):
    """老师接管时间：单独一个窗口（训练模式「上课铃声」旁边的按钮）"""

    def __init__(self, cfg, bell, parent=None):
        super().__init__(parent)
        self.setWindowTitle("老师接管时间")
        self.setMinimumWidth(460)
        self.cfg, self.bell = cfg, bell
        self.takeover = QLineEdit(cfg.get("takeover", ""))
        self.takeover.setPlaceholderText("随便填，比如：10:00-10:20, 15:30, 16:00-16:30")
        self.take_hint = QLabel()
        self.take_hint.setWordWrap(True)
        self.take_hint.setStyleSheet("color: gray;")
        self.takeover.textChanged.connect(self._take_changed)
        self.vol = QSlider(Qt.Horizontal)       # 试听用，音量跟上课铃共用一个
        self.vol.setRange(0, 100)
        self.vol.setValue(int(cfg["volume"]))
        self.vol.hide()
        self.bell_take = self._bell_box(cfg["takeover_bell"])
        form = QFormLayout()
        form.addRow("老师接管时间", self.takeover)
        form.addRow("", self.take_hint)
        form.addRow("接管铃声", self._bell_row(self.bell_take))
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        clear = bb.addButton("清空", QDialogButtonBox.ResetRole)
        clear.clicked.connect(self.takeover.clear)
        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(bb)
        self._take_changed()

    _bell_box = ScheduleDialog._bell_box
    _maybe_pick = ScheduleDialog._maybe_pick
    _bell_row = ScheduleDialog._bell_row

    def _take_changed(self):
        got = parse_takeover(self.takeover.text())
        self.take_hint.setText("会响：" + "，".join(a + (f" 到 {b}" if b else "") for a, b in got) if got
                               else "到这些时间响铃；可以写一个时间，也可以写一段（开始和结束各响一次），接管期间顶上显示「老师接管中」")

    def result(self):
        return dict(self.cfg, takeover=self.takeover.text().strip(), takeover_bell=self.bell_take.currentData() or "")
