"""「电池记录」窗口：一节课的时间轴（每块电池一个颜色、炸机红点）、几个大数字、进步趋势、全班对比。
数据和判断都在 battery.py，这里只管画和让老师改。"""
from datetime import datetime, timedelta

from PySide6.QtCore import QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPen, QPolygonF
from PySide6.QtCore import QPointF
from PySide6.QtWidgets import (QAbstractItemView, QComboBox, QDialog, QDoubleSpinBox, QFrame, QGridLayout,
                               QHBoxLayout, QHeaderView, QLabel, QMenu, QPushButton, QTableWidget,
                               QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget)

from app import battery as B

BAT_COLORS = ["#007aff", "#34c759", "#ff9500", "#af52de", "#5ac8fa", "#ffcc00", "#ff2d55", "#64d2a5"]
RED = "#ff3b30"
SUB = "#6e6e73"
LINE = "#d2d2d7"


def _bat_color(n):
    return QColor(BAT_COLORS[(n - 1) % len(BAT_COLORS)])


def _hm(ts):
    return datetime.fromtimestamp(ts).strftime("%H:%M:%S")


# ---- 一节课时间轴 -------------------------------------------------------------
class Timeline(QWidget):
    """一个钟头一行，横着 60 分钟。飞行是色块（同一块电池同一个颜色），炸机是红色倒三角，空白就是没在飞。"""
    picked = Signal(float)          # 点了哪次飞行（start）

    ROW_H, LEFT, RIGHT, TOP = 46, 64, 16, 22

    def __init__(self):
        super().__init__()
        self.flights = []
        self.hours = []
        self.selected = None
        self.setMinimumHeight(self.TOP + self.ROW_H + 10)
        self.setMouseTracking(True)

    def set_flights(self, flights):
        self.flights = flights
        hrs = set()
        for f in flights:
            h = datetime.fromtimestamp(f["start"]).replace(minute=0, second=0, microsecond=0)
            while h.timestamp() < f["end"]:
                hrs.add(h)
                h += timedelta(hours=1)
        self.hours = sorted(hrs)
        self.setMinimumHeight(self.TOP + self.ROW_H * max(1, len(self.hours)) + 10)
        self.update()

    def _x(self, frac):
        return self.LEFT + frac * (self.width() - self.LEFT - self.RIGHT)

    def _blocks(self):
        """(rect, flight)，跨钟头的飞行拆成两段"""
        out = []
        for row, h in enumerate(self.hours):
            h0 = h.timestamp()
            y = self.TOP + row * self.ROW_H + 8
            for f in self.flights:
                a, b = max(f["start"], h0), min(f["end"], h0 + 3600)
                if b <= a:
                    continue
                x0, x1 = self._x((a - h0) / 3600), self._x((b - h0) / 3600)
                out.append((QRectF(x0, y, max(3.0, x1 - x0), self.ROW_H - 22), f, f["end"] <= h0 + 3600))
        return out

    def mousePressEvent(self, e):
        for r, f, _ in self._blocks():
            if r.adjusted(-3, -4, 3, 4).contains(e.position()):
                self.selected = f["start"]
                self.picked.emit(f["start"])
                self.update()
                return

    def mouseMoveEvent(self, e):
        for r, f, _ in self._blocks():
            if r.adjusted(-3, -4, 3, 4).contains(e.position()):
                tip = (f"第 {f['battery']} 块电池  {_hm(f['start'])}–{_hm(f['end'])}  飞 {B.fmt_s(f['end'] - f['start'])}"
                       + ("\n炸机：" + "、".join(f.get("reasons", [])) if f.get("is_crash") else ""))
                self.setToolTip(tip)
                return
        self.setToolTip("")

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor("#ffffff"))
        small = QFont(self.font())
        small.setPointSizeF(max(7.5, small.pointSizeF() - 1))
        p.setFont(small)
        if not self.hours:
            p.setPen(QColor(SUB))
            p.drawText(self.rect(), Qt.AlignCenter, "这一天还没有飞行记录。\n在训练模式里解锁飞一次，锁桨后就会记到这里（不用录像）。")
            return
        p.setPen(QColor(SUB))
        for m in range(0, 61, 10):
            x = self._x(m / 60)
            p.drawText(QRectF(x - 20, 2, 40, 16), Qt.AlignCenter, f"{m}分")
        for row, h in enumerate(self.hours):
            y = self.TOP + row * self.ROW_H
            p.setPen(QColor(SUB))
            p.drawText(QRectF(0, y + 8, self.LEFT - 8, self.ROW_H - 22), Qt.AlignRight | Qt.AlignVCenter,
                       h.strftime("%H:00"))
            p.setPen(Qt.NoPen)
            p.setBrush(QColor("#f2f2f5"))
            p.drawRoundedRect(QRectF(self.LEFT, y + 8, self.width() - self.LEFT - self.RIGHT, self.ROW_H - 22), 5, 5)
            p.setPen(QPen(QColor(LINE), 1, Qt.DotLine))
            for m in range(10, 60, 10):
                x = self._x(m / 60)
                p.drawLine(QPointF(x, y + 8), QPointF(x, y + self.ROW_H - 14))
        seen = set()
        for r, f, ends_here in self._blocks():
            c = _bat_color(f["battery"])
            p.setPen(QPen(QColor("#1d1d1f"), 2) if f["start"] == self.selected else Qt.NoPen)
            p.setBrush(c)
            p.drawRoundedRect(r, 3, 3)
            if f["battery"] not in seen:
                seen.add(f["battery"])
                p.setPen(c.darker(130))
                p.drawText(QRectF(r.left(), r.bottom() + 1, 60, 13), Qt.AlignLeft | Qt.AlignTop, f"电池{f['battery']}")
            if f.get("is_crash") and ends_here:
                x, y = r.right(), r.top() - 1
                p.setPen(Qt.NoPen)
                p.setBrush(QColor(RED))
                p.drawPolygon(QPolygonF([QPointF(x - 6, y - 8), QPointF(x + 6, y - 8), QPointF(x, y + 2)]))


# ---- 进步趋势 -----------------------------------------------------------------
class TrendChart(QWidget):
    """每天一根柱子：折合每小时几块电池（蓝）；红线：每块电池炸几次。"""

    def __init__(self):
        super().__init__()
        self.rows = []      # [(day, summary)]
        self.setMinimumHeight(240)

    def set_rows(self, rows):
        self.rows = rows
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor("#ffffff"))
        L, R, T, Bm = 48, 48, 30, 36
        w, h = self.width() - L - R, self.height() - T - Bm
        rows = self.rows
        if not rows:
            p.setPen(QColor(SUB))
            p.drawText(self.rect(), Qt.AlignCenter, "飞过几天以后，这里会画出每天的训练量和炸机率。")
            return
        vals = [s["per_hour"] if s["per_hour"] is not None else s["batteries"] for _, s in rows]
        vmax = max(4.0, max(vals) * 1.15)
        cmax = max(1.0, max((s["crash_per_battery"] or 0) for _, s in rows) * 1.15)
        n = len(rows)
        slot = w / n
        bw = min(38.0, slot * 0.6)
        p.setPen(QPen(QColor(LINE), 1))
        for k in range(5):
            y = T + h - h * k / 4
            p.drawLine(QPointF(L, y), QPointF(L + w, y))
            p.setPen(QColor("#007aff"))
            p.drawText(QRectF(0, y - 8, L - 6, 16), Qt.AlignRight | Qt.AlignVCenter, f"{vmax * k / 4:.1f}")
            p.setPen(QColor(RED))
            p.drawText(QRectF(L + w + 6, y - 8, R - 6, 16), Qt.AlignLeft | Qt.AlignVCenter, f"{cmax * k / 4:.1f}")
            p.setPen(QPen(QColor(LINE), 1))
        pts = []
        for i, ((day, s), v) in enumerate(zip(rows, vals)):
            cx = L + slot * (i + 0.5)
            bh = h * v / vmax
            p.setPen(Qt.NoPen)
            p.setBrush(QColor("#007aff") if s["per_hour"] is not None else QColor("#9ec9ff"))
            p.drawRoundedRect(QRectF(cx - bw / 2, T + h - bh, bw, bh), 3, 3)
            p.setPen(QColor("#1d1d1f"))
            p.drawText(QRectF(cx - 30, T + h - bh - 16, 60, 14), Qt.AlignCenter, f"{v:.1f}")
            p.setPen(QColor(SUB))
            p.drawText(QRectF(cx - slot / 2, T + h + 4, slot, 14), Qt.AlignCenter, day[5:])
            pts.append(QPointF(cx, T + h - h * (s["crash_per_battery"] or 0) / cmax))
        p.setPen(QPen(QColor(RED), 2))
        p.setBrush(Qt.NoBrush)
        if len(pts) > 1:
            p.drawPolyline(QPolygonF(pts))
        p.setBrush(QColor(RED))
        for q in pts:
            p.drawEllipse(q, 3.5, 3.5)
        p.setPen(QColor(SUB))
        p.drawText(QRectF(L, 4, w, 18), Qt.AlignLeft,
                   "蓝柱：折合每小时几块电池（浅蓝 = 飞不到 15 分钟，显示的是块数）    红线：每块电池炸几次")


class _NumItem(QTableWidgetItem):
    """全班对比按数字排序（不是按文字）"""

    def __lt__(self, other):
        a, b = self.data(Qt.UserRole), other.data(Qt.UserRole)
        if isinstance(a, (int, float)) and isinstance(b, (int, float)):
            return a < b
        return str(a) < str(b)


# ---- 窗口 -------------------------------------------------------------------
def _tile(title):
    box = QFrame()
    box.setStyleSheet("QFrame { background: #ffffff; border-radius: 10px; }")
    lay = QVBoxLayout(box)
    lay.setContentsMargins(12, 8, 12, 8)
    t = QLabel(title)
    t.setStyleSheet(f"color: {SUB}; background: transparent;")
    v = QLabel("—")
    v.setStyleSheet("font-size: 22px; font-weight: bold; background: transparent;")
    sub = QLabel("")
    sub.setStyleSheet(f"color: {SUB}; background: transparent;")
    for w in (t, v, sub):
        lay.addWidget(w)
    return box, v, sub


class BatteryDialog(QDialog):
    def __init__(self, log: B.TrainingLog, students: list, current: str, parent=None, on_gap=None,
                 volt_status=None, volt_reset=None):
        super().__init__(parent)
        self.setWindowTitle("电池记录")
        self.resize(1100, 760)
        self.log, self.on_gap = log, on_gap
        self.volt_status, self.volt_reset = volt_status, volt_reset
        root = log.root_fn()
        names = list(dict.fromkeys(list(students) + B.pilots_of(root)))
        self.student = QComboBox()
        self.student.addItems(names or [current or "未选学员"])
        if current in names:
            self.student.setCurrentText(current)
        self.day = QComboBox()
        self.gap = QDoubleSpinBox()
        self.gap.setRange(20, 600)
        self.gap.setDecimals(0)
        self.gap.setSuffix(" 秒")
        self.gap.setValue(log.gap_s)
        self.gap.setToolTip("锁桨后隔这么久才再解锁，就算换了一块电池。换电池特别快的话调小一点。")
        self.gap.valueChanged.connect(self._gap_changed)

        top = QHBoxLayout()
        top.addWidget(QLabel("学员"))
        top.addWidget(self.student)
        top.addWidget(QLabel("日期"))
        top.addWidget(self.day)
        top.addStretch()
        top.addWidget(QLabel("锁桨超过"))
        top.addWidget(self.gap)
        top.addWidget(QLabel("再解锁算换电池"))

        tiles = QGridLayout()
        self.t = {}
        for i, (k, title) in enumerate((("bat", "用了几块电池"), ("rate", "折合每小时"), ("fly", "纯飞行时间"),
                                        ("each", "平均每块飞"), ("swap", "平均换电池"), ("crash", "炸机"))):
            box, v, sub = _tile(title)
            self.t[k] = (v, sub)
            tiles.addWidget(box, 0, i)

        self.timeline = Timeline()
        self.timeline.picked.connect(self._select_flight)
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["解锁", "锁桨", "电池", "飞了", "炸机", "为什么这么判断"])
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._menu)
        hint = QLabel("右键一次飞行可以改：算炸机 / 不算炸机 / 从这次起换了新电池 / 和上一次是同一块电池 / 删掉（误记）。改过的以你为准。")
        hint.setStyleSheet(f"color: {SUB};")
        hint.setWordWrap(True)
        day_page = QWidget()
        dl = QVBoxLayout(day_page)
        dl.addWidget(self.timeline)
        dl.addWidget(hint)
        dl.addWidget(self.table, 1)

        self.trend = TrendChart()
        trend_page = QWidget()
        tl = QVBoxLayout(trend_page)
        tl.addWidget(self.trend, 1)

        self.cls = QTableWidget(0, 7)
        self.cls.setHorizontalHeaderLabels(["学员", "电池", "折合每小时", "纯飞行", "平均每块飞", "炸机", "每块电池炸几次"])
        self.cls.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.cls.verticalHeader().setVisible(False)
        self.cls.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.cls.setSortingEnabled(True)

        self.tabs = QTabWidget()
        self.tabs.addTab(day_page, "这一天")
        self.tabs.addTab(trend_page, "进步趋势")
        self.tabs.addTab(self.cls, "全班对比")

        self.volt_label = QLabel()
        self.volt_label.setWordWrap(True)
        how = QPushButton("怎么设")
        how.clicked.connect(self._show_guide)
        again = QPushButton("重新找")
        again.setToolTip("换了电压通道，或者找错了：清掉，下次飞的时候重新找")
        again.clicked.connect(self._volt_again)
        vrow = QHBoxLayout()
        vrow.addWidget(self.volt_label, 1)
        vrow.addWidget(how)
        vrow.addWidget(again)
        from PySide6.QtCore import QTimer
        self._vt = QTimer(self, interval=1000, timeout=self._volt_tick)
        self._vt.start()
        self._volt_tick()

        lay = QVBoxLayout(self)
        lay.addLayout(top)
        lay.addLayout(vrow)
        lay.addLayout(tiles)
        lay.addWidget(self.tabs, 1)
        close = QPushButton("关闭")
        close.clicked.connect(self.accept)
        row = QHBoxLayout()
        note = QLabel("不录像也会记：训练模式里遥控器连着，每次解锁到锁桨就是一次飞行。炸机是看打杆猜的，不一定准，可以右键改。")
        note.setStyleSheet(f"color: {SUB};")
        row.addWidget(note, 1)
        row.addWidget(close)
        lay.addLayout(row)

        self.student.currentTextChanged.connect(self._fill_days)
        self.day.currentTextChanged.connect(self._refresh)
        self._fill_days()

    # ---- 飞机电压 ----
    def _volt_tick(self):
        self.volt_label.setText(self.volt_status() if self.volt_status else "飞机电压：没用")

    def _show_guide(self):
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(self, "用飞机电压判断换电池", B.VOLT_GUIDE)

    def _volt_again(self):
        if self.volt_reset:
            self.volt_reset()
        self._volt_tick()

    # ---- 数据 ----
    def _pilot(self):
        return self.student.currentText()

    def _fill_days(self):
        days = B.days_of(self.log.root_fn(), self._pilot())
        today = datetime.now().strftime("%Y-%m-%d")
        if today not in days:
            days.insert(0, today)
        self.day.blockSignals(True)
        self.day.clear()
        self.day.addItems(days)
        self.day.blockSignals(False)
        self._refresh()

    def _gap_changed(self, v):
        self.log.set_gap(float(v))
        if self.on_gap:
            self.on_gap(float(v))
        self._refresh()

    def _refresh(self):
        pilot, day = self._pilot(), self.day.currentText()
        if not day:
            return
        fl = self.log.flights(pilot, day)
        s = B.summary(fl)
        self._set("bat", f"{s['batteries']} 块", f"{s['flights']} 次起飞")
        self._set("rate", f"{s['per_hour']:.1f} 块" if s["per_hour"] is not None else "—",
                  (f"{_hm(s['first'])[:5]}–{_hm(s['last'])[:5]}" if s["first"] else "")
                  + ("" if s["per_hour"] is not None else "（练满 15 分钟才折算）"))
        pct = f"占 {s['fly_s'] / s['span_s'] * 100:.0f}%" if s["span_s"] else ""
        self._set("fly", B.fmt_s(s["fly_s"]), pct + ("，其余是换电池和等待" if pct else ""))
        self._set("each", B.fmt_s(s["avg_battery_s"]), "")
        self._set("swap", B.fmt_s(s["avg_swap_s"]), "锁桨到下一块解锁")
        self._set("crash", f"{s['crashes']} 次",
                  (f"每块 {s['crash_per_battery']:.1f} 次 · 每10分钟 {s['crash_per_10min']:.1f} 次"
                   if s["crash_per_battery"] is not None else ""))
        self.timeline.set_flights(fl)
        self.table.setRowCount(len(fl))
        for i, f in enumerate(fl):
            crash = "是" if f["is_crash"] else ""
            if f.get("crash") is not None:
                crash = ("是" if f["crash"] else "否") + "（老师改）"
            bat = f"第 {f['battery']} 块"
            if f.get("new_battery") is not None:
                bat += "（老师改）"
            elif f.get("volt_new") is not None:
                bat += "（看电压）"
            if f.get("volt_pct_end") is not None:
                bat += f" 落地剩约 {f['volt_pct_end']}%"
            cells = [_hm(f["start"]), _hm(f["end"]), bat,
                     B.fmt_s(f["end"] - f["start"]), crash, "、".join(f.get("reasons", [])) + f"（{f['score']} 分）"]
            for c, text in enumerate(cells):
                it = QTableWidgetItem(text)
                it.setData(Qt.UserRole, f["start"])
                if c == 4 and f["is_crash"]:
                    it.setForeground(QColor(RED))
                if c == 2:
                    it.setForeground(_bat_color(f["battery"]).darker(120))
                self.table.setItem(i, c, it)
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.Stretch)
        self._trend(pilot)
        self._class(day)

    def _set(self, k, value, sub):
        self.t[k][0].setText(value)
        self.t[k][1].setText(sub)

    def _trend(self, pilot):
        days = sorted(B.days_of(self.log.root_fn(), pilot))[-20:]
        rows = [(d, B.summary(self.log.flights(pilot, d))) for d in days]
        self.trend.set_rows([r for r in rows if r[1]["flights"]])

    def _class(self, day):
        names = [self.student.itemText(i) for i in range(self.student.count())]
        rows = [(n, B.summary(self.log.flights(n, day))) for n in names]
        rows = [r for r in rows if r[1]["flights"]]
        self.cls.setSortingEnabled(False)
        self.cls.setRowCount(len(rows))
        for i, (n, s) in enumerate(rows):
            vals = [n, s["batteries"], s["per_hour"], s["fly_s"], s["avg_battery_s"], s["crashes"], s["crash_per_battery"]]
            texts = [n, f"{s['batteries']}", f"{s['per_hour']:.1f}" if s["per_hour"] is not None else "—",
                     B.fmt_s(s["fly_s"]), B.fmt_s(s["avg_battery_s"]), f"{s['crashes']}",
                     f"{s['crash_per_battery']:.2f}" if s["crash_per_battery"] is not None else "—"]
            for c, (v, t) in enumerate(zip(vals, texts)):
                it = _NumItem(t)
                it.setData(Qt.UserRole, v if v is not None else -1)
                self.cls.setItem(i, c, it)
        self.cls.setSortingEnabled(True)

    # ---- 老师改 ----
    def _select_flight(self, start):
        for i in range(self.table.rowCount()):
            if abs(self.table.item(i, 0).data(Qt.UserRole) - start) < 0.01:
                self.table.selectRow(i)
                self.table.scrollToItem(self.table.item(i, 0))
                return

    def _menu(self, pos):
        it = self.table.itemAt(pos)
        if not it:
            return
        start = it.data(Qt.UserRole)
        m = QMenu(self)
        acts = {m.addAction("算炸机"): dict(crash=True), m.addAction("不算炸机"): dict(crash=False),
                m.addAction("炸机交给软件判断"): dict(crash=None)}
        m.addSeparator()
        acts.update({m.addAction("从这次起换了新电池"): dict(new_battery=True),
                     m.addAction("和上一次是同一块电池"): dict(new_battery=False),
                     m.addAction("电池交给软件判断"): dict(new_battery=None)})
        m.addSeparator()
        acts[m.addAction("删掉这次（误记）")] = dict(delete=True)
        a = m.exec(self.table.viewport().mapToGlobal(pos))
        if a in acts:
            self.log.edit(self._pilot(), self.day.currentText(), start, **acts[a])
            self._refresh()
            self._select_flight(start)
